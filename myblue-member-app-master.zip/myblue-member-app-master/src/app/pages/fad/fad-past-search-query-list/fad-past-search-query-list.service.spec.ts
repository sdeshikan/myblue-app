import { TestBed, inject } from '@angular/core/testing';

import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('FadPastSearchQueryListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FadPastSearchQueryListService, BcbsmaHttpService]
    });
  });

  it('should be created', inject([FadPastSearchQueryListService], (service: FadPastSearchQueryListService) => {
    expect(service).toBeTruthy();
  }));
});
