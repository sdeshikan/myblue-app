import { Injectable } from '@angular/core';
import { FadCostBenefitsModel, FadFacilityCostModel } from '../modals/fad-facility-profile-details.model';
import { FadCostBenefitsInterface, FadFacilityCostInterface } from '../modals/interfaces/fad-facility-profile-details.interface';

@Injectable({
  providedIn: 'root'
})
export class FadCostBreakdownService {
  public costBenefitsData: FadCostBenefitsInterface = new FadCostBenefitsModel();
  public facilityCostData: FadFacilityCostInterface = new FadFacilityCostModel();
  public parentPage: string;
}
