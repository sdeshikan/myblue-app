import { animate, state, style, transition, trigger } from '@angular/animations';
import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
  ChangeDetectorRef,
  ViewEncapsulation
} from '@angular/core';
import { MatCalendar, MatRadioGroup, MatSelectionList, MatSelectionListChange, MatSidenav } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import moment from "moment";
import {  SubscriptionLike as ISubscription } from 'rxjs';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FilterItem } from '../../../shared/models/filterItem.model';
import { MemberInfo } from '../../../shared/models/memberInfo.model';
import { Option } from '../../../shared/models/option.model';
import { DependantsService } from '../../../shared/services/dependant.service';
import { FilterService } from '../../../shared/services/filter.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ClaimsService } from '../../../shared/services/myclaims/claims.service';
import { AuthService } from '../../../shared/shared.module';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { environment } from '../../../../environments/environment';
import { RadioList } from '../claims.model';
import { DependentsResponseModel } from '../models/dependants.model';
import { DependentsResponseModelInterface } from '../models/interfaces/dependants-model.interface';
import { ClaimMemberRecord } from '../models/claims-summary-data.model';
import {
  ClaimFiltersMetadataInterface,
  ClaimSummaryMetadataInterface,
  ClaimMemberRecordInterface,
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface
} from '../models/interfaces/claims-summary-data-model.interface';
import {
  ProviderMetaInterface,
  VisitTypeMetaInterface,
  MemberTypeMetaInterface,
  ClaimStatusMetaInterface,
  PlanSearchListInterface,
  ProviderSearchListInterface,
  MemberTypeSearchListInterface,
  VisitTypeSearchListInterface,
  ClaimStatusSearchListInterface,
  DateMetaInterface,
  DateSearchListInterface,
  CustomDateRangeMetaInterface
} from '../models/interfaces/claims-generic-models.interface';
import { DatePipe } from '@angular/common';
import { ClaimSummarySortOrderType } from '../models/types/claims.types';
import { PopoverController, Platform } from '@ionic/angular';
import { FilterClaimsComponent } from './filter-claims/filter-claims.component';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { File } from '@ionic-native/file/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { SsoService } from '../../sso/sso.service';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { SwrveService, SwrveEventNames } from '../../../shared/services/swrve.service';


@Component({
  templateUrl: './claims.page.html',
  styleUrls: ['./claims.page.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class ClaimsPage implements OnInit, OnDestroy {
  isUserStateActive: boolean;
  userString: 'User' = 'User';
  dependant: string;
  subscription: ISubscription;
  claimsListing;
  claims: ClaimMemberRecord[] = [];
  filteredClaims: ClaimMemberRecordInterface[] = ClaimMemberRecord[''];
  allClaims: ClaimMemberRecord[] = [];
  memberData: MemberInfo;
  sideNavHeight: string;
  sideNavStatus: string;
  noClaimsAvailable = false;
  dateList: DateSearchListInterface[] = [];
  showClose: boolean;
  showCalender: boolean;
  sortList: RadioList[] = [
    {
      value: 'Most Recent',
      checked: true
    },
    {
      value: 'Oldest First',
      checked: false
    }
  ];
  sortSelectedFilter: string;
  searchval: string;
  isautosearch: boolean; // TO CHECK -> Always false
  isDisplayMessage = false;
  isDisplayResults = false;
  medicationsMessage: string;
  issearchShowing: boolean; // TO CHECK -> are we using search feature
  isfilterShowing: boolean;
  // Filter options
  dateSelectedFilter: DateSearchListInterface;
  showDate: boolean;
  fromMinDate: Date;
  calendarMaxDate = new Date();
  currentSelectedDate: Date = null;
  isCustomDateRangeInValid = false;
  isSelectedDateInvalid = false;
  sideNavMode: string; // TO CHECK -> not using side nav using PopUP
  lastDate: Date; // TO CHECK -> Not being used
  fromDate: string;
  toDate: string = moment().format('L');
  autoCompleteSearchArray: string[] = []; // TO CHECK -> Not being used
  index: number; // TO CHECK -> Not being used
  isSidenavOpened: boolean; // TO CHECK -> not using side nav using PopUP
  ismobile: boolean; // To CHECK -> do we need this flag
  errorMessage: string; // TO CHECK -> Not being used
  collapsedHeight: string;
  collapsedSortHeight: string;
  expandedHeight: string;
  expandedSortHeight: string;
  mobileViewPort = 992; // To CHECK -> do we need this flag
  filterWidth: string; // TO CHECK -> Not being used
  isexpanded: boolean; // TO CHECK -> Not being used
  isSortExpanded: boolean;
  isFormDateSelected = true;
  dateFormat = 'MM/DD/YYYY';
  currentSortValue: string;

  // Filters List
  planList: PlanSearchListInterface[] = [];
  selectedPlanList: Object[];
  allPlansString = 'All Plans';

  // Filters List
  visitTypeList: VisitTypeSearchListInterface[] = [];
  selectedVisitTypeList: Object[];
  selectedMemberList: Object[];
  allVisitsString = 'All visits';

  providerList: ProviderSearchListInterface[] = [];
  selectedProviderList: Object[];
  allProvidersString = 'All Providers';

  allClaimsStatuesString = 'All statuses';
  claimsStatuses = this.getDefaultClaimsStatuses();
  claimsStatusList: ClaimStatusSearchListInterface[] = [];
  selectedClaimsList: Object[];
  allClaimsString = 'All Claims';
  membersList: MemberTypeSearchListInterface[] = [];
  dependentList: DependentsResponseModelInterface = new DependentsResponseModel();
  selectedSortString: string;
  myFocusTriggeringEventEmitter = new EventEmitter<boolean>();
  showClearLink = false;
  showResultsCount = false;
  searchString: string;
  bHasDependents = false;
  claimsInfo: any;
  public allClaimsFilterOptions;
  public isDisplayCustomDateRange = false;
  public recordsPerPage = 50;
  public checkFromDate: boolean;
  public checkToDate: boolean;
  public isDisplaySpinner = false;
  public isClearFilter = false;
  step = [];
  fpoTargetUrl = '';
  fpoTargetListingUrl = '';
  showFinancialLink = false;
  showHEQALGFinancialLink = false;
  ssoFinancialLink = '';
  ssoALGFinancialLink: String = '';
  ssoHEQFinancialLink: String = '';
  initialClaimsCount: number;
  private hasHEQ = false;
  private hasALG = false;

  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;
  @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;
  @ViewChild('matcalender') picker: MatCalendar<Date>;
  @ViewChild('fromDateInput') fromInputDate: ElementRef;
  @ViewChild('toDateInput') toInputDate: ElementRef;
  @ViewChild('searchInput') inputSearch: ElementRef;
  @ViewChild('memberFilter') memberFilter;
  @ViewChild('providerFilter') providerFilter;
  @ViewChild('visitTypeFilter') visitTypeFilter;
  @ViewChild('claimStatusFilter') claimStatusFilter;

  contactus = this.constants.contactus + this.authService.authToken.scopename;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }

  constructor(
    private claimService: ClaimsService,
    public authService: AuthService,
    private router: Router,
    private location: Location,
    public dependantsService: DependantsService,
    public filterService: FilterService,
    public globalService: GlobalService,
    private ssoService: SsoService,
    public constants: ConstantsService,
    private activatedRoute: ActivatedRoute,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef,
    private popoverController: PopoverController,
    private document: DocumentViewer,
    private file: File,
    private transfer: FileTransfer,
    private platform: Platform,
    // private iabOptions: InAppBrowserOptions,
    // private iabEvent: InAppBrowserEvent,
    private fileOpener: FileOpener,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {}

  private handleFinanceLinksInSideBar() {
    this.hasALG = this.authService.authToken ? this.authService.authToken.isALG === 'true' : false;
    this.hasHEQ = this.authService.authToken ? this.authService.authToken.isHEQ === 'true' : false;

    this.showHEQALGFinancialLink = false;
    this.showFinancialLink = false;
    if (this.hasALG) {
      if (this.hasHEQ) {
        // both are true - show 2 links
        this.showHEQALGFinancialLink = true;
        this.showFinancialLink = false;
      } else {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      }
    } else {
      if (this.hasHEQ) {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      } else {
        // both are false - show no links
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = false;
      }
    }

    // this.showFinancialLink = (hasALG || hasHEQ) ? true : false;
    this.ssoFinancialLink = this.hasHEQ ? 'sso/heathequity' : 'sso/alegeus';
  }

  openSSO(module?) {
    if (module === 'algOrHeq') {
      this.ssoService.openSSO(this.hasHEQ ? 'heq' : 'alg');
    } else {
      this.ssoService.openSSO(module);
    }
  }

  ngOnInit() {}
  ionViewWillEnter() {
    this.claimsInfo = [...this.activatedRoute.snapshot.data.claimsInfo];
    if (this.claimsInfo && this.claimsInfo[0] && this.claimsInfo[0].memberRecord) {
      this.initialClaimsCount = this.claimsInfo[0].memberRecord.length;
    }
    this.sortSelectedFilter = 'Most Recent';
    this.currentSortValue = this.sortSelectedFilter;
    this.isautosearch = false;
    this.isDisplayMessage = false;
    this.issearchShowing = false;
    this.showDate = false;
    this.sideNavMode = 'side';
    this.index = -1;
    this.isSidenavOpened = false;
    this.errorMessage = null;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '48px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isexpanded = false;
    this.sideNavHeight = '600';
    this.showCalender = false;
    this.searchString = '';
    this.isSortExpanded = false;
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.sideNavStatus = this.ismobile ? 'out' : 'in';
    this.dependentList = this.authService.getDependentsList();
    this.subscription = this.globalService.memberData$.subscribe(data => {
      this.memberData = data;
    });

    if (this.authService.fetchUserState() === 'Active') {
      this.isUserStateActive = true;
    } else {
      this.isUserStateActive = false;
    }
    // console.log(`isUserStateActive in myclaims - ${this.isUserStateActive}`);

    if (sessionStorage.getItem('claimsDepId')) {
      sessionStorage.removeItem('claimsDepId');
    }
    this.initAllClaimsFilterOptions();
    this.manageClaimsListing();
    this.handleFinanceLinksInSideBar();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyClaims);
  }

  formattedData(value: string) {
    // console.log('value = ' + value);
    value = value.substring(0, 11);
    return this.datePipe.transform(value, 'MM/dd/yyyy');
  }

  isSortOpened() {
    this.isSortExpanded = true;
  }

  isSortClosed() {
    this.isSortExpanded = false;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.alertService.clearError();
  }

  // filter Logic below
  toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    this.sideNavMode = window.innerWidth <= 992 ? 'over' : 'side';
  }

  closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  closeFilter() {
    if (this.ismobile) {
      this.sideNavStatus = 'out';
      this.isSidenavOpened = false;
    }
  }



  isOpened(value) {
    switch (value) {
      case 1:
        this.step[1] = 1;
        break;
      case 2:
        this.step[2] = 2;
        break;
      case 3:
        this.step[3] = 3;
        break;
      case 4:
        this.step[4] = 4;
        break;
      case 5:
        this.step[5] = 5;
        break;
      case 6:
        this.step[6] = 6;
        break;
      default:
        break;
    }
  }


  showClaimDetails(claim) {
    console.log('-- showClaimDetails -- Claims - claims detail clicked', this.swrveEventNames.AppClick_MyClaims_ViewClaim);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyClaims_ViewClaim);
    sessionStorage.setItem('claimId', claim.claimId);
    this.router.navigate(['/myClaims/claimdetails']);
  }

  validateFromDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.fromDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.fromDate ||
        this.fromDate.length !== 10 ||
        moment(this.fromDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }

    return this.isSelectedDateInvalid;
  }

  validateToDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.toDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.toDate ||
        moment(this.toDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
    return this.isSelectedDateInvalid;
  }

  validateCustomRange() {
    if (this.toDate && this.fromDate) {
      this.isCustomDateRangeInValid = moment(this.toDate).diff(moment(this.fromDate)) < 0;
    }
  }

  toDateChange(toDate) {
    this.validateCustomRange();
    this.validateToDate();
    if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
      this.showCalender = false;
    }
  }

  clearCustomDateRangeSelections() {
    this.toDate = moment().format('L');
    this.fromDate = null;
    this.fromMinDate = null;
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    this.isDisplayCustomDateRange = false;
  }

  clearSearchVal() {
    this.searchval = '';
    this.showClose = false;
    this.isautosearch = false;
    this.inputSearch.nativeElement.focus();
  }

  toggleCalender(selectedDateType: string) {
    const isControlChanged =
      (selectedDateType === 'to' && this.isFormDateSelected) || (selectedDateType === 'from' && !this.isFormDateSelected);
    this.isFormDateSelected = selectedDateType === 'from';
    this.currentSelectedDate = this.isFormDateSelected ? new Date(this.fromDate) : new Date(this.toDate);
    this.setCalendarMinimumDate();
    if (isControlChanged) {
      this.toggleCalendarDisplay();
    } else {
      this.showCalender = true;
    }
  }

  toggleCalendarDisplay() {
    this.showCalender = false;
    setTimeout(() => {
      this.showCalender = true;
      setTimeout(() => {
        if (this.isFormDateSelected) {
          this.fromInputDate.nativeElement.focus();
        } else {
          this.toInputDate.nativeElement.focus();
        }
      }, 1);
    }, 1);
  }

  getSelectedValue(date) {
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    if (this.isFormDateSelected) {
      this.fromDate = this.filterService.getFormatDateString(date);
    } else {
      this.toDate = this.filterService.getFormatDateString(date);
    }
    this.setCalendarMinimumDate();
    this.showCalender = false;
  }

  setCalendarMinimumDate() {
    if (!this.isFormDateSelected && this.fromDate) {
      this.fromMinDate = new Date(this.fromDate);
    } else {
      const minFormDate = this.filterService.getMinimumFromDate();
      this.fromMinDate = minFormDate;
    }
  }

  formatInputFromDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.fromDate = dateString;
    }
    if (this.fromDate.length >= 10) {
      this.validateFromDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.fromDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  formatInputToDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.toDate = dateString;
    }
    if (this.toDate.length >= 10) {
      this.validateToDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.toDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  customDateInputKeyDownEvent(e) {
    return this.filterService.customDateInputKeyDownEvent(e);
  }

  getDefaultClaimsStatusList() {
    return this.claimsStatuses.map(statusItem => {
      return FilterItem.getDefaultFilterItem(statusItem.value, statusItem.label);
    });
  }

  getDefaultPlanList() {
    return [
      FilterItem.getDefaultFilterItem('Plan 1'),
      FilterItem.getDefaultFilterItem('Plan 2'),
      FilterItem.getDefaultFilterItem('Plan 3'),
      FilterItem.getDefaultFilterItem('Plan 4'),
      FilterItem.getDefaultFilterItem('Plan 5'),
      FilterItem.getDefaultFilterItem('All Plans')
    ];
  }

  getDefaultClaimsStatuses() {
    return [
      Option.getOption('Pending', 'Pending'),
      Option.getOption('Adjusted', 'Adjusted'),
      Option.getOption('Completed', 'Completed'),
      Option.getOption('Denied', 'Denied'),
      Option.getOption(this.allClaimsStatuesString)
    ];
  }

  openUrl() {
    window.open(this.contactus, '_self');
  }

  openUrlinNewWindow(url) {
    window.open(this.constants.directPayUrl, '_blank');
  }
  trackByFn(index, claim) {
    return claim ? claim.id : index;
  }

  /* Initialize all filter option for members, providers
     visits,status etc.
     Initialize all filter flag for the filter options
  */
  private initAllClaimsFilterOptions(): void {
    this.allClaimsFilterOptions = {
      plan: { text: 'plan', allOptRequired: false, all: { planName: 'All Plans', planCount: 0 } },
      date: { text: 'date', allOptRequired: false, custom: { dateRange: 'Custom Date Range', dateCount: 0 } },
      member: { text: 'member', allOptRequired: false, all: { memberName: 'All Members', memberCount: 0 } },
      provider: { text: 'provider', allOptRequired: false, all: { providerName: 'All Providers', providerCount: 0 } },
      visitType: { text: 'visit', allOptRequired: false, all: { visitType: 'All Visits', visitTypeCount: 0 } },
      claimStatus: { text: 'status', allOptRequired: false, all: { status: 'All Statuses', statusCount: 0 } }
    };
  }

  /* TO show the claims listing or member record on page load
     To show the filter criteria on page load
     TO check whether it belongs to page load api data or filter api data
  */

  public manageClaimsListing(filterPaginationApiData?: ClaimsSummaryResponseModelInterface): void {
    if (!filterPaginationApiData) {
      if (this.claimsInfo && this.claimsInfo.length) {
        if (!this.claimsInfo[0].hasOwnProperty('result') && this.claimsInfo[0].result !== 0) {
          this.claimsListing = this.claimsInfo[0];
          if (!this.isClearFilter) {
            this.recordsPerPage = this.claimsListing.summaryMetaData.recordEndIndex;
            this.manageClaimsFilter(this.claimsListing);
          }
        } else {
          //  this.alertService.setAlert('', this.claimsInfo[0]['displaymessage'], AlertType.Failure);
        }
      }
    } else {
      this.claimsListing = filterPaginationApiData;
    }

    if (this.claimsListing && this.claimsListing.hasOwnProperty('memberRecord') && this.claimsListing.memberRecord.length) {
      this.filteredClaims = this.claimsListing.memberRecord;
      this.fpoTargetUrl = this.constants.drupalClaimsrUrl;
    } else {
      this.fpoTargetUrl = this.constants.drupalNoClaimsrUrl;
      this.noClaimsAvailable = true;
    }

    this.fpoTargetListingUrl = environment.drupalTestUrl + '/page/mydoctors-listingscreen';
  }

  /*
     To set/show the filter criteria on page load for date, members, providers,visits, claims status etc..
  */
  public manageClaimsFilter(claimsListing) {
    this.allClaimsFilterOptions.member.all.memberCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.provider.all.providerCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.visitType.all.visitTypeCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.claimStatus.all.statusCount = claimsListing.summaryMetaData.totalRecordCount;
    if (claimsListing.filtersMetadata.dateMetaData.hasOwnProperty('customDateRange')) {
      this.allClaimsFilterOptions.date.custom.dateCount = claimsListing.dateMetaData.customDateRange.customDateCount;
    }

    this.membersList = [...claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.membersList, this.allClaimsFilterOptions.member.all.memberName)) {
      this.membersList.push(this.allClaimsFilterOptions.member.all);
    }

    // this.membersList = this.initClearFilterOptions(this.membersList);

    this.providerList = [...claimsListing.filtersMetadata.providerMetaData.providerMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.providerList, this.allClaimsFilterOptions.provider.all.providerName)) {
      this.providerList.push(this.allClaimsFilterOptions.provider.all);
    }

    // this.providerList = this.initClearFilterOptions(this.providerList);

    this.visitTypeList = [...claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.visitTypeList, this.allClaimsFilterOptions.visitType.all.visitType)) {
      this.visitTypeList.push(this.allClaimsFilterOptions.visitType.all);
    }

    // this.visitTypeList = this.initClearFilterOptions(this.visitTypeList);

    this.claimsStatusList = [...claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.claimsStatusList, this.allClaimsFilterOptions.claimStatus.all.status)) {
      this.claimsStatusList.push(this.allClaimsFilterOptions.claimStatus.all);
    }

    // this.claimsStatusList = this.initClearFilterOptions(this.claimsStatusList);

    this.dateList = [...claimsListing.filtersMetadata.dateMetaData.dateMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.dateList, this.allClaimsFilterOptions.date.custom.dateRange)) {
      this.dateList.push(this.allClaimsFilterOptions.date.custom);
    }
    // this.dateList = this.initClearFilterOptions(this.dateList, this.allClaimsFilterOptions.date.text);
  }

  private checkExistingClaimsFilterOptions(filterList, allOptions: string) {
    return filterList.find(oFilterList => {
      return Object.values(oFilterList).includes(allOptions);
    });
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedClaimsFilter(selectionListChange: MatSelectionListChange, filterType: string) {
    switch (filterType) {
      case this.allClaimsFilterOptions.member.text:
        this.allClaimsFilterOptions.member.allOptRequired = this.checkClaimsFilterOptions(
          selectionListChange,
          this.allClaimsFilterOptions.member.all.memberName,
          this.membersList
        );
        break;

      case this.allClaimsFilterOptions.provider.text:
        this.allClaimsFilterOptions.provider.allOptRequired = this.checkClaimsFilterOptions(
          selectionListChange,
          this.allClaimsFilterOptions.provider.all.providerName,
          this.providerList
        );
        break;

      case this.allClaimsFilterOptions.visitType.text:
        this.allClaimsFilterOptions.visitType.allOptRequired = this.checkClaimsFilterOptions(
          selectionListChange,
          this.allClaimsFilterOptions.visitType.all.visitType,
          this.visitTypeList
        );
        break;

      case this.allClaimsFilterOptions.claimStatus.text:
        this.allClaimsFilterOptions.claimStatus.allOptRequired = this.checkClaimsFilterOptions(
          selectionListChange,
          this.allClaimsFilterOptions.claimStatus.all.status,
          this.claimsStatusList
        );
        break;
    }
  }

  /*
     To check whether the user selected the all options or individual options and
     make disabled other relevant options if user selected the all options and vice-versa
  */
  public checkClaimsFilterOptions(selectionListChange: MatSelectionListChange, allOptions: string, filterList) {
    const selectAllOption = selectionListChange.option;
    let allOptRequired = false;
    if (Object.values(selectAllOption.value).includes(allOptions)) {
      if (selectAllOption.selected) {
        allOptRequired = true;
        selectionListChange.source.selectAll();
      } else {
        selectionListChange.source.deselectAll();
      }
      filterList = filterList.map(filterObj => {
        if (selectAllOption.selected) {
          filterObj.selected = true;
          filterObj.disabled = !Object.values(filterObj).includes(allOptions);
          allOptRequired = true;
        } else {
          filterObj.selected = false;
          filterObj.disabled = false;
        }
        return filterObj;
      });
    } else if (selectAllOption.selected) {
      if (selectAllOption.selectionList.selectedOptions.selected.length === filterList.length - 1) {
        allOptRequired = true;
        switch (allOptions) {
          case 'All Members': {
            const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Providers': {
            const selectedAllOption = filterList.find(listItem => listItem.providerName === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Visits': {
            const selectedAllOption = filterList.find(listItem => listItem.visitType === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Statuses': {
            const selectedAllOption = filterList.find(listItem => listItem.status === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
        }
        return filterList;
      }
    } else {
      switch (allOptions) {
        case 'All Members': {
          const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Providers': {
          const selectedAllOption = filterList.find(listItem => listItem.providerName === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Visits': {
          const selectedAllOption = filterList.find(listItem => listItem.visitType === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Statuses': {
          const selectedAllOption = filterList.find(listItem => listItem.status === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
      }
      return filterList;
    }
    // this.cdr.detectChanges();
    return allOptRequired;
  }

  onSelectionChange(selectionListChange: MatSelectionListChange, selectAllOptionIdentifier: string, selectedList) {
    const changeEvent = selectionListChange.option;
    if (changeEvent && changeEvent.value === selectAllOptionIdentifier) {
      this.selectAllOptions(selectedList, changeEvent.selected, selectAllOptionIdentifier);
    } else {
      const selectedOption = selectedList.find(listItem => changeEvent && listItem.value === changeEvent.value);
      if (selectedOption) {
        selectedOption.selected = changeEvent.selected;
      }
      if (changeEvent.selected) {
        // when the user wants to check all option if he selects all the other list items
        if (changeEvent.selectionList.selectedOptions.selected.length === selectedList.length - 1) {
          this.checkSelectAllOptionIfAllSelected(selectedList, selectAllOptionIdentifier);
        }
      } else {
        this.unCheckSelectAllOption(selectedList, selectAllOptionIdentifier);
      }
    }
  }

  checkSelectAllOptionIfAllSelected(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && !selectedAllOption.selected) {
      selectedAllOption.selected = true;
    }
    return list;
  }

  unCheckSelectAllOption(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && selectedAllOption.selected) {
      selectedAllOption.selected = false;
    }
    return list;
  }

  selectAllOptions(list, selectedValue: boolean, selectAllOptionIdentifier: string) {
    return list.map(listItem => {
      listItem.selected = selectedValue;
      if (selectedValue) {
        listItem.selected = true;
        listItem.disabled = listItem.value !== selectAllOptionIdentifier;
      } else {
        listItem.selected = false;
        listItem.disabled = false;
      }

      return listItem;
    });
  }

  /*
     To get the selected filter criteria from the view/template to apply filter for all the filter criteria
  */

  private getSelectedClaimsFilterOptions(list: MatSelectionList, allOptions: string) {
    if (list && list.selectedOptions.selected.length > 0) {
      const filteredItems = list.selectedOptions.selected.filter(selectedItem => !Object.values(selectedItem.value).includes(allOptions));
      return filteredItems.map(filteredOptions => {
        const selectedFilterOptions = {};
        for (const prop in filteredOptions.value) {
          if (!(prop === 'selected' || prop === 'disabled')) {
            selectedFilterOptions[prop] = filteredOptions.value[prop];
          }
        }
        return selectedFilterOptions;
      });
    }
    return null;
  }

  /*
     To apply filter for all the selected filter criteria
  */

  public applyFilter(
    providerList: MatSelectionList,
    claimStatusList: MatSelectionList,
    visitTypeList: MatSelectionList,
    memberList: MatSelectionList
  ) {
    // , clearSearch: boolean = true
    this.filterService.scrollToTop();
    this.closeFilter();
    this.closeSideNavigation();
    this.isDisplaySpinner = false;
    this.showCalender = false;
    this.isDisplayMessage = false;
    this.alertService.clearError();

    this.selectedProviderList = this.getSelectedClaimsFilterOptions(providerList, this.allClaimsFilterOptions.provider.all.providerName);
    this.selectedClaimsList = this.getSelectedClaimsFilterOptions(claimStatusList, this.allClaimsFilterOptions.claimStatus.all.status);
    this.selectedVisitTypeList = this.getSelectedClaimsFilterOptions(visitTypeList, this.allClaimsFilterOptions.visitType.all.visitType);
    this.selectedMemberList = this.getSelectedClaimsFilterOptions(memberList, this.allClaimsFilterOptions.member.all.memberName);

    const reqParams = this.claimsFilterPaginationReqParams(
      this.selectedProviderList,
      this.selectedClaimsList,
      this.selectedVisitTypeList,
      this.selectedMemberList,
      this.sortSelectedFilter
    );

    // always send sort order for filter submit
    reqParams.summaryMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;

    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      this.claimService.getClaims(reqParams).subscribe(apiData => {
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            this.manageClaimsListing(apiData);
            this.isDisplayResults = true;
            this.showClearLink = true;
          } else {
            if (apiData.result === -90202) {
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.showClearLink = true;
              this.filteredClaims = [];
            } else {
              this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
            }
          }
        }
      });
    }
  }

  /*
       To clear the filter for all the selected filter criteria
  */

  public clearFilter(
    providerList?: MatSelectionList,
    claimStatusList?: MatSelectionList,
    visitTypeList?: MatSelectionList,
    memberList?: MatSelectionList
  ) {
    this.step = [];
    // this.dependant = this.userString; // "User"
    // this.setSortFiltervalue();
    // this.ClearSearch();
    this.closeFilter();
    sessionStorage.removeItem('claims');
    // this.clearFilterList();
    // this.handleMedicationsResponse(this.allClaims, true);
    // this.clearSessionStorageItems();
    // this.setShowClearLink();

    this.showClose = false;
    this.showCalender = false;
    this.showResultsCount = false;
    this.isSortExpanded = false;
    this.isClearFilter = true;
    this.isDisplayMessage = false;
    this.isDisplayResults = false;
    this.showClearLink = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      this.dateSelectedFilter = {} as DateSearchListInterface;
      this.clearCustomDateRangeSelections();
    }

    this.clearFilterOptionsFromView(memberList);
    this.clearFilterOptionsFromView(providerList);
    this.clearFilterOptionsFromView(visitTypeList);
    this.clearFilterOptionsFromView(claimStatusList);

    this.initClearFilterOptions(this.membersList);
    this.initClearFilterOptions(this.providerList);
    this.initClearFilterOptions(this.visitTypeList);
    this.initClearFilterOptions(this.claimsStatusList);

    this.selectedProviderList = [];
    this.selectedClaimsList = [];
    this.selectedVisitTypeList = [];
    this.selectedMemberList = [];

    this.manageClaimsListing();
    this.filterService.scrollToTop();
    this.closeSideNavigation();
    this.alertService.clearError();
  }

  /*
      Inner function of clear filter to clear the filter for all the selected filter criteria
  */
  private clearFilterOptionsFromView(filterList) {
    if (filterList && filterList.selectedOptions.selected.length > 0) {
      filterList = filterList.selectedOptions.selected.map(oFilterList => {
        oFilterList.selected = false;
        oFilterList.disabled = false;
        return oFilterList;
      });
    }
  }

  private initClearFilterOptions(filterList, filterType?: string) {
    if (filterList && filterList.length) {
      // if (filterList && filterList.selectedOptions.selected.length > 0) {
      return filterList.map(oFilterList => {
        if (!filterType) {
          oFilterList.selected = false;
          oFilterList.disabled = false;
        } else {
          oFilterList.checked = false;
        }
        return oFilterList;
      });
    }
  }

  /*
    To get the another result set of records when scolling down
  */
  public paginationOnScrollDown(event) {

    this.alertService.clearError();

    if (
      this.claimsListing.summaryMetaData.totalRecordCount > this.recordsPerPage &&
      this.filteredClaims &&
      this.filteredClaims.length >= this.recordsPerPage &&
      this.filteredClaims.length < this.claimsListing.summaryMetaData.totalRecordCount &&
      !this.isSidenavOpened
    ) {
      this.isDisplaySpinner = true;
      let reqParams;
      reqParams = this.claimsFilterPaginationReqParams(
        this.selectedProviderList,
        this.selectedClaimsList,
        this.selectedVisitTypeList,
        this.selectedMemberList,
        this.sortSelectedFilter
      );
      reqParams.scrollIndicator = 'DOWN';

      this.claimService.getClaims(reqParams).subscribe(apiData => {
        const tempFilteredCalaims = this.filteredClaims;
        // console.log ('Filtered list length: ' + tempFilteredCalaims.length);
        // console.log ('Filtered list last item: ', tempFilteredCalaims[tempFilteredCalaims.length-1]);
        this.isDisplaySpinner = false;
        this.claimsListing.summaryMetaData.hasMoreRecords = apiData.summaryMetaData.hasMoreRecords;
        this.claimsListing.summaryMetaData.recordStartIndex = apiData.summaryMetaData.recordStartIndex;
        this.claimsListing.summaryMetaData.recordEndIndex = apiData.summaryMetaData.recordEndIndex;
        this.claimsListing.summaryMetaData.totalRecordCount = apiData.summaryMetaData.totalRecordCount;
        if (apiData.summaryMetaData.sortOrder) {
          this.claimsListing.summaryMetaData.sortOrder = apiData.summaryMetaData.sortOrder;
        }
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            if (apiData.hasOwnProperty('memberRecord') && apiData.memberRecord.length) {
              apiData.memberRecord.map(oMemberRecord => {
                this.filteredClaims.push(oMemberRecord);
              });
            }
          } else {
            this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
          }
        }
      });
    }
    event.target.complete();
  }

  /*
    To get the another result set of records when scolling up
  */
  onScrollUp() {
    console.log('fdfdsf');
  }

  /*
     To create the request params for sorting, filter & pagination
  */

  private claimsFilterPaginationReqParams(
    selectedProviderList,
    selectedClaimsList,
    selectedVisitTypeList,
    selectedMemberList,
    sortSelectedFilter
  ) {
    const providerMetaReqParams = {} as ProviderMetaInterface,
      visitTypeMetaReqParams = {} as VisitTypeMetaInterface,
      claimStatusMetaReqParams = {} as ClaimStatusMetaInterface,
      memberTypeMetaReqParams = {} as MemberTypeMetaInterface,
      claimFiltersMetaReqParams = {} as ClaimFiltersMetadataInterface,
      dateMetaReqParams = {} as DateMetaInterface,
      dateSearchListReqParams = {} as DateSearchListInterface,
      customDateRangeMetaReqParams = {} as CustomDateRangeMetaInterface,
      claimSummaryMetaReqParams = {} as ClaimSummaryMetadataInterface,
      claimsSummaryReqParams = {} as ClaimsSummaryRequestModelInterface;

    this.isSelectedDateInvalid = false;
    this.isCustomDateRangeInValid = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      if (this.dateSelectedFilter.dateRange.toLowerCase().indexOf('all') !== -1) {
        dateMetaReqParams.allDatesRequired = true;
      } else if (this.dateSelectedFilter.dateRange.indexOf(this.allClaimsFilterOptions.date.custom.dateRange) !== -1) {
        dateMetaReqParams.allDatesRequired = false;
        this.checkFromDate = this.validateFromDate();
        this.checkToDate = this.validateToDate();
        if (!this.checkFromDate && !this.checkToDate) {
          this.validateCustomRange();
          customDateRangeMetaReqParams.startDate = this.datePipe.transform(this.fromDate, 'yyyy-MM-dd');
          customDateRangeMetaReqParams.endDate = this.datePipe.transform(this.toDate, 'yyyy-MM-dd');
          dateMetaReqParams.customDateRange = customDateRangeMetaReqParams;
        } else {
          this.isSelectedDateInvalid = true;
        }
      } else {
        dateSearchListReqParams.dateRange = this.dateSelectedFilter.dateRange;
        dateMetaReqParams.dateMetaList = new Array(dateSearchListReqParams);
        dateMetaReqParams.allDatesRequired = false;
      }
      claimFiltersMetaReqParams.dateMetaData = dateMetaReqParams;
    }

    if (selectedProviderList && selectedProviderList.length) {
      providerMetaReqParams.allProvidersRequired = this.allClaimsFilterOptions.provider.allOptRequired;
      if (!providerMetaReqParams.allProvidersRequired) {
        providerMetaReqParams.providerMetaList = selectedProviderList;
      }
      claimFiltersMetaReqParams.providerMetaData = providerMetaReqParams;
    }

    if (selectedClaimsList && selectedClaimsList.length) {
      claimStatusMetaReqParams.allStatusesRequired = this.allClaimsFilterOptions.claimStatus.allOptRequired;
      if (!claimStatusMetaReqParams.allStatusesRequired) {
        claimStatusMetaReqParams.claimStatusMetaList = selectedClaimsList;
      }
      claimFiltersMetaReqParams.claimStatusMetaData = claimStatusMetaReqParams;
    }

    if (selectedVisitTypeList && selectedVisitTypeList.length) {
      visitTypeMetaReqParams.allVisitTypesRequired = this.allClaimsFilterOptions.visitType.allOptRequired;
      if (!visitTypeMetaReqParams.allVisitTypesRequired) {
        visitTypeMetaReqParams.visitTypeMetaList = selectedVisitTypeList;
      }
      claimFiltersMetaReqParams.visitTypeMetaData = visitTypeMetaReqParams;
    }

    if (selectedMemberList && selectedMemberList.length) {
      memberTypeMetaReqParams.allmembersRequired = this.allClaimsFilterOptions.member.allOptRequired;
      if (!memberTypeMetaReqParams.allmembersRequired) {
        memberTypeMetaReqParams.memberTypeMetaList = selectedMemberList;
      }
      claimFiltersMetaReqParams.memberTypeMetaData = memberTypeMetaReqParams;
    }

    claimsSummaryReqParams.useridin = this.authService.useridin;
    // for pagination
    claimSummaryMetaReqParams.hasMoreRecords = this.claimsListing.summaryMetaData.hasMoreRecords;
    claimSummaryMetaReqParams.recordStartIndex = this.claimsListing.summaryMetaData.recordStartIndex;
    claimSummaryMetaReqParams.recordEndIndex = this.claimsListing.summaryMetaData.recordEndIndex;
    claimSummaryMetaReqParams.totalRecordCount = this.claimsListing.summaryMetaData.totalRecordCount;

    // check if here is a change in sort order?
    if (this.currentSortValue !== this.sortSelectedFilter) {
      this.currentSortValue = this.sortSelectedFilter;
      claimSummaryMetaReqParams.sortOrder = sortSelectedFilter;
    } else {
      delete claimSummaryMetaReqParams.sortOrder;
    }

    claimsSummaryReqParams.summaryMetaData = claimSummaryMetaReqParams;
    if (Object.keys(claimFiltersMetaReqParams).length) {
      claimsSummaryReqParams.filtersMetadata = claimFiltersMetaReqParams;
    }
    console.log(claimsSummaryReqParams);

    return claimsSummaryReqParams;
  }

  public openPDF(fileItem: string) {
    // window.location.href = fileItem;
    // return;
    /*Download and open pdf*/
    // let path = null;
    // if(this.platform.is('ios')){
    //   path = this.file.documentsDirectory;
    // }else{
    //   path = this.file.dataDirectory;
    // }

    // const transfer = this.transfer.create();
    // transfer.download(fileItem, path + 'file.pdf').then(entry =>{
    //   let url = entry.toURL();
    //  this.document.viewDocument(fileItem,'submit-claim/pdf',{});
    // })
    /*open a pdf*/
    const absolutePath = this.file.applicationDirectory + 'www/assets/files/';
    if (this.platform.is('android')) {
      const fakeName = Date.now();
      this.file.copyFile(absolutePath, 'SubscriberSubmitClaimForm7307.pdf', this.file.dataDirectory, `${fakeName}.pdf`).then(result => {
        this.fileOpener
          .open(result.nativeURL, 'application/pdf')
          .then(() => console.log('File is opened'))
          .catch(e => console.log('Error opening file', e));
      });
    } else {
      this.document.viewDocument(`${absolutePath}SubscriberSubmitClaimForm7307.pdf`, 'application/pdf', {});
    }
  }

  public decimalFragment(sourceNumber): string {
    try {
      if (!sourceNumber) {
        return '00';
      }
      if (Number(sourceNumber)) {
        return Number(sourceNumber)
          .toFixed(2)
          .split('.')[1];
      } else {
        return '00';
      }
    } catch (error) {
      return '00';
    }
  }
  //
  // for APP
  appClearSessionStorageItems() {
    // sessionStorage.removeItem('claims');  //TODO - find where it is appropriate to clear
    // sessionStorage.removeItem('visitTypeSelectedfilter');
    // sessionStorage.removeItem('claimStatusSelectedfilter');
    // sessionStorage.removeItem('dateSelectedFilter');
    // sessionStorage.removeItem('fromDate');
    // sessionStorage.removeItem('toDate');
    // sessionStorage.removeItem('sortSelectedFilter');
    // if (sessionStorage.getItem('claimsSelectedUserId') !== 'User') {
    //   sessionStorage.removeItem('claimsSelectedUserId');
    // }
  }

  public appApplyFilter(
    claimStatusMetaInterface: ClaimStatusMetaInterface,
    dateMetaData: DateMetaInterface,
    memberTypeMetaData: MemberTypeMetaInterface,
    providerMetaData: ProviderMetaInterface,
    visitTypeMetaData: VisitTypeMetaInterface
    // providerList: MatSelectionList,
    // claimStatusList: MatSelectionList,
    // visitTypeList: MatSelectionList,
    // memberList: MatSelectionList
  ) {
    // , clearSearch: boolean = true
    this.isDisplayMessage = false;
    const claimsSummaryReqParams = {} as ClaimsSummaryRequestModelInterface;
    claimsSummaryReqParams.useridin = this.authService.useridin;

    claimsSummaryReqParams.summaryMetaData = {} as ClaimSummaryMetadataInterface;
    claimsSummaryReqParams.summaryMetaData.hasMoreRecords = true;
    claimsSummaryReqParams.summaryMetaData.recordStartIndex = 1;
    claimsSummaryReqParams.summaryMetaData.recordEndIndex = 50;
    claimsSummaryReqParams.summaryMetaData.totalRecordCount = this.claimsListing.summaryMetaData.totalRecordCount;
    claimsSummaryReqParams.summaryMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;
    claimsSummaryReqParams.filtersMetadata = {} as ClaimFiltersMetadataInterface;
    claimsSummaryReqParams.filtersMetadata.claimStatusMetaData = claimStatusMetaInterface;
    claimsSummaryReqParams.filtersMetadata.dateMetaData = dateMetaData;
    claimsSummaryReqParams.filtersMetadata.memberTypeMetaData = memberTypeMetaData;
    claimsSummaryReqParams.filtersMetadata.providerMetaData = providerMetaData;
    claimsSummaryReqParams.filtersMetadata.visitTypeMetaData = visitTypeMetaData;

    // const reqParams = this.claimsFilterPaginationReqParams(
    //   this.selectedProviderList,
    //   this.selectedClaimsList,
    //   this.selectedVisitTypeList,
    //   this.selectedMemberList,
    //   this.sortSelectedFilter
    // );

    // always send sort order for filter submit
    // reqParams.summaryMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;

    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      this.claimService.getClaims(claimsSummaryReqParams).subscribe(apiData => {
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            this.appClearSessionStorageItems();
            this.manageClaimsListing(apiData);
            this.isDisplayResults = true;
            this.showClearLink = true;
          } else {
            if (apiData.result === -90202) {
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.showClearLink = true;
              this.filteredClaims = [];
            } else {
              this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
            }
          }
        }
      });
    }
  }

  async handleClaimsFilter(ev) {
    console.log('-- handleClaimsFilter -- Claims Filter clicked', this.swrveEventNames.AppClick_MyClaims_Search);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyClaims_Search);
    let popover: HTMLIonPopoverElement;
    popover = await this.popoverController.create({
      component: FilterClaimsComponent,
      event: ev,
      cssClass: 'my-claims-filter',
      translucent: true,
      componentProps: {
        showClearLink: this.showClearLink,
        sortSelectedFilter: this.sortSelectedFilter,
        dateList: this.dateList,
        memberList: this.membersList, // this.selectedMemberList,
        memberFilterList: this.claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList,
        providerList: this.providerList,
        providerFilterList: this.claimsListing.filtersMetadata.providerMetaData.providerMetaList,
        visitTypeList: this.visitTypeList,
        visitTypeFilterList: this.claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList,
        claimStatusList: this.claimsStatusList,
        claimStatusFilterList: this.claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList,
        closeFilterAction: returnData => {
          if (popover) {
            popover.dismiss(returnData);
          }
        },
        getPopOver: () => {
          popover;
        }
      }
    });

    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        console.log('Filter settings 1: ', dataReturned);
        this.sortSelectedFilter = dataReturned.data.sortSelectedFilter;
        // this.fromDate = dataReturned.data.fromDate;
        // this.toDate = dataReturned.data.toDate;
        this.appApplyFilter(
          dataReturned.data.claimStatusMetaInterface,
          dataReturned.data.dateMetaData,
          dataReturned.data.memberTypeMetaData,
          dataReturned.data.providerMetaData,
          dataReturned.data.visitTypeMetaData
        );
      } else if (dataReturned && dataReturned.role !== 'backdrop' && !dataReturned.data) {
        this.clearFilter();
      }
    });

    return popover.present();
  }

  goBack() {
    this.location.back();
  }
}
