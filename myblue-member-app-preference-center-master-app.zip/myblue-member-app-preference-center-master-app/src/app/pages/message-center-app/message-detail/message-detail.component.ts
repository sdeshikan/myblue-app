import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HeaderService } from '../../../shared/layouts/header/header.service';

import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { MsgListingService } from '../msg-listing/msg-listing.service';
import { MessageDetailService } from './message-detail.service';

import { MessageDetailModelInterface, MessageDetailRequestDataModelInterface } from '../modals/interfaces/message-detail.interface';

import { Location } from '@angular/common';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { MessageCenterSearchService } from '../message-center-search/message-center-search.service';
import { MessageCenterService } from '../message-center.service';
import { UpdateMsgListingAndMemberAlertsRequestInterface } from '../modals/interfaces/message.interface';
import { MessageDetailModel, MessageDetailRequestDataModel } from '../modals/message-detail.model';
import { UpdateMsgListingAndMemberAlertsRequestModel } from '../modals/messages.model';

@Component({
  selector: 'app-message-detail',
  templateUrl: './message-detail.component.html',
  styleUrls: ['./message-detail.component.scss']
})
export class MessageDetailComponent implements OnInit {

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  public msgDetail: MessageDetailModelInterface = new MessageDetailModel();
  public category: string;
  public timeStamp: string;
  public test;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private headerService: HeaderService,
    private msgListingService: MsgListingService,
    private messageCenterService: MessageCenterService,
    private messageDetailService: MessageDetailService,
    private messageCenterSearchService: MessageCenterSearchService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.onBackPressed();
    });
  }

  ngOnInit() {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewMessage_ViewMessageDetails);
      this.setMessageDetail();
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public onBackPressed(): void {
    this.router.navigate(['../tabs/myInbox/messages'], { replaceUrl: true });
  }

  private setMessageDetail() {
    this.messageDetailService.getMessageDetail(this.setMsgDetailAndMemberAlertsReqParams()).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.hasOwnProperty('messageDetailResponse') && Object.keys(apiData.messageDetailResponse).length) {
          this.msgDetail = apiData.messageDetailResponse;
          if (this.msgDetail.body) {
            this.setCtaLink();
          }
          this.category = sessionStorage.getItem('category') ? sessionStorage.getItem('category') : '';
          if (this.messageCenterService.msgListingResponse.isRead === 'false') {
            // if it's already read, this call is not required
            this.markAsRead();
          }
        } else if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        }
      }
    });
  }

  private setCtaLink() {
    const urlRegex = /(\b((https?|ftp|file):\/\/|(www))[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|]*)/gi;
    const msgBody = this.msgDetail.body.toLowerCase();

    if (msgBody.indexOf('cta:') !== -1) {
      if (msgBody.split('cta:')[1].indexOf('opens') !== -1) {
        this.msgDetail.body = this.msgDetail.body.replace(urlRegex, url => `<a href=${url}>${url}</a>`);
        if (this.msgDetail.body.indexOf('CTA: Opens') >= 0) {
          this.msgDetail.body = this.msgDetail.body.replace('CTA: Opens ', '');
        } else if (this.msgDetail.body.indexOf('CTA:Opens') >= 0) {
          this.msgDetail.body = this.msgDetail.body.toLowerCase().replace('CTA:Opens ', '');
        }
      }
    }
  }

  public backToMsgListing() {
    this.messageCenterSearchService.isPersistSearchCriteria = true;
    this.router.navigate(['/tabs/myInbox/messages']);
  }

  public deleteMessage() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MessageCenter_DeleteMessage);
    this.backToMsgListing();
    this.messageCenterService.msgListingResponse.type = 'delete';
  }

  public markAsUnread() {
    this.msgListingService.getUpdateMsgListingAndMemberAlerts(this.setMsgDetailAndMemberAlertsReqParams(false)).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          this.headerService.unReadMsgCount = apiData.successresponse.unreadMessageCount.toString();
          this.backToMsgListing();
        }
      }
    });
  }

  public markAsRead() {
    this.msgListingService.getUpdateMsgListingAndMemberAlerts(this.setMsgDetailAndMemberAlertsReqParams(true)).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          console.log(apiData);
          this.headerService.unReadMsgCount = apiData.successresponse.unreadMessageCount.toString();
        }
      }
    });
  }

  public formattedDate(date: string, format: string): string {
    if (date) {
      return this.datePipe.transform(date, format);
    }
  }

  private setMsgDetailAndMemberAlertsReqParams(isMsgRead?: boolean): any {
    const memberId = sessionStorage.getItem('memberId') ? sessionStorage.getItem('memberId') : '';
    const messageId = sessionStorage.getItem('messageId') ? sessionStorage.getItem('messageId') : '';
    const useridin = this.useridin;

    if (typeof isMsgRead === 'boolean') {
      // tslint:disable-next-line:max-line-length
      const updateMsgListingAndMemberAlertsReqParams: UpdateMsgListingAndMemberAlertsRequestInterface = new UpdateMsgListingAndMemberAlertsRequestModel();

      if (isMsgRead === true) {
        updateMsgListingAndMemberAlertsReqParams.readalertids = messageId;
      } else {
        updateMsgListingAndMemberAlertsReqParams.unreadalertids = messageId;
      }
      updateMsgListingAndMemberAlertsReqParams.useridin = useridin;
      updateMsgListingAndMemberAlertsReqParams.memberId = memberId;
      return updateMsgListingAndMemberAlertsReqParams;
    } else {
      const msgDetailReqParams: MessageDetailRequestDataModelInterface = new MessageDetailRequestDataModel();
      msgDetailReqParams.memberId = memberId;
      msgDetailReqParams.messageId = messageId;
      msgDetailReqParams.useridin = useridin;

      return msgDetailReqParams;
    }

  }
}
