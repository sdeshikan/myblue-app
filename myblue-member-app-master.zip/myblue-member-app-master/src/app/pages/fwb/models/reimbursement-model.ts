export interface ReimbursementModel {
  collateralName: string;
  collateralTitle: string;
  collateralText: string;
  onlineSubmissionEligible: boolean;
  benefitAmount: number;
  receiptRequired: boolean;
  isEHB: boolean;
}
