import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ReimbursementSelectionPage } from './reimbursement-selection.page';
import { RadioDirectiveModule } from '../../../../directives/radio-button.module';
import { RouterModule } from '@angular/router';
import { ReimbursementNotEligibleModule } from '../../components/reimbursement-not-eligible/reimbursement-not-eligible.module';
import { ReimbursementNotEligibleComponent } from '../../components/reimbursement-not-eligible/reimbursement-not-eligible.component';

@NgModule({
  declarations: [ReimbursementSelectionPage],
  imports: [CommonModule, FormsModule, IonicModule, RadioDirectiveModule, RouterModule, ReimbursementNotEligibleModule],
  entryComponents: [ReimbursementNotEligibleComponent]
})
export class ReimbursementSelectionModule {}
