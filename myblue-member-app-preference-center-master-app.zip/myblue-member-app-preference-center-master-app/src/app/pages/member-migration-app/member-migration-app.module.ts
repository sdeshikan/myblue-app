import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { MigrationAppRouter } from './member-migration-app.routing';
import { MigrationAppGuard } from './migration-app.guard';
import { MigrationAppService } from './migration-app.service';
import { ProfileInfoAppPage } from './profile-info-app/profile-info-app.page';
import { MigrationConfirmationAppPage } from './profile-info-update-app/migration-confirmation-app/migration-confirmation-app.page';
import { MigrationSuccessAppPage } from './profile-info-update-app/migration-success-app/migration-success-app.page';
import { UpdatePasswordAppPage } from './profile-info-update-app/update-password-app/update-password-app.page';
import { VerifyEmailMobileAppPage } from './profile-info-update-app/verify-email-mobile-app/verify-email-mobile-app.page';
import { AlertsModule } from '../../shared/alerts/alerts.module';
@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MigrationAppRouter,
    TextMaskModule,
    AlertsModule
  ],
  declarations: [
    ProfileInfoAppPage,
    UpdatePasswordAppPage,
    VerifyEmailMobileAppPage,
    MigrationSuccessAppPage,
    MigrationConfirmationAppPage
  ],
  providers: [MigrationAppService, MigrationAppGuard]
})
export class MemberMigrationAppModule {}
