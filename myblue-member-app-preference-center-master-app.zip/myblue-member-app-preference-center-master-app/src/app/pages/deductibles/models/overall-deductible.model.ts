export interface OverallDeductibleModel {
  isFirstCoverage: boolean;
  overallDeductible: string;
  deductibleContributed: string;
  deductibleRemainingToMeet: string;
  overallDeductibleExclusionExcep: string;
  overallDeductibleLimitationContent: string;
}
