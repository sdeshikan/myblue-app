import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSearchListService } from './fad-search-list.service';

describe('FadSearchListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FadSearchListService, FadSearchResultsService]
    });
  });

  it('should be created', inject([FadSearchListService], (service: FadSearchListService) => {
    expect(service).toBeTruthy();
  }));
});
