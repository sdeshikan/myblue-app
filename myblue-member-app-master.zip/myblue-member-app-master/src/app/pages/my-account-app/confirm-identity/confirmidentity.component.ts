import { Component, OnInit } from '@angular/core';
import { ValidationService } from '../../../shared/services/validation.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { MyAccountService } from '../my-account.service';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { SwrveService, SwrveEventNames } from './../../../shared/services/swrve.service';

@Component({
  selector: 'app-confirmidentity',
  templateUrl: './confirmidentity.component.html',
  styleUrls: ['./confirmidentity.component.scss']
})
export class ConfirmidentityComponent implements OnInit {
  identityForm: FormGroup;
  dobMask: Array<any>;

  constructor(
    private fb: FormBuilder,
    private myAccountService: MyAccountService,
    private router: Router,
    private globalService: GlobalService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private validationService: ValidationService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.identityForm = this.fb.group({
      dob: ['', [Validators.required, this.validationService.dateValidator(), this.validationService.dobValidator()]]
    });
    this.dobMask = this.validationService.dobMask;
  }

  handleVerifiedResponse() {
    sessionStorage.setItem('otp', 'TRUE');
    this.router.navigate(['/account/verifyAccessCode', 'FUN']).then(() => {
      this.alertService.setAlert('Verification code sent!', '', AlertType.Success);
    });
  }

  onSubmit() {
    const request = this.identityForm.value;
    this.alertService.clearError();
    this.myAccountService.confirmIdentity(request).subscribe(res => {
      if (res && (res['result'] === '0' || res['result'] === 0)) {
        this.handleVerifiedResponse();
      } else if (res['result'] < 0) {
        this.globalService.handleError(res, this.constants.displayMessage);
      }
    });
  }

  ngOnInit() {
    this.alertService.clearError();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ForgotUsername_ConfirmIdentity);
  }
}
