export interface FadNoDocsPageInputDataModelInterface {
    type: string
}
