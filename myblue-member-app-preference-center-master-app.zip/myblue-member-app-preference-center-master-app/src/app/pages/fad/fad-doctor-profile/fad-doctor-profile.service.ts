import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import {
  FadDoctorProfileRequestModelInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface,
  FadProfessionalResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';

@Injectable()
export class FadDoctorProfileService {

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  public doctorProfile: any;
  constructor(private http: HttpClient) {}

  getFadGetprofessionalprofileDetails(request: FadDoctorProfileRequestModelInterface): Observable<FadProfessionalResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    return this.http.post<FadProfessionalResponseModelInterface>(FAD_CONSTANTS.urls.professionalprofile, request);
  }

  getProfessionalratings(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    return this.http.post<FadDoctorRatingsResponseModelInterface>(FAD_CONSTANTS.urls.fadGetDoctorRatings, request);
  }

  getAcceptableReviewers(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();
    delete request.ratingIdentifier;

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    return this.http.post<FadDoctorRatingsResponseModelInterface>(FAD_CONSTANTS.urls.fadGetAcceptableReviersUrl, request);
  }
}
