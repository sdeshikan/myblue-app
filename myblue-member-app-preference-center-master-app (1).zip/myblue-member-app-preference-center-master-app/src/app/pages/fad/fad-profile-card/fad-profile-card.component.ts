import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadDoctorRatingsRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadProfileCardComponentOutputModel } from '../modals/fad-profile-card.modal';
import { FadDoctorRatingsRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import {
  FadProfileCardComponentInputModelInterface,
  FadProfileCardComponentOutputModelInterface
} from '../modals/interfaces/fad-profile-card.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { PopoverComponent } from '../popover/popover.component';

@Component({
  selector: 'app-fad-profile-card',
  templateUrl: './fad-profile-card.component.html',
  styleUrls: ['./fad-profile-card.component.scss']
})
export class FadProfileCardComponent implements OnInit, StarRatingComponentConsumer {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  @Output() componentOutput: EventEmitter<FadProfileCardComponentOutputModelInterface> = new EventEmitter<
    FadProfileCardComponentOutputModelInterface
  >();

  @Input() componentInput: FadProfileCardComponentInputModelInterface;

  // temporary stuff
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public checked = false;
  public toggleShowMoreLocationStatus = false;
  // end of temporary stuff
  public tier: string;
  public doctorName: string;
  public speciality: string;
  public medicalGroup: string;
  public address: string;
  public phoneNumber: string;
  public awards = [];
  public numberOfLocations: number;
  public costDollars = '00';
  public costPennies = '00';
  public isMemberCost = false;
  public disclaimers: any;
  public accordianToggleStatus: any = {};
  public disclaimersText: string;
  public disclaimersFlag: boolean;
  public blueDistinct: string;
  public blueDistinctPlus: string;
  public blueDistinctTotal: string;
  public telehealth: boolean;
  public tierTooltipDescription: string;
  public tierTooltip = [];
  public blueAwardFlag = false;
  public endDateDisclaimers: string;
  public endDateDisclaimersFlag: boolean;
  public endDateDisclaimersDate: string;

  toolTipVisible = false;

  constructor(
    private router: Router,
    private doctorProfileService: FadDoctorProfileService,
    private fadSearchResultsService: FadSearchResultsService,
    private callNumber: CallNumber,
    private popoverController: PopoverController
  ) {}

  ngOnInit() {
    try {
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      console.log(this.componentInput);
      this.doctorName = this.componentInput.professional.doctorName;
      if (this.componentInput.professional.disclaimers) {
        this.disclaimers = this.componentInput.professional.disclaimers;
        if (this.disclaimers && this.disclaimers.category && this.disclaimers.category === 'on_record' && this.disclaimers.text) {
          this.disclaimersFlag = true;
          this.disclaimersText = this.disclaimers.text;
        }
      }

      this.speciality = this.componentInput.professional.specialty;
      this.blueDistinct = FAD_CONSTANTS.text.blueDistinct;
      this.blueDistinctPlus = FAD_CONSTANTS.text.blueDistinctPlus;
      this.blueDistinctTotal = FAD_CONSTANTS.text.blueDistinctTotal;
      if (this.componentInput.professional.locations) {
        this.numberOfLocations = this.componentInput.professional.locations.length;

        const firstLocation = this.componentInput.professional.locations[0];
        const firstLocation1 = Object.create(this.componentInput.professional.locations[0]);
        this.medicalGroup = firstLocation.name;
        this.address = firstLocation.address;
        this.phoneNumber = firstLocation.phone;
        this.endDateDisclaimers = firstLocation.endDateDisclaimers.text;
        this.endDateDisclaimersFlag = firstLocation.endDateDisclaimers.showEndDateDisclmrs;
        this.endDateDisclaimersDate = firstLocation.endDateDisclaimers.futureTerminationDate;
        this.awards = [];

        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });
          if (blueAwards.length) {
            this.awards = [{ name: 'Blue Distinctions', awardDetails: [] }];
            blueAwards.forEach(award => {
              if (award.awardDetails.length) {
                this.blueAwardFlag = true;
                award.awardDetails.forEach(awardDetail => {
                  this.awards[0].awardDetails.push(awardDetail);
                });
              }
            });
          }
        }

        for (let i = 0; i < firstLocation.amenities.length; i++) {
          if (firstLocation.amenities[i].type === 'Telehealth') {
            this.telehealth = true;
          }
        }

        this.accordianToggleStatus = {};

        if (firstLocation1.memberCost) {
          const costString: string = firstLocation1.memberCost.memberCost + '';
          this.costDollars = costString.split('.')[0];
          this.costPennies = costString.split('.')[1];
          this.isMemberCost = true;
        }
        if (firstLocation && firstLocation.tiers && firstLocation.tiers.description) {
          this.tier = firstLocation.tiers.description;
          this.getToolTipDescription(this.tierTooltip, this.tier);
        }
      } else {
        this.numberOfLocations = 0;
      }

      // temporary stuff
      this.doctorStarRating = new StarRatingComponentInputModel();
      if (this.componentInput.professional.reviews) {
        if (this.componentInput.professional.reviews.overallRating) {
          this.doctorStarRating.ratingInPercentage = parseInt(
            // tslint:disable-next-line:no-magic-numbers
            '' + (parseFloat(this.componentInput.professional.reviews.overallRating.toString()) * 100) / 5,
            10
          );
        }
        this.doctorStarRating.totalRatings = this.componentInput.professional.reviews.totalRatings;
        if (this.componentInput.professional.reviews.overallRating) {
          this.doctorStarRating.overAllRating = parseFloat(this.componentInput.professional.reviews.overallRating.toString());
        }

        // end of temporary stuff
      }
      this.getProfessionalreviews();
    } catch (exception) {}
  }
  callHelpLine(number: string) {
    from(this.callNumber.callNumber(number, true)).subscribe(data => console.log(data));
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }

  private getProfessionalreviews(): void {
    const fadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    const reviewIdentifier: string = this.componentInput.professional['reviewIdentifier'];

    fadDoctorProfileRequestParams.setReviewIdentifier(reviewIdentifier);
    const authUserId = this.useridin;
    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      fadDoctorProfileRequestParams.useridin = this.useridin;
    }
  }

  public openProfile(event): void {
    try {
      const professionalDetails: any = this.componentInput.professional;
      this.doctorProfileService.doctorProfile = professionalDetails.providerId;
      sessionStorage.setItem('professionalId', professionalDetails.providerId.toString());
      sessionStorage.setItem('locationId', this.componentInput.professional.locations[0].id.toString());
      setTimeout(() => {
        this.router.navigate(['/fad/doctor-profile']);
      }, 1);
    } catch (exception) {}
  }

  toggleAccordion(listItem) {
    if (this.accordianToggleStatus[listItem] === undefined) {
      this.accordianToggleStatus[listItem] = false;
    }
    this.accordianToggleStatus[listItem] = !this.accordianToggleStatus[listItem];
  }

  public onSelectionChange(event): void {
    const output: FadProfileCardComponentOutputModelInterface = new FadProfileCardComponentOutputModel();
    output.professional = this.componentInput.professional;
    output.professional.isChecked = event.detail.checked;
    output.isSelected = event.detail.checked;
    this.checked = event.detail.checked;

    this.componentOutput.emit(output);
  }

  async showToolTip(ev) {
    this.toolTipVisible = !this.toolTipVisible;

    if (this.toolTipVisible) {
      const popover = await this.popoverController.create({
        component: PopoverComponent,
        event: ev,
        mode: 'ios',
        cssClass: 'drupal-tooltip',
        componentProps: {
          tooltip: {
            targetUrl: null,
            toolTipdataPlans: this.tierTooltipDescription,
            isplandetails: null
          }
        }
      });
      popover.onDidDismiss().then(dataReturned => {
        this.toolTipVisible = !this.toolTipVisible;
      });

      return await popover.present();
    }
  }
}
