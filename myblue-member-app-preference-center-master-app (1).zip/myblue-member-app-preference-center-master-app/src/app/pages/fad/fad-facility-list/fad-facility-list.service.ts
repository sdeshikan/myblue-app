import { Injectable } from '@angular/core';

@Injectable()
export class FadFacilityListService {
  public isFilterChangedFlag = false;

  constructor() {}

  isFilterChanged(value) {
    this.isFilterChangedFlag = value;
  }
}
