import { RouterModule, Routes } from '@angular/router';
import { AddOtcComponent } from './add-otc/add-otc.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { LandingComponent } from './landing/landing.component';
import { MedicationsComponent } from './medications/medications.component';

const PILLPACK_ROUTER: Routes = [
  {
    path: '',
    component: MedicationsComponent
  },
  {
    path: 'add-otc',
    component: AddOtcComponent
  },
  {
    path: 'landing',
    component: LandingComponent
  },
  {
    path: 'confirmation',
    component: ConfirmationComponent
  }
];

export const PillpackRouter = RouterModule.forChild(PILLPACK_ROUTER);
