import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpParams } from '@angular/common/http';
import { FadConstants } from '../constants/fad.constants';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import {
  FadDoctorProfileRequestModelInterface,
  FadProfessionalResponseModelInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import { AuthService } from '../../../shared/services/auth.service';

@Injectable()
export class FadDoctorProfileService {
  public doctorProfile: any;
  constructor(private http: AuthHttp, private authService: AuthService) {}

  getFadGetprofessionalprofileDetails(request: FadDoctorProfileRequestModelInterface): Observable<FadProfessionalResponseModelInterface> {
    let params = new HttpParams();

    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptPost(FadConstants.urls.professionalprofile, request);
  }

  getProfessionalratings(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();

    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptPost(FadConstants.urls.fadGetDoctorRatings, request);
  }

  getAcceptableReviewers(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();
    delete request.ratingIdentifier;

    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptPost(FadConstants.urls.fadGetAcceptableReviersUrl, request);
  }
}
