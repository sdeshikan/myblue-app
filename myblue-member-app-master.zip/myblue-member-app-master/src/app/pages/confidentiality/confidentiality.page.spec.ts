import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfidentialityPage } from './confidentiality.page';
import { RouterTestingModule } from '@angular/router/testing';
import { HomeService } from '../../shared/services/home.service';
import { AuthHttp } from '../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../shared/services/constants.service';

describe('ConfidentialityPage', () => {
  let component: ConfidentialityPage;
  let fixture: ComponentFixture<ConfidentialityPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgxsModule.forRoot([]), HttpClientTestingModule],
      providers: [HomeService, AuthHttp, AuthService, ConstantsService],
      declarations: [ConfidentialityPage],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfidentialityPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
