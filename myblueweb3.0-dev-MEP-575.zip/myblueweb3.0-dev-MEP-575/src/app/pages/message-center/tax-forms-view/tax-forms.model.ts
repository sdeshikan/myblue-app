export interface TaxFormModel {
    year: string;
    name: string;
    file: string;
}

export interface TaxFileModel {
    formData: TaxFormModel[];
}