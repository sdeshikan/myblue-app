import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadFacilityCompareService } from '../fad-facility-compare/fad-facility-compare.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityListComponent } from './fad-facility-list.component';
import { FadFacilityListService } from './fad-facility-list.service';

describe('FadFacilityListComponent', () => {
  let component: FadFacilityListComponent;
  let fixture: ComponentFixture<FadFacilityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, IonicModule, NgxsModule.forRoot([])],
      declarations: [FadFacilityListComponent],
      providers: [
        FadFacilityListService,
        BcbsmaHttpService,
        FadSearchResultsService,
        ConstantsService,
        FadFacilityProfileService,
        FadLandingPageService,
        FadFacilityCompareService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
