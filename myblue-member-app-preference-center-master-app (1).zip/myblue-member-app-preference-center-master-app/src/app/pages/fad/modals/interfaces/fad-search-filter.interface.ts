import { FacilityFiltersMetadataInterface } from './getSearchByFacility-models.interface';
import { FiltersMetadataInterface, SortMetadataInterface } from './getSearchByProfessional-models.interface';

export interface FadSearchFilterComponentOutputModelInterface {
  resourcetype?: any;
    filterOverlayFlag: boolean;
    filterCriteriaData: FiltersMetadataInterface;
    sortCriteriaData: SortMetadataInterface;
}

export interface FadFacilitySearchFilterComponentOutputModelInterface {
    filterOverlayFlag: boolean;
    filterCriteriaData: FacilityFiltersMetadataInterface;
    sortCriteriaData: SortMetadataInterface;
}

export interface FadSpecialtyFilterComponentOutputModelInterface {
    filterOverlayFlag: boolean;
    filterCriteriaData: FiltersMetadataInterface;
    sortCriteriaData: SortMetadataInterface;
}

export interface FilterListItemInterface {
    name: string;
    value: string;
    count: string;
    default: string;
    selected: string;
}

export interface FilterRadioItemInterface {
    name: string;
    value: string;
    checked: boolean;
}

export interface FilterCheckboxItemInterface {
    value: string;
    count: string;
    default: string;
    selected: string;
}

export interface GrpHospitalAffiliationFilterListItemInterface {
    name: string;
    value: string;
    count: string;
    category: string;
    default: string;
    selected: string;
}
