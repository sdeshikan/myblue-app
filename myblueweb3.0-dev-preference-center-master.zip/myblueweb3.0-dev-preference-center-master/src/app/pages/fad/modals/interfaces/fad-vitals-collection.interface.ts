import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';
import { FPSRPlan, FZCSRCity } from '../fad-vitals-collection.model';
import { FVPSRMeta, FVPSRProvider } from '../fad-vitals-providers-summary-response.model';

export interface FadZipCodeSearchResponseModelInterface {
  cities: FZCSRCity[];
}

export interface FadPlanSearchResponseModelInterface extends GeneralErrorInterface {
  networks: FadVitalsNetworkInterface[];
}

export interface FadVitalsNetworkInterface {
  getNetwork(): FPSRPlan;
  setNetwork(network: FPSRPlan): FadVitalsNetworkInterface;
}

export interface FadVitalsProvidersSummaryResponseModelInterface {
  _meta: FVPSRMeta;
  provides: FVPSRProvider[];
}

export interface FadVitalsSearchHistoryResponseModelInterface {
  searchHistory: FVSHRSearchHistoryInterface[];
}

export interface FVSHRSearchHistoryInterface {
  planId: number;
  searchKeyword: string;
  zipcode: string;
  planName: string;
  userId: string;
  city: string;
  state: string;
  dependant: string;
  date: string;
}

export interface FadVitalsZipCodeSearchRequestModelInterface {
  place?: string;
  page?: number;
  limit: number;
  zip?: string;
  state?: string;
  city?: string;
  lat?: string;
  lng?: string;
  sort?: string;
}

export interface DoctorProfileSearchRequestModelInterface {
  professionalid: string;
  geo_location: string; // 'lattitude,longitude'
  network_id: string;
  userid: string;
  locationId: string;
}

export interface FacilityProfileSearchRequestModelInterface {
  facility: string;
  geolocation: string; // 'lattitude,longitude'
  network_id: string;
  location_id: string;
}

export interface FadPlanSearchRequestModelInterface {
  useridin: string;
}
