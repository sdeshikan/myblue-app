import { Injectable } from '@angular/core';
import { AlertService } from '../../shared/shared.module';
import { AlertType } from '../../shared/alerts/alertType.model';
import { Router } from '@angular/router';
import { FadConstants } from './constants/fad.constants';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class FadService {
  public fadConstants = FadConstants;
  public searchDataSource = new BehaviorSubject<any>('');

  constructor(private alertService: AlertService, private router: Router) {}

  /**
   * @description set service alerts
   */
  public setServiceAlert(title, type = AlertType.Failure, scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (JSON.stringify(errorList) === '{}' || errorList['component'] === '') {
      this.alertService.setAlert(title, '', type, scope);
    }
  }

  /**
   * @description clearing the service alerts
   */
  public clearServiceAlert(scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (errorList && errorList.hasOwnProperty(scope)) {
      this.resetServiceError();
    }
  }

  /**
   * @description Reset the service alerts
   */
  public resetServiceError(): void {
    this.alertService.resetErrorObject();
  }
  public reviewMyBenfits() {
    this.router.navigate([this.fadConstants.urls.reviewmybenfits]);
  }

  public requestWrittenEstimate() {
    this.router.navigate([this.fadConstants.urls.requestEstimateUrl]);
  }
}
