import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadConstants } from '../constants/fad.constants';
import { FadCostBenefitsModel, FadFacilityCostModel } from '../modals/fad-facility-profile-details.model';
import { FadCostBenefitsInterface, FadFacilityCostInterface } from '../modals/interfaces/fad-facility-profile-details.interface';

@Injectable()
export class FadCostBreakdownService {
  public costBenefitsData: FadCostBenefitsInterface = new FadCostBenefitsModel();
  public facilityCostData: FadFacilityCostInterface = new FadFacilityCostModel();
  public parentPage: string;
  public facilityData: any;
  constructor(private bcbsmaHttpService: BcbsmaHttpService) {}

  public getCostBreakDown() {
    const url = FadConstants.jsonurls.fadCostBreakDownUrl;
    // FadConstants.api.fadUrl + FadConstants.urls.fadCostBreakDownUrl :
    return this.bcbsmaHttpService.get(url);
  }
}
