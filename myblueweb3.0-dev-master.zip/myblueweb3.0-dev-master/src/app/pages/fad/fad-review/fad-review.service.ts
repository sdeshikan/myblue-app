import { AuthService } from '../../../shared/shared.module';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { Injectable } from '@angular/core';
import { FadConstants } from '../constants/fad.constants';

@Injectable()
export class FadReviewService {
  constructor(private authHttp: AuthHttp, private authService: AuthService) {}

  getReviewQuestions() {
    const request = {
      useridin: this.authService.useridin
    };
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    return this.authHttp.encryptPost(FadConstants.urls.fadGetReviewQuestons, request);
  }

  postReviewSubmitQuestions(questionsrequestobject) {
    const request = {
      useridin: this.authService.useridin
    };
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    request['reviewQuestions'] = questionsrequestobject;
    request['reviewIdentifier'] = sessionStorage.getItem('reviewIdentifier');

    return this.authHttp.encryptPost(FadConstants.urls.fadpostSubmitQuestions, request);
  }
}
