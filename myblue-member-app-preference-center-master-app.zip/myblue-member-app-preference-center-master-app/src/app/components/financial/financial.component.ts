import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DeductibleModel } from '../../models/deductible.model';

@Component({
  selector: 'app-financial',
  templateUrl: './financial.component.html',
  styleUrls: ['./financial.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FinancialComponent {
  @Input() financial: any;
  @Output() goToFinancialDetails = new EventEmitter();

  goToDetails() {
    this.goToFinancialDetails.emit(this.financial);
  }

  isHsaAccount(accountType) {
    return accountType === 'ABH' || accountType === 'HSA' || accountType === 'AB2';
  }
}
