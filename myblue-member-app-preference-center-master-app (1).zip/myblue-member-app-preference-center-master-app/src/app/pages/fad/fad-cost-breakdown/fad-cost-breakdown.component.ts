import { TitleCasePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FAD_CONSTANTS } from '../constants/fad.constants';

import { LineChartOptionsInterface } from '../../../shared/components/alegeus-line-chart/line-chart.interface';
import { LineChartOptions } from '../../../shared/components/alegeus-line-chart/line-chart.model';
import { FilterInterface } from '../../../shared/components/cost-breakdown-financialsfilter/filter.model';
import { GlobalService } from '../../../shared/services/global.service';
import { FadCostBreakdownService } from './fad-cost-breakdown.service';

import { HttpClient } from '@angular/common/http';
import { PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { CostBreakdownFilterComponent } from '../../../shared/components/cost-breakdown-financialsfilter/filter.component';
import { FilterSelection, FilterToggle } from '../../../shared/models/filter/filter.model';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadFacilityProfileRequestModel } from '../modals/fad-facility-profile-details.model';
import { FadDoctorProfileRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import {
  FadCostBenefitsInterface,
  FadFacilityCostInterface,
  FadFacilityProfileRequestModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { BreadCrumb } from '../utils/fad.utils';

@Component({
  selector: 'app-fad-cost-breakdown',
  templateUrl: './fad-cost-breakdown.component.html',
  styleUrls: ['./fad-cost-breakdown.component.scss']
})
export class FadCostBreakdownComponent implements OnInit {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getMLEEligibility) mleEligibility: string;

  public fadConstants = FAD_CONSTANTS;
  public hideMainContentOnFilterToggleForMobile = false;
  public filterConfig: FilterInterface;
  public totalCostbreakDownData: FadFacilityCostInterface;
  public costBreakdownData: FadCostBenefitsInterface;
  public memberFirstName: string;
  public selectedMember: string;
  public isProcedure: boolean;
  public procedureTitle: string;
  public parentPage = '';
  public mobileHideByFilterOverlay = false;
  public breakdownCostFlag = false;
  public totalCostbreakDownDataFlag = false;
  public showFamilyGraph = false;
  public relation = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private fadCostBreakdownService: FadCostBreakdownService,
    private globalService: GlobalService,
    private titleCase: TitleCasePipe,
    private fadSearchResultsService: FadSearchResultsService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    public landingPageService: FadLandingPageService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private fadService: FadService,
    private http: HttpClient,
    private cdRef: ChangeDetectorRef,
    private popoverController: PopoverController
  ) {
    this.totalCostbreakDownData = this.fadCostBreakdownService.facilityCostData;
    this.costBreakdownData = this.fadCostBreakdownService.costBenefitsData;
    this.parentPage = this.fadCostBreakdownService.parentPage;
    this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0
      ? (this.breakdownCostFlag = true)
      : (this.breakdownCostFlag = false);

    this.totalCostbreakDownDataFlag =
      this.totalCostbreakDownData.copay != null &&
      this.totalCostbreakDownData.coinsuranceAmount != null &&
      this.totalCostbreakDownData.deductibleAmount != null;

    if (this.parentPage === undefined) {
      const parentPage = sessionStorage.getItem('cost-breakdown-parent');

      if (parentPage === this.fadConstants.text.facilityPage) {
        this.router.navigate(['/fad/facility-profile']);
      } else if (parentPage === this.fadConstants.text.doctorPage) {
        this.router.navigate(['/fad/doctor-profile']);
      }
    } else {
      sessionStorage.setItem('cost-breakdown-parent', this.parentPage);
    }
  }

  ngOnInit() {
    this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Cost Breakdown').setUrl('/fad/cost-breakdown'));

    this.filterConfig = {
      items: [
        {
          list: [],
          type: 'radio',
          divider: false,
          multi: false,
          headerText: 'Member',
          hideToggle: false,
          expanded: false,
          disabled: false,
          disableRipple: false,
          collapsedHeight: null,
          expandedHeight: '44px',
          titlecase: false
        }
      ],
      hasSearch: false
    };
    this.memberFirstName = this.authToken && this.authToken.firstName ? this.authToken.firstName : '';
    this.landingPageService.getVitalsDependantList().subscribe(response => {
      for (let i = 0; i < response.membersInfoList.length; i++) {
        const selectedvalue = false;
        const relation = response.membersInfoList[i].relation;
        if (sessionStorage.getItem('fadVendorMemberNumber')) {
          if (response.membersInfoList[i].fadVendorMemberNumber === sessionStorage.getItem('fadVendorMemberNumber')) {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: true,
              disabled: false
            });
            this.relation = relation;
            this.selectedMember = response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')';
          } else {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: selectedvalue,
              disabled: false
            });
          }
        } else {
          if (relation === 'Subscriber') {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: true,
              disabled: false
            });
            this.relation = relation;
            this.selectedMember = response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')';
          } else {
            this.filterConfig.items[0].list.push({
              text: response.membersInfoList[i].subscriberFirstName + ' (' + relation + ')',
              value: response.membersInfoList[i].fadVendorMemberNumber,
              fadVendorMemberNumber: response.membersInfoList[i].fadVendorMemberNumber,
              selected: selectedvalue,
              disabled: false
            });
            // this.selectedMember = response.membersInfoList[i].subscriberFirstName;
          }
        }
      }

      if (this.filterConfig.items[0].list && this.filterConfig.items[0].list.length === 1 && this.relation !== 'Subscriber') {
        this.showFamilyGraph = true;
      }
    });
    // this.memberFirstName = this.titleCase.transform(this.memberFirstName);

    // if (userFullName !== "undefined undefined") {
    //   this.selectedMember = userFullName;
    // } else {
    //   this.selectedMember = this.memberFirstName;
    // }

    // console.log("relation",this.relation);
    // console.log("length",this.filterConfig.items[0].list);
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    // const isProcedure = searchCriteria.getSearchText().getIsProcedure();
    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
      this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
    }
  }

  async handleFilter($event: any) {
    const popover = await this.popoverController.create({
      component: CostBreakdownFilterComponent,
      event: $event,
      mode: 'ios',
      cssClass: 'cost-breakdown-filter',
      componentProps: {
        filterConfig: this.filterConfig
      }
    });
    await popover.present();
    from(popover.onDidDismiss())
      .pipe(
        filter(event => event && event.data !== undefined),
        map(event => event.data)
      )
      .subscribe(filterConfig => {
        this.filterConfig.items[filterConfig.filterItemNumber].list.forEach(item => {
          item.selected = filterConfig.selectedOption === item.value;
        });
        this.onRadioButtonChange(filterConfig);
      });
  }

  public getCostBreakDownData(event) {
    if (this.parentPage === 'doctor') {
      const professionalId = parseInt(sessionStorage.getItem('professionalId'), 10);
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FAD_CONSTANTS.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setProfessional(professionalId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FAD_CONSTANTS.defaults.radius);
      }

      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }
      const mleIndicator = this.mleEligibility;
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = event.selectedOption;
      }

      this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(
        data => {
          if (data && Object.keys(data).length > 0) {
            this.totalCostbreakDownData = data.locations[0].facilityCost;
            // tslint:disable-next-line:prefer-conditional-expression
            if (
              this.totalCostbreakDownData.copay === null ||
              this.totalCostbreakDownData.coinsuranceAmount === null ||
              this.totalCostbreakDownData.deductibleAmount === undefined ||
              this.totalCostbreakDownData.copay === undefined
            ) {
              this.totalCostbreakDownDataFlag = false;
            } else {
              this.totalCostbreakDownDataFlag = true;
            }
            this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0
              ? (this.breakdownCostFlag = true)
              : (this.breakdownCostFlag = false);
            this.costBreakdownData = data.locations[0].costBenefit;
          }
        }
      );
    } else if (this.parentPage === 'facility') {
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'), 10);
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FAD_CONSTANTS.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));

      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FAD_CONSTANTS.defaults.radius);
      }

      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }
      const mleIndicator = this.mleEligibility;
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = event.selectedOption;
      }

      this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(
        data => {
          if (data && Object.keys(data).length > 0) {
            this.totalCostbreakDownData = data.facility.location[0].facilityCost;
            this.totalCostbreakDownData && this.totalCostbreakDownData.copay > 0
              ? (this.breakdownCostFlag = true)
              : (this.breakdownCostFlag = false);
            this.costBreakdownData = data.facility.location[0].costBenefit;
          }
        },
        error => {

        }
      );
      this.cdRef.detectChanges();
    }
  }

  public costBreakdownAsLineChartOptions(chartNumber = FAD_CONSTANTS.text.chart1) {
    const linechartOption: LineChartOptionsInterface = new LineChartOptions();
    try {
      if (this.selectedMember === 'Family') {
        switch (chartNumber) {
          case FAD_CONSTANTS.text.chart1:
            linechartOption.headerText = FAD_CONSTANTS.text.chart1HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart1Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart1Param2Text;
            linechartOption.chartOption3Text = FAD_CONSTANTS.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.overallDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.overallDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FAD_CONSTANTS.text.chart2BarColorRemaining;
            break;
          case FAD_CONSTANTS.text.chart2:
            linechartOption.headerText = FAD_CONSTANTS.text.chart2HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart2Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart2Param2Text;
            linechartOption.chartColor = FAD_CONSTANTS.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.familyOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.familyOutofPocketAccumulated;
            linechartOption.chartValue = linechartOption.AnnualElection - linechartOption.totalValue;
            break;
          default:
            break;
        }
      } else {
        switch (chartNumber) {
          case FAD_CONSTANTS.text.chart1:
            linechartOption.headerText = FAD_CONSTANTS.text.chart1HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart1Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart1Param2Text;
            linechartOption.chartOption3Text = FAD_CONSTANTS.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.individualDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.individualDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.showOption3 = true;
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.chartOption3BackgroundColor = FAD_CONSTANTS.text.chart2BarColorRemaining;
            break;
          case FAD_CONSTANTS.text.chart2:
            linechartOption.headerText = FAD_CONSTANTS.text.chart2HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart2Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart2Param2Text;
            linechartOption.chartOption3Text = FAD_CONSTANTS.text.chart1Param3Text;
            linechartOption.chartColor = FAD_CONSTANTS.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.individualOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.individualOutofPocketAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.memberCost;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FAD_CONSTANTS.text.chart2BarColorRemaining;
            // linechartOption.chartValue = (linechartOption.AnnualElection - linechartOption.totalValue);
            break;
          case FAD_CONSTANTS.text.chart3:
            linechartOption.headerText = FAD_CONSTANTS.text.chart1HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart1Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart1Param2Text;
            linechartOption.chartOption3Text = FAD_CONSTANTS.text.chart1Param3Text;
            linechartOption.AnnualElection = this.costBreakdownData.overallDeductibleLimit;
            linechartOption.totalValue = this.costBreakdownData.overallDeductibleAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.deductibleAmount;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FAD_CONSTANTS.text.chart2BarColorRemaining;
            break;
          case FAD_CONSTANTS.text.chart4:
            linechartOption.headerText = FAD_CONSTANTS.text.chart2HeaderText;
            linechartOption.chartOption1Text = FAD_CONSTANTS.text.chart2Param1Text;
            linechartOption.chartOption2Text = FAD_CONSTANTS.text.chart2Param2Text;
            linechartOption.chartOption3Text = FAD_CONSTANTS.text.chart1Param3Text;
            linechartOption.chartColor = FAD_CONSTANTS.text.chart2BarColor;
            linechartOption.AnnualElection = this.costBreakdownData.familyOutofPocketLimit;
            linechartOption.totalValue = this.costBreakdownData.familyOutofPocketAccumulated;
            linechartOption.chartOption3Value = this.totalCostbreakDownData.memberCost;
            linechartOption.chartValue = linechartOption.AnnualElection - (linechartOption.totalValue + linechartOption.chartOption3Value);
            linechartOption.chartValue = linechartOption.chartValue < 0 ? 0 : linechartOption.chartValue;
            linechartOption.showOption3 = true;
            linechartOption.chartOption3BackgroundColor = FAD_CONSTANTS.text.chart2BarColorRemaining;
            break;
          default:
            break;
        }
      }
    } catch (exception) {}

    return linechartOption;
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  public convertAmountToDecimalValue(value) {
    const intPart = Math.trunc(value);
    const floatPart = Number((value - intPart).toFixed(2));
    const decimal: string[] = floatPart.toString().split('.');
    if (!decimal[1]) {
      return '00';
    }
    return decimal[1];
  }

  toggleFilter(event: FilterToggle) {
    this.hideMainContentOnFilterToggleForMobile = !this.hideMainContentOnFilterToggleForMobile;

    // toggle filter section display as necessary
    this.mobileHideByFilterOverlay = !!this.hideMainContentOnFilterToggleForMobile;
  }

  applyFilter(event: FilterSelection) {}

  clearFilter(event: FilterSelection) {
    this.hideMainContentOnFilterToggleForMobile = false;
  }

  onRadioButtonChange(event: any) {
    this.getCostBreakDownData(event);
    sessionStorage.setItem('fadVendorMemberNumber', event.selectedOption);
    this.selectedMember = this.filterConfig.items[0].list.find(p => p.fadVendorMemberNumber === event.selectedOption).text;
    this.hideMainContentOnFilterToggleForMobile = false;
    this.mobileHideByFilterOverlay = false;
  }
}
