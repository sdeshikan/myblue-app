import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AlertService } from '../../../shared/services/alert.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { MyAccountsConstants } from '../constants/my-accounts.constants';
import { MyAccountConstants } from '../my-account.constants';
import { MyAccountService } from '../my-account.service';
declare let $: any;

@Component({
  selector: 'app-confirmidentity',
  templateUrl: './confirmidentity.component.html',
  styleUrls: ['./confirmidentity.component.scss']
})
export class ConfirmidentityComponent implements OnInit, OnDestroy {
  dobMask: any[];
  identityForm: FormGroup;
  dobMessages = {
    required: 'Please enter a valid date of birth.'
  };
  private caller: any;
  private clearAlertOnDestroy = true;

  constructor(
    private fb: FormBuilder,
    private myAccountService: MyAccountService,
    private router: Router,
    private globalService: GlobalService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private validationService: ValidationService,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService
  ) {
    try {
      this.identityForm = this.fb.group({
        dob: ['', [Validators.required, this.validationService.dateValidator(), this.validationService.dobValidator()]]
      });
      this.dobMask = this.validationService.dobMask;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.confirmIdentityComponent,
        MyAccountsConstants.methods.constructor
      );
    }
  }

  ngOnInit() {
    try {
      this.alertService.clearError();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.confirmIdentityComponent,
        MyAccountsConstants.methods.ngOnInit
      );
    }
  }

  ngOnDestroy() {
    if (this.clearAlertOnDestroy) {
      this.alertService.clearError();
    }
  }

  handleVerifiedResponse() {
    //Security Fixes

    try {
      //   //for now in secuirty fixes
      this.clearAlertOnDestroy = false;
      this.alertService.setAlert(MyAccountConstants.NotificationMsg, '', AlertType.Notification);
      this.myAccountService.clearStorage();
      //sessionStorage.setItem('otpsuccess', 'TRUE');
      this.router.navigate(['/login']).then(() => {
        this.alertService.setAlert('Please check your email account or mobile number for your username.', '', AlertType.Success);
      });
      // }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.confirmIdentityComponent,
        MyAccountsConstants.methods.handleVerifiedResponse
      );
    }
  }

  onSubmit() {
    try {
      const request = this.identityForm.value;
      this.alertService.clearError();
      this.myAccountService.confirmIdentity(request).subscribe(res => {
        if (res && (res['result'] === '0' || res['result'] === 0)) {
          this.handleVerifiedResponse();
        } else if (res['result'] < 0) {
          this.globalService.handleError(res, this.constants.displayMessage);
        }
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.confirmIdentityComponent,
        MyAccountsConstants.methods.onSubmit
      );
    }
  }
}
