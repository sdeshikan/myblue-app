import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-first-time.page',
  templateUrl: './first-time.page.component.html',
  styleUrls: ['./first-time.page.component.scss'],
})
export class FirstTimePage implements OnInit {

  constructor(
    private route: Router
  ) { }

  goHome() {
    this.route.navigate(['tabs/home']);
  }

  ngOnInit() {}

}
