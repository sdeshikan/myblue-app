import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { DeductibleModule } from '../../components/deductible/deductible.module';
import { AlertsModule } from '../../shared/alerts/alerts.module';
import { PromoCarouselModule } from '../../shared/components/promo/promo-carousel/promo-carousel.module';
import { PromoImagesModule } from '../../shared/components/promo/promo-images/promo-images.module';
import { HomeService } from '../../shared/services/home.service';
import { HomePageComponent } from './home-page.component';
import { HomeGuard } from './home.guard';
import { FinancialChartModule } from '../../shared/components/financial-chart/financial-chart.module';
import { CamelCaseModule } from '../../pipes/camelcase/camel-case.module';
import { NgxMaskModule } from 'ngx-mask';
import { CasingForFilterModule } from '../../pipes/casingForFilter/casing-for-filter.module';
import { ClaimIdModule } from '../../pipes/claim-id/claim-id.module';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent,
    canActivate: [HomeGuard],
    runGuardsAndResolvers: 'always'
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IonicStorageModule.forRoot(),
    RouterModule.forChild(routes),
    DeductibleModule,
    AlertsModule,
    PromoCarouselModule,
    PromoImagesModule,
    FinancialChartModule,
    CamelCaseModule,
    NgxMaskModule,
    CasingForFilterModule,
    ClaimIdModule
  ],

  providers: [
    HomeGuard,
    HomeService,
    InAppBrowser,
    AppRate
  ],
  declarations: [
    HomePageComponent
  ]
})
export class HomePageModule {}
