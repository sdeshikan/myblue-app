import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';

@Component({
  selector: 'app-popover',
  templateUrl: './popover.component.html',
  styleUrls: ['./popover.component.scss'],
})
export class PopoverComponent implements OnInit {

  tooltip: any;

  constructor(private navParams: NavParams) { }

  ngOnInit() {
    console.log(this.navParams);
    this.tooltip = this.navParams.data.tooltip;
  }

}
