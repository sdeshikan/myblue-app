import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ReimbursementNotEligibleComponent } from './reimbursement-not-eligible.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [ReimbursementNotEligibleComponent],
  declarations: [ReimbursementNotEligibleComponent]
})
export class ReimbursementNotEligibleModule {}
