import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { AppSelectors } from '../../store/selectors/app-selectors';

@Injectable()
export class HomeGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const scopename = this.authToken ? this.authToken.scopename : '';

    switch (scopename) {
      case 'AUTHENTICATED-NOT-VERIFIED': {
        if (this.authToken.migrationtype !== 'NONE') {
          this.router.navigate(['member-migration']);
        } else {
          sessionStorage.setItem('accesscode', 'true');
          sessionStorage.setItem('isReqCode', 'true');
          this.router.navigate(['/register/verifyaccesscode']);
          return false;
        }
      }

      // tslint:disable-next-line:no-switch-case-fall-through
      case 'AUTHENTICATED-AND-VERIFIED': {
        if (this.authToken.migrationtype !== 'NONE') {
          this.router.navigate(['member-migration']);
          return false;
        } else {
          return true;
        }
      }
      default:
        return true;
    }
  }
}
