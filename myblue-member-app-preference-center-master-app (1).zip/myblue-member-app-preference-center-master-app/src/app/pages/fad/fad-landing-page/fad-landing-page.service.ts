import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { v4 as uuid } from 'uuid';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { HashMapInterface } from '../../financials/models';
import { HashMap } from '../../financials/utils/all-transaction.utilities';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import {
  FadAutoCompleteOptionForSearchText,
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  FadMembersInfoRequestModel
} from '../modals/fad-landing-page.modal';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';
import {
  FadLandingPageSearchControlsModelInterface,
  FadLandingPageSearchControlValuesInterface,
  FadMembersInfoRequestModelInterface,
  FadMembersInfoResponseModelInterface,
  LandingPageResponseCacheModelInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  DoctorProfileSearchRequestModelInterface,
  FadVitalsZipCodeSearchRequestModelInterface,
  FadZipCodeSearchResponseModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { GetSearchByFacilityResponseModelInterface } from '../modals/interfaces/getSearchByFacility-models.interface';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { GetSearchByProviderRequestModelInterface } from '../modals/interfaces/getSearchByProvider-models.interface';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';

@Injectable()
export class FadLandingPageService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  public vitalsZipCodeInfo: FadZipCodeSearchResponseModelInterface = null;
  public cachedResponse: LandingPageResponseCacheModelInterface = null;
  public planNetworkData = null;
  public showAutoCompleteDropDownSpinner = false;
  private cachedSearchControlState: FadLandingPageSearchControlsModelInterface = null;
  private cachedSearchTextLookupOptions: HashMapInterface<FadAutoCompleteOptionForSearchText[]> = new HashMap<
    FadAutoCompleteOptionForSearchText[]
  >();
  private cachedZipCodeLookupOptions: HashMapInterface<FZCSRCity[]> = new HashMap<FZCSRCity[]>();

  constructor(
    private bcbsmaHttpService: BcbsmaHttpService,
    private http: HttpClient,
    private constants: ConstantsService,
    private fadSearchResultsService: FadSearchResultsService
  ) {}

  public getCachedZipCodeLookupOptions(searchText: string): FZCSRCity[] {
    return this.cachedZipCodeLookupOptions.get(searchText);
  }
  public setCachedZipCodeLookupOptions(searchText: string, zipCodeLookupOptions: FZCSRCity[]): FadLandingPageService {
    this.cachedZipCodeLookupOptions.put(searchText, zipCodeLookupOptions);
    return this;
  }

  public getCachedSearchTextLookupOptions(key: string): FadAutoCompleteOptionForSearchText[] {
    let options: FadAutoCompleteOptionForSearchText[] = this.cachedSearchTextLookupOptions.get(key);
    if (!options) {
      const keyEntities = key.split('~');
      options = this.cachedSearchTextLookupOptions.get(`${keyEntities[0]}~`);
    }
    return options;
  }

  public setCachedSearchTextLookupOptions(searchText: string, lookupOptions: FadAutoCompleteOptionForSearchText[]): FadLandingPageService {
    this.cachedSearchTextLookupOptions.put(searchText, lookupOptions);
    return this;
  }

  getVitalsAutoCompleteSearchResponse(request: GetSearchByProviderRequestModelInterface): Observable<any> {
    this.showAutoCompleteDropDownSpinner = true;

    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    const url = FAD_CONSTANTS.urls.fadLandingPageSearchAutocompleteListUrl;

    return this.http.post(url, request);
  }

  getVitalsZipCodeInfo(
    vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface
  ): Observable<FadZipCodeSearchResponseModelInterface> {
    let url;

    if (vitalsZipCodeSearchRequest.city || vitalsZipCodeSearchRequest.zip || vitalsZipCodeSearchRequest.state) {
      // tslint:disable-next-line:max-line-length
      url = `${FAD_CONSTANTS.urls.fadLandingPageZipcodeAutocompleteListUrl}?city=${vitalsZipCodeSearchRequest.city}&state_code=${vitalsZipCodeSearchRequest.state}&zip=${vitalsZipCodeSearchRequest.zip}`;
    } else if (
      vitalsZipCodeSearchRequest.lat &&
      vitalsZipCodeSearchRequest.lng &&
      vitalsZipCodeSearchRequest.sort &&
      vitalsZipCodeSearchRequest.limit
    ) {
      // tslint:disable-next-line:max-line-length
      url = `${FAD_CONSTANTS.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&lat=${vitalsZipCodeSearchRequest.lat}&lng=${vitalsZipCodeSearchRequest.lng}&sort=${vitalsZipCodeSearchRequest.sort}`;
    } else {
      // tslint:disable-next-line:max-line-length
      url = `${FAD_CONSTANTS.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&place=${vitalsZipCodeSearchRequest.place}`;
    }
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };

    return this.http.get<FadZipCodeSearchResponseModelInterface>(url, httpOptions);
  }

  getVitalsDependantList(): Observable<any> {
    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.useridin;
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    const url = FAD_CONSTANTS.urls.fadLandingPageDependentsListUrl;
    return this.http.post(url, request);
  }

  getProcedureSummary() {
    const procedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    procedureSearchReq.setUserId(this.useridin).setLocale(FAD_CONSTANTS.defaults.locale + '');
    if (this.hccsFlag !== null) {
      procedureSearchReq['hccsFlag'] = this.hccsFlag;
    }
    if (sessionStorage.getItem('fadVendorMemberNumber')) {
      procedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FAD_CONSTANTS.urls.fadVitalsProcedureUrl;
    return this.http.post(url, procedureSearchReq);
  }

  getCachedSearchControlState(): FadLandingPageSearchControlsModelInterface {
    return this.cachedSearchControlState;
  }

  setCachedSearchControlState(
    searchControlState: FadLandingPageSearchControlsModelInterface | FadLandingPageSearchControlValuesInterface
  ): FadLandingPageService {
    this.cachedSearchControlState = new FadLandingPageSearchControlsModel();
    if (searchControlState instanceof FadLandingPageSearchControlsModel) {
      this.cachedSearchControlState.setControls(
        searchControlState as FadLandingPageSearchControlsModelInterface,
        this.fadSearchResultsService
      );
    } else {
      this.cachedSearchControlState.setValues(searchControlState as FadLandingPageSearchControlValues);
    }
    return this;
  }

  clearCachedSearchControlState(): FadLandingPageService {
    this.cachedSearchControlState = null;
    return this;
  }

  getToolTipInfo() {
    const toolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if (this.useridin && this.useridin !== 'undefined') {
      toolTipReq.setUserId(this.useridin);
    }
    toolTipReq['categoryType'] = 'All';
    const url = FAD_CONSTANTS.urls.fadVitalsToolTipsInfo;
    return this.http.post(url, toolTipReq);
  }
}
