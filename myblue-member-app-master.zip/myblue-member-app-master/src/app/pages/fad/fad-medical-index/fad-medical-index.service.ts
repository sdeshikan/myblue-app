import { Injectable } from '@angular/core';
import { FadMedicalIndexRequestModal } from '../modals/fad-medical-index.modal';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { Observable } from 'rxjs/Observable';
import { FadConstants } from '../constants/fad.constants';
import { FadMedicalIndexParamType } from '../modals/types/fad.types';
import {
  GetSearchBySpecialityResponseModelInterface,
  GetSearchBySpecialityRequestModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { AuthService } from '../../../shared/shared.module';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { map } from 'rxjs/operators';

@Injectable()
export class FadMedicalIndexService {
  constructor(private bcbsmaHttpService: BcbsmaHttpService, private http: AuthHttp, private authService: AuthService) {}

  public fetchMedicalIndex(request: FadMedicalIndexRequestModal): Observable<GetSearchBySpecialityResponseModelInterface> {
    if (request.type === FadMedicalIndexParamType.procedures) {
      // Once We received URL have to update in (FadConstants.urls.fadVitalsProcedureUrl)
      const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
      ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
      if (this.authService.getFadHccsFlag() !== null) {
        ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }

      if (this.authService.useridin) {
        ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      return this.http.encryptPost(FadConstants.urls.fadVitalsProcedureUrl, ProcedureSearchReq);
    } else if (request.type === FadMedicalIndexParamType.specialities) {
      const specialitySearchReq: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        specialitySearchReq.setUserId(this.authService.useridin);
      }
      if (this.authService.getFadHccsFlag() !== null) {
        specialitySearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }
      specialitySearchReq.setNetworkId(FadConstants.defaults.networkId);
      console.log('about to call it !!!!!!!!!!!!!!!!!!!!!');
      return this.http.encryptPost(FadConstants.urls.fadVitalsSpecialitiesUrl, specialitySearchReq);
    }
  }
}
