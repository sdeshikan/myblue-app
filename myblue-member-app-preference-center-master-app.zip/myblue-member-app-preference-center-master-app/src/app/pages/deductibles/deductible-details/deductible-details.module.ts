import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { DeductibleDetailsPage } from './deductible-details.page';
import { DeductibleListItemModule } from '../../../components/deductible-list-item/deductible-list-item.module';

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule, DeductibleListItemModule],
  declarations: [DeductibleDetailsPage]
})
export class DeductibleDetailsModule {}
