import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FadCostBreakdownComponent } from './fad-cost-breakdown.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FadCostBreakdownService } from './fad-cost-breakdown.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { DependantsService } from '../../../shared/services/dependant.service';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadService } from '../fad.service';
import { PopoverController } from '@ionic/angular';

describe('FadCostBreakdownComponent', () => {
  let component: FadCostBreakdownComponent;
  let fixture: ComponentFixture<FadCostBreakdownComponent>;

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [
        FadCostBreakdownService,
        BcbsmaHttpService,
        AuthService,
        ConstantsService,
        GlobalService,
        AlertService,
        AuthHttp,
        DependantsService,
        TitleCasePipe,
        DatePipe,
        FadSearchResultsService,
        FadBreadCrumbsService,
        FadFacilityProfileService,
        FadLandingPageService,
        FadDoctorProfileService,
        FadService,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      declarations: [FadCostBreakdownComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadCostBreakdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
