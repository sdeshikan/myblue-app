import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatToolbarModule,
  MatSidenavModule,
  MatIconModule,
  MatCardModule,
  MatMenuModule,
  MatExpansionModule,
  MatDialogModule,
  MatFormFieldModule,
  MatCheckboxModule,
  MatRadioModule,
  MatListModule,
  MatListItem,
  MatDatepickerModule,
  MatCalendar,
  MatNativeDateModule,
  MatInputModule,
  MatTabsModule,
  MatSelectModule
} from '@angular/material';

@NgModule({
  imports: [
    MatButtonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatCardModule,
    MatMenuModule,
    MatExpansionModule,
    MatDialogModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatRadioModule,
    MatListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatTabsModule,
    MatSelectModule
  ],
  exports: [
    MatButtonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatCardModule,
    MatMenuModule,
    MatExpansionModule,
    MatDialogModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatRadioModule,
    MatListModule,
    MatDatepickerModule,
    MatListItem,
    MatCalendar,
    MatNativeDateModule,
    MatInputModule,
    MatTabsModule,
    MatSelectModule
  ]
})
export class MaterialModule {}
