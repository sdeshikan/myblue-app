import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { LoginAppPage } from './login-app.page';
import { LoginService } from './login.service';
import { SharedModule } from '../../shared/shared.module';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { Keychain } from '@ionic-native/keychain/ngx';

const routes: Routes = [
  {
    path: '',
    component: LoginAppPage,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, IonicModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [LoginAppPage],
  providers: [FingerprintAIO, LoginService, Keychain]
})
export class LoginAppPageModule {}
