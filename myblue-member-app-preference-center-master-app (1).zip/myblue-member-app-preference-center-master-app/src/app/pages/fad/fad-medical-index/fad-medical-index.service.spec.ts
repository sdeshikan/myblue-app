import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadMedicalIndexService } from './fad-medical-index.service';

describe('FadMedicalIndexService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadMedicalIndexService, BcbsmaHttpService, ConstantsService]
    });
  });

  it('should be created', inject([FadMedicalIndexService], (service: FadMedicalIndexService) => {
    expect(service).toBeTruthy();
  }));
});
