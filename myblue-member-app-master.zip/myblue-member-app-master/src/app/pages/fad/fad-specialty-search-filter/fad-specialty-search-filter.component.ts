import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChild,
  ElementRef,
  OnChanges,
  SimpleChanges,
  ChangeDetectorRef,
  OnDestroy
} from '@angular/core';
import {
  FadSpecialtyFilterComponentOutputModelInterface,
  FilterListItemInterface,
  FilterCheckboxItemInterface,
  GrpHospitalAffiliationFilterListItemInterface,
  FilterRadioItemInterface
} from '../modals/interfaces/fad-search-filter.interface';
import { FadSpecialtyFilterComponentOutputModel, FilterRadioItem } from '../modals/fad-search-filter.modal';

import { FadConstants } from '../constants/fad.constants';
import { MatSidenav } from '@angular/material';
import { GlobalService } from '../../../shared/services/global.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadSpecialtyListComponentInputModelInterface } from '../modals/interfaces/fad-search-list.interface';
import { FiltersMetadataInterface, SortMetadataInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

import { FiltersMetadata, SortMetadata } from '../modals/getSearchByProfessional.model';
import { FadSpecialtyListComponentInputModel } from '../modals/fad-search-list.modal';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { Subscription } from 'rxjs';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

import { FadProviderFacilityListService } from '../fad-provider-facility-list/fad-provider-facility-list.service';
import { PopoverController, NavParams } from '@ionic/angular';
import {
  GetSearchBySpecialtyResponseModelInterface,
  SpecialtyFacetsListInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import {
  FadAutoCompleteComplexOptionInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';

@Component({
  selector: 'app-specialty-search-filter',
  templateUrl: './fad-specialty-search-filter.component.html',
  styleUrls: ['./fad-specialty-search-filter.component.scss']
})
export class FadSpecialtySearchFilterComponent implements OnInit, OnChanges, OnDestroy {
  @Output('componentOutput') componentOutput = new EventEmitter<FadSpecialtyFilterComponentOutputModelInterface>();
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;

  // being used both the html view and the component(this file)
  public isDisplayFilter = false;
  public fadConstants;
  public outputTransaction: FadSpecialtyFilterComponentOutputModelInterface = new FadSpecialtyFilterComponentOutputModel();

  // flag values used bound to the view alone (html tags)
  public collapsedSortHeight: string;
  public expandedSortHeight: string;
  public sortSelectedFilter: string;
  public collapsedHeight: string;
  public expandedHeight: string;

  @Input('componentFilterInput')
  componentFilterInput: FadSpecialtyListComponentInputModelInterface = new FadSpecialtyListComponentInputModel();
  public searchResponse: GetSearchBySpecialtyResponseModelInterface;
  public facetsList: SpecialtyFacetsListInterface;
  public locationGeoList: FilterListItemInterface[] = [];
  public modifiedlocationGeoList: FilterListItemInterface[] = [];
  public languagesList: FilterListItemInterface[] = [];
  public providerList: FilterListItemInterface[] = [];
  public genderList: FilterListItemInterface[] = [];
  public ratingList: FilterListItemInterface[] = [];
  public agesTreatedList: FilterListItemInterface[] = [];
  public specialtyList: FilterListItemInterface[] = [];
  public disordersTreatedList: FilterListItemInterface[] = [];
  public treatmentMethodsList: FilterListItemInterface[] = [];
  public groupAffiliationList: GrpHospitalAffiliationFilterListItemInterface[] = [];
  public hospitalAffiliationList: GrpHospitalAffiliationFilterListItemInterface[] = [];
  public acceptingNewPatientsCheckbox: FilterCheckboxItemInterface;
  public techSavvyCheckbox: FilterCheckboxItemInterface;
  public inNetworkOnlyCheckbox: FilterCheckboxItemInterface;
  public primaryCareProviderCheckbox: FilterCheckboxItemInterface;
  public isChoicePcpCheckbox: FilterCheckboxItemInterface;
  public tiersList: FilterListItemInterface[] = [];
  public awardTypeCodesList: FilterListItemInterface[] = [];
  public bcdTypeCodesList: FilterListItemInterface[] = [];
  public cqmsList: FilterListItemInterface[] = [];

  public filterMetaData: FiltersMetadataInterface = new FiltersMetadata();
  public sortMetaData: SortMetadataInterface = new SortMetadata();
  public enableClearfilterFlag = false;
  public clearFilterFlagSubjectSubscription: Subscription;

  public showClearLink = false;

  public sortCurrentValue: string;
  public isSortExpanded: boolean;
  submenu: any = {};
  public sortList: FilterRadioItem[] = [
    {
      name: 'Last Name A-Z',
      value: 'provider_name_sortable+asc',
      checked: false
    },
    {
      name: 'Last Name Z-A',
      value: 'provider_name_sortable+desc',
      checked: false
    },
    {
      name: 'Best Match',
      value: 'relevancy+desc',
      checked: false
    },
    {
      name: 'Quality',
      value: 'clinical_quality+desc',
      checked: false
    }
  ];
  locationGeoListduplicate: FilterListItemInterface[];

  constructor(
    public globalService: GlobalService,
    private cdRef: ChangeDetectorRef,
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadProviderFacilityListService,
    private popoverController: PopoverController,
    private navParams: NavParams
  ) {
    this.fadConstants = FadConstants;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '56px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isSortExpanded = false;
    this.sortSelectedFilter = 'Cost';

    this.pushSortData();
  }

  ngOnInit() {
    this.clearFilterFlagSubjectSubscription = this.fadSearchResultsService.clearFilterFlagSubject$.subscribe(message => {
      if (message && message.clearFlag == true && message.type == FadResouceTypeCodeConfig.professional) {
        this.clearFilter();
      }
    });
    console.log(this.navParams.data);
    this.initialData(this.navParams.data);
  }
  initialData(data) {
    if (data) {
      this.searchResponse = data.specialtyListComponentInput.specialtyResults;

      if (this.searchResponse && this.searchResponse.facets) {
        this.facetsList = this.searchResponse.facets;
        console.log(this.sortList);
        if (this.searchResponse.sort == 'cost+asc' || data.isProcedureFlag) {
          this.sortSelectedFilter = 'Cost';
          const costFilterData = this.sortList.filter(filterData => {
            return filterData.name === 'Cost';
          });
          if (costFilterData && costFilterData.length < 1) {
            this.sortList.push(
              {
                name: 'Cost',
                value: 'cost+asc',
                checked: true
              },
              {
                name: 'Distance',
                value: 'distance+asc',
                checked: false
              }
            );
          }
        } else {
          const distanceFilterData = this.sortList.filter(filterData => {
            return filterData.name === 'Distance';
          });
          if (distanceFilterData && distanceFilterData.length < 1) {
            this.sortList.push({
              name: 'Distance',
              value: 'distance+asc',
              checked: true
            });
          }
        }
        this.manageFilter(this.facetsList);
      }

      if (this.searchResponse && this.searchResponse.sort) {
        this.sortCurrentValue = this.searchResponse.sort;
        this.manageSorting();
      }
      console.log(this.sortList);
    }
    console.log(this.filterMetaData, data.filterMetaData);
    this.filterMetaData = Object.assign(this.filterMetaData, data.filterMetaData ? data.filterMetaData : {});
    this.showClearLink = data.isFilterChanged;
  }
  ngOnChanges(changes: SimpleChanges) {
    try {
      if (changes) {
        console.log(changes, 'check here');
        this.componentFilterInput = changes.componentFilterInput.currentValue;
        if (this.componentFilterInput) {
          this.searchResponse = this.componentFilterInput.specialtyResults;

          if (this.searchResponse && this.searchResponse.facets) {
            this.facetsList = this.searchResponse.facets;

            if (this.searchResponse.sort == 'cost+asc') {
              this.sortSelectedFilter = 'Cost';
              const costFilterData = this.sortList.filter(filterData => {
                return filterData.name === 'Cost';
              });
              if (costFilterData && costFilterData.length < 1) {
                this.sortList.push(
                  {
                    name: 'Cost',
                    value: 'cost+asc',
                    checked: true
                  },
                  {
                    name: 'Distance',
                    value: 'distance+asc',
                    checked: false
                  }
                );
              }
            } else {
              const distanceFilterData = this.sortList.filter(filterData => {
                return filterData.name === 'Distance';
              });
              if (distanceFilterData && distanceFilterData.length < 1) {
                this.sortList.push({
                  name: 'Distance',
                  value: 'distance+asc',
                  checked: true
                });
              }
            }
            this.manageFilter(this.facetsList);
          }

          if (this.searchResponse && this.searchResponse.sort) {
            this.sortCurrentValue = this.searchResponse.sort;
            this.manageSorting();
          }
          this.cdRef.detectChanges();
        }
      }
    } catch (exception) {}
  }

  ngOnDestroy(): void {
    this.clearFilterFlagSubjectSubscription.unsubscribe();
  }

  public manageSorting() {
    this.sortList = this.sortList.map(sortObj => {
      if (this.sortCurrentValue && sortObj.value == this.sortCurrentValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });
  }

  public manageFilter(facetsList) {
    this.locationGeoList = facetsList.locationGeo ? [...facetsList.locationGeo] : [];
    this.genderList = facetsList.professionalGender ? facetsList.professionalGender : [];
    this.languagesList = facetsList.professionalLanguages ? facetsList.professionalLanguages : [];
    this.providerList = facetsList.providerType ? facetsList.providerType : [];
    this.ratingList = facetsList.overallRating ? facetsList.overallRating : [];
    this.agesTreatedList = facetsList.treatedTypeCodes ? facetsList.treatedTypeCodes : [];
    this.specialtyList = facetsList.fieldSpecialtyIds ? facetsList.fieldSpecialtyIds : [];
    this.disordersTreatedList = facetsList.disordersTreatedTypeCodes ? facetsList.disordersTreatedTypeCodes : [];
    this.treatmentMethodsList = facetsList.treatmentMethodsTypeCodes ? facetsList.treatmentMethodsTypeCodes : [];
    this.groupAffiliationList = facetsList.groupAffiliationIds ? facetsList.groupAffiliationIds : [];
    this.hospitalAffiliationList = facetsList.hospitalAffiliationIds ? facetsList.hospitalAffiliationIds : [];
    this.acceptingNewPatientsCheckbox = facetsList.acceptingNewPatients ? facetsList.acceptingNewPatients : null;
    this.techSavvyCheckbox = facetsList.techSavvy ? facetsList.techSavvy : null;
    this.inNetworkOnlyCheckbox = facetsList.inNetwork ? facetsList.inNetwork : null;
    this.primaryCareProviderCheckbox = facetsList.isPcp ? facetsList.isPcp : null;
    this.isChoicePcpCheckbox = facetsList.isChoicePcp ? facetsList.isChoicePcp : null;
    this.tiersList = facetsList.tiers ? facetsList.tiers : null;
    this.awardTypeCodesList = facetsList.awardTypeCodes ? facetsList.awardTypeCodes : null;
    this.bcdTypeCodesList = facetsList.bdcTypeCodes ? facetsList.bdcTypeCodes : null;
    this.cqmsList = facetsList.cqms ? facetsList.cqms : null;
    let itemslected = false;
    const modifiedlocationGeoList: FilterListItemInterface[] = [];
    console.log('this geolocationlist', this.locationGeoList);
    let firstelement = false;
    this.locationGeoListduplicate = this.locationGeoList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
      } else {
        firstelement = false;
      }
      return {
        ...item,
        count: itemslected && !firstelement ? 'N' : item.count
      };
      //  if(itemslected && !firstelement){
      //    item.count = "N";
      //  }
      //  console.log(item);
      //   modifiedlocationGeoList.push(item);
      //   console.log(modifiedlocationGeoList);
    });

    this.locationGeoList = this.locationGeoListduplicate;
  }

  public isSortOpened() {
    this.isSortExpanded = true;
  }

  public isSortClosed() {
    this.isSortExpanded = false;
  }

  /**
   * @description helps hide the sections other than the filter section and vice versa when the "Filter" dropdown is clicked in
   *  mobile screen only. Does not have any effect on the desktop screens
   */
  public toggleFilter() {
    this.isDisplayFilter = !this.isDisplayFilter;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.outputTransaction.filterCriteriaData = null;
    this.outputTransaction.sortCriteriaData = null;
    // this.componentOutput.emit(this.outputTransaction);
  }
  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
  }
  public applySortFilter() {
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.isDisplayFilter = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.enableClearfilterFlag = true;
    this.fadSearchListService.isFilterChanged(true);
    this.popoverController.dismiss(this.outputTransaction);
    this.componentOutput.emit(this.outputTransaction);
  }

  public clearFilter() {
    this.isSortExpanded = false;
    this.isDisplayFilter = false;
    this.enableClearfilterFlag = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.showClearLink = false;

    this.filterMetaData = new FiltersMetadata();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.fadSearchListService.isFilterChanged(true);
    this.popoverController.dismiss(this.outputTransaction);
    this.componentOutput.emit(this.outputTransaction);
  }

  /*
     To get the selected sorted criteria from the view/template while changing the options
  */
  public onSortItemChanged(selectedSortObject): void {
    const selectValue = selectedSortObject.target.value;
    this.sortList = this.sortList.map(sortObj => {
      if (selectValue && sortObj.value == selectValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });

    this.sortMetaData = selectedSortObject.target.value;
    this.showClearLink = true;
    this.applySortFilter();
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedProfessionalFilter(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    window.scroll(0, 0);
    switch (selectionListRadioBoxChange.target.name) {
      case 'filterLocation':
        this.filterMetaData.filterLocation = selectValue;
        break;
      case 'filterGender':
        this.filterMetaData.filterGender = selectValue;
        break;
      case 'filterLanguage':
        this.filterMetaData.filterLanguage = selectValue;
        break;
      case 'filterRating':
        this.filterMetaData.filterRating = selectValue;
        break;
      case 'filterAges':
        this.filterMetaData.filterAges = selectValue;
        break;
      case 'filterSpecialities':
        this.filterMetaData.filterSpecialities = selectValue;
        break;
      case 'filterDisorders':
        this.filterMetaData.filterDisorders = selectValue;
        break;
      case 'filterTreatment':
        this.filterMetaData.filterTreatment = selectValue;
        break;
      case 'filterHospitalAffilation':
        this.filterMetaData.filterHospitalAffilation = selectValue;
        break;
      case 'filterGroupAffilation':
        this.filterMetaData.filterGroupAffilation = selectValue;
        break;
      case 'filterCqms':
        this.filterMetaData.filterCqms = selectValue;
        break;
      case 'filterBcd':
        this.filterMetaData.filterBcd = selectValue;
        break;
      case 'filterAwards':
        this.filterMetaData.filterAwards = selectValue;
        break;
      case 'filterProviderType':
        this.filterMetaData.filterProviderType = selectValue;
        break;
      case 'filterTiers':
        this.filterMetaData.filterTiers = selectValue;
        break;
    }
    this.showClearLink = true;
    this.applySortFilter();
  }

  /*
      To get the selected filter criteria from the view/template while changing the options
   */
  public manageCheckboxProfessionalFilter(selectionChBoxChange) {
    console.log(selectionChBoxChange);
    const selectValue = selectionChBoxChange.detail.checked ? selectionChBoxChange.target.value : null;
    switch (selectionChBoxChange.target.name) {
      case 'filterPCP':
        this.filterMetaData.filterPCP = selectValue;
        break;
      case 'filterAcceptingNewPatients':
        this.filterMetaData.filterAcceptingNewPatients = selectValue;
        break;
      case 'filterTechSavvy':
        this.filterMetaData.filterTechSavvy = selectValue;
        break;
      case 'filterInNetwork':
        this.filterMetaData.filterInNetwork = selectValue;
        break;
      case 'filterisChoicePCP':
        this.filterMetaData.filterisChoicePcp = selectValue;
        break;
    }
    this.showClearLink = true;
    this.applySortFilter();
  }

  private pushSortData() {
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
    if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
      const newSortItem: FilterRadioItemInterface = {
        name: 'Ratings',
        value: 'aggregate_overall_rating+desc',
        checked: false
      };
      this.sortList.push(newSortItem);
    } else {
      const newSortItem: FilterRadioItemInterface = {
        name: 'Ratings',
        value: 'prs_overall_rating+desc,+prs_experience_of_care+desc',
        checked: false
      };
      this.sortList.push(newSortItem);
    }
  }
}
