import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { rxOrderSummaryModel } from "../../../../shared/models/rxordersummary.model";
import { MatExpansionPanel } from '@angular/material';
@Component({
  selector: 'app-rx-order-summary',
  templateUrl: './rx-order-summary.component.html',
  styleUrls: ['./rx-order-summary.component.scss']
})
export class RxOrderSummaryComponent implements OnInit {
  @Input('otcSummaryTotal') otcSummaryTotal: number;
  @Input('estimatedOrderTotal') estimatedOrderTotal: number;
  @Input('maintenanceMedicationsSummaryTotal') maintenanceMedicationsSummaryTotal: number;
  @Input('hasMaintenanceMeds') hasMaintenanceMeds: boolean;
  @Input('isAddingOTC') isAddingOTC: boolean;
  @Input('selectedMedications') selectedMedications :any[];
  @Input('selectedOTCs') selectedOTCs :any[];
  @Input('currentStep') currentStep: number;
  @Input('medicationsLength') medicationsLength:number;
  @Output() otcTotalChange = new EventEmitter<number>();
  _rxOrderSummary: rxOrderSummaryModel;
  _shippingAmountFreeText: string = "No Cost";
  _dispensorAmountFreeText: string = "No Cost";
  selectedMedicationTitle:string = "Show Details";
  selectedOTCTitle:string = "Show Details";
  doseType = {'T':'Tablet','C':'Capsule','S':'Spray','O':'Tube'};
  pluralDoseType = {'T':'Tablets','C':'Capsules','S':'Sprays','O':'Tubes'};

  constructor() {
  

  }

  ngDoCheck(){
    if (sessionStorage.getItem('selectedOTCs')!=""){
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
  }
  ngOnInit() {
    if (sessionStorage.getItem('selectedOTCs')!=""){
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    } 
 }

  getType(medication : any)
   {
     if(medication.orderDetails[0].orderCount==1){
      return this.doseType[medication.doseType];
     }else{
      return this.pluralDoseType[medication.doseType];
     }
   }

  closePanel(disCountedOTCs: MatExpansionPanel){
    disCountedOTCs.close();
  }

 

  onSelectedMedicationMatClick(matExpansionPanel: MatExpansionPanel){
    if(matExpansionPanel.expanded){
      this.selectedMedicationTitle = "Hide Details";
    } else {
      this.selectedMedicationTitle = "Show Details";
    }
  }
  onSelectedOTCMatClick(matExpansionPanel: MatExpansionPanel){
    if(matExpansionPanel.expanded){
      this.selectedOTCTitle = "Hide Details";
    } else {
      this.selectedOTCTitle = "Show Details";
    }
  }
  getBasePrice(price: number) {
    if (price != undefined)
   return ('' + price).split('.')[0];
   else return '';
 }

 getFloatPrice(price: number) {
   if (price != undefined)
   return price.toFixed(2).split('.')[1];
   else return '';
 }

  getBaseCostSum(medication: any) {
    return  this.getCost(medication).toString().split('.')[0];
   }
 
   getCost(medication: any){
     var cost = 0.00;
     var unitCost = medication.price/medication.count;
     medication.orderDetails.map(item =>{
       if(medication.inPackets){
         cost = cost + (unitCost * item.orderCount * 30);
       } else {
         cost = cost + (item.orderCount  * medication.price);
       }
    });
    return cost;
 }
 
  getFloatCostSum(medication: any) {
    return  this.getCost(medication).toFixed(2).toString().split('.')[1];
  }

  
}
