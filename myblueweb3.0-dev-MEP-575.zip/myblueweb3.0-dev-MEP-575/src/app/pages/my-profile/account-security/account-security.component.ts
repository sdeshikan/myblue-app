import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { AuthService } from '../../../shared/shared.module';

@Component({
  selector: 'app-account-security',
  templateUrl: './account-security.component.html',
  styleUrls: ['./account-security.component.scss']
})
export class AccountSecurityComponent implements OnInit, OnDestroy {
  profile: any;
  //aboutMeProfile: any;
  useridin: string = '';
  isUseridAPhone: boolean = false;
  diplayUserID: string = '';
  securityQuestionSetUp: boolean = false;
  canEdit: boolean = false;
  editAddress: boolean = false;
  editEmail: boolean = false;
  editPhone: boolean = false;
  editHint: boolean;
  profileHintEditForm: FormGroup;
  registeredUserOnly: boolean = false;
  typePlaceholder: string;
  type: string;
  editHintText = 'edit';
  securityQuestionsOptions = [
    {
      label: 'Who was your favorite teacher?',
      value: 'Who was your favorite teacher?'
    },
    {
      label: 'Where did you meet your spouse?',
      value: 'Where did you meet your spouse?'
    },
    {
      label: 'What is your Mother’s middle name?',
      value: 'What is your Mother’s middle name?'
    },
    {
      label: 'What is the name of your closest friend from childhood?',
      value: 'What is the name of your closest friend from childhood?'
    },
    {
      label: 'In what city or town does your nearest relative live?',
      value: 'In what city or town does your nearest relative live?'
    },
    {
      label: 'What was the name of your elementary school?',
      value: 'What was the name of your elementary school?'
    },
    {
      label: 'What was the name of your first pet?',
      value: 'What was the name of your first pet?'
    }
  ];
  hintAnswercustomMessages = {
    tralingspace: 'You must enter a valid hint answer',
    required: 'You must answer the hint question.',
    // tslint:disable-next-line:max-line-length
    invalidHintAnswer: "Incorrect answer. Please try again. Remember that your answer can't contain any spaces or special characters."
  };
  editPassword = false;
  editPasswordText = 'edit';
  typeCurrent: string;
  typePlaceholderCurrent: string;
  typeNew: string;
  typeReEnterNew: string;
  typePlaceholderNew: string;
  typePlaceholderReEnterNew: string;
  isFormSubmitted = false;
  updatePasswordForm: FormGroup;
  // added to resolve ng build --prod issue
  showPasswordErrors = false;
  showReEnterPasswordErrors = false;
  passwordcustomMessages = {
    required: 'You must enter a password.',
    invalidPassword: 'Your password does not match the minimum requirement. Please try again.',
    samePassword: "Your new password can't be the same as your old password.",
    confirmPassword: "Password doesn't match "
  };
  impersonate = true;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private fb: FormBuilder,
    private profileService: ProfileService,
    private validationService: ValidationService,
    private globalService: GlobalService,
    private constants: ConstantsService,
    private authService: AuthService
  ) {
    const numberRegEx = new RegExp('^[0-9]{10}');
    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    //this.aboutMeProfile = sessionStorage.getItem('memProfile') ? sessionStorage.getItem('memProfile') : '';
    this.useridin = sessionStorage.getItem('useridin');
    this.isUseridAPhone = numberRegEx.test(this.useridin) ? true : false;
    this.diplayUserID = this.isUseridAPhone ? this.maskPhoneNumberId(this.useridin) : this.useridin;
    // this.canEdit = this.profileService.authService.isSubscriber;
    this.typePlaceholder = 'Show';
    this.type = 'password';
    this.profileHintEditForm = this.fb.group({
      useridin: '',
      userState: '',
      hintQuestion: [this.getDefaultOptionForSecurityQuestions(), this.editHint ? [Validators.required] : []],
      hintAnswer: ['', this.editHint ? [Validators.required, Validators.minLength(3), Validators.maxLength(30)] : []]
    });
    //Update Password
    this.typeCurrent = 'password';
    this.typePlaceholderCurrent = 'Show';
    this.typeNew = 'password';
    this.typePlaceholderNew = 'Show';
    this.updatePasswordForm = this.fb.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', []],
      reEnterNewPassword: ['', []]
    });
    this.updatePasswordForm.controls['newPassword'].setValidators([
      Validators.required,
      Validators.minLength(8),
      this.validationService.invalidPasswordValidatorWrapper(),
      this.validationService.samePasswordValidator(this.updatePasswordForm.controls['currentPassword']),
      this.validationService.checkConfirmPasswordValidator(this.updatePasswordForm.controls['reEnterNewPassword'])
    ]);
    this.updatePasswordForm.controls['reEnterNewPassword'].setValidators([
      this.validationService.checkConfirmPasswordValidator(this.updatePasswordForm.controls['newPassword'], true)
    ]);
    this.alertService.clearError();
  }

  maskPhoneNumberId(userId: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    const subst = `$1-$2-$3`;
    const maskedUserId = userId ? userId.replace(regex, subst) : userId;
    return maskedUserId;
  }

  ngOnInit() {
    console.log('this.profile', this.profile);
    const userRole = this.profileService.getUserRole();
    this.registeredUserOnly = userRole === 'REGISTERED-NOT-VERIFIED' || userRole === 'REGISTERED-AND-VERIFIED' ? true : false;
    this.securityQuestionSetUp = this.profile.hintQuestion && this.profile.hintQuestion !== '' ? true : false;
    //Updated Password
    this.typeCurrent = 'password';
    this.typePlaceholderCurrent = 'Show';
    this.typeNew = 'password';
    this.typeReEnterNew = 'password';
    this.typePlaceholderNew = 'Show';
    this.typePlaceholderReEnterNew = 'Show';
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }

  navigateToUrl(url) {
    this.router.navigate([url]);
  }

  toggleHintVisibility() {
    this.alertService.clearError();
    this.editHint = !this.editHint;
    if (this.editHint) {
      this.editHintText = 'cancel';
      this.getFormDefinition();
    } else {
      this.editHintText = 'edit';
      this.profileService.fetchProfileInfo().subscribe(profile => {
        this.profile = Object.assign({}, profile);
        this.profileService.setProfile(this.profile);
        this.profileHintEditForm.patchValue(this.profile);
      });
    }
  }

  showEdit() {
    let rtnVal: boolean;
    rtnVal = this.profile.userState !== 'REGISTERED-NOT-VERIFIED';
    rtnVal = rtnVal && !this.profileService.authService.isSubscriber;
    rtnVal = rtnVal && this.profileHintEditForm.value.isEditableAddress;
    return rtnVal;
  }

  togglePasswordVisibility() {
    if (this.type === 'text') {
      this.type = 'password';
      this.typePlaceholder = 'Show';
    } else {
      this.type = 'text';
      this.typePlaceholder = 'Hide';
    }
  }

  onSubmit() {
    let alertMessageFinal = '';
    let alertType = '';
    let resultCode = 0;
    this.profileService
      .updateProfile(this.profileHintEditForm.value, this.editAddress, this.editEmail, this.editPhone, this.editHint)
      .flatMap(result => {
        resultCode = result.result;
        if (resultCode === -90129) {
          alertType = 'success';
          alertMessageFinal = result.displaymessage;
        } else if (resultCode === -90124 || resultCode === -90126) {
          alertType = 'error';
          alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
          alertMessageFinal = result.displaymessage;
          console.log('result.displaymessage=', result.displaymessage);
        }
        return this.profileService.fetchProfileInfo();
      })
      .subscribe(
        profile => {
          this.profile = profile;
          this.profileHintEditForm.patchValue(profile);
          this.profileService.setProfile(this.profile);

          let message = '';
          const addressSuccessMessage = '';
          if (alertMessageFinal === '') {
            message = this.editHint ? 'You have successfully updated your hint question and answer!' : message;
            this.alertService.setAlert(message, '', AlertType.Success, 'component', 'accountsecuritysuccess');
            this.resetAllEdits();
            this.editHintText = "edit";
            window.scrollTo(0, 0);
          } else {
            message = alertMessageFinal;
            this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'accountsecurityhintfailure');
          }
          this.resetAllEdits();
          this.editHintText = 'edit';
        },
        err => {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      );
  }

  resetAllEdits() {
    this.editHint = false;
    this.editPassword = false;
  }

  getFormDefinition() {
    this.profile = this.profileService.getProfile();
    console.log(this.profileHintEditForm);
    this.profileHintEditForm = this.fb.group({
      useridin: '',
      userState: '',
      hintQuestion: [this.getDefaultOptionForSecurityQuestions(), this.editHint ? [Validators.required] : []],
      hintAnswer: [
        '',
        this.editHint
          ? [Validators.required, Validators.minLength(3), Validators.maxLength(30), this.validationService.trailingSpaceValidator()]
          : []
      ]
    });
    this.profileHintEditForm.patchValue(this.profile);
  }

  getDefaultOptionForSecurityQuestions(): string {
    if (this.profile) {
      this.profile.hintQuestion =
        this.profile.hintQuestion &&
        this.profile.hintQuestion === '' &&
        this.securityQuestionsOptions &&
        this.securityQuestionsOptions.length > 0
          ? this.securityQuestionsOptions[0].value
          : this.profile.hintQuestion;
      return this.profile.hintQuestion;
    }
  }

  cancelHint() {
    this.resetAllEdits();
    this.editHintText = 'edit';
    this.profileService.fetchProfileInfo().subscribe(profile => {
      this.profile = Object.assign({}, profile);
      this.profileService.setProfile(this.profile);
      this.profileHintEditForm.patchValue(this.profile);
    });
  }

  togglePwdFormVisibility() {
    this.alertService.clearError();
    this.editPassword = !this.editPassword;
    if (this.editPassword) {
      this.editPasswordText = 'cancel';
      this.updatePasswordForm = this.fb.group({
        currentPassword: ['', [Validators.required]],
        newPassword: ['', []],
        reEnterNewPassword: ['', []]
      });
      this.updatePasswordForm.controls['newPassword'].setValidators([
        Validators.required,
        Validators.minLength(8),
        this.validationService.invalidPasswordValidatorWrapper(),
        this.validationService.samePasswordValidator(this.updatePasswordForm.controls['currentPassword']),
        this.validationService.checkConfirmPasswordValidator(this.updatePasswordForm.controls['reEnterNewPassword'])
      ]);
      this.updatePasswordForm.controls['reEnterNewPassword'].setValidators([
        this.validationService.checkConfirmPasswordValidator(this.updatePasswordForm.controls['newPassword'], true)
      ]);
    } else {
      this.editPasswordText = 'edit';
    }
  }

  currentPasswordKeyUp() {
    this.updatePasswordForm.controls['newPassword'].setValue(this.updatePasswordForm.controls['newPassword'].value);
  }

  togglecurrentPasswordVisibility() {
    if (this.typeCurrent === 'text') {
      this.typeCurrent = 'password';
      this.typePlaceholderCurrent = 'Show';
    } else {
      this.typeCurrent = 'text';
      this.typePlaceholderCurrent = 'Hide';
    }
  }

  togglenewPasswordVisibility(confirmPassword?: boolean) {
    if (confirmPassword) {
      if (this.typeReEnterNew === 'text') {
        this.typeReEnterNew = 'password';
        this.typePlaceholderReEnterNew = 'Show';
      } else {
        this.typeReEnterNew = 'text';
        this.typePlaceholderReEnterNew = 'Hide';
      }
    } else {
      if (this.typeNew === 'text') {
        this.typeNew = 'password';
        this.typePlaceholderNew = 'Show';
      } else {
        this.typeNew = 'text';
        this.typePlaceholderNew = 'Hide';
      }
    }
  }

  onPwdFormSubmit() {
    this.isFormSubmitted = true;
    this.alertService.clearError();
    /* TODO : API Calls */
    this.profileService.updatePassword(this.updatePasswordForm.value).subscribe(
      updatePasswordActionResp => {
        if (updatePasswordActionResp.result && updatePasswordActionResp.result < 0) {
          this.updatePasswordForm.controls.currentPassword.setValue('');
          this.alertService.setAlert(updatePasswordActionResp.displaymessage, '', AlertType.Failure, 'component', 'pwderror');
          return;
        }
        console.log('RES=' + updatePasswordActionResp);
        //this.router.navigate(['/myprofile']).then(() => {
        this.alertService.setAlert(
          'Success! Your password has been changed!',
          '',
          AlertType.Success,
          'component',
          'accountsecuritysuccess'
        );
        //});
        this.resetAllEdits();
        this.editPasswordText = 'edit';
      },
      error => {
        this.alertService.setAlert(
          "Your password didn't match the minimum criteria listed below.Please try again",
          '',
          AlertType.Failure,
          'component',
          'pwderror'
        );
      }
    );
    /* For error scenario */
    // this.alertService.setAlert("Your password didn't match the minimum criteria listed below. Please try again", '' , AlertType.Failure);
  }
  showErrorOnBlur(confirmPassword?: boolean) {
    if (confirmPassword) {
      this.showReEnterPasswordErrors = true;
    } else {
      this.showPasswordErrors = true;
    }
  }

  cancelPassword() {
    this.resetAllEdits();
    this.isFormSubmitted = false;
    this.alertService.clearError();
    this.editPasswordText = 'edit';
  }

  ngOnDestroy() {}
}
