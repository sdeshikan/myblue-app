import { HttpParams } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';

@Injectable()
export class FadFacilityProfileService {
  public facilityProfile: any;
  constructor(private http: AuthHttp, private authService: AuthService) {}

  getFadGetprofessionalprofileDetails(request: FadFacilityProfileRequestModelInterface): Observable<FadFacilityResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    // this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(FadConstants.urls.facilityProfile, request, '', '', false).map(response => {
      return response;
    });
  }
  getToolTipInfo() {
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if (this.authService.useridin && this.authService.useridin != 'undefined') {
      ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType'] = 'All';
    const url = FadConstants.urls.fadVitalsToolTipsInfo;
    return this.http.encryptPost(url, ToolTipReq, null, null, false);
  }
}
