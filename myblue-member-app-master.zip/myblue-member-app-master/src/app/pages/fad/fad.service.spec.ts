import { TestBed, inject } from '@angular/core/testing';

import { FadService } from './fad.service';
import { AlertService } from '../../shared/services/alert.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('FadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [FadService, AlertService]
    });
  });

  it('should be created', inject([FadService], (service: FadService) => {
    expect(service).toBeTruthy();
  }));
});
