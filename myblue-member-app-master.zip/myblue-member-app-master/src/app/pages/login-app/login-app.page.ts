import { SwrveService, SwrveEventNames } from '../../shared/services/swrve.service';
import { AnalyticsService } from '../../shared/services/analytics.service';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { Storage } from '@ionic/storage';
import { from, forkJoin } from 'rxjs';
import { Router } from '@angular/router';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { LoginRequest } from '../../shared/models/loginRequest.model';
import { AlertService, ConstantsService } from '../../shared/shared.module';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AuthHttp } from '../../shared/services/authHttp.service';
import { GlobalService } from '../../shared/services/global.service';
import { AuthService } from '../../shared/services/auth.service';
import { LoadingController, Platform } from '@ionic/angular';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { Keychain } from '@ionic-native/keychain/ngx';
import { LoadingHelperClass } from '../../shared/classes/loadingHelper.class';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { ModalController } from '@ionic/angular';
import { PreferenceModalComponent } from '../../shared/components/preference-modal/preference-modal.component';

@Component({
  selector: 'app-login-app',
  templateUrl: './login-app.page.html',
  styleUrls: ['./login-app.page.scss']
})

// tslint:disable-next-line:component-class-suffix
export class LoginAppPage {
  loginForm = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    rememberMe: new FormControl(''),
    bioMetrics: new FormControl('')
  });
  showPassword: string;
  message: string;
  idText = 'test';
  idIcon = 'finger-print';
  idAvailable = true;
  faceIdAvailable: boolean;
  fingerPrintAvailable: boolean;
  isAuthenticatedUser: boolean;
  userName: any;
  private loadingHelper: LoadingHelperClass;

  constructor(
    private loginService: LoginService,
    private storage: Storage,
    private router: Router,
    private authService: AuthService,
    private faio: FingerprintAIO,
    private alertService: AlertService,
    private authHttp: AuthHttp,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private analyticsService: AnalyticsService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    public loadingController: LoadingController,
    private keyboard: Keyboard,
    private keychain: Keychain,
    private platform: Platform,
    private profileService: ProfileService,
    private modalController: ModalController
  ) {
    this.loadingHelper = new LoadingHelperClass(loadingController);
    this.showPassword = 'password';
    this.checkIdTech();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_SignIn);
  }

  checkIdTech() {
    this.faio
      .isAvailable()
      .then(result => {
        result === 'finger' ? (this.fingerPrintAvailable = true) : (this.faceIdAvailable = true);
      })
      .catch(err => {
        this.idAvailable = false;
      });
  }

  ionViewWillEnter() {
    this.checkRememberMe();
    this.checkIsBioSetup();
  }

  ionViewWillLeave() {
    this.clearForm();
  }

  checkRememberMe() {
    from(this.storage.get('userid')).subscribe(data => {
      if (data) {
        this.loginForm.patchValue({ rememberMe: true });
        this.getSavedUserName();
      } else {
        this.loginForm.patchValue({ rememberMe: true });
        this.checkLocalStorageForUserId();
      }
    });
  }

  checkLocalStorageForUserId() {
    if (window.localStorage && localStorage.getItem('userid')) {
      this.loginForm.patchValue({
        userName: localStorage.getItem('userid'),
        rememberMe: true
      });
    }
  }

  checkIsBioSetup() {
    from(this.storage.get('pBioData')).subscribe(pBioData => {
      if (pBioData) {
        this.launchBioMetrics();
      } else {
        this.loginForm.patchValue({ bioMetrics: false });
      }
    });
  }

  getSavedUserName() {
    from(this.storage.get('userid')).subscribe(data => {
      this.userName = data;
      this.loginForm.patchValue({
        userName: data,
        rememberMe: true
      });
    });
  }

  showHidePassword(type: string) {
    type === 'text' ? (this.showPassword = 'text') : (this.showPassword = 'password');
  }

  onSubmit() {
    this.loadingHelper.fetch(() => this.handleSubmit());
  }

  handleSubmit() {
    this.loginForm.get('rememberMe').value ? this.saveUserName(this.loginForm.get('userName').value) : this.eraseUserNameFromStorage();
    this.loginForm.get('bioMetrics').value ? this.setBioUp() : this.eraseBiometricsFromStorage();
    this.showHidePassword('password');
    this.login(this.createRequest());
  }

  closeKeyboard() {
    this.keyboard.hide();
  }

  createRequest(): LoginRequest {
    return {
      useridin: this.loginForm.get('userName').value,
      passwordin: this.loginForm.get('password').value
    };
  }

  launchBioMetrics() {
    this.faio
      .show({
        title: 'Use Pin',
        disableBackup: true // Only for Android(optional)
      })
      .then((result: any) => {
        console.log(result);
        return this.bioMetricSuccess();
      })
      .catch((error: any) => console.log(error));
  }

  bioMetricSuccess() {
    this.storage
      .get('pBioData')
      .then(pBioData => {
        this.loadingHelper.fetch(() => this.login({ useridin: this.userName, passwordin: pBioData.password }));
      })
      .catch((error: any) => {
        console.log(error);
      });
  }

  setBioUp() {
    const pBioData = {
      password: this.loginForm.get('password').value,
      userid: this.loginForm.get('userName').value
    };
    this.storage
      .set('pBioData', pBioData)
      .then(() => {})
      .catch((error: any) => console.log(error));
  }

  handleSwrveMessages(isAuthenticatedUser: boolean, scopeName: string) {
    if (isAuthenticatedUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeAuthenticated, '{}');
      console.log('-- handleSwrveMessages -- isAuthenticatedUser: ', this.swrveEventNames.AppScreen_HomeAuthenticated);
    } else if (scopeName === 'REGISTERED-NOT-VERIFIED') {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeRegistered);
      console.log('-- handleSwrveMessages -- REGISTERED-NOT-VERIFIED: ', this.swrveEventNames.AppScreen_HomeRegistered);
    } else {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeAnonymous);
      console.log('-- handleSwrveMessages -- else: ', this.swrveEventNames.AppScreen_HomeAnonymous);
    }
  }

  handleUserVerification() {
    sessionStorage.setItem('isReqCode', 'true');
    sessionStorage.setItem('isUserLogginIn', 'true');
    this.router.navigate(['/register/verifyaccesscode']);
  }

  async handleResponse(response: any = {}) {
    const scopeName = this.authService.getScopeName();
    this.swrveService.identifyUserToSwrve(this.authService.authToken.syntheticID);
    this.swrveService.identifySwrveUserIdToBackend();
    // this.swrveService.sendAppMessage('MyBlue 4.0/Sign In', JSON.stringify({ "Logged In": this.authService.authToken.syntheticID }));
    // this.swrveService.sendAppMessage('AppClick.Authentication.SubmittedStudentID', '{"Studend": "yes" }');

    // TODO ANALYTICS

    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
    const shownFirstTime = await this.storage.get('shown-first-time');
    this.handleSwrveMessages(this.isAuthenticatedUser, response.scopename);
    if (this.isAuthenticatedUser && !shownFirstTime) {
      console.log('redirecting to first time');
      this.storage.set('shown-first-time', 'true');
      this.router.navigate(['first-time']).then(() => this.getPreferencesAndConsent(response.scopeName));
    } else {
      this.handleDeepLinkData();

      if (response.scopename === 'REGISTERED-NOT-VERIFIED' || response.scopename === 'AUTHENTICATED-NOT-VERIFIED') {
        // console.log('-- login-app -- navigate:/register/verifyaccesscode');
        if (response.scopename === 'AUTHENTICATED-NOT-VERIFIED') {
          this.router.navigate(['member-migration']);
        } else {
          this.handleUserVerification();
        }
        return;
      }
      if (response.destinationURL && response.migrationtype === 'NONE') {
        if (response.scopename === 'AUTHENTICATED-NOT-VERIFIED') {
          // console.log('-- login-app -- navigate:tabs/home');
          this.router.navigateByUrl('tabs/home');
        } else {
          // console.log('-- login-app -- response.destinationURL', response.destinationURL);
          this.router.navigate([response.destinationURL]).then(() => this.getPreferencesAndConsent(response.scopename));
        }
      } else {
        // console.log('-- login-app --: navigate to tabs/home' + shownFirstTime);
        this.router.navigateByUrl('tabs/home').then(() => this.getPreferencesAndConsent(response.scopename));
      }
    }
  }

  getPreferencesAndConsent(scopeName: string = '') {
    if (scopeName === 'AUTHENTICATED-AND-VERIFIED') {
      forkJoin([
        this.globalService.getProgramGroups(),
        this.globalService.getPreferences(),
        this.globalService.getConsent(),
        this.profileService.fetchProfileInfo()
      ]).subscribe((responses: any) => {
        if (responses.length > 0) {
          sessionStorage.setItem('programGroups', JSON.stringify(responses[0].message));
          if (responses[1].errormessage) {
            sessionStorage.setItem('preferences', JSON.stringify(responses[1]));
          } else {
            sessionStorage.setItem('preferences', JSON.stringify(responses[1].message));
          }
          sessionStorage.setItem('consentData', JSON.stringify(responses[2]));
          this.profileService.setProfile(responses[3]);

          if (responses[3]) {
            if (
              responses[1].errormessage &&
              !(
                this.authService.authToken &&
                this.authService.authToken.userType &&
                this.authService.authToken.userType.toLowerCase() === 'medicare'
              )
            ) {
              this.showPreferenceModal(responses);
            }
          }
        }
      });
    }
  }

  async showPreferenceModal(responses: any[]) {
    const modal = await this.modalController.create({
      component: PreferenceModalComponent,
      cssClass: 'preference-center-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false,
      componentProps: {
        programGroupsObj: responses[0].message,
        preferences: responses[1].errormessage ? responses[1] : responses[1].message,
        getConsentRes: responses[2],
        profile: responses[3]
      }
    });
    await modal.present();
  }

  clearForm() {
    this.loginForm.patchValue({ password: '' });
  }

  async handleDeepLinkData() {
    await this.storage.get('deepLinkRoute').then(route => {
      if (route) {
        from(this.storage.set('deepLinkRoute', '')).subscribe(() => {});
        this.router.navigate([route]);
      }
    });
  }

  login(request: LoginRequest) {
    return this.loginService.login(request).subscribe(
      (response: any) => {
        if (response.displaymessage) {
          this.handleApiError(response);
        } else {
          this.handleResponse(response);
        }
      },
      err => {
        if (err.status >= 500) {
          if (err && err.error && err.error.result) {
            this.message = this.message + ' (' + err.error.result + ')';
          }
          this.alertService.setAlert(this.message, '', AlertType.Failure);
        } else if (err.status === 404) {
          this.authHttp.handleError(err);
        } else {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      }
    );
  }

  handleApiError(response?) {
    const displayMessage = response.displaymessage;
    this.alertService.setAlert(displayMessage, '', AlertType.Failure);
  }

  saveUserName(userName: string) {
    from(this.storage.set('userid', userName)).subscribe(() => {});
  }

  eraseBiometricsFromStorage() {
    from(this.storage.set('pBioData', '')).subscribe(() => {});
  }

  eraseUserNameFromStorage() {
    from(this.storage.set('userid', '')).subscribe(() => {});
  }

  bioMetricChange() {
    this.loginForm.get('bioMetrics').value ? this.loginForm.patchValue({ rememberMe: true }) : this.eraseBiometricsFromStorage();
  }

  rememberMeChange() {
    if (!this.loginForm.get('rememberMe').value) {
      this.eraseUserNameFromStorage();
    }
  }

  navigateToForgotPassword() {
    const userName =
      this.loginForm && this.loginForm.controls && this.loginForm.controls.useridin ? this.loginForm.controls.useridin.value : '';

    if (userName) {
      this.router.navigate(['/account/forgotPassword', userName]);
    } else {
      this.router.navigate(['/account/forgotPassword']);
    }
  }
}
