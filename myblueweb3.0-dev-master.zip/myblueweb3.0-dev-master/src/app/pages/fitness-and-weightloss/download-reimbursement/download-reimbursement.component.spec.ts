import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SelectionService } from './../../../shared/services/downloadForm/selection.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { DownloadReimbursementComponent } from './download-reimbursement.component';

fdescribe('DownloadReimbursementComponent', () => {
  let component: DownloadReimbursementComponent;
  let fixture: ComponentFixture<DownloadReimbursementComponent>;
  beforeEach(() => {
    const selectionServiceStub = {
      getYear: () => ({
        subscribe: () => (
          {
            benefits: 'Fitness',
            subscriberMaskedEmail: 'maskedemail',
            memberEmail: 'memberEmail'
          })
      })
    };
    const formBuilderStub = {
      group: formGroup => ({
        year: 2018,
        typeOfReimbursement: 'fitness',
      })
    }; const routerStub = { navigate: array => ({}) };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [DownloadReimbursementComponent],
      providers: [
        { provide: SelectionService, useValue: selectionServiceStub },
        { provide: FormBuilder, useValue: formBuilderStub },
        { provide: Router, useValue: routerStub }
      ]
    });
    fixture = TestBed.createComponent(DownloadReimbursementComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
  it('isFormSubmitted defaults to: false', () => {
    expect(component.isFormSubmitted).toEqual(false);
  });
  it('showForm defaults to: false', () => {
    expect(component.showForm).toEqual(false);
  });
  it('buttonCopy defaults to: Continue', () => {
    expect(component.buttonCopy).toEqual('Continue');
  });
  it('typeofBenefit defaults to: []', () => {
    expect(component.typeofBenefit).toEqual([]);
  });
  it('onlineSubmission defaults to: false', () => {
    expect(component.onlineSubmission).toEqual(false);
  });
  it('showSelectionForm defaults to: false', () => {
    expect(component.showSelectionForm).toEqual(false);
  });
  it('showNoFormPage defaults to: true', () => {
    expect(component.showNoFormPage).toEqual(true);
  });
  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'initializeReimbursementsForm').and.callThrough();
      component.ngOnInit();
      expect(component.initializeReimbursementsForm).toHaveBeenCalled();
    });
  });
  describe('initializeReimbursementsForm', () => {
    it('makes expected calls', () => {
      const selectionServiceStub: SelectionService = fixture.debugElement.injector.get(
        SelectionService
      );
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
        FormBuilder
      );
      spyOn(selectionServiceStub, 'getYear').and.callThrough();
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.initializeReimbursementsForm();
      expect(selectionServiceStub.getYear).toHaveBeenCalled();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });

  describe('navigateToFitness', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.navigateToFitness();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
  describe('navigateToWeightloss', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.navigateToWeightloss();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
