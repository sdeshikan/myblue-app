﻿import { Component, NgZone, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { MenuController, ModalController, NavController, Platform, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import * as moment from 'moment-timezone';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { AuthToken } from './models/auth-token.model';
import { PostLoginModel } from './models/post-login.model';
import { SsoService } from './pages/sso/sso.service';
import { FeatureToggleService } from './services/feature.service';
import { SwrveEventNames, SwrveService } from './services/swrve.service';
import { HeaderService } from './shared/layouts/header/header.service';
import { AnalyticsService } from './shared/services/analytics.service';
import { DynamicScriptLoaderService } from './shared/services/dynamic-script-loader.service';
import { GlobalService } from './shared/services/global.service';
import { HomeService } from './shared/services/home.service';
import { IabService } from './shared/services/iab/iab.service';
import { AlertService } from './shared/shared.module';
import { Logout } from './store/actions/app.actions';
import { AppSelectors } from './store/selectors/app-selectors';
import { PharmacyLinkType } from './models/pharmacy-link-type';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  @Select(AppSelectors.getAuthToken) authToken$: Observable<AuthToken>;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @Select(AppSelectors.getPharmacyLinks) pharmacyLinks$: Observable<PharmacyLinkType[]>;

  destroy$: Subject<boolean> = new Subject<boolean>();

  homeNavigationApiResponse: any;
  isRegisteredUser = false;
  isAuthenticatedUser = false;
  isAnonymousUser = false;
  memberFirstName: string;
  scopeName: string;
  submenu: any = {};
  estGreeting = '';
  buildVersion = '';
  mobileAppVersion = '';
  currentUrl: string;
  callNurseLineNumber = '';
  showMyPharmacy: boolean;
  isFitnessEnabled = false;
  authToken: AuthToken;

  constructor(
    private menu: MenuController,
    private store: Store,
    private platform: Platform,
    private router: Router,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private modalController: ModalController,
    private toastCtrl: ToastController,
    private globalService: GlobalService,
    private alertService: AlertService,
    private analyticsService: AnalyticsService,
    private dynamicScriptLoaderService: DynamicScriptLoaderService,
    private appVersion: AppVersion,
    private storage: Storage,
    private deepLinks: Deeplinks,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    public headerService: HeaderService,
    public homeService: HomeService,
    private ngZone: NgZone,
    private featureToggleService: FeatureToggleService,
    private navCtrl: NavController
  ) {
    this.dynamicScriptLoaderService
      .load('adobe-analytics')
      .then(data => {
        console.log('Analytics Service BCBSMA: adobe-analytics library loaded successfully');
        console.log((window as any)._satellite);
      })
      .catch(error => console.log('Analytics Service BCBSMA: adobe-analytics library load failed' + error));

    this.initializeApp();

    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe((event: RouterEvent) => {
        this.currentUrl = event.url;

        this.menu.close();
        if (event.url !== '/register/updatessn' && event.url.indexOf('/myprofile/communication-preferences') === -1) {
          this.alertService.clearError();
        }
      });

    this.isFitnessEnabled = this.featureToggleService.isFeatureEnabled('fitness-benefits');

    this.authToken$.pipe(takeUntil(this.destroy$)).subscribe(token => {
      if (token) {
        this.authToken = token;
        this.scopeName = this.authToken.scopename;
        this.memberFirstName = '';

        if (this.scopeName === 'AUTHENTICATED-NOT-VERIFIED' || this.scopeName === 'AUTHENTICATED-AND-VERIFIED') {
          this.memberFirstName = this.authToken.firstName;
          this.isAuthenticatedUser = true;
          this.isRegisteredUser = false;
          this.isAnonymousUser = false;
        } else if (this.scopeName === 'REGISTERED-AND-VERIFIED' || this.scopeName === 'REGISTERED-NOT-VERIFIED') {
          this.isRegisteredUser = true;
          this.isAuthenticatedUser = false;
          this.isAnonymousUser = false;
        } else {
          this.isRegisteredUser = false;
          this.isAnonymousUser = true;
          this.isAuthenticatedUser = false;
        }

        if (this.authToken.unreadMsgCount) {
          this.headerService.unReadMsgCount = this.authToken.unreadMsgCount.toString();
        }

        this.analyticsService.initializeAdobe((window as any)._satellite, this.authToken);
      } else {
        this.memberFirstName = '';
      }
    });

    this.platform.pause.pipe(takeUntil(this.destroy$)).subscribe(() => {
      // this.store.dispatch(new Logout());
    });

    this.platform.backButton.pipe(takeUntil(this.destroy$)).subscribe(() => {
      if (this.currentUrl !== '/tabs/home') {
        this.navCtrl.back();
      } else if (this.currentUrl === '/tabs/home') {
        this.menu.isOpen().then(isOpen => {
          isOpen ? this.menu.close() : (navigator as any).app.exitApp();
        });
      }
    });
  }

  ngOnInit() {
    if (this.authToken && this.authToken.unreadMsgCount) {
      this.headerService.unReadMsgCount = this.authToken.unreadMsgCount.toString();
    }
    this.buildVersion = environment.buildVersion;
    this.mobileAppVersion = environment.mobileAppVersion;
    const hour = moment.tz(new Date(), 'America/New_York').hour();
    const MORNING = 12;
    const AFTERNOON = 17;
    if (hour < MORNING) {
      this.estGreeting = 'Good morning';
    } else if (hour >= MORNING && hour < AFTERNOON) {
      this.estGreeting = 'Good afternoon';
    } else {
      this.estGreeting = 'Good evening';
    }
  }

  initializeApp() {
    this.platform.ready().then(() => {
      if (this.platform.is('cordova')) {
        this.checkDeeplinks();
        this.getLocalAppVersion();
        this.statusBar.styleDefault();
        this.statusBar.backgroundColorByHexString('#1866a3');
        this.splashScreen.hide();
        this.getLocalAppVersion();
      }

      this.homeService.setSessionLinks();
    });
  }

  checkDeeplinks() {
    this.deepLinks
      .route({
        '/home': 'home',
        '/register': 'register',
        '/registerdetail': 'register/register-detail',
        '/login': 'login-app',
        '/whatsnew': 'whatsnew',
        '/myplan': 'myPlan',
        '/mydoctor': 'my-doctor',
        '/myclaims': 'myClaims',
        '/myinbox': 'myInbox',
        '/my-financial': 'my-financial',
        '/myprofile': 'myprofile',
        '/mycards': 'mycards',
        '/account': 'account',
        '/request-estimate': 'request-estimate',
        '/mydedco-app': 'deductibles',
        '/med-lookup-tool': 'med-lookup-tool',
        '/fad': 'fad',
        '/fitness-and-weightloss': 'fitness-and-weightloss'
      })
      .subscribe(
        match => {
          this.ngZone.run(() => {
            this.storage.set('deepLinkRoute', match.$route).then(() => {
              this.router.navigateByUrl(match.$route);
            });
          });
        },
        nomatch => {
          console.error("Got a deeplink that didn't match", nomatch);
          this.storage.set('deepLinkRoute', false);
        }
      );
  }

  logOut() {
    sessionStorage.clear();
    this.store.dispatch(new Logout());
    this.menu.close();
  }

  goToLogin() {
    this.navCtrl.navigateRoot('login-app');
  }

  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        this.callNurseLineNumber = this.homeNavigationApiResponse.APPTextUrl2 || '';
      }
    });
  }

  closeMenu() {
    this.menu.close();
  }

  getLocalAppVersion() {
    this.storage.get('appVersion').then(storedAppVersion => {
      storedAppVersion ? this.checkIfAppUpdated(storedAppVersion) : this.setAppVersion();
    });
  }

  async checkIfAppUpdated(storedAppVersion: string) {
    const currentAppVersion = await this.appVersion.getVersionNumber();
    if (storedAppVersion !== currentAppVersion) {
      this.callUpdateAppMessage();
      this.setAppVersion();
    }
  }

  callUpdateAppMessage() {
    (window as any).plugins.swrve.event(
      'update',
      'custom.app_update',
      successCallBack => {
        console.log(successCallBack);
      },
      failureCallback => {
        console.log(failureCallback);
      }
    );
  }

  async setAppVersion() {
    const currentAppVersion = await this.getCurrentAppVersion();
    this.storage.set('appVersion', currentAppVersion);
  }

  getCurrentAppVersion() {
    return this.appVersion.getVersionNumber().then(version => {
      return version;
    });
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  findADoctorClicked() {
    const isSmartShopperUser = this.checkSmartShopperUser(this.postLoginInfo);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_FindaDoctor);
    if (isSmartShopperUser) {
      this.ssoService.openSSO('fad');
    } else {
      this.router.navigate(['tabs/fad']);
    }
  }

  wellConnectionClicked() {
    const url = 'https://myblue.bluecrossma.com/health-plan/well-connection';
    if (url) {
      this.iabService.create(url);
    }
  }

  contactUsClicked() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_ContactUs);
  }

  openUrl() {
    this.iabService.create('http://20181129medication.test-bluecrossma.acsitefactory.com/?referer=mobile-app');
  }

  myInboxClicked() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_MyInbox);
  }

  navigate(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
