import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { EOBService } from './eob.service';

@Injectable()
export class EOBResolverService implements Resolve<Observable<any>> {
  constructor(private eobService: EOBService) {}

  resolve() {
    return this.getEobList();
  }

  getEobList() {
    const obs = [];
    obs.push(this.eobService.getEobList());
    return forkJoin(obs);
  }
}
