import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { Store } from '@ngxs/store';
import { SwrveEventNames, SwrveService } from '../../../../services/swrve.service';
import { Logout } from '../../../../store/actions/app.actions';

@Component({
  selector: 'app-migration-success-app',
  templateUrl: './migration-success-app.page.html',
  styleUrls: ['./migration-success-app.page.scss']
})
export class MigrationSuccessAppPage implements OnInit {
  public userid: string = localStorage['login-user'];

  constructor(
    private location: Location,
    private router: Router,
    private platform: Platform,
    private store: Store,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {}

  ngOnInit() {
    this.store.dispatch(new Logout());
    this.platform.backButton.subscribe(() => {
      this.exploreNew();
    });
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MigrationComplete);
  }

  exploreNew(): void {
    this.router.navigateByUrl('login-app');
  }
}
