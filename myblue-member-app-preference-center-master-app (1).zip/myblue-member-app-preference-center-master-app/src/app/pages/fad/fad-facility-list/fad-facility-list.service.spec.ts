import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityListService } from './fad-facility-list.service';

describe('FadFacilityListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, IonicModule, NgxsModule.forRoot([])],
      providers: [FadFacilityListService, FadSearchResultsService, BcbsmaHttpService, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityListService], (service: FadFacilityListService) => {
    expect(service).toBeTruthy();
  }));
});
