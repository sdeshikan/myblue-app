import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// import { AuthGuard } from '../../shared/utils/auth.guard';
// import { AuthHttp } from '../../shared/services/authHttp.service';
import { AuthService, ConstantsService, SharedModule } from '../../shared/shared.module';
// import { authHttpFactory } from '../../shared/utils/authHttp.factory';
import { FadLandingPageComponent } from './fad-landing-page/fad-landing-page.component';
import { FadLandingPageService } from './fad-landing-page/fad-landing-page.service';
import { FadMedicalIndexComponent } from './fad-medical-index/fad-medical-index.component';
import { FadMedicalIndexService } from './fad-medical-index/fad-medical-index.service';
import { FadNoDocsPageComponent } from './fad-no-docs-page/fad-no-docs-page.component';
import { FadNoDocsPageService } from './fad-no-docs-page/fad-no-docs-page.service';
import { FadSearchFilterComponent } from './fad-search-filter/fad-search-filter.component';
import { FadSearchListComponent } from './fad-search-list/fad-search-list.component';
import { FadSearchListService } from './fad-search-list/fad-search-list.service';
// import { HttpClient } from '@angular/common/http';
import { FadSearchResultsComponent } from './fad-search-results/fad-search-results.component';
import { FadSearchResultsService } from './fad-search-results/fad-search-results.service';
import { FadRouter } from './fad.routing';
import { FadService } from './fad.service';

import { FadCostBreakdownService } from '../fad/fad-cost-breakdown/fad-cost-breakdown.service';
import { FadCostBreakdownComponent } from './fad-cost-breakdown/fad-cost-breakdown.component';
import { FadDoctorProfileComponent } from './fad-doctor-profile/fad-doctor-profile.component';
import { FadDoctorProfileService } from './fad-doctor-profile/fad-doctor-profile.service';
import { FadDoctorRatingComponent } from './fad-doctor-rating/fad-doctor-rating.component';
import { FadFacilityCardComponent } from './fad-facility-card/fad-facility-card.component';
import { FadFacilityCompareComponent } from './fad-facility-compare/fad-facility-compare.component';
import { FadFacilityCompareService } from './fad-facility-compare/fad-facility-compare.service';
import { FadFacilityListComponent } from './fad-facility-list/fad-facility-list.component';
import { FadFacilityListService } from './fad-facility-list/fad-facility-list.service';
import { FadFacilityProfileComponent } from './fad-facility-profile/fad-facility-profile.component';
import { FadFacilityProfileService } from './fad-facility-profile/fad-facility-profile.service';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list/fad-past-search-query-list.component';
import { FadPastSearchQueryListService } from './fad-past-search-query-list/fad-past-search-query-list.service';
import { FadProfessionalCompareComponent } from './fad-professional-compare/fad-professional-compare.component';
import { FadProfessionalCompareService } from './fad-professional-compare/fad-professional-compare.service';
import { FadProfileCardComponent } from './fad-profile-card/fad-profile-card.component';
import { FadProviderCompareComponent } from './fad-provider-compare/fad-provider-compare.component';
import { FadProviderCompareService } from './fad-provider-compare/fad-provider-compare.service';
import { FadSearchResultsResolver } from './fad-search-results/fad-search-results.resolver';

import { FadProviderFacilityCardComponent } from './fad-provider-facility-card/fad-provider-facility-card.component';
import { FadProviderFacilityListComponent } from './fad-provider-facility-list/fad-provider-facility-list.component';
import { FadProviderFacilityListService } from './fad-provider-facility-list/fad-provider-facility-list.service';

import { FadBreadCrumbsComponent } from './fad-bread-crumbs/fad-bread-crumbs.component';
import { FadBreadCrumbsService } from './fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileResolver } from './fad-doctor-profile/fad-doctor-profile.resolver';
import { FadFacilityProfileResolver } from './fad-facility-profile/fad-facility-profile.resolver';
import { FadFacilitySearchFilterComponent } from './fad-facility-search-filter/fad-facility-search-filter.component';
import { FadReviewQuestionComponent } from './fad-review/fad-review-question/fad-review-question.component';
import { FadReviewComponent } from './fad-review/fad-review.component';
import { FadReviewService } from './fad-review/fad-review.service';
import { RatingComponent } from './fad-review/rating/rating.component';
import { FadSpecialtySearchFilterComponent } from './fad-specialty-search-filter/fad-specialty-search-filter.component';
import { FadGuard } from './fad.guard';

@NgModule({
  imports: [CommonModule, FadRouter, SharedModule, InfiniteScrollModule],
  exports: [],
  declarations: [
    FadLandingPageComponent,
    FadMedicalIndexComponent,
    FadSearchResultsComponent,
    FadNoDocsPageComponent,
    FadSearchFilterComponent,
    FadSearchListComponent,
    FadDoctorProfileComponent,
    FadFacilityProfileComponent,
    FadProfileCardComponent,
    FadPastSearchQueryListComponent,
    FadProviderCompareComponent,
    FadProfessionalCompareComponent,
    FadFacilityCompareComponent,
    FadCostBreakdownComponent,
    FadDoctorRatingComponent,
    FadFacilityListComponent,
    FadFacilityCardComponent,
    FadFacilitySearchFilterComponent,
    FadSpecialtySearchFilterComponent,
    FadBreadCrumbsComponent,
    FadReviewComponent,
    FadReviewQuestionComponent,
    RatingComponent,
    FadProviderFacilityListComponent,
    FadProviderFacilityCardComponent
  ],
  entryComponents: [FadProfileCardComponent, FadFacilityCardComponent, FadProviderFacilityCardComponent],
  providers: [
    FadService,
    FadLandingPageService,
    FadMedicalIndexService,
    FadSearchResultsService,
    FadNoDocsPageService,
    FadSearchListService,
    FadDoctorProfileService,
    FadFacilityProfileService,
    FadPastSearchQueryListService,
    FadProviderCompareService,
    FadProfessionalCompareService,
    FadFacilityCompareService,
    FadCostBreakdownService,
    FadSearchResultsResolver,
    FadDoctorProfileResolver,
    FadFacilityProfileResolver,
    FadFacilityListService,
    FadBreadCrumbsService,
    FadGuard,
    FadReviewService,
    FadProviderFacilityListService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FadModule {}
