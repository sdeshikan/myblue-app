import { TestBed, inject } from '@angular/core/testing';
import { FadCostBreakdownService } from './fad-cost-breakdown.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('FadCostBreakdownService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FadCostBreakdownService, BcbsmaHttpService]
    });
  });

  it('should be created', inject([FadCostBreakdownService], (service: FadCostBreakdownService) => {
    expect(service).toBeTruthy();
  }));
});
