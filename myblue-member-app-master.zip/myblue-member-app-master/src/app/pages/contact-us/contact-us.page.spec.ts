import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactUsPage } from './contact-us.page';
import { SwrveEventNames } from '../../shared/services/swrve.service';
import { AuthService } from '../../shared/services/auth.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../shared/services/constants.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AuthHttp } from '../../shared/services/authHttp.service';
import { AlertService } from '../../shared/services/alert.service';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { RouterTestingModule } from '@angular/router/testing';

describe('ContactUsPage', () => {
  let component: ContactUsPage;
  let fixture: ComponentFixture<ContactUsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([])],
      providers: [SwrveEventNames, AuthService, ConstantsService, InAppBrowser, AuthHttp, AlertService, CallNumber],
      declarations: [ContactUsPage],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactUsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
