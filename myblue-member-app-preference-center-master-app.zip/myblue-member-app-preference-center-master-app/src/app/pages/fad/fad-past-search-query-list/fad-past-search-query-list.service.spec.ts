import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';

describe('FadPastSearchQueryListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FadPastSearchQueryListService, BcbsmaHttpService]
    });
  });

  it('should be created', inject([FadPastSearchQueryListService], (service: FadPastSearchQueryListService) => {
    expect(service).toBeTruthy();
  }));
});
