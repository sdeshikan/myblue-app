import { PharmacyModel } from '../pages/my-pillpack-app/model/pillpack-generic.models';
import { PhoneNumberModel } from './phone-number.model';

export interface PostLoginModel {
  hasSS: boolean;
  hasCI: boolean;
  hasSSO: boolean;
  isCPDPEnrolled: boolean;
  isCPDPHandedoff: boolean;
  isCPDPPromotion: boolean;
  isKYMember: boolean;
  repPayeeFalg: string;
  phoneNumbers: PhoneNumberModel[];
  pharmacyLinks: PharmacyModel[];
}
