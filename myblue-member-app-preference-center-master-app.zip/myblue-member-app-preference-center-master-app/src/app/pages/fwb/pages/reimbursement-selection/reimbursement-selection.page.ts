import { animate, group, state, style, transition, trigger } from '@angular/animations';
import { Component, ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { GetBenefitsInfo, GetReimbursementForm, SetReimbursement, SetSelectedBenefit } from '../../../../store/actions/fitness.actions';
import { FitnessSelectors } from '../../../../store/selectors/fitness.selectors';
import { BenefitModel } from '../../models/benefit-model';
import { ReimbursementModel } from '../../models/reimbursement-model';

@Component({
  selector: 'app-fwb',
  templateUrl: './reimbursement-selection.page.html',
  styleUrls: ['./reimbursement-selection.page.scss'],
  animations: [
    trigger('slideInOut', [
      state('in', style({ height: '*', opacity: 0 })),
      transition(':leave', [
        style({ height: '*', opacity: 1 }),
        group([animate(400, style({ height: 0 })), animate('400ms ease-in-out', style({ opacity: '0' }))])
      ]),
      transition(':enter', [
        style({ height: '0', opacity: 0 }),
        group([animate(400, style({ height: '*' })), animate('1000ms ease-in-out', style({ opacity: '1' }))])
      ])
    ])
  ]
})
export class ReimbursementSelectionPage {
  @ViewChild(IonContent) content: IonContent;

  @Select(FitnessSelectors.getBenefits) benefits$: Observable<BenefitModel[]>;
  @Select(FitnessSelectors.getSelectedBenefit) selectedBenefit$: Observable<BenefitModel>;
  @Select(FitnessSelectors.getSelectedReimbursement) selectedReimbursement$: Observable<ReimbursementModel>;
  @Select(FitnessSelectors.getEligibility) notEligible$: Observable<boolean>;
  @Select(FitnessSelectors.getEligibilityStatement) eligibilityText$: Observable<string>;

  toggle = false;

  constructor(private store: Store) {}

  ionViewDidEnter() {
    this.content.scrollToTop(500);
    this.toggle = false;
    this.store.dispatch(new GetBenefitsInfo());
  }

  yearChange(e) {
    this.store.dispatch(new SetSelectedBenefit(e.detail.value));
  }

  benefitTypeChange(e) {
    this.store.dispatch(new SetReimbursement(e.detail.value));
  }

  submit() {
    this.store.dispatch(new GetReimbursementForm());
  }

  toggleEligibility() {
    this.toggle = !this.toggle;

    if (this.toggle) {
      setTimeout(() => {
        this.content.scrollToBottom(0);
      }, 500);
    }
  }
}
