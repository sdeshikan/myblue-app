import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { DeductibleDetailsPage } from './deductible-details/deductible-details.page';
import { DeductibleDetailsModule } from './deductible-details/deductible-details.module';
import { DeductibleFilterPopover } from './popovers/deductible-filter.popover';
import { DeductibleFilterModule } from './popovers/deductible-filter.module';

const routes: Routes = [
  {
    path: '',
    component: DeductibleDetailsPage
  }
];

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule.forChild(routes), DeductibleDetailsModule, DeductibleFilterModule],
  entryComponents: [DeductibleFilterPopover]
})
export class DeductiblesModule {}
