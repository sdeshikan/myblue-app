import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';
import { FilterCheckboxItemInterface, FilterListItemInterface, FilterRadioItemInterface } from './fad-search-filter.interface';
import { CostDetails, Disclaimers, FadLocationDetailsInterface, FadReviewsListInterface } from './getSearchByProfessional-models.interface';

// tslint:disable-next-line:no-empty-interface
export interface GetSearchByFacilityRequestModelInterface {
  geoLocation: string;
  limit: number;
  page: number;
  radius: number;
  networkId: number;
  searchSpecialtyId: string;
  name: string;
  sort: string;
  procedureId: string;
  aggregateOverallRating: string;
  awardId: string;
  cqmId: string;
  bdcId: string;
  useridin: string;
  tiers: string;

  getGeoLocation(): string;
  setGeoLocation(geoLocation: string): GetSearchByFacilityRequestModelInterface;

  getLimit(): number;
  setLimit(limit: number): GetSearchByFacilityRequestModelInterface;

  getPage(): number;
  setPage(page: number): GetSearchByFacilityRequestModelInterface;

  getRadius(): number;
  setRadius(radius: number): GetSearchByFacilityRequestModelInterface;

  getNetworkId(): number;
  setNetworkId(networkId: number): GetSearchByFacilityRequestModelInterface;

  getSearchSpecialtyId(): string;
  setSearchSpecialtyId(searchSpecialtyId: string): GetSearchByFacilityRequestModelInterface;

  getName(): string;
  setName(name: string): GetSearchByFacilityRequestModelInterface;

  getUserIdIn(): string;
  setUserIdIn(useridin: string): GetSearchByFacilityRequestModelInterface;

  getSort(): string;
  setSort(sort: string): GetSearchByFacilityRequestModelInterface;

  getProcedureId(): string;
  setProcedureId(procedureId: string): GetSearchByFacilityRequestModelInterface;

  getTiers(): string;
  setTiers(tiers: string): GetSearchByFacilityRequestModelInterface;

  getAggregateOverallRating(): string;
  setAggregateOverallRating(aggregateOverallRating: string): GetSearchByFacilityRequestModelInterface;

  getAwardId(): string;
  setAwardId(awardId: string): GetSearchByFacilityRequestModelInterface;

  getCqmId(): string;
  setCqmId(cqmId: string): GetSearchByFacilityRequestModelInterface;

  getBdcId(): string;
  setBdcId(bdcId: string): GetSearchByFacilityRequestModelInterface;
}

export interface GetSearchByFacilityResponseModelInterface extends GeneralErrorInterface {
  totalCount: number;
  facilities: FadFacilityInterface[];
  facets: FacetsFacilityListInterface;
  costDetails: CostDetails;
  sort: string;
  disclaimers: Disclaimers[];
  pdfRequest: FadPdfRequestInterface;
}

export interface FadPdfRequestInterface {
  filters: string[];
  queryUrl: string;
  queue: boolean;
  source: string;
  searchParams: FadSearchParamsInterface;
}

export interface FadSearchParamsInterface {
  accountId: string;
  ci: string;
  dataLanguage: string;
  geoLocation: string;
  limit: string;
  memberNumber: string;
  name: string;
  networkId: string;
  page: string;
  radius: string;
  sort: string;
}

export interface FadFacilityInterface {
  isChecked: boolean;
  id: string;
  facilityId: string;
  type: string;
  facilityName: string;
  specialty: string; // This is the name of the city
  locations: FadLocationDetailsInterface[];
  reviews: FadReviewsListInterface;
  isDisabled: boolean;
  tiers: FadTiersInterface;
  disclaimers?: object;
}

export interface FacetsFacilityListInterface {
  overallRating: FilterListItemInterface[];
  fieldSpecialtyIds: FilterListItemInterface[];
  locationGeo: FilterListItemInterface[];
  inNetwork: FilterCheckboxItemInterface;
  bdcTypeCodes: FilterListItemInterface[];
  awardTypeCodes: FilterListItemInterface[];
  cqms: FilterListItemInterface[];
  tiers: FilterListItemInterface[];
}

export interface FacilityFiltersMetadataInterface {
  filterInNetwork: FilterCheckboxItemInterface;
  filterLocation: FilterListItemInterface;
  filterRating: FilterListItemInterface;
  filterSpecialities: FilterListItemInterface;
  filterBDC: FilterListItemInterface;
  filterAward: FilterListItemInterface;
  filterCQMS: FilterListItemInterface;
  filterTiers: FilterListItemInterface;
}

export interface FadTiersInterface {
  description: string;
}
