import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { TaxFormsModel } from '../tax-forms/models/tax-froms-models';

@Injectable({
  providedIn: 'root'
})

export class TaxFormsService {

  constructor(public http: HttpClient) {}

  getTaxFormsData(year: number): Observable<TaxFormsModel> {
    const file = "tax-forms-" + year + ".json";
    return this.http.get('../../../../../assets/' + file)
      .pipe(
        map((data) => data as TaxFormsModel)
      );
  }
}
