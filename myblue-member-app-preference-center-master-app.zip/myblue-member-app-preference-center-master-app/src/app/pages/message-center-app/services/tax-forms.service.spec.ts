import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { TaxFormsService } from './tax-forms.service';

describe('TaxFormsService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    })
  );

  it('should be created', () => {
    const service: TaxFormsService = TestBed.get(TaxFormsService);
    expect(service).toBeTruthy();
  });
});
