export interface DeductibleModel {
  title: string;
  fullName: string;
  isFirstCoverage?: boolean;
  startDate: string;
  endDate: string;
  type: string;
  totalAmount: number;
  contributed: number;
  contributedLabel: string;
  remaining: number;
  remainingLabel: string;
  limitations: string;
  exceptions: string;
}
