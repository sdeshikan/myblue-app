import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { FadConstants } from '../constants/fad.constants';
import {
  FadFacilityCardComponentInputModel,
  FadFacilityCardComponentOutputModel,
  FadProfileCardComponentInputModel,
  FadProfileCardComponentOutputModel,
  FadProviderProfileCardComponentOutputModel
} from '../modals/fad-profile-card.modal';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';

import {
  FadFacilityCardComponentInputModelInterface,
  FadFacilityCardComponentOutputModelInterface,
  FadProfileCardComponentInputModelInterface,
  FadProfileCardComponentOutputModelInterface,
  FadProviderCardComponentInputModelInterface,
  FadProviderCardComponentOutputModelInterface
} from '../modals/interfaces/fad-profile-card.interface';

import { Router } from '@angular/router';
// import { FVProSRLocation } from '../modals/fad-vitals-professionals-search-response.model';
import { first } from 'rxjs/operators';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
@Component({
  selector: 'app-fad-provider-facility-card',
  templateUrl: './fad-provider-facility-card.component.html',
  styleUrls: ['./fad-provider-facility-card.component.scss']
})
export class FadProviderFacilityCardComponent implements OnInit, StarRatingComponentConsumer {
  @Output('componentOutput') componentOutput: EventEmitter<FadProviderCardComponentOutputModelInterface> = new EventEmitter<
    FadProviderCardComponentOutputModelInterface
  >();

  @Input('componentInput') componentInput: FadProviderCardComponentInputModelInterface;

  @Input('disbaleSelection') disbaleSelection: boolean;

  // temporary stuff
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public checked = false;
  // end of temporary stuff
  public tier: string;
  public facilityName: string;
  public doctorDegree: string;
  public speciality: string;
  public medicalGroup: string;
  public address: string;
  public phoneNumber: string;
  public numberOfLocations: number;
  public awards = [];
  public cost_dollars = '00';
  public cost_pennies = '00';
  public costAvailable = false;
  public isProcedure = false;
  public accordianToggleStatus: any = {};
  public toggleShowMoreLocationStatus = false;
  public costNotAvailableToolTipVisible = false;
  public blueDistinct: string;
  public blueDistinctPlus: string;
  public blueDistinctTotal: string;
  public telehealth: boolean;
  public tierTooltipDescription: string;
  public fasFlag = false;
  public tierTooltip = new Array();
  public blueAwardFlag = false;
  public disclaimers: any;
  public disclaimersText: string;
  public disclaimersFlag: boolean;
  public endDateDisclaimers: string;
  public endDateDisclaimersFlag: boolean;
  public endDateDisclaimersDate: string;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private router: Router,
    private fadSearchResultsService: FadSearchResultsService,
    private doctorProfileService: FadDoctorProfileService,
    private facilityProfileService: FadFacilityProfileService,
    public authService: AuthService,
    private authHttp: AuthHttp
  ) {}

  ngOnDestroy(): void {
    //this.authhttp.hideSpinnerLoading();
  }

  ngOnInit() {
    try {
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      this.facilityName = this.componentInput.provider.providerName;

      if (this.componentInput.provider.disclaimers) {
        this.disclaimers = this.componentInput.provider.disclaimers;
        if (this.disclaimers && this.disclaimers.category && this.disclaimers.category == 'on_record' && this.disclaimers.text) {
          this.disclaimersFlag = true;
          this.disclaimersText = this.disclaimers.text;
        }
      }
      // this.doctorDegree = this.componentInput.professional.degrees.join(',');
      this.speciality = this.componentInput.provider.specialty;

      // const specialityBuffer = [];
      // this.componentInput.professional.specializations.map((specialization) => {
      //   specialityBuffer.push(specialization.field_specialty.name);
      //   return specialization;
      // });
      // this.speciality = specialityBuffer.join(',');

      this.blueDistinct = FadConstants.text.blueDistinct;
      this.blueDistinctPlus = FadConstants.text.blueDistinctPlus;
      this.blueDistinctTotal = FadConstants.text.blueDistinctTotal;
      if (this.componentInput.provider.locations) {
        this.numberOfLocations = this.componentInput.provider.locations.length;
        const firstLocation = this.componentInput.provider.locations[0];
        this.medicalGroup = firstLocation.name;
        this.address = firstLocation.address;
        this.phoneNumber = firstLocation.phone;
        this.endDateDisclaimers = firstLocation.endDateDisclaimers.text;
        this.endDateDisclaimersFlag = firstLocation.endDateDisclaimers.showEndDateDisclmrs;
        this.endDateDisclaimersDate = firstLocation.endDateDisclaimers.futureTerminationDate;
        this.awards = [];
        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });
          if (blueAwards.length) {
            this.awards = [{ name: 'Blue Distinctions', awardDetails: [] }];
            blueAwards.forEach(award => {
              if (award.awardDetails.length) {
                this.blueAwardFlag = true;
                award.awardDetails.forEach(awardDetail => {
                  this.awards[0].awardDetails.push(awardDetail);
                });
              }
            });
          }
        }
        for (let i = 0; i < firstLocation.amenities.length; i++) {
          if (firstLocation.amenities[i].type == 'Telehealth') this.telehealth = true;
        }
        /*this.address = [firstLocation.address.addr_line1, firstLocation.address.addr_line2, // have to check
        firstLocation.address.city, firstLocation.address.state_code, firstLocation.address.county].filter((adrItem) => {
          if (adrItem) {
            return adrItem;
          }
        }).join(', ') + ' ' + firstLocation.address.postal_code;

        if (firstLocation.phones.voice && firstLocation.phones.voice.length > 0) {
          this.phoneNumber = firstLocation.phones.voice[0].number;  // have to check
        }*/

        /* COST IS MISSING */
        /* kalagi01: DO NOT DELETE******************/
        if (firstLocation.providerCost && firstLocation.providerCost.memberCost >= 0) {
          const costString: string = firstLocation.providerCost.memberCost + '';
          this.cost_dollars = costString.split('.')[0];
          this.cost_pennies = costString.split('.')[1];
          this.costAvailable = true;
        } else {
          this.costAvailable = false;
        }
        if (firstLocation && firstLocation.tiers && firstLocation.tiers.description) {
          this.tier = firstLocation.tiers.description;
          this.getToolTipDescription(this.tierTooltip, this.tier);
        }
      } else {
        this.numberOfLocations = 0;
      }

      // temporary stuff
      this.doctorStarRating = new StarRatingComponentInputModel();
      if (this.componentInput.provider.reviews) {
        if (this.componentInput.provider.reviews.overallRating) {
          this.doctorStarRating.ratingInPercentage = parseInt(
            '' + (parseFloat(this.componentInput.provider.reviews.overallRating.toString()) * 100) / 5
          );
        }
        // parseInt(this.componentInput.facility.reviews.overallRating.toString())*100/5;
        // this.doctorStarRating.numberOfStars = 5;
        this.doctorStarRating.totalRatings = this.componentInput.provider.reviews.totalRatings;
        if (this.componentInput.provider.reviews.overallRating) {
          this.doctorStarRating.overAllRating = parseFloat(this.componentInput.provider.reviews.overallRating.toString());
        }
        // end of temporary stuff
      }
      //this.authhttp.hideSpinnerLoading();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.ngOnInit
      );
    }

    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
    }
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }
  fasIcon() {
    this.fasFlag = !this.fasFlag;
  }
  public openProfile(event): void {
    try {
      const facilityDetails: any = this.componentInput.provider;
      if (facilityDetails.providerType == 'F') {
        this.facilityProfileService.facilityProfile = facilityDetails.providerId;
        sessionStorage.setItem('facilityProfileId', facilityDetails.providerId.toString());

        sessionStorage.setItem('locationId', this.componentInput.provider.locations[0].id.toString());
        setTimeout(() => {
          this.router.navigate(['/fad/facility-profile']);
        }, 1);
      } else if (facilityDetails.providerType == 'P') {
        this.doctorProfileService.doctorProfile = facilityDetails.providerId;
        sessionStorage.setItem('professionalId', facilityDetails.providerId.toString());
        sessionStorage.setItem('locationId', this.componentInput.provider.locations[0].id.toString());
        setTimeout(() => {
          this.router.navigate(['/fad/doctor-profile']);
        }, 1);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.openProfile
      );
    }
  }

  public toggleShowMoreLocation() {
    this.toggleShowMoreLocationStatus = !this.toggleShowMoreLocationStatus;
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  /**
   * @description: get triggered when check box selection changes in the profile card. Triggers an output with the necessary info to
   * the parent component
   */
  public onSelectionChange(event): void {
    try {
      const output: FadProviderCardComponentOutputModelInterface = new FadProviderProfileCardComponentOutputModel();
      output.provider = this.componentInput.provider;
      output.provider.isChecked = event.checked;
      output.isSelected = event.checked;
      this.checked = event.checked;
      this.componentOutput.emit(output);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityCardComponent,
        FadConstants.methods.onSelectionChange
      );
    }
  }

  public doAuthentication() {
    this.router.navigateByUrl('/login');
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }

  showCostCostAvailableToolTip() {
    this.costNotAvailableToolTipVisible = !this.costNotAvailableToolTipVisible;
  }
}
