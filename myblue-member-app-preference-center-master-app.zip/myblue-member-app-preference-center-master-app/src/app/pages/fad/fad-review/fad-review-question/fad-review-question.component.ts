import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';
import { FadReviewQuestion } from '../../modals/fad-review-questions.modal';
import { StarRatingComponentConsumer } from '../../modals/interfaces/fad.interface';

@Component({
  selector: 'app-fad-review-question',
  templateUrl: './fad-review-question.component.html',
  styleUrls: ['./fad-review-question.component.scss']
})
export class FadReviewQuestionComponent implements OnInit, StarRatingComponentConsumer {

    @Input() form: FormGroup;
    @Input() question: FadReviewQuestion;

    constructor() {

    }

    ngOnInit() {
        // TODO
    }

    ratingChanged(event) {
        this.form.controls[event.id].setValue(event.currentRating);
    }
}
