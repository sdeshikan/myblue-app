import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { Camera } from '@ionic-native/camera/ngx';
import { IonicModule, ModalController, PopoverController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsModule } from '@ngxs/store';
import { StorageServiceModule } from 'angular-webstorage-service';
import { NgxCurrencyModule } from 'ngx-currency';
import { MaskApplierService, NgxMaskModule } from 'ngx-mask';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { AppState } from '../../../../store/state/app.state';
import { ReimbursementDetailsPage } from './reimbursement-details.page';
import { AlertService } from '../../../../shared/services/alert.service';
import { IonicStorageModule } from '@ionic/storage';

describe('ReimbursementDetailsPage', () => {
  let component: ReimbursementDetailsPage;
  let fixture: ComponentFixture<ReimbursementDetailsPage>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        NgxCurrencyModule,
        IonicModule,
        StorageServiceModule,
        IonicStorageModule.forRoot(),
        NgxsSelectSnapshotModule.forRoot(),
        NgxMaskModule.forRoot({}),
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([AppState])
      ],
      declarations: [ReimbursementDetailsPage],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        },
        Camera,
        ConstantsService,
        MaskApplierService,
        AlertService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReimbursementDetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
