import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { DocumentDetailService } from '../document-detail/document-detail.service';
import { DocumentsService } from '../documents/documents.service';
import { EocPolicyInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';




@Component({
  selector: 'app-documents-overall-view',
  templateUrl: './documents-overall-view.component.html',
  styleUrls: ['./documents-overall-view.component.scss']
})
export class DocumentsOverallViewComponent implements OnInit {

  public parentFolderName: string;

  constructor(private router: Router,
    private documentDetailService: DocumentDetailService,
    private documentsService: DocumentsService,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames) {
      this.platform.backButton.subscribeWithPriority(1, () => {
        this.onBackPressed();
      });

  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_BenefitLists_OverallPlanLists);
    this.parentFolderName = this.documentsService.getSelectedPlan().planName;
  }

  public onBackPressed(): void {
    this.location.back();
    //this.router.navigate(['../tabs/myInbox/documents/planDocuments/benefitCoverageList'], {replaceUrl: true});
  }

  public displayBenefitText(benefitTextType: number) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_BenefitLists_DocumentsDetails);
    this.documentDetailService.setBenefitTextType(benefitTextType);
    this.router.navigate(['/tabs/myInbox/documents/document-view']);
  }

}


