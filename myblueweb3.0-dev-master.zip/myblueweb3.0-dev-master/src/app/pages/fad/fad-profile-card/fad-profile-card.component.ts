import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import {
  FadProfileCardComponentOutputModel,
  FadProfileCardComponentInputModel,
  FadFacilityCardComponentOutputModel
} from '../modals/fad-profile-card.modal';
import {
  FadProfileCardComponentOutputModelInterface,
  FadProfileCardComponentInputModelInterface, FadFacilityCardComponentOutputModelInterface
} from '../modals/interfaces/fad-profile-card.interface';
import { Router } from '@angular/router';
import {
  FadDoctorProfileRequestModelInterface, FadProfessionalResponseModelInterface,
  FadLocationDetailsInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import {
  FadDoctorProfileRequestModel, FadProfessionalResponseModel, FadDoctorRatingsRequestModel,
  FadDoctorRatingsResponseModel
} from '../modals/fad-doctor-profile-details.model';
// import { FVProSRLocation } from '../modals/fad-vitals-professionals-search-response.model';
import { first } from 'rxjs/operators';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AuthService } from '../../../shared/shared.module';
import { AuthHttp } from '../../../shared/services/authHttp.service';
@Component({
  selector: 'app-fad-profile-card',
  templateUrl: './fad-profile-card.component.html',
  styleUrls: ['./fad-profile-card.component.scss']
})
export class FadProfileCardComponent implements OnInit, StarRatingComponentConsumer {

  @Output('componentOutput') componentOutput: EventEmitter<FadProfileCardComponentOutputModelInterface>
    = new EventEmitter<FadProfileCardComponentOutputModelInterface>();

  @Input('componentInput') componentInput: FadProfileCardComponentInputModelInterface;

  // temporary stuff
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public checked: boolean = false;
  public toggleShowMoreLocationStatus: boolean = false;
  // end of temporary stuff
  public tier: string;
  public doctorName: string;
  public doctorDegree: string;
  public speciality: string;
  public medicalGroup: string;
  public address: string;
  public phoneNumber: string;
  public awards = [];
  public numberOfLocations: number;
  public cost_dollars: string = '00';
  public cost_pennies: string = '00';
  public isMemberCost: boolean = false;
  public acceptableReviews :boolean = false;
  public disclaimers : any;
  public accordianToggleStatus: any = {};
  public disclaimersText :string;
  public disclaimersFlag: boolean;
  public blueDistinct: string;
  public blueDistinctPlus: string;
  public blueDistinctTotal: string;
  public telehealth: boolean;
  public bdawardslist: any = [];
  public tierTooltipDescription : string;
  public fasFlag:boolean = false;
  public tierTooltip = new Array();
  public blueAwardFlag:boolean =false;
  public endDateDisclaimers: string;
  public endDateDisclaimersFlag: boolean;
  public endDateDisclaimersDate: string;

  constructor(private bcbsmaErrorHandler: BcbsmaerrorHandlerService, private router: Router,
    private doctorProfileService: FadDoctorProfileService, public authService: AuthService,
    private fadSearchResultsService: FadSearchResultsService,
    private authHttp: AuthHttp ) { }
    ngOnDestroy(): void {
      this.authHttp.hideSpinnerLoading();
    }

  ngOnInit() {
    try {
      if(JSON.parse(sessionStorage.getItem("tiersLabel"))){
        this.tierTooltip = JSON.parse(sessionStorage.getItem("tiersLabel"));
      }
        
      this.doctorName = this.componentInput.professional.doctorName;
      if(this.componentInput.professional.disclaimers){
        this.disclaimers = this.componentInput.professional.disclaimers;
        if(this.disclaimers && this.disclaimers.category && this.disclaimers.category=="on_record" && this.disclaimers.text){
          this.disclaimersFlag = true;
          this.disclaimersText = this.disclaimers.text;
        }
      }
      // this.doctorDegree = this.componentInput.professional.degrees.join(',');
      this.speciality = this.componentInput.professional.specialty;
      // const specialityBuffer = [];
      // this.componentInput.professional.specializations.map((specialization) => {
      //   specialityBuffer.push(specialization.field_specialty.name);
      //   return specialization;
      // });
      // this.speciality = specialityBuffer.join(',');
      this.blueDistinct = FadConstants.text.blueDistinct; 
      this.blueDistinctPlus = FadConstants.text.blueDistinctPlus;
      this.blueDistinctTotal = FadConstants.text.blueDistinctTotal;
      if (this.componentInput.professional.locations) {
        this.numberOfLocations = this.componentInput.professional.locations.length;
        
        const firstLocation = this.componentInput.professional.locations[0];
        const firstLocation1 = Object.create(this.componentInput.professional.locations[0]);
        this.medicalGroup = firstLocation.name;
        this.address = firstLocation.address;
        this.phoneNumber = firstLocation.phone;
        this.endDateDisclaimers = firstLocation.endDateDisclaimers.text;
        this.endDateDisclaimersFlag = firstLocation.endDateDisclaimers.showEndDateDisclmrs;
        this.endDateDisclaimersDate = firstLocation.endDateDisclaimers.futureTerminationDate;
        this.awards = [];
       
        // if(this.awards && this.awards != undefined && this.awards.length>=1)
        // {
        //   for( var i=0; i<firstLocation.awards.length;i++)
        //   {
        //     if(this.awards[i].name.includes("BLUE DISTINCTION"))
        //     {
        
        //       this.bdawardslist.push(this.awards[i].name);
        //     }
        //   }
        // }
        if(firstLocation.awards && firstLocation.awards.length){
          const blueAwards = firstLocation.awards.filter(award=>{
          return award.name.indexOf("BLUE DISTINCTION")>=0;
          });
          if(blueAwards.length){
          this.awards=[{"name":"Blue Distinctions","awardDetails":[]}];
          blueAwards.forEach(award=>{
          if(award.awardDetails.length){
            this.blueAwardFlag = true;
          award.awardDetails.forEach(awardDetail => {
          this.awards[0].awardDetails.push(awardDetail);
          });
          }
          });
          }
         
          } 
        
        
        for(var i =0;i<firstLocation.amenities.length;i++)
        {
          if(firstLocation.amenities[i].type == "Telehealth")
          this.telehealth = true;
        }
        //this.telehealth = firstLocation.amenities;
       
        
        this.accordianToggleStatus = {};
        /*this.address = [firstLocation.address.addr_line1, firstLocation.address.addr_line2, // have to check
        firstLocation.address.city, firstLocation.address.state_code, firstLocation.address.county].filter((adrItem) => {
          if (adrItem) {
            return adrItem;
          }
        }).join(', ') + ' ' + firstLocation.address.postal_code;

        if (firstLocation.phones.voice && firstLocation.phones.voice.length > 0) {
          this.phoneNumber = firstLocation.phones.voice[0].number;  // have to check
        }*/

        /* COST IS MISSING */
        /* kalagi01: DO NOT DELETE******************/
        if (firstLocation1.memberCost) {
          const costString: string = firstLocation1.memberCost.memberCost + '';
          this.cost_dollars = costString.split('.')[0];
          this.cost_pennies = costString.split('.')[1];
          this.isMemberCost = true;
        }
        if (firstLocation && firstLocation.tiers && firstLocation.tiers.description) {
          this.tier = firstLocation.tiers.description;
          this.getToolTipDescription(this.tierTooltip,this.tier);
        }
      } else {  
        this.numberOfLocations = 0;
        //this.authHttp.hideSpinnerLoading();
      }

      // temporary stuff
      this.doctorStarRating = new StarRatingComponentInputModel();
      if (this.componentInput.professional.reviews) {
        if (this.componentInput.professional.reviews.overallRating) {
          this.doctorStarRating.ratingInPercentage = parseInt('' + parseFloat(this.componentInput.professional.reviews.overallRating.toString()) * 100 / 5);
        }
        this.doctorStarRating.totalRatings = this.componentInput.professional.reviews.totalRatings;
        if (this.componentInput.professional.reviews.overallRating) {
          this.doctorStarRating.overAllRating = parseFloat(this.componentInput.professional.reviews.overallRating.toString());
        }
        // this.doctorStarRating.numberOfStars = 5;
        // end of temporary stuff
      }
      this.getProfessionalreviews();

    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadProfileCardComponent,
        FadConstants.methods.ngOnInit);
    }
  }

  getToolTipDescription(toolTip,tier){
    this.tierTooltipDescription = "";
    if(toolTip){
      toolTip.forEach(toolTips=>{
        if(toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase()===tier.toLowerCase()){
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }
  fasIcon(){
    this.fasFlag = !this.fasFlag;
  }

  private getProfessionalreviews(): void {
    const FadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    //const ratingsIdentifier: string = this.componentInput.professional['ratingsIdentifier'];
    const reviewIdentifier: string = this.componentInput.professional['reviewIdentifier'];
   
      //FadDoctorProfileRequestParams.setRatingIdentifier(ratingsIdentifier);
      FadDoctorProfileRequestParams.setReviewIdentifier(reviewIdentifier);
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        FadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      // this.doctorProfileService.getAcceptableReviewers(FadDoctorProfileRequestParams).subscribe((responseData) => {
      //   this.acceptableReviews = responseData.canReview;
      // })
      //this.authHttp.hideSpinnerLoading();

  }

  public openProfile(event): void {
    try {
      const professionalDetails: any = this.componentInput.professional;
      this.doctorProfileService.doctorProfile = professionalDetails.providerId;
      sessionStorage.setItem('professionalId', professionalDetails.providerId.toString());
      sessionStorage.setItem('locationId',this.componentInput.professional.locations[0].id.toString());
      setTimeout(() => {
        this.router.navigate(['/fad/doctor-profile']);
      }, 1);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadProfileCardComponent,
        FadConstants.methods.openProfile);
    }
  }

  public reviewPage(){
    const professionalDetails: any = this.componentInput.professional;
    
    sessionStorage.setItem('doctorreviewer',professionalDetails.doctorName.toString());
    sessionStorage.setItem('reviewIdentifier', professionalDetails.reviewIdentifier.toString());
    this.router.navigate(['/fad/review']);
  }
  
  public toggleShowMoreLocation() {
    this.toggleShowMoreLocationStatus = !this.toggleShowMoreLocationStatus;
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  /**
   * @description: get triggered when check box selection changes in the profile card. Triggers an output with the necessary info to
   * the parent component
   */
  public onSelectionChange(event): void {
    try {
      const output: FadProfileCardComponentOutputModelInterface = new FadProfileCardComponentOutputModel();
      output.professional = this.componentInput.professional;
      output.professional.isChecked = event.checked;
      output.isSelected = event.checked;
      this.checked = event.checked;
      this.componentOutput.emit(output);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadProfileCardComponent,
        FadConstants.methods.onSelectionChange);
    }
  }

  public doAuthentication() {
    this.router.navigateByUrl('/login');
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }
}
