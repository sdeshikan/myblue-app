import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CareCostPage } from './careCost.page';
import { RouterTestingModule } from '@angular/router/testing';
import { SsoService } from '../sso/sso.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { AuthService } from '../../shared/services/auth.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { AuthHttp } from '../../shared/services/authHttp.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ModalController } from '@ionic/angular';
import { HomeService } from '../../shared/services/home.service';

describe('Tab2Page', () => {
  let component: CareCostPage;
  let fixture: ComponentFixture<CareCostPage>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [
        SsoService,
        ConstantsService,
        AuthService,
        AuthHttp,
        InAppBrowser,
        HomeService,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      declarations: [CareCostPage],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareCostPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
