import { inject, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { AlertService } from '../../shared/services/alert.service';
import { FadService } from './fad.service';

describe('FadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [FadService, AlertService]
    });
  });

  it('should be created', inject([FadService], (service: FadService) => {
    expect(service).toBeTruthy();
  }));
});
