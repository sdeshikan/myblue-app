import {
  UpdateDemographicInfoRequestModelInterface,
  UpdateDemographicInfoResponseModelInterface
} from './interfaces/update-demographic-info.interface';
import { BaseDemographicInfoModel, MemberProfileGenericResponseModel } from './member-profile-generics.model';

// tslint:disable-next-line:no-empty-interface
export class UpdateDemographicInfoRequestModel extends BaseDemographicInfoModel implements UpdateDemographicInfoRequestModelInterface {}

// tslint:disable-next-line:no-empty-interface
export class UpdateDemographicInfoResponseModel extends MemberProfileGenericResponseModel
  implements UpdateDemographicInfoResponseModelInterface {}
