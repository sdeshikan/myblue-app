import { Component, OnInit } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { FitnessSelectors } from '../../../../store/selectors/fitness.selectors';
import { Observable } from 'rxjs';
import { SetReimbursement, SetSelectedBenefit } from '../../../../store/actions/fitness.actions';
import { BenefitModel } from '../../models/benefit-model';
import { ReimbursementModel } from '../../models/reimbursement-model';
import { NavController } from '@ionic/angular';
import { AlertService } from '../../../../shared/shared.module';
import { AlertType } from '../../../../shared/alerts/alertType.model';
@Component({
  selector: 'app-reimbursement-success',
  templateUrl: './reimbursement-success.page.html',
  styleUrls: ['./reimbursement-success.page.scss']
})
export class ReimbursementSuccessPage implements OnInit {
  @Select(FitnessSelectors.getConfirmationNumber) confirmationNumber$: Observable<string>;
  @Select(FitnessSelectors.getBenefits) benefits$: Observable<BenefitModel[]>;
  @Select(FitnessSelectors.hasMoreThanOneReimbursement) hasMoreReimbursement$: Observable<boolean>;

  currentSelection: ReimbursementModel;
  currentYear: number;
  disableContinue = true;
  connumber: any;
  constructor(private store: Store, private navCtrl: NavController, private alertService: AlertService) {}

  ngOnInit(): void {
    this.currentSelection = this.store.selectSnapshot(FitnessSelectors.getSelectedReimbursement);
    this.currentYear = this.store.selectSnapshot(FitnessSelectors.getSelectedBenefit).year;
    this.connumber = this.store.selectSnapshot(FitnessSelectors.getConfirmationNumber);
    this.showalert();
  }

  showalert() {
    setTimeout(() => {
      this.alertService.setAlert('Success!', '', AlertType.Success);
    }, 1000);
  }
  yearChange(e) {
    this.disableContinue = false;
    this.store.dispatch([new SetSelectedBenefit(e.detail.value.benefit), new SetReimbursement(e.detail.value.type)]);
  }

  continue() {
    this.navCtrl.navigateForward('/tabs/fitness-and-weightloss/reimbursement-details');
  }
}
