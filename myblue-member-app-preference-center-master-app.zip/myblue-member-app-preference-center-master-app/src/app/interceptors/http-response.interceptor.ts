import { HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AppService } from '../services/app.service';
import { ErrorDialogService } from '../shared/services/error-dialog.service';
import { ClearState, SetLoader } from '../store/actions/app.actions';
import { AppSelectors } from '../store/selectors/app-selectors';
import { decryptPayload } from '../utils/app.utils';

@Injectable()
export class HttpResponseInterceptor implements HttpInterceptor {
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  constructor(
    private errorDialogService: ErrorDialogService,
    private appService: AppService,
    private store: Store,
    private router: Router
  ) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      map((event: HttpEvent<any>) => {
        // console.log('EVENT ' + JSON.stringify(event, null, 2));
        if (event instanceof HttpResponse) {
          if (event.body.errormessage && event.body.errormessage !== '') {
            throw new HttpErrorResponse({
              error: event.body.errormessage,
              headers: event.headers,
              status: 500,
              statusText: 'ERROR',
              url: event.url
            });
          } else if (event.body.message || event.body.algmsg || event.body.heqmsg || event.body.lnmessage || event.body.ssomsg) {
            let decryptedBody = null;

            if (event.body.message) {
              decryptedBody = decryptPayload(event.body.message, this.cryptoToken);
            } else if (event.body.algmsg) {
              decryptedBody = { algmsg: decryptPayload(event.body.algmsg, this.cryptoToken) };
            } else if (event.body.heqmsg) {
              decryptedBody = { heqmsg: decryptPayload(event.body.heqmsg, this.cryptoToken) };
            } else if (event.body.lnmessage) {
              decryptedBody = { lnmessage: decryptPayload(event.body.lnmessage, this.cryptoToken) };
            } else if (event.body.ssomsg) {
              decryptedBody = { ssomsg: decryptPayload(event.body.ssomsg, this.cryptoToken) };
            }

            // console.log('DECRYPTED RESPONSE ' + JSON.stringify(decryptedBody, null, 2));
            return event.clone({
              body: decryptedBody
            });
          }
        }
        // this.store.dispatch(new SetLoader(true));
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('RESPONSE INTERCEPTOR ERROR: ', JSON.stringify(error, null, 2));
        // this.store.dispatch(new SetLoader(true));

        if (error.status === 401) {
          if (this.router.url !== '/tabs/login-app') {
            this.store.dispatch(new ClearState(true));
          }
          return throwError(error);
        } else {
          this.store.dispatch(new SetLoader(false));
          this.errorDialogService.openDialog('Internal Server Error: ' + request.url);
          return throwError(error);
        }
      })
    );
  }
}
