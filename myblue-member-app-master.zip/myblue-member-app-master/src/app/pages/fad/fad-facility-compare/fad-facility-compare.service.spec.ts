import { TestBed, inject } from '@angular/core/testing';
import { FadFacilityCompareService } from './fad-facility-compare.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';

describe('FadFacilityCompareService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadFacilityCompareService, BcbsmaHttpService, AuthService, AuthHttp, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityCompareService], (service: FadFacilityCompareService) => {
    expect(service).toBeTruthy();
  }));
});
