import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadMedicalIndexRequestModal } from '../modals/fad-medical-index.modal';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import {
  GetSearchBySpecialityRequestModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { FadMedicalIndexParamType } from '../modals/types/fad.types';


@Injectable()
export class FadMedicalIndexService {

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag)  hccsFlag: string;

  constructor(private http: HttpClient) {}

  public fetchMedicalIndex(request: FadMedicalIndexRequestModal): Observable<any> {
    if (request.type === FadMedicalIndexParamType.procedures) {
      // Once We received URL have to update in (FAD_CONSTANTS.urls.fadVitalsProcedureUrl)
      const procedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
      procedureSearchReq.setUserId(this.useridin).setLocale(FAD_CONSTANTS.defaults.locale + '');
      if (this.hccsFlag !== null) {
        procedureSearchReq['hccsFlag'] = this.hccsFlag;
      }

      if (this.useridin) {
        procedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      return this.http.post(FAD_CONSTANTS.urls.fadVitalsProcedureUrl, procedureSearchReq);
    } else if (request.type === FadMedicalIndexParamType.specialities) {
      const specialitySearchReq: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        specialitySearchReq.setUserId(this.useridin);
      }
      if (this.hccsFlag !== null) {
        specialitySearchReq['hccsFlag'] = this.hccsFlag;
      }
      specialitySearchReq.setNetworkId(FAD_CONSTANTS.defaults.networkId);
      return this.http.post(FAD_CONSTANTS.urls.fadVitalsSpecialitiesUrl, specialitySearchReq);
    }
  }
}
