import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list.component';
import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';

describe('FadPastSearchQueryListComponent', () => {
  let component: FadPastSearchQueryListComponent;
  let fixture: ComponentFixture<FadPastSearchQueryListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [FadPastSearchQueryListService, BcbsmaHttpService],
      declarations: [FadPastSearchQueryListComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadPastSearchQueryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
