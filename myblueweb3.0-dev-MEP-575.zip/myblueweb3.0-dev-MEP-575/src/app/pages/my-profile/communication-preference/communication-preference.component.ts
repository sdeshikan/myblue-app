import { DatePipe } from '@angular/common';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AlertService, AuthService, ConstantsService } from '../../../shared/shared.module';
import { CommunicationPreferenceService } from './communication-preference.service';
import { isNgTemplate } from '@angular/compiler';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { distinctUntilChanged } from 'rxjs/operator/distinctUntilChanged';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-communication-preferences',
  templateUrl: './communication-preference.component.html',
  styleUrls: ['./communication-preference.component.scss']
})
export class CommunicationPreferenceComponent implements OnInit, OnDestroy {
  programGroupObject: any;
  preferenceObject: any;
  filterListReverse: any;
  pageTitle: string;
  pageDesc: string;
  emailDesc: string;
  submitBtnTxt: string;
  disclosureText: string;
  programList: any;
  preferenceList = [];
  radioChecked: boolean;
  toolTipVisible = {
    Documents_Plan: false,
    Health_Benefits: false,
    BC_News: false
  };
  prefCID: string;
  displayEmailAddress: string;
  profile: any;
  isUserVerified = false;
  getConsent: any;
  getConsentDrupal: any;
  impersonate = true;
  isPhone = false;
  mobileViewPort = 992;
  preferences: any;
  getConsentRes: any;
  programGroupsObj: any;
  selectedChannel = [];
  changedItem = [];
  displayPhoneNumber: number;
  displayAddress: string;
  displayCity: string;
  displayState: string;
  displayZip: number;
  changeValue = false;

  requiredCategoryArr = ['Documents_Plan'];
  tooltipDescription = [
    'Explanation of Benefits, Summary of Health Plan Payments, Evidence of Coverage, Tax Documents, Plan Benefits and Updates, Mandated Notices.\n Some communications are only available in certain channels.',
    'Routine Care Reminders, Helpful Wellness Tips, Relevant Health Condition-Related information, Exclusive Member Perks and More.\r Some communications are only available in certain channels.',
    'Important Company Updates, Industry Awards, Recognition, and More.\n Some communications are only available in certain channels.'
  ];
  lblEmailNotVerified: string =
    'After saving your preferences you will be asked verify your email address or mobile number in order to receive communications.';
  errorText: string =
    "We're sorry. We are experiencing technical difficulties. Please try again later, or if this is urgent, please contact customer care.";
  successText: string = 'Thank you. Your selections have been saved.';

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isPhone = event.target.innerWidth <= this.mobileViewPort;
  }

  constructor(
    private dateFilter: DatePipe,
    private globalService: GlobalService,
    private alertService: AlertService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private profileService: ProfileService,
    private authHttp: AuthHttp,
    private constants: ConstantsService,
    private preferenceService: CommunicationPreferenceService,
    private authService: AuthService) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.isPhone = true;
    }

    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    this.preferences = Object.assign({}, this.activatedRoute.snapshot.data.preferences.message);
    this.preferenceService.preferenceDataChange$.subscribe(data => {
      if (data == new Date()) {
        if (JSON.parse(sessionStorage.getItem("preferenceDataChange"))) {
          sessionStorage.removeItem("preferenceDataChange");
          this.fetchUpdatedProfileInfo();
          console.log('constructor', this.selectedChannel);
        }
      }
    });
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }

  ngOnInit() {
    this.getConsentRes = JSON.parse(sessionStorage.getItem('consentData'));
    this.globalService.getProgramGroups()
      // .catch(err => {
      //   console.log("err in cp page", err);
      //   // this.router.navigate(this.previousUrl).then(
      //   //   this.alertService.setAlert(this.errorText,'',AlertType.Failure);
      //   // )
      //   return err
      // })
      .subscribe(response => {
        //if (response.message) {
        this.programGroupsObj = response.message;
        this.handleInputData();
        this.authHttp.hideSpinnerLoading();
        // } else {

        // }
      });
  }

  handleInputData() {
    this.programList = [];
    console.log(
      '#####',
      this.programGroupsObj,
      this.preferences,
      this.getConsentRes
    );
    if (this.programGroupsObj && this.programGroupsObj.ProgramGroup) {
      this.programGroupsObj.ProgramGroup.map(group => {
        if (group.ID !== 'Consents_Available') {
          if (group.Programs[0]) {
            group.Programs[0].Locales[0].DisplayTags.map(item => {
              group.Programs[0].displayName =
                item.Key === 'Name' ? item.Value : '';
            });
          }
          this.programList.push(group.Programs[0]);
          console.log('program', this.programList);
        }
      });
      this.programList.map(program => {
        program.Filters.forEach((f, index) => {
          this.reOrderFilterArray(program, f, index);
        });
      });
      this.preferenceList = [];
      if (this.preferences && this.preferences.errormessage) {
        // if user has no prefernce get CID from error msg
        this.prefCID = this.preferences.errormessage.slice(
          this.preferences.errormessage.length - 40
        );
      } else {
        // user already has preference
        console.log('$$$###', this.preferences);
        this.preferenceList = this.preferences.Preferences.filter(
          x => !(x.FilterID === 'CONSENT_PAPERLESS_SOLICIT')
        );
        console.log('$$$', this.preferenceList);
        this.prefCID = this.preferences.Preferences[0].CID;
        if (this.preferenceList.length > 0) {
          this.preferenceList.forEach(item => {
            if (item.PreferenceType === 1) {
              this.selectedChannel.push(
                this.createSelectedObject(item.ChannelID, item.ProgramID, true)
              );
              console.log("handle", this.selectedChannel);
            }
          });
        }
        this.programList.map(program => {
          program.Filters.forEach((f, index) => {
            f.selected = false;
            this.preferenceList.map(sc => {
              if (f.ID === sc.FilterID && sc.PreferenceType === 1) {
                f.selected = true;
              }
            });
          });
        });
      }
      this.displayEmailAddress = this.profile.emailAddress;
      this.displayAddress = this.profile.address1;
      this.displayCity = this.profile.city;
      this.displayState = this.profile.state;
      this.displayZip = this.profile.zip;
      this.displayPhoneNumber = this.profile.phoneNumber;
      if (
        this.profile &&
        (!this.profile.isVerifiedEmail || !this.profile.isVerifiedMobile)
      ) {
        this.alertService.setAlert(
          this.lblEmailNotVerified,
          '',
          AlertType.Failure,
          'component',
          'communication'
        );
      }
    }
  }

  showToolTip(program) {
    if (program.ID === 'Documents_Plan') {
      this.toolTipVisible.Documents_Plan = !this.toolTipVisible.Documents_Plan;
      this.toolTipVisible.Health_Benefits = false;
      this.toolTipVisible.BC_News = false;
    } else if (program.ID === 'Health_Benefits') {
      this.toolTipVisible.Health_Benefits = !this.toolTipVisible
        .Health_Benefits;
      this.toolTipVisible.Documents_Plan = false;
      this.toolTipVisible.BC_News = false;
    } else if (program.ID === 'BC_News') {
      this.toolTipVisible.BC_News = !this.toolTipVisible.BC_News;
      this.toolTipVisible.Documents_Plan = false;
      this.toolTipVisible.Health_Benefits = false;
    }
  }

  get isButtonEnabled() {
    return this.disableBtnWithValue();
  }

  disableBtnWithValue() {
    let value = true;
    if (this.changeValue) {
      this.selectedChannel.forEach(sc => {
        this.requiredCategoryArr.forEach(rc => {
          if (rc === sc.programId) {
            value = false;
          }
        });
      });
    }
    return value ? true : false;
  }

  reOrderFilterArray(program, item, index) {
    item.ChannelID === 'SOLICIT' || item.ChannelID === 'EMAIL'
      ? program.Filters.splice(0, 0, program.Filters.splice(index, 1)[0])
      : item.ChannelID === 'SMS'
        ? program.Filters.splice(1, 0, program.Filters.splice(index, 1)[0])
        : program.Filters.splice(2, 0, program.Filters.splice(index, 1)[0]);
  }

  createSelectedObject(channel, program, value) {
    const object: any = {};
    object.channelId = channel;
    object.programId = program;
    object.checked = value;
    return object;
  }

  createConsentObject() {
    const consent: any = {};
    consent.PreferenceType = this.getConsentRes.consentFlag === 'Y' ? '1' : '2';
    consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
    consent.PreferenceAttributes = this.createPreferenceAttributes();
    consent.CustomerDate = this.getConsentRes.consentTS;
    consent.CID = this.prefCID;
    return consent;
  }

  createPreferenceAttributes() {
    const sessionId = this.authHttp.sessionid();
    const attributes = [
      {
        Key: 'PS_Update_Type',
        Value: 'A'
      },
      {
        Key: 'PS_EventID',
        Value: sessionId
      },
      {
        Key: 'PS_SystemName',
        Value: 'MyBlue_PC_APP'
      },
      {
        Key: 'ConsentVerNo',
        Value: this.getConsentRes.consentLanguageId
      }
    ];
    return attributes;
  }

  onChange(event: any) {
    console.log('program List', this.programList)
    this.changeValue = true;
    console.log(' event', event);
    const { value, name, checked } = event.source
    if (name === 'Documents_Plan') {
      this.programList.forEach(program => {
        program.Filters.forEach((f) => {
          if (f.ProgramID === 'Documents_Plan') {
            if (f.ChannelID == value) {
              f.selected = checked
              if (checked) {
                let v = this.createSelectedObject(f.ChannelID, name, f.selected)
                this.selectedChannel.push(v)
              } else {
                this.selectedChannel = this.selectedChannel.filter(c => {
                  return !(c.channelId === f.ChannelID && c.programId === name);
                });
              }
            } else {
              f.selected = false
              this.selectedChannel = this.selectedChannel.filter(c => {
                return !(c.channelId === f.ChannelID && c.programId === name);
              });
            }
          }
        });
      });
    }
    else {
      if (event.source.checked) {
        this.selectedChannel.push(
          this.createSelectedObject(
            event.source.value,
            event.source.name,
            event.source.checked
          )
        );
      } else {
        this.selectedChannel = this.selectedChannel.filter(c => {
          return !(
            c.channelId === event.source.value &&
            c.programId === event.source.name
          );
        });
      }
    }
    console.log('selectedChannel', this.selectedChannel);
    this.preferenceService.selectedPreferenceChannel(this.selectedChannel);
  }

  getSelectedChannel() {
    return this.preferenceService.selectedChannel$.subscribe(res => this.selectedChannel = res);
  }

  fetchUpdatedProfileInfo() {
    this.profileService.fetchProfileInfo().subscribe(profile => {
      this.profile = Object.assign({}, profile);
      profile && this.getSelectedChannel() && this.submitPreference();
    });
  }

  reqParam() {
    this.changedItem = [];
    let tempItem: any = {};
    let consent: any = {};
    consent = this.createConsentObject();
    this.programList.map(program => {
      program.Filters.map(filter => {
        tempItem = {};
        tempItem.PreferenceType = '';
        tempItem.FilterID = filter.ID;
        tempItem.CustomerDate = this.dateFilter.transform(
          new Date(),
          'M/d/yyyy h:m:s aa'
        );
        tempItem.PreferenceAttributes = this.createPreferenceAttributes();
        tempItem.CID = this.prefCID;
        tempItem = { ...tempItem, PreferenceType: '2' };
        if (this.selectedChannel.length > 0) {
          this.selectedChannel.map(item => {
            if (
              item.programId == program.ID &&
              item.channelId == filter.ChannelID
            ) {
              tempItem = { ...tempItem, PreferenceType: '1' };
            }
          });
        }
        this.changedItem.push(tempItem);
      });
    });
    this.changedItem = [...this.changedItem, consent];
    console.log('tempitem', this.changedItem);
    return this.changedItem;
  }

  // Updating Consent
  updatePreferenceInfo(data) {
    console.log("inside update pref");
    this.globalService.updatePreferences(data).subscribe(res => {
      if (res.errormessage) {
        this.router.navigate(['/myprofile']).then(() => {
          this.alertService.setAlert(this.errorText, '', AlertType.Failure);
        });
      } else {
        this.globalService.getPreferences().subscribe(updatedpref => {
          sessionStorage.setItem(
            'paperlessPromo',
            JSON.stringify(
              this.profileService.extractPreferenceObject(updatedpref.message)
            )
          );
          this.router.navigate(['/myprofile']).then(() => {
            this.alertService.setAlert(this.successText, '', AlertType.Success);
          });
        });
      }
    });
  }

  submitPreference() {
    let emailSelected = false;
    let mobileSelected = false;
    this.selectedChannel.forEach(item => {
      if (item.channelId === 'EMAIL' || item.channelId === 'SOLICIT') {
        emailSelected = true;
      } else if (item.channelId === 'SMS') {
        mobileSelected = true;
      }
    });
    sessionStorage.setItem('communicationPreferencePath', 'communication-preferences');
    if (!this.profile.isVerifiedEmail && emailSelected) {
      this.profileService.verifyEmail(this.profile.emailAddress);
      if (!this.profile.isVerifiedMobile && mobileSelected) {
        sessionStorage.setItem('isPendingPhone', 'true');
      }
    } else if (!this.profile.isVerifiedMobile && mobileSelected) {
      this.profileService.verifyPhone(this.profile.phoneNumber);
    } else {
      console.log('submit', this.selectedChannel);
      this.updatePreferenceInfo(this.reqParam());
    }
  }

  navigateToVerifyScreen() {
    this.router.navigate(['/myprofile/verify']).then(() => {
      this.alertService.setAlert(
        'Verification code sent!.',
        '',
        AlertType.Success
      );
    });
  }

  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
        return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
      })
      : userId;
    return maskedUserId;
  }

  ngOnDestroy() {
    // if (JSON.parse(sessionStorage.getItem("preferenceDataChange"))) {
    //   this.subscription.unsubscribe();
    //   sessionStorage.removeItem("preferenceDataChange");
    // }
  }
}
