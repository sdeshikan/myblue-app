import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityProfileRequestModel } from '../modals/fad-facility-profile-details.model';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadFacilityProfileService } from './fad-facility-profile.service';

@Injectable({
  providedIn: 'root'
})
export class FadFacilityProfileResolver<T> implements Resolve<Promise<FadFacilityResponseModelInterface>> {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(
    private fadSearchResultsService: FadSearchResultsService,
    private router: Router,
    private fadFacilityProfileService: FadFacilityProfileService
  ) {}

  async resolve(): Promise<FadFacilityResponseModelInterface> {
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    // tslint:disable-next-line:radix
    const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));

    const networkId =
      searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
        ? searchCriteria.getPlanName().getNetworkId()
        : FAD_CONSTANTS.defaults.networkId;
    const geoLocation =
      searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
        ? searchCriteria.getZipCode().geo
        : FAD_CONSTANTS.defaults.geo;
    const locationId = sessionStorage.getItem('locationId');
    const procedureID = searchCriteria.getSearchText().getProcedureId();
    const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');

    const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
    if (facilityLocationFlag === 'true') {
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId);
    } else {
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
    }

    if (procedureID && facilityLocationFlag !== 'true') {
      fadDoctorProfileRequestParams.setProcedureId(procedureID);
      // tslint:disable-next-line:no-magic-numbers
      fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius') !== 'null' ? Number(sessionStorage.getItem('radius')) : 25);
    }

    const authUserId = this.useridin;
    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      fadDoctorProfileRequestParams.useridin = this.useridin;
    }

    fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');

    return await this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).toPromise();
  }
}
