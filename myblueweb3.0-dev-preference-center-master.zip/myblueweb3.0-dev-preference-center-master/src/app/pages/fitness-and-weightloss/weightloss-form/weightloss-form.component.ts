import { Location } from '@angular/common';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmailAddress } from '../../../shared/components/email/EmailAddressInterface';
import { SelectionService } from '../../../shared/services/downloadForm/selection.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { BenefitData, MemberList } from '../benefits.model';
import { ValidationService } from './../../../shared/services/validation.service';

@Component({
  selector: 'app-weightloss-form',
  templateUrl: './weightloss-form.component.html',
  styleUrls: ['./weightloss-form.component.scss']
})
export class WeightlossFormComponent implements OnInit {
  fitnessForm: FormGroup;
  isFormSubmitted = false;
  showForm = false;
  isAgreed = false;
  toolTipVisible = false;
  isEHB: boolean;
  memberList: MemberList[];
  collateralText: string;
  termsChecked: boolean;
  benefitsData: BenefitData = {};
  receiptRequired: boolean;
  showEligibility: boolean;
  showCertification: boolean;
  isMedicare: boolean;
  photosCount = 0;
  currentProgress: number;
  showProgress = false;
  submissionErrorCodes = [];
  tooltipText: string;
  sizeExceeded = false;
  constructor(
    private selectionService: SelectionService,
    private location: Location,
    private fb: FormBuilder,
    public router: Router,
    private authService: AuthService,
    private validationService: ValidationService,
    private constantService: ConstantsService
  ) {}
  email_Addresses: EmailAddress[] = [];

  ngOnInit() {
    this.benefitsData = this.selectionService.getBenefitModelData();
    this.collateralText = this.benefitsData.collateralText;
    this.isMedicare =
      this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex';
    this.initializeFitnessForm();
    this.tooltipText = this.benefitsData.collateralText;
  }
  initializeFitnessForm() {
    const totalRequestAmount = '';
    this.receiptRequired = this.benefitsData.weightlossReceiptRequired;
    this.isEHB = this.benefitsData.isEHB;
    this.memberList = this.benefitsData.memberList;
    const formGroup = {
      member: ['', this.memberList.length > 1 ? [Validators.required] : []],
      fitnessCostAmount: ['', this.isEHB ? [Validators.required, Validators.min(1), Validators.max(1000)] : []],
      annualFee: ['', [this.selectionService.checkAnnualFee(), Validators.max(1000)]],
      totalrequestamount: [totalRequestAmount, [Validators.required, Validators.min(1), Validators.max(1000)]],
      programName: ['', Validators.required],
      address: ['', Validators.required],
      state: ['', Validators.required],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)]],
      phoneNumber: ['', [Validators.required, Validators.minLength(10), Validators.pattern(/^\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$/)]],
      termsCheck: ['', [Validators.required]],
      email: [{ value: '', disabled: true }, [Validators.required, this.validationService.emailValidator()]],
      additionalemail: ['', [this.validationService.emailValidator()]],
      images: ['', this.receiptRequired && this.photosCount === 0 ? [Validators.required] : []]
    };
    this.fitnessForm = this.fb.group(formGroup);
    this.fitnessForm.patchValue({ state: 'MA' });
    this.showForm = true;
    this.collateralText = this.benefitsData.weightlossCollateralText;
    this.setMemberList(this.memberList);
    this.setEmails();
  }

  setMemberList(memberList) {
    if (memberList.length === 1) {
      this.fitnessForm.patchValue({ member: memberList[0] });
    }
  }

  setEmails() {
    const maskedEmail = this.benefitsData.subscriberMaskedEmail;
    if (maskedEmail) {
      this.email_Addresses.push({
        title: '',
        emailAddress: maskedEmail,
        hide: false,
        formName: '',
        editable: false
      });
    } else {
      this.email_Addresses.push({
        title: '',
        emailAddress: maskedEmail,
        hide: false,
        formName: '',
        editable: true
      });
    }
    const memberEmail = this.benefitsData.memberEmail;
    if (memberEmail) {
      this.email_Addresses.push({
        title: '',
        emailAddress: memberEmail,
        hide: false,
        formName: '',
        editable: true
      });
    }
  }

  removeEmail($event: { email: EmailAddress; e: any }) {
    const email_address = $event.email;
    this.email_Addresses.splice(this.email_Addresses.indexOf(email_address), 1);
  }

  onBackPressed() {
    this.location.back();
  }
  termsAndConditionsChange() {
    this.termsChecked = this.fitnessForm.get('termsCheck').value;
  }
  onSubmit() {
    this.selectionService.submitForm(this.fitnessForm.value, this.isEHB).subscribe((response: HttpEvent<any> | any) => {
      if (response.type === HttpEventType.Sent) {
        // Show progress here
        this.showProgress = true;
      } else if (response.type === HttpEventType.UploadProgress) {
        // Update progress here
        this.currentProgress = Math.floor(100 * (response.loaded / (response.total * 1.2)));
      } else if (response.type === HttpEventType.DownloadProgress) {
        // Set percentage to 1 (100%) and close loader
        this.currentProgress = 100;
      } else {
        this.submissionErrorCodes = this.benefitsData.submissionErrorCodes;
        this.submissionErrorCodes.forEach(codeVal => {
          if (codeVal === response.result) {
            this.router.navigate(['fitness-and-weightloss/reimbursement-oops']);
          }
        });

        if (response.confirmationNumber) {
          this.benefitsData.confirmationNumber = response.confirmationNumber;
          this.selectionService.setBenefitModelData(this.benefitsData);
          this.router.navigate(['fitness-and-weightloss/success-message']);
        }
      }
    });
  }

  showToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }

  openEligibility() {
    this.showEligibility = true;
  }

  openCertification() {
    this.showCertification = true;
  }

  displayModal($event: { showModal: boolean }) {
    this.showEligibility = $event.showModal;
    this.showCertification = $event.showModal;
  }

  imagesCount($event: { imagesCount: number }) {
    this.photosCount = $event.imagesCount;
  }

  disableSubmit(value) {
    this.sizeExceeded = value;
  }

  toggleToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }

  cancel() {
    this.router.navigate(['fitness-and-weightloss']);
  }
}
