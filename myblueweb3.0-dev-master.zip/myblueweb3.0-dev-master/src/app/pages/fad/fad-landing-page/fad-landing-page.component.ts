import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChanges,
  ViewChild,
  HostListener,
  ElementRef,
  Output,
  EventEmitter,
  AfterViewInit
} from '@angular/core';
import {
  FadLandingPageCompInputInterface,
  FadAutoCompleteOptionForSearchTextInterface,
  FadAutoCompleteComplexOptionInterface,
  FadLinkOptionInterface,
  FadLandingPageCompOutputInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  FadAutoCompleteOptionForSearchText,
  FadAutoCompleteComplexOption,
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  LandingPageResponseCacheModel,
  FadMembersInfoRequestModel,
  FadMembersInfoResponseModel,
  FadMembersInfoModel
} from '../modals/fad-landing-page.modal';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FadConstants } from '../constants/fad.constants';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import {
  FadLandingPageComponentMode,
  FadLandingPageFocusTracker,
  AuthRequestType,
  FadResourceTypeCode,
  FadResouceTypeCodeConfig
} from '../modals/types/fad.types';

import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { startWith } from 'rxjs/operators/startWith';
import { delay } from 'rxjs/operators/delay';
import { MatAutocompleteTrigger } from '@angular/material';
import { FadLandingPageService } from './fad-landing-page.service';
import {
  FPSRPlan,
  DoctorProfileSearchRequestModel,
  FZCSRCity,
  FadVitalsZipCodeSearchRequestModel,
  FadVitalsNetwork
} from '../modals/fad-vitals-collection.model';
import {
  FVSHRSearchHistoryInterface,
  DoctorProfileSearchRequestModelInterface,
  FadVitalsZipCodeSearchRequestModelInterface,
  FadVitalsNetworkInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { FadPastSearchQueryListService } from '../fad-past-search-query-list/fad-past-search-query-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { MatchTextHighlightPipe } from '../../../shared/pipes/match-text-highlight/match-text-highlight.pipe';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { AuthService } from '../../../shared/shared.module';
import { GetSearchByProviderRequestModelInterface } from '../modals/interfaces/getSearchByProvider-models.interface';
import { GetSearchByProviderRequestModel } from '../modals/getSearchByProvider.models';
import { FormBuilder } from '@angular/forms';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { FadService } from '../fad.service';
import * as cloneDeep from 'lodash/cloneDeep';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { BreadCrumb } from '../utils/fad.utils';
import { GlobalService } from '../../../shared/services/global.service';
import { ConstantsService } from './../../../shared/services/constants.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { FadResolverService } from '../../../shared/routeresolvers/FadResolverService';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { AppModalsService } from '../../../shared/modals/appmodals.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
declare let $: any;

@Component({
  selector: 'app-fad-landing-page',
  templateUrl: './fad-landing-page.component.html',
  styleUrls: ['./fad-landing-page.component.scss']
})
export class FadLandingPageComponent implements OnInit, OnChanges, AfterViewInit {
  // optional input value to be provided only when consumed by other components like
  // fad-search-results component
  @Input('componentInput') componentInput: FadLandingPageCompInputInterface;
  @Output('componentOutput') componentOutput = new EventEmitter<FadLandingPageCompOutputInterface>();
  @ViewChild('searchTextTypeAhead', { read: MatAutocompleteTrigger }) searchTextTypeAheadTrigger;
  @ViewChild('zipCodeTypeAhead', { read: MatAutocompleteTrigger }) zipCodeTypeAheadTrigger;
  @ViewChild('planTypeAhead', { read: MatAutocompleteTrigger }) planTypeAheadTrigger;
  @ViewChild('dependantListTypeAhead', { read: MatAutocompleteTrigger }) dependantListTypeAheadTrigger;
  @ViewChild('searchBar') searchBar: ElementRef;

  public fadConstants = FadConstants;
  public zipClearIcon = 'hidden';
  public planClearIcon = 'hidden';
  public dependantClearIcon = 'hidden';
  public searchTextPlaceHolder: string = '';
  public networkPlaceHolder: string = '';
  public isMedicareUser: boolean = false;
  public isRVRNVUser: boolean = false;
  // public mleIndicator: string = 'Y';

  public componentMode: FadLandingPageComponentMode = FadConstants.flags.fadLandingPageComponentMode_Normal;

  public displayPastSearchHistoryFlag: boolean = false;
  public displayDependentsOptionFlag: boolean = false;

  public searchControls: FadLandingPageSearchControlsModel;

  public zipCodeOptions: FZCSRCity[] = [];
  public filteredZipCodeOptions: Observable<FZCSRCity[]>;

  public dependantsList: FadMembersInfoModel[] = [];
  public filteredDependantsList: Observable<FadMembersInfoModel[]>;
  public selectedMember: FadMembersInfoModel;

  public defaultPlanOptions: FadAutoCompleteOptionForSearchText[] = [];
  public planOptions: FadAutoCompleteOptionForSearchText[] = [];
  public filteredPlanOptions: Observable<FadAutoCompleteOptionForSearchText[]>;

  public autoCompleteOptionsForSearchText: FadAutoCompleteOptionForSearchText[] = [];
  public filteredAutoCompleteSearchOptions: Observable<FadAutoCompleteOptionForSearchText[]>;

  public searchHistory: FVSHRSearchHistoryInterface[] = [];

  public viewPortWidth: number = null;
  public emboseSearchTextField: boolean = false;
  public emboseZipCodeField: boolean = false;
  public embosePlanField: boolean = false;
  public emboseDependantsField: boolean = false;

  public focusedTarget: string;
  public userCurrentPlan: FPSRPlan = new FPSRPlan();

  private preventSearchTextAutoCompleteDropdown: boolean = false;
  private textToHighlightInPlanOption: string;
  private textToHighlightInSearchTextOption: string;
  private isLogin: boolean = false;
  private titleCase: TitleCasePipe;

  private defaultAutoCompleteSearchOption: FadAutoCompleteOptionForSearchTextInterface[] = [];
  private searchTextMaterialAutoCompleteBugWorkAroundFlag: number = 0;
  private searchTextMaterialAutoCompleteBugWorkAroundTimerFlag: number = 0;
  private debounceTime: number = 400;
  private isPageReload: boolean = false;
  private bypassPlanFieldFocusLogic: boolean = false;
  private userState: string;

  public getLocalStorageZipCodeOption: FZCSRCity;
  public searchButtonDisabled: boolean = true;
  public fadInfo: any;
  public showTextField: boolean = false;
  public zipCodeValidationErrors = {
    invalidZipCode: {
      exists: false,
      errorMsg: 'Please enter Zip Code or City, State.',
      display: false
    },
    noMatchFound: {
      exists: false,
      errorMsg: 'Please check that you have entered the correct Zip Code or City.',
      display: false
    }
  };

  public planValidationErrors = {
    invalidPlan: {
      errorMsg: 'Please enter a valid plan name.',
      display: false
    },
    noMatchFound: {
      errorMsg: 'Please check that you have entered a correct plan name.',
      display: false
    }
  };
  private isChangedUserFlag: boolean;
  public iszipcodechangeFlag: boolean = false;
  private currentPlanNetwork: any;
  private autoCompleteWarningFlag: any;
  public lat: string;
  public lng: string;
  constructor(
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public landingPageService: FadLandingPageService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadPastSearchQueryListService: FadPastSearchQueryListService,
    private doctorProfileService: FadDoctorProfileService,
    private facilityProfileService: FadFacilityProfileService,
    public authService: AuthService,
    public fb: FormBuilder,
    private fadService: FadService,
    private profileService: ProfileService,
    private activatedRoute: ActivatedRoute,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private globalService: GlobalService,
    private constantsService: ConstantsService,
    private authHttp: AuthHttp,
    private appModalService: AppModalsService,
    public fadResolverService: FadResolverService
  ) {
    this.landingPageService.plannetworkdata = this.activatedRoute.snapshot.data.fadInfo;
    console.log(this.activatedRoute.snapshot.data.fadInfo);

    this.isChangedUserFlag = false;
    this.fadInfo = this.landingPageService.plannetworkdata;
    const planOption = new FadAutoCompleteOptionForSearchText();
    if (!this.fadInfo) {
      //alert("testinside");
      this.fadResolverService.getVitalsPlanInfo().subscribe(data => {
        this.landingPageService.plannetworkdata = data;
        this.fadInfo = data;
        this.fadInfo.networks.map(_network => {
          const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
          const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
          planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
          if (plan.getPlanIndicator()) {
            this.userCurrentPlan = plan;
          }
        });
      });
    }

    this.autoCompleteWarningFlag = false;

    //Reset Plan option when user login
    console.log(sessionStorage.getItem('userLoginFlag'));
    if (sessionStorage.getItem('userLoginFlag') != 'true') {
      this.fadInfo = this.activatedRoute.snapshot.data.fadInfo;
      if (this.fadInfo) {
        this.userCurrentPlan = this.getDefaultPlan();
        this.authService.setMleEligibility(this.fadInfo.mleEligibility);
        if (this.userCurrentPlan.getName() && this.userCurrentPlan.getId()) {
          let cachedPlans = new FadAutoCompleteComplexOption()
            .setSimpleText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId());
          //this.searchControls = new FadLandingPageSearchControlsModel();
          this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlans);
          sessionStorage.setItem('userLoginFlag', 'true');
        }
      }
    }

    // setting modal popup for mleindicator for null & N scenarios
    const mleIndicator = this.fadInfo && this.fadInfo.mleEligibility;
    const hccsFlag = this.fadInfo && this.fadInfo.hccsFlag;
    // if (!mleIndicator || (mleIndicator && mleIndicator === 'N')) {
    //   if (!authHttp.isModalOpen('mleIndicatorError')) {
    //     $('#mleIndicatorError').modal('open');
    //   }
    // }
    if (hccsFlag !== undefined) {
      sessionStorage.setItem('hccsFlag', hccsFlag);
    }
    this.authService.setMLEIndicator(mleIndicator);
    if (this.fadInfo && this.fadInfo.mleEligibility) {
      //this.authService.setMleEligibility(this.fadInfo.mleEligibility);
    }
    this.viewPortWidth = window.innerWidth;
    const checkzipcodechangeflag = sessionStorage.getItem('zipcodechangeflag');
    const zipCodeLastSearchedWith: FZCSRCity = <FZCSRCity>JSON.parse(localStorage.getItem('FadLandingPageSearchCriteria_zipCode'));
    const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
    if (zipCodeLastSearchedWith) {
      this.getLocalStorageZipCodeOption = Object.assign(new FZCSRCity(), cloneDeep(zipCodeLastSearchedWith));
    } else {
      this.fillLocationOnLoad();
      this.getLocalStorageZipCodeOption = null;
    }

    // communication preference and consent api
    if (this.authService.authToken && this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      forkJoin([
        this.globalService.getProgramGroups(),
        this.globalService.getPreferences(),
        this.globalService.getConsent(),
        this.profileService.fetchProfileInfo()
      ]).subscribe(responses => {
        if (responses.length > 0) {
          sessionStorage.setItem('programGroups', JSON.stringify(responses[0].message));
          if (responses[1].errormessage) {
            sessionStorage.setItem('preferences', JSON.stringify(responses[1]));
          } else {
            sessionStorage.setItem('preferences', JSON.stringify(responses[1].message));
          }
          sessionStorage.setItem('consentData', JSON.stringify(responses[2]));
          this.profileService.setProfile(responses[3]);
          this.appModalService.setModalDataChange();

          if (responses[3]) {
            if (
              responses[1].errormessage &&
              !(
                this.authService.authToken &&
                this.authService.authToken.userType &&
                this.authService.authToken.userType.toLowerCase() === 'medicare'
              )
            ) {
              setTimeout(() => {
                $('#communicationPreference').modal('open');
              }, 50);
            }
          }
        }
      });
    }
  }

  ngOnInit() {
    try {
      //$('ng4-loading-spinner .spinner').addClass('visible');
      this.networkPlaceHolder = this.fadConstants.text.landingPage_selectPlan_placeHolder_anonymous;

      if (
        this.isAnonymousUser() ||
        this.authService.getScopeName() === 'REGISTERED-NOT-VERIFIED' ||
        this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED'
      ) {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
      } else if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        (this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex')
      ) {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
      } else {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_user;
      }
      this.router.events.subscribe(event => {
        if (event instanceof NavigationEnd) {
          if (!event.url.includes('/fad')) {
            sessionStorage.removeItem('selMemIdx');
          }
        }
      });

      if (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && !this.showTextField) {
        this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Find a Doctor').setUrl('/fad'));
      }

      // DO NOT CHANGE CODE ORDER - STEP 1
      // step 1 - If the component is being opened in abstract mode, the set values persisted from the
      // main screen on to the search fields in the current age
      if (this.componentInput && this.componentInput.componentMode === FadConstants.flags.fadLandingPageComponentMode_Abstract) {
        this.searchControls = new FadLandingPageSearchControlsModel();
        this.searchControls.setValues(<FadLandingPageSearchControlValues>this.fadSearchResultsService.getSearchCriteria());
        this.landingPageService.setCachedSearchControlState(this.fadSearchResultsService.getSearchCriteria());
      }

      // DO NOTE CHANGE CODE ORDER - STEP 2
      // step 2 - use existing search control references if any
      if (this.landingPageService.getCachedSearchControlState()) {
        this.searchControls = <FadLandingPageSearchControlsModel>this.landingPageService.getCachedSearchControlState();
        //alert("cached plan");
        this.fadInfo = this.landingPageService.plannetworkdata;
        if (
          this.searchControls.planControl.value === '' ||
          this.searchControls.planControl.value == null ||
          this.searchControls.planControl.value.simpleText == ''
        ) {
          this.currentPlanNetwork = new FadAutoCompleteComplexOption()
            .setSimpleText(this.getDefaultPlanOption().getName())
            .setNetworkId(this.getDefaultPlanOption().getId());
          this.fadSearchResultsService.setLastSelectedPlanOption(this.currentPlanNetwork);
          this.searchControls.planControl.setValue(this.currentPlanNetwork);
        }
      } else {
        this.searchControls = new FadLandingPageSearchControlsModel();
        this.fadInfo = this.landingPageService.plannetworkdata;
      }

      // DO NOT CHANGE CODE ORDER - STEP 3
      // step 3 - service call initiations. This is sequential and hence the code order must not change
      if (
        this.viewPortWidth > 992 ||
        (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
      ) {
        this.initData();
      } else if (
        this.landingPageService.getCachedSearchControlState() &&
        this.searchControls.dependantNameControl.value &&
        this.authService.getDependentsList() &&
        this.authService.getDependentsList().dependents.length > 0
      ) {
        this.displayDependentsOptionFlag = true;
      } else if (this.landingPageService.getCachedSearchControlState() && this.searchControls.dependantNameControl.value) {
        this.fetchDependentList();
      }

      /*this.displayDependentsOptionFlag = true; */

      // DO NOTE CHANGE CODE ORDER - STEP 4
      // step 4 - page needs to be updated with cached values if any, only after the defaults are loaded into memory
      if (this.fadPastSearchQueryListService.searchControlValues) {
        this.searchControls.setValues(<FadLandingPageSearchControlValues>this.fadPastSearchQueryListService.searchControlValues);
        this.fadPastSearchQueryListService.searchControlValues = null;
      }

      // step 4 - help to enhanced the search functionlity in the typehead component which are loaded into memory with data
      if (
        this.viewPortWidth > 992 ||
        (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
      ) {
        this.enhancedSearchAfterInitData();
      }

      const searchText: string = this.searchControls.searchTypeAheadControl.value;
      if (!searchText) {
        this.isPageReload = true;
      }

      if (searchText && searchText.trim) {
        this.isPageReload = false;
        this.stripAllDoctorFacilityTextAndUpdateUI(searchText);
      } else {
        this.searchControls.searchTypeAheadControl.setValue(searchText);
      }
      //   $('ng-loading-spinner .spinner').addClass('visible');
      this.landingPageService.getToolTipInfo().subscribe(data => {
        if (data.toolTipInfo.tiersLabel) {
          data.toolTipInfo.tiersLabel.map(tierLabels => {
            switch (tierLabels.toolTip.code) {
              case 'TEBT':
                tierLabels.toolTip.code = 'Enhanced Benefits Tier';
                break;
              case 'TBBT':
                tierLabels.toolTip.code = 'Basic Benefits Tier';
                break;
              case 'TSBT':
                tierLabels.toolTip.code = 'Standard Benefits Tier';
                break;
              case 'THCS':
                tierLabels.toolTip.code = 'Higher Cost Share';
                break;
              case 'TLCS':
                tierLabels.toolTip.code = 'Lower Cost Share';
                break;
              default:
                tierLabels.toolTip.code = 'Higher Cost Share';
                break;
            }
          });
          //console.log("tiersLabel",data.toolTipInfo.tiersLabel);

          sessionStorage.setItem('tiersLabel', JSON.stringify(data.toolTipInfo.tiersLabel));
          sessionStorage.setItem('profileLabel', JSON.stringify(data.toolTipInfo.profile));
        }
      });
      //$('ng4-loading-spinner .spinner').removeClass('visible');
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      this.componentInput = changes.componentInput.currentValue;
      // if the component is being displayed as part of other components in 'abstract' mode
      // for example as part of fad-search-results component
      // use the input provided by the consumer to popuplate the component
      if (this.componentInput) {
        //this.componentMode = this.componentInput.componentMode;

        this.showTextField = true;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngOnChanges
      );
    }
  }

  ngAfterViewInit() {
    try {
      if (this.landingPageService.getCachedSearchControlState()) {
        this.landingPageService.clearCachedSearchControlState();
      }

      if (
        this.landingPageService.getCachedSearchControlState() &&
        this.landingPageService.cachedResponse.planOptions &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger._element.nativeElement.value = this.searchControls.planControl.value.getSimpleText();
      } else if (
        this.isLogin &&
        (!this.landingPageService.cachedResponse || !this.landingPageService.cachedResponse.planOptions) &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger._element.nativeElement.value = this.userCurrentPlan.getName();
      }

      if (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal) {
        this.updateZipCodeFieldFromApplicationStorage();

        let cachedPlan: FadAutoCompleteComplexOption = this.fadSearchResultsService.getLastSelectedPlanOption();

        if (!cachedPlan) {
          const searchCriteria = Object.assign(new FadLandingPageSearchControlValues(), this.fadSearchResultsService.getSearchCriteria());
          cachedPlan = searchCriteria && searchCriteria.getPlanName ? searchCriteria.getPlanName() : null;
          if (!cachedPlan || !cachedPlan.getSimpleText || cachedPlan.getSimpleText() === '') {
            cachedPlan = new FadAutoCompleteComplexOption()
              .setSimpleText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId());
          }
        }
        this.searchControls.planControl.setValue(cachedPlan);
        this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlan);

        if (this.planOptions.length === 0) {
          const planOption = new FadAutoCompleteOptionForSearchText();
          planOption.addOption(
            new FadAutoCompleteComplexOption().setSimpleText(this.userCurrentPlan.getName()).setNetworkId(this.userCurrentPlan.getId())
          );
          this.planOptions.push(planOption);
        }
      } else {
        this.updateZipCodeFieldFromApplicationStorage();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngAfterViewInit
      );
    }
    let zipCode = this.searchControls.zipCodeTypeAheadControl.value;
    let plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
    if (zipCode && !plan) {
      this.autoCompleteWarningFlag = true;
    } else {
      this.autoCompleteWarningFlag = false;
    }
  }

  private addOnClickToAutoCompleteSpinner() {
    const autoCompleteSpinnerList: HTMLElement[] = <HTMLElement[]>Array.from(document.getElementsByClassName('mat-auto-complete-spinner'));
    autoCompleteSpinnerList.map(spinner => {
      const _spinner = <HTMLDivElement>spinner;
      spinner['removeAllListeners'] ? spinner['removeAllListeners']() : this.noop();
      _spinner.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
      });
    });
  }

  getDefaultPlan(): FPSRPlan {
    console.log(this.fadInfo);
    let resultValue: FPSRPlan = new FPSRPlan();
    try {
      if (this.fadInfo && this.fadInfo && this.fadInfo.networks) {
        this.fadInfo.networks.some(res => {
          if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
            resultValue = Object.assign(new FPSRPlan(), res.network);
            return true;
          }
        });
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getDefaultPlanOption
      );
    }
    return resultValue;
  }

  getDefaultPlanOption(): FPSRPlan {
    let resultValue: FPSRPlan = new FPSRPlan();
    console.log(this.fadInfo);
    try {
      if (this.fadInfo && this.fadInfo.networks) {
        this.fadInfo.networks.some(res => {
          if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
            resultValue = Object.assign(new FPSRPlan(), res.network);
            return true;
          }
        });
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getDefaultPlanOption
      );
    }
    return resultValue;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    try {
      this.fadService.resetServiceError();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngOnDestroy
      );
    }
  }

  // will help determine the window width of the screen at all times
  // helps make RWD specific code as necessary
  // viewPortWidth for desktop is >= 993, for mobile and tablet is <=992
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.viewPortWidth = window.innerWidth;
  }

  /**
   * @description triggered with login/register/authenticate related links are clicked
   * YET TO BE CODED
   * @param event : HTML Event
   * @param target : AuthRequestType
   */
  public redirectRequestPlanDropDown(event, target?: AuthRequestType) {
    try {
      if (target === AuthRequestType.authenticate) {
        this.globalService
          .redirectionRoute()
          .then(response => {})
          .catch(route => {
            this.router.navigate([route]);
          });
      } else if (target === AuthRequestType.login) {
        this.router.navigateByUrl('/login');
      } else if (target === AuthRequestType.register) {
        this.router.navigateByUrl('/register');
      }
      event.stopPropagation();
      // throw new Error('Yet to code >>> target is ' + target);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.redirectRequestPlanDropDown
      );
    }
  }

  /**
   * @description helps highlight text being searched for matching in the auto complete options
   * @param optionText - string  - the option that is displayed in the drop down autocompelete list
   */
  public getMatchHighlightedTextInPlanOption(optionText: string): string {
    let returnValue: string = '';
    try {
      if (optionText) {
        returnValue = new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInPlanOption);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getMatchHighlightedTextInPlanOption
      );
    } finally {
      return returnValue;
    }
  }

  public getTotalMatchHiglithedPlanOption(): boolean {
    const textMatchFlag = this.textToHighlightInPlanOption && this.textToHighlightInPlanOption !== '' ? true : false;
    return textMatchFlag;
  }

  /**
   * @description helps highlight text being searched for matching in the auto complete options
   * @param optionText - string  - the option that is displayed in the drop down autocompelete list
   */
  public getMatchHighlightedTextInSearchTextOption(optionText: string): string {
    let returnValue: string = '';
    try {
      if (optionText) {
        returnValue = new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInSearchTextOption);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getMatchHighlightedTextInSearchTextOption
      );
    } finally {
      return returnValue;
    }
  }

  /**
   * @description helps remove focus from a search field to avoid the auto complete list from being displayed
   * @param target - string
   */
  public removeIconFocusTracker(target: string, event?) {
    try {
      this.focusedTarget = target;
      if (this.viewPortWidth < 993) {
        switch (target) {
          // when remove icon inside the search doctor field is clicked
          case FadLandingPageFocusTracker.searchText:
            break;
          // when remove icon inside the search zipcode field is clicked
          case FadLandingPageFocusTracker.zipCode:
            this.landingPageService.cachedResponse.zipCodeOptions = [];
            this.filteredZipCodeOptions = Observable.of([]);
            this.displayZipCodeDropDown(event);
            break;
          // when remove icon inside the search plan field is clicked
          case FadLandingPageFocusTracker.plan:
            this.displayPlanDropDown(event);
            break;
          // when remove icon inside the search dependant field is clicked
          case FadLandingPageFocusTracker.dependant:
            break;
          // otherwise do nothing
          default:
            break;
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removeIconFocusTracker
      );
    }
  }

  /**
   * @description helps display only the search for doctor fiel on mobile screen
   * @param flag
   */
  public emboseSearchTextFieldOnScreen(flag: boolean, cancelButtonClicked?: boolean): boolean {
    try {
      this.emboseSearchTextField = flag;
      if (!flag && !cancelButtonClicked) {
        this.triggerSearchOnEnterKey();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseSearchTextFieldOnScreen
      );
    }
    return flag;
  }

  public triggerSearchOnSearchLensIcon(flag: boolean): boolean {
    try {
      this.emboseSearchTextFieldOnScreen(flag);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.triggerSearchOnSearchLensIcon
      );
    }
    return flag;
  }
  /**
   * @description helps display only the search for zipcode field on mobile screen
   * @param flag
   */
  public emboseZipCodeFieldOnScreen(flag: boolean, location?: FZCSRCity): boolean {
    try {
      if (location) {
        const selectedZipCodeOption: FZCSRCity = new FZCSRCity();
        selectedZipCodeOption
          .setCity(location.city)
          .setCounty(location.county)
          .setGeo(location.geo)
          .setLat(location.lat)
          .setLng(location.lng)
          .setName(location.name)
          .setPlace_id(location.place_id)
          .setScore(location.score)
          .setState(location.state)
          .setState_code(location.state_code)
          .setZip(location.zip);

        this.fadSearchResultsService.setLastSelectedZipCodeOption(selectedZipCodeOption);

        setTimeout(() => {
          try {
            this.zipCodeTypeAheadTrigger._onChange(selectedZipCodeOption.getDisplayValue());
            this.zipCodeTypeAheadTrigger.closePanel();
            this.emboseZipCodeField = false;
          } finally {
            // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
          }
        }, 100);
      } else {
        this.emboseZipCodeField = flag;
      }

      this.zipClearIcon = flag ? 'visible' : 'hidden';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseZipCodeFieldOnScreen
      );
    }
    return flag;
  }

  /**
   * @description helps display only the search for plan name field on mobile screen
   * @param flag
   */
  public embosePlanFieldOnScreen(flag: boolean, planOption?: FadAutoCompleteComplexOption): boolean {
    try {
      console.log(planOption);
      if (planOption) {
        const selectedPlanOption: FadAutoCompleteComplexOption = Object.assign(new FadAutoCompleteComplexOption(), planOption);

        this.planValidator(selectedPlanOption.getSimpleText() || selectedPlanOption.getContextText());

        this.fadSearchResultsService.setLastSelectedPlanOption(selectedPlanOption);
        this.searchControls.planControl.setValue(selectedPlanOption);
        console.log(this.searchControls);
        setTimeout(() => {
          try {
            this.planTypeAheadTrigger._onChange(selectedPlanOption.getSimpleText());
            this.planTypeAheadTrigger.closePanel();
            this.embosePlanField = false;
          } finally {
            // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
          }
        }, 100);
      } else {
        this.embosePlanField = flag;
      }

      this.planClearIcon = flag ? 'visible' : 'hidden';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseZipCodeFieldOnScreen
      );
    }

    return flag;
  }

  public planAutoCompleteListDesktopViewSelectionChange(option: FadAutoCompleteComplexOption): void {
    console.log(option);

    try {
      this.bypassPlanFieldFocusLogic = true;
      if (this.userCurrentPlan.getId() == option.getNetworkId()) {
        sessionStorage.setItem('networkChange', 'false');
      } else {
        if (this.authService.authToken) {
          if (this.authService.useridin && this.authService.authToken.userType) {
            sessionStorage.setItem('networkChange', 'true');
          }
        }
      }
      console.log(option.getInfoText());
      if (option.getInfoText() === 'my-current-plan-option') {
        option.setSimpleText(option.getContextText());
        option.setInfoText('');
        option.setContextText('');
      }
      console.log(option);
      if (option.getInfoText() !== FadConstants.plans.dontKnowPlanOption) {
        this.fadSearchResultsService.setLastSelectedPlanOption(option);
        this.planValidator(option.getSimpleText() || option.getContextText());
        this.doSearch();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.planAutoCompleteListDesktopViewSelectionChange
      );
    }
  }

  /**
   * @description helps display only the search for dependants field on mobile screen
   * @param flag
   */
  public emboseDependantsFieldOnScreen(flag: boolean): boolean {
    try {
      this.emboseDependantsField = flag;
      this.dependantClearIcon = flag ? 'visible' : 'hidden';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseDependantsFieldOnScreen
      );
    }
    return flag;
  }

  /**
   * @description helps navigate to All Specialities and All Procedures page
   * @param event
   * @param link
   */
  public openSelectionList(event, link: FadLinkOptionInterface): boolean {
    try {
      this.router.navigate([link.href]);
      event.stopPropagation();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.openSelectionList
      );
    }
    return false;
  }

  /**
   * @description helps display the zip code typeahead drop down with options
   * @param event
   */
  public checkAndDisplayZipCodeDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayZipCodeDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayZipCodeDropDown
      );
    }
    return true;
  }

  /**
   * @description helps display the plan name typeahead drop down with options
   * @param event
   */
  public checkAndDisplayPlanDropDown(event) {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPlanDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayPlanDropDown
      );
    }
  }

  /**
   * @description helps dislay dependants name typeahead drop down with options on screen
   * @param event
   */
  public checkAndDisplayDependentListDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayDependentListDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayDependentListDropDown
      );
    }
    return true;
  }

  /**
   * @description helps display past search history on screen
   * @param event
   */
  public checkAndDisplayPastSearchHistory(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPastSearchHistory();
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayPastSearchHistory
      );
    }
    return true;
  }

  /**
   * @description - defines what has to happen when the user selects a different option value in
   *    the search type a head drop down. In this case it ensures that the drop down list
   *    being displayed is hidden from view
   */
  public onSearchTextOptionSelected(option: FadAutoCompleteComplexOption, isSpecialityOption: boolean): void {
    try {
      this.isPageReload = false;
      this.fadSearchResultsService.setLastSelectedSearchTextOption(option);
      this.preventSearchTextAutoCompleteDropdown = true;
      let zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      let plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
      if (zipCode && !plan) {
        this.autoCompleteWarningFlag = true;
      } else {
        this.autoCompleteWarningFlag = false;
      }
      if (isSpecialityOption) {
        if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
          // if a speciality option is clicked in the autocomplete dropdown, trigger the search for the same
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
          searchControlValues.setSearchText(option);
          this.searchControls.setValues(searchControlValues);
          option.setSimpleText(searchControlValues.getSearchText().getSimpleText());
          this.fadSearchResultsService.setSearchCriteria(searchControlValues);

          if (!this.isSearchButtonDisabled()) {
            this.doSearch();
          }
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.onSearchTextOptionSelected
      );
    }
  }

  onZipCodeTypeaheadOptionSelectionChange(location: FZCSRCity) {
    //alert("called");
    try {
      this.fadSearchResultsService.setLastSelectedZipCodeOption(location);
      this.iszipcodechangeFlag = true;
      sessionStorage.setItem('zipcodechangeflag', 'true');
      this.doSearch();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.onZipCodeTypeaheadOptionSelectionChange
      );
    }
  }

  private triggerSearchOnEnterKey(desktopSearchButtonClick?: boolean, enterKeyPressed?: boolean) {
    try {
      //sessionStorage.setItem('FadLandingPageSearchCriteria',null);
      // if enter key has been pressed, select the first matching option in the dropdown as the lastselected option
      const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
      const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
      const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
      const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
        `${userProvidedSearchText}~${geoKey}`
      );

      if (cachedLookupOptions && cachedLookupOptions.length) {
        let cachedLookupOption = this.getCachedLookupOption(cachedLookupOptions, enterKeyPressed);
        cachedLookupOption = cachedLookupOption == null ? cachedLookupOptions[0] : cachedLookupOption;
        if (cachedLookupOption && cachedLookupOption.category === FadConstants.text.areYouLookingFor) {
          const firstSpecialityOption: FadAutoCompleteComplexOption = <FadAutoCompleteComplexOption>cachedLookupOptions[0].options[0];
          this.fadSearchResultsService.setLastSelectedSearchTextOption(firstSpecialityOption);
          if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
            this.emboseSearchTextField = false;
            this.searchControls.searchTypeAheadControl.setValue(cachedLookupOption.options[0].getSimpleText());
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
            this.searchTextTypeAheadTrigger.closePanel();
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          } else {
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
            this.searchTextTypeAheadTrigger.closePanel();
          }
        } else if (
          cachedLookupOption &&
          cachedLookupOption.category &&
          cachedLookupOption.category.indexOf(FadConstants.text.allDoctorOptionText) === 0
        ) {
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

          const searchTextOption = new FadAutoCompleteComplexOption();
          searchTextOption.setSimpleText(cachedLookupOption.category);
          searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);

          searchControlValues.setSearchText(searchTextOption);

          this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
          if (!this.isSearchButtonDisabled()) {
            this.searchControls.setValues(searchControlValues);
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          }
        } else if (
          cachedLookupOption &&
          cachedLookupOption.category &&
          cachedLookupOption.category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
        ) {
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

          const searchTextOption = new FadAutoCompleteComplexOption();
          searchTextOption.setSimpleText(cachedLookupOption.category); // cachedLookupOptions[0].options[0].getSimpleText());
          searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);

          searchControlValues.setSearchText(searchTextOption);

          this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
          if (!this.isSearchButtonDisabled()) {
            this.searchControls.setValues(searchControlValues);
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          }
        }
      } else if (desktopSearchButtonClick) {
        this.doSearch();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.triggerSearchOnEnterKey
      );
    }
  }

  /*
  Method to get the correct cached option list based on the item selected in the autocomplete
  - if specialty/procedure has been selected, it will be always the 1st list
  - if 'All doctors' has been selected, find based on category (could be 1st/2nd list)
  - if 'All facilities' has been selected, find based on category (could be 1st/2nd/3rd list)
  */
  private getCachedLookupOption(lookupOptions, enterKeyPressed: boolean) {
    let lookupOption = null;

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    const searchText = searchCriteria ? searchCriteria.getSearchText() : null;
    const specialtyId = searchText ? searchText.getSpecialityId() : '';
    const procedureId = searchText ? searchText.getProcedureId() : '';
    const resourceTypeCode = searchText ? searchText.getResourceTypeCode() : '';
    // if specialty/procedure or Enter button is clicked
    if ((specialtyId || procedureId || !resourceTypeCode || enterKeyPressed) && lookupOptions[0]) {
      lookupOption = lookupOptions[0];
      // if 'All doctors'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'P') {
      if (lookupOptions[0] && lookupOptions[0].category && lookupOptions[0].category.indexOf(FadConstants.text.allDoctorOptionText) === 0) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FadConstants.text.allDoctorOptionText) === 0
      ) {
        lookupOption = lookupOptions[1];
      }
      // if 'All facilities'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'F') {
      if (
        lookupOptions[0] &&
        lookupOptions[0].category &&
        lookupOptions[0].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[1];
      } else if (
        lookupOptions[2] &&
        lookupOptions[2].category &&
        lookupOptions[2].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[2];
      }
    }
    return lookupOption;
  }

  /**
   * @description helps display values in the search for a doctor typeahead list
   */
  public displaySearchTextAutoCompleteDropDown(event?: KeyboardEvent): void {
    try {
      this.removeIconFocusTracker(FadLandingPageFocusTracker.searchText);

      // if (!!this.searchControls.searchTypeAheadControl.value && !!this.searchControls.searchTypeAheadControl.value.trim) {
      //   this.searchControls.searchTypeAheadControl.setValue(this.searchControls.searchTypeAheadControl.value.trim());
      // }

      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.emboseSearchTextFieldOnScreen(!this.preventSearchTextAutoCompleteDropdown);
      }

      if (event && event.keyCode === 13) {
        this.triggerSearchOnEnterKey(false, true);

        return;
      } else if (event && event instanceof KeyboardEvent && (event.keyCode === 38 || event.keyCode === 40)) {
        // if up or down arrow is pressed do the associated menu navigation
        window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
        return;
      }

      if (this.preventSearchTextAutoCompleteDropdown) {
        this.preventSearchTextAutoCompleteDropdown = false;
        return;
      }

      setTimeout(() => {
        try {
          if (!!this.searchControls.searchTypeAheadControl.value && !!this.searchControls.searchTypeAheadControl.value.trim) {
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value.trim());
            this.searchTextTypeAheadTrigger.openPanel();

            setTimeout(() => {
              try {
                this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag = window.setInterval(() => {
                  this.searchTextMaterialAutoCompleteBugWorkAroundFlag++;
                  try {
                    const autoCompletePanes: HTMLCollection = document.getElementsByClassName('cdk-overlay-pane');
                    let activeAutoCompletePane: HTMLElement = null;
                    for (let acpItr = 0; acpItr < autoCompletePanes.length; acpItr++) {
                      const autoCompPane: HTMLElement = <HTMLElement>autoCompletePanes[acpItr];
                      if (autoCompPane.innerHTML !== '') {
                        activeAutoCompletePane = autoCompPane;
                        break;
                      }
                    }

                    if (activeAutoCompletePane) {
                      const optionGroups: HTMLCollectionOf<HTMLElement> = <HTMLCollectionOf<HTMLElement>>(
                        activeAutoCompletePane.getElementsByClassName('mat-optgroup-label')
                      );

                      if (optionGroups && optionGroups.length && activeAutoCompletePane) {
                        const firstOptGroupLabel: HTMLElement = optionGroups[0];

                        if (
                          firstOptGroupLabel &&
                          firstOptGroupLabel.innerHTML &&
                          (firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.allDoctorOptionText) === 0 ||
                            firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0)
                        ) {
                          if (firstOptGroupLabel.className.indexOf('mat-active') !== -1) {
                            this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                            window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
                            return;
                          }
                          firstOptGroupLabel.className += ' mat-active';

                          const matOptions: HTMLCollectionOf<HTMLElement> = <HTMLCollectionOf<HTMLElement>>(
                            activeAutoCompletePane.getElementsByTagName('mat-option')
                          );
                          const firstMatOption: HTMLElement = matOptions[0];
                          if (firstMatOption) {
                            firstMatOption.className = firstMatOption.className
                              ? firstMatOption.className.replace('mat-active', '').trim()
                              : '';
                          }
                        } else if (
                          firstOptGroupLabel &&
                          firstOptGroupLabel.innerHTML &&
                          firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.notSureWhatToSearch) === 0
                        ) {
                          return;
                        } else if (firstOptGroupLabel && firstOptGroupLabel.innerHTML === '') {
                          const matOptions: HTMLCollectionOf<HTMLElement> = <HTMLCollectionOf<HTMLElement>>(
                            activeAutoCompletePane.getElementsByTagName('mat-option')
                          );
                          const firstMatOption: HTMLElement = matOptions[0];
                          this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;

                          if (firstMatOption && firstMatOption.className.indexOf('mat-active') === -1) {
                            firstMatOption.className += ' mat-active';

                            return;
                          }
                        }
                      }
                    }
                    if (this.searchTextMaterialAutoCompleteBugWorkAroundFlag > 25) {
                      this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                      window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
                    }

                    this.addOnClickToAutoCompleteSpinner();
                  } catch (exception) {
                    this.bcbsmaErrorHandler.logError(
                      exception,
                      BcbsmaConstants.modules.fadModule,
                      FadConstants.components.fadLandingPageComponent,
                      [FadConstants.methods.displaySearchTextAutoCompleteDropDown, FadConstants.methods.setInterval, 'nested level 3'].join(
                        ' - '
                      )
                    );
                  }
                }, 200);
              } catch (exception) {
                this.bcbsmaErrorHandler.logError(
                  exception,
                  BcbsmaConstants.modules.fadModule,
                  FadConstants.components.fadLandingPageComponent,
                  [FadConstants.methods.displaySearchTextAutoCompleteDropDown, FadConstants.methods.setTimeout, 'nested level 2'].join(
                    ' - '
                  )
                );
              }
            }, 100);
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 500);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displaySearchTextAutoCompleteDropDown
      );
    }
  }

  /**
   * @description hide the auto complete text search
   */
  public cancelSearchTextAutoCompleteDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        const cancelFlag: boolean = true;
        this.emboseSearchTextFieldOnScreen(false, cancelFlag);
        // if pageloads to clear session storage to avoid last value fetching in autocomplete
        if (this.isPageReload) {
          const option: FadAutoCompleteComplexOption = new FadAutoCompleteComplexOption();
          // option.setSimpleText(searchControlValues.getSearchText().getSimpleText());
          option.setSimpleText('');
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
          searchControlValues.setSearchText(option);
          this.searchControls.setValues(searchControlValues);
        }
      }

      setTimeout(() => {
        try {
          if (this.searchControls.searchTypeAheadControl.value) {
            const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

            if (!searchCriteria) {
              this.searchControls.searchTypeAheadControl.setValue('');
              this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
              this.searchTextTypeAheadTrigger.closePanel();
            } else {
              const simpleText = searchCriteria.getSearchText().getSimpleText();
              this.searchControls.searchTypeAheadControl.setValue(simpleText);
              this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
              this.searchTextTypeAheadTrigger.closePanel();
            }
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.cancelSearchTextAutoCompleteDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a zip code typeahead list
   * @param event
   */

  public fillLocation() {
    this.zipCodeValidationErrors.noMatchFound.display = false;
    this.zipCodeValidationErrors.invalidZipCode.display = false;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = Observable.of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          console.log(vitalsZipCodeResponse.cities);
          console.log(Observable.of(vitalsZipCodeResponse.cities));
          this.filteredZipCodeOptions = Observable.of([]);
          this.filteredZipCodeOptions = Observable.of(vitalsZipCodeResponse.cities);
        });
      });
    }
  }

  public fillLocationOnLoad() {
    this.zipCodeValidationErrors.noMatchFound.display = false;
    this.zipCodeValidationErrors.invalidZipCode.display = false;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = Observable.of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          console.log(vitalsZipCodeResponse.cities);
          console.log(Observable.of(vitalsZipCodeResponse.cities));
          this.filteredZipCodeOptions = Observable.of([]);
          this.filteredZipCodeOptions = Observable.of(vitalsZipCodeResponse.cities);
          this.filteredZipCodeOptions.subscribe(response => {
            console.log(response[0]);
            let defaultCityZip: FZCSRCity = new FZCSRCity();
            defaultCityZip
              .setZip(response[0].zip)
              .setCity(response[0].city)
              .setState_code(response[0].state_code)
              .setGeo(response[0].geo) // '42.242921,-71.009972');
              .setCounty(response[0].county)
              .setGeo(response[0].geo)
              .setLat(response[0].lat)
              .setLng(response[0].lng)
              .setName(response[0].name)
              .setPlace_id(response[0].place_id)
              .setScore(response[0].score)
              .setState(response[0].state)
              .setState_code(response[0].state_code)
              .setZip(response[0].zip);

            const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();

            this.fadSearchResultsService.setLastSelectedZipCodeOption(defaultCityZip);
            const zipCodeText = defaultCityZip.getDisplayValue();
            this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
            this.zipCodeTypeAheadTrigger._element.nativeElement.value = zipCodeText;
            this.zipCodeOptions.push(defaultCityZip);

            localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(defaultCityZip));
          });
        });
      });
    } else {
      //this.authHttp.hideSpinnerLoading();
    }
  }

  public displayZipCodeDropDown(event, flag = false): void {
    try {
      if (flag) {
        flag = false;
        this.filteredZipCodeOptions = Observable.of([]);
        this.fillLocation();
      }
      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.emboseZipCodeFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      setTimeout(() => {
        const zipCodeField = this.zipCodeTypeAheadTrigger._element.nativeElement;
        zipCodeField.focus();
        if (zipCodeField.value && zipCodeField.value.length > 0) {
          this.zipClearIcon = 'visible';
          if (zipCodeField.value.length < 3) {
            return;
          }
        } else {
          this.zipClearIcon = 'hidden';
        }
        event.stopPropagation();
        setTimeout(() => {
          this.zipCodeTypeAheadTrigger._onChange('');
          this.zipCodeTypeAheadTrigger.openPanel();
        });
      });
      console.log(this.filteredZipCodeOptions);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayZipCodeDropDown
      );
    }
  }

  /**
   * @description hide the zipcode drop down
   */
  public hideZipCodeDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseZipCodeFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          const lastSelectedZipCodeOption: FZCSRCity = Object.assign(
            Object.create(new FZCSRCity()),
            this.fadSearchResultsService.getLastSelectedZipCodeOption()
          );
          this.zipCodeTypeAheadTrigger._onChange(lastSelectedZipCodeOption.getDisplayValue());
          this.zipCodeTypeAheadTrigger.closePanel();
          this.searchControls.zipCodeTypeAheadControl.setValue(lastSelectedZipCodeOption.getDisplayValue());
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hideZipCodeDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a plan name typeahead list
   * @param event
   */
  public displayPlanDropDown(event): void {
    try {
      if (this.bypassPlanFieldFocusLogic) {
        this.bypassPlanFieldFocusLogic = false;
        return;
      }

      if (event.keyCode && (event.keyCode === 38 || event.keyCode === 40)) {
        // if user presses up arrow or down arrow, then skip proceeding further
        return;
      }

      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.embosePlanFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      const planField = this.planTypeAheadTrigger._element.nativeElement;
      planField.focus();
      if (planField.value && planField.value.length > 0) {
        this.planClearIcon = 'visible';
      } else {
        this.planClearIcon = 'hidden';
      }

      event.stopPropagation();
      setTimeout(() => {
        this.planTypeAheadTrigger._onChange(this.searchControls.planControl.value);
        this.filterAutoCompletePlanOptions(this.searchControls.planControl.value, true);
        this.planTypeAheadTrigger.openPanel();
        if (this.viewPortWidth > 992) {
          setTimeout(() => {
            const planDropDownList: HTMLCollectionOf<Element> = document.getElementsByClassName('mat-autocomplete-panel planOption');
            const planDropDown: HTMLElement = planDropDownList ? <HTMLElement>planDropDownList[0] : null;

            const planDropDownContainer: HTMLElement = planDropDown ? planDropDown.parentElement : null;
            if (planDropDownContainer) {
              let pddcClass = planDropDown.getAttribute('class');
              pddcClass = pddcClass && pddcClass.trim ? pddcClass.trim() : '';

              if (!!this.planValidationErrors.invalidPlan.display) {
                pddcClass = pddcClass.replace(' planValidationErrorExist-42', '').replace('planValidationErrorExist-42', '');
                if (pddcClass.indexOf('planValidationErrorExist-42') < 0) {
                  pddcClass += ' planValidationErrorExist-42';
                }
              } else if (!!this.planValidationErrors.noMatchFound.display) {
                pddcClass = pddcClass.replace(' planValidationErrorExist-55', '').replace('planValidationErrorExist-55', '');
                if (pddcClass.indexOf('planValidationErrorExist-55') < 0) {
                  pddcClass += ' planValidationErrorExist-55';
                }
              } else {
                pddcClass = pddcClass
                  .replace(' planValidationErrorExist-42', '')
                  .replace('planValidationErrorExist-42', '')
                  .replace(' planValidationErrorExist-55', '')
                  .replace('planValidationErrorExist-55', '');
              }
              planDropDown.setAttribute('class', pddcClass);
            }
          });
        }
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayPlanDropDown
      );
    }
  }

  /**
   * @description hide the plan drop down
   */
  public hiddenPlanDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.embosePlanFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          const lastSelectedPlanOption = this.fadSearchResultsService.getLastSelectedPlanOption();
          this.planTypeAheadTrigger._onChange(lastSelectedPlanOption);
          this.planTypeAheadTrigger.closePanel();
          this.searchControls.planControl.setValue(lastSelectedPlanOption);
          if (lastSelectedPlanOption && lastSelectedPlanOption.getSimpleText) {
            this.planValidator(lastSelectedPlanOption.getSimpleText());
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenPlanDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a dependant typeahead list
   * @param event
   */
  public displayDependentListDropDown(event): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseDependantsFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      const dependantField = this.dependantListTypeAheadTrigger._element.nativeElement;
      dependantField.focus();
      if (dependantField.value && dependantField.value.length > 0) {
        this.dependantClearIcon = 'visible';
      } else {
        this.dependantClearIcon = 'hidden';
      }
      event.stopPropagation();
      setTimeout(() => {
        this.dependantListTypeAheadTrigger._onChange('');
        this.dependantListTypeAheadTrigger.openPanel();
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayDependentListDropDown
      );
    }
  }

  /**
   * @description hide the dependant drop down
   */
  public hiddenDependantDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseDependantsFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          this.dependantListTypeAheadTrigger._onChange(this.searchControls.dependantNameControl.value);
          this.dependantListTypeAheadTrigger.closePanel();
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenDependantDropDown
      );
    }
  }

  /**
   * @name showDoctorList
   * @description to help display the doctors list on screen
   */
  public showDoctorList(): void {
    try {
      this.router.navigate([FadConstants.urls.fadSearchResultsPage]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.showDoctorList
      );
    }
  }

  /**
   * @name displayPastSearchHistory
   * @description helps display 10 previous search results
   */
  public displayPastSearchHistory() {
    try {
      this.router.navigate([FadConstants.urls.fadPastSearchQueries]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayPastSearchHistory
      );
    }
  }

  /**
   * @description helps display the All Specialities and All Procedures screen
   * @param url - specialities/procedures routing url
   */
  public openMedicalIndex(url: string) {
    try {
      this.landingPageService.setCachedSearchControlState(this.searchControls);
      this.router.navigate([url]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.openMedicalIndex
      );
    }
  }

  /**
   * @description gets triggered when the remove icon is clicked inside the search fields. Helps clear the current field value when clicked
   * @return void - nothing
   */
  public clearTargetValue(target?: string): void {
    try {
      target = target || this.focusedTarget;

      switch (target) {
        // when remove icon inside the search doctor field is clicked
        case FadLandingPageFocusTracker.searchText:
          this.searchControls.searchTypeAheadControl.setValue('');
          this.searchTextTypeAheadTrigger._element.nativeElement.focus();
          break;
        // when remove icon inside the search zipcode field is clicked
        case FadLandingPageFocusTracker.zipCode:
          this.searchControls.zipCodeTypeAheadControl.setValue('');

          if (this.searchControls.zipCodeTypeAheadControl.value === '') {
            this.zipCodeValidationErrors.noMatchFound.display = false;
            this.zipCodeValidationErrors.invalidZipCode.display = true;
            this.landingPageService.cachedResponse.zipCodeOptions = [];
            this.filteredZipCodeOptions = Observable.of([]);
            this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
            this.landingPageService.cachedResponse.setZipCodeOptions([]);
          }

          this.zipCodeTypeAheadTrigger._element.nativeElement.focus();
          break;
        // when remove icon inside the search plan field is clicked
        case FadLandingPageFocusTracker.plan:
          this.searchControls.planControl.setValue('');

          if (this.searchControls.planControl.value === '') {
            this.planValidationErrors.noMatchFound.display = false;
            this.fadSearchResultsService.setLastSelectedPlanOption(null);
            this.planValidationErrors.invalidPlan.display = true;
          }

          this.planTypeAheadTrigger._element.nativeElement.focus();
          break;
        // when remove icon inside the search dependant field is clicked
        case FadLandingPageFocusTracker.dependant:
          this.searchControls.dependantNameControl.setValue('');
          this.dependantListTypeAheadTrigger._element.nativeElement.focus();
          break;
        // otherwise do nothing
        default:
          break;
      }
      this.focusedTarget = '';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.clearTargetValue
      );
    }
  }

  /**
   * @description triggers when the 'Search' button is clicked on the landing page component
   *  defines specific behavour for Abstract mode (when displayed as child component)
   *  and Normal mode (when displayed as stand alone component)
   * @returns void - nothing
   */
  public doSearch(flag = false): void {
    try {
      if (this.userCurrentPlan.getId() == this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()) {
        sessionStorage.setItem('networkChange', 'false');
      } else {
        if (this.authService.authToken) {
          if (this.authService.useridin && this.authService.authToken.userType) sessionStorage.setItem('networkChange', 'true');
        }
      }
      if (this.isSearchButtonDisabled() && !flag) {
        //alert("search button disabled true");
        return;
      }
      const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);
      if (this.viewPortWidth <= 992 && this.showTextField && flag) {
        this.landingPageService.setCachedSearchControlState(this.searchControls);
        this.router.navigate([FadConstants.urls.fadLandingPage]);
        return;
      }

      if (this.showTextField && flag) {
        this.router.navigate([FadConstants.urls.fadSearchResultsPage]);
      } else {
        this.router.navigate([FadConstants.urls.fadSearchResultsPage]);
      }
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.doSearch
      );
    }
  }

  showAllProdecuresOptionInSearchDropdown(useridin) {
    if (
      useridin !== '' &&
      useridin !== undefined &&
      this.userState !== this.constantsService['Inactive'] &&
      sessionStorage.getItem('mleEligibility') &&
      sessionStorage.getItem('mleEligibility') !== 'N'
    ) {
      return true;
    }
    return false;
  }

  /**
   * @description helps populate the landing page's search control with default/cached values as necessary
   *  Also take care of initializing the drop down typeahead component behaviour for each of the search fields
   */
  private initData() {
    try {
      this.userCurrentPlan = this.getDefaultPlanOption();

      this.isLogin = this.authService.isLogin();
      const useridin = this.authService.useridin;

      if (this.isLogin) {
        this.defaultAutoCompleteSearchOption.push(
          new FadAutoCompleteOptionForSearchText()
            .setCategory(FadConstants.text.notSureWhatToSearch)
            .addOption(new FadAutoCompleteComplexOption().setLink(FadConstants.text.allSpecialities, '/fad/medical-index/specialities'))
        );

        this.userState = this.authService.fetchUserState();

        const planOption = new FadAutoCompleteOptionForSearchText();
        console.log(this.fadInfo);
        if (!this.fadInfo) {
          this.fadResolverService.getVitalsPlanInfo().subscribe(data => {
            this.fadInfo = data;
            this.fadInfo.networks.map(_network => {
              const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
              const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
              planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
              if (plan.getPlanIndicator()) {
                this.userCurrentPlan = plan;
              }
            });
          });
        }
        if (
          this.authService.authToken.userType != null &&
          (this.authService.authToken.userType.toLowerCase() === 'medicare' ||
            this.authService.authToken.userType.toLowerCase() === 'medex') &&
          this.authService.getMLEIndicator() != 'N' &&
          this.getDefaultPlan()
        ) {
          this.isMedicareUser = true;
        }
        if (
          this.authService.authToken.userType == null &&
          (this.authService.getScopeName() != 'REGISTERED-NOT-VERIFIED' || this.authService.getScopeName() != 'REGISTERED-AND-VERIFIED')
        ) {
          this.isRVRNVUser = true;
        }

        if (this.showAllProdecuresOptionInSearchDropdown(useridin) && !this.isMedicareUser && !this.isRVRNVUser) {
          this.defaultAutoCompleteSearchOption.push(
            new FadAutoCompleteOptionForSearchText().addOption(
              new FadAutoCompleteComplexOption().setLink(FadConstants.text.allProcedures, '/fad/medical-index/procedures')
            )
          );
        }
        if (!this.landingPageService.getCachedSearchControlState()) {
          const defaultObj = new FadAutoCompleteComplexOption()
            .setSimpleText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId());
          this.searchControls.planControl.setValue(defaultObj);
        }
      } else {
        this.defaultAutoCompleteSearchOption.push(
          new FadAutoCompleteOptionForSearchText()
            .setCategory(FadConstants.text.notSureWhatToSearch)
            .addOption(new FadAutoCompleteComplexOption().setLink(FadConstants.text.allSpecialities, '/fad/medical-index/specialities'))
        );
      }

      if (!this.landingPageService.cachedResponse) {
        this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();
        this.landingPageService.cachedResponse.userId = this.authService.useridin;
        console.log(this.landingPageService.cachedResponse);
      } else if (this.isUserIdChanged()) {
        this.isChangedUserFlag = true;
        this.clearCacheResponseOnUserIdChange();
      }
      this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;

      // Start Handle Dependend list data //
      this.fetchDependentList();
      // End Handle Dependend list data //
    } catch (exception) {
      console.log('init catch data', this.fadInfo);
      if (this.fadInfo && this.fadInfo.result && this.fadInfo.result < 0) {
        this.setServiceAlert(this.fadInfo['displaymessage'], AlertType.Failure);
        console.log(this.fadInfo.displaymessage);
      }
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.initData
      );
    }
  }
  public fetchProcedureSummary() {
    this.landingPageService.getProcedureSummary().subscribe(data => {
      $('ng4-loading-spinner .spinner').removeClass('visible');
    });
  }

  private fetchDependentList() {
    const useridin = this.authService.useridin;
    console.log('userid', this.authService.useridin);
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    const memIdx = sessionStorage.getItem('selMemIdx');
    if (
      useridin !== '' &&
      useridin !== undefined &&
      this.landingPageService.cachedResponse &&
      !this.landingPageService.cachedResponse.dependantsList &&
      (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'AUTHENTICATED-NOT-VERIFIED')
    ) {
      //alert("test1");
      this.authHttp.showSpinnerLoading();
      this.landingPageService.getVitalsDependantList().subscribe(
        response => {
          if (response && response.result && response.result < 0) {
            this.setServiceAlert(response['displaymessage'], AlertType.Failure);

            return;
          } else if (response && response.membersInfoList && response.membersInfoList.length > 0) {
            this.clearServiceAlert();
            this.dependantsList = response.membersInfoList;
            this.displayDependentsOptionFlag = true;
            // this.authHttp.hideSpinnerLoading();
          } else {
            //this.authHttp.hideSpinnerLoading();
            return;
          }

          this.landingPageService.cachedResponse.dependantsList = this.dependantsList;
          if (memIdx) {
            this.selectedMember = this.dependantsList[memIdx];
            sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
            console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
          } else {
            this.selectedMember = this.dependantsList[0];
            sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
            console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
          }
          this.fetchProcedureSummary();
          //this.authHttp.hideSpinnerLoading();
        },
        error => {
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.landingPageService,
            FadConstants.methods.getVitalsDependantList
          );
        },
        () => {
          this.landingPageService.showAutoCompleteDropDownSpinner = false;
        }
      );
    } else if (useridin !== '' && useridin !== undefined && useridin !== 'undefined' && useridin != 'null') {
      //alert("test2");
      this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
      this.displayDependentsOptionFlag = true;
      if (this.dependantsList) {
        if (memIdx) {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
          console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
          console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
        }
      }
      //this.authHttp.hideSpinnerLoading();
    } else if (this.landingPageService.cachedResponse && this.landingPageService.cachedResponse.dependantsList) {
      //alert("test3");
      this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
      this.displayDependentsOptionFlag = true;
      if (memIdx) {
        this.selectedMember = this.landingPageService.cachedResponse.dependantsList[memIdx];
        sessionStorage.setItem(
          'fadVendorMemberNumber',
          this.landingPageService.cachedResponse.dependantsList[memIdx].fadVendorMemberNumber
        );
        console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
      } else {
        this.selectedMember = this.landingPageService.cachedResponse.dependantsList[0];
        sessionStorage.setItem('fadVendorMemberNumber', this.landingPageService.cachedResponse.dependantsList[0].fadVendorMemberNumber);
        console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
      }
      //this.authHttp.hideSpinnerLoading();
    } else {
      //alert("test4");

      this.authHttp.hideSpinnerLoading();
    }
  }

  private clearCacheResponseOnUserIdChange() {
    // const zipCodeOptions = this.landingPageService.cachedResponse.getZipCodeOptions();
    this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();
    console.log(this.landingPageService.cachedResponse);
    this.landingPageService.cachedResponse.userId = this.authService.useridin;
    this.landingPageService.cachedResponse.planOptions = null;
    this.landingPageService.cachedResponse.zipCodeOptions = [];

    this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
    //this.fadSearchResultsService.setLastSelectedPlanOption(null);
    //this.landingPageService.cachedResponse.planOptions = [];
    this.landingPageService.cachedResponse.setZipCodeOptions([]);
    console.log(this.landingPageService.cachedResponse);
    //this.landingPageService.cachedResponse.setZipCodeOptions(null);
    //this.searchControls = new FadLandingPageSearchControlsModel();
    //this.fadSearchResultsService.setLastSelectedPlanOption(null);
  }

  private isUserIdChanged(): boolean {
    return (
      this.landingPageService.cachedResponse &&
      this.landingPageService.cachedResponse.userId &&
      this.landingPageService.cachedResponse.userId !== this.authService.useridin
    );
  }
  /**
   * @description helps to search the data on typehead component after populate the
   * landing page's search control with default/cached values as necessary
   */
  private enhancedSearchAfterInitData() {
    try {
      this.searchControls.zipCodeTypeAheadControl.valueChanges.subscribe(
        searchText => {
          if (searchText && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.removeZipCodeError();
          }

          if (!searchText || (searchText && searchText.length < 3)) {
            return;
          }

          const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(searchText.trim());
          if (cachedZipCodeLookupOptions) {
            this.zipCodeOptions = cachedZipCodeLookupOptions;
            this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);

            this.searchControls.zipCodeTypeAheadControl.valueChanges
              .pipe(
                startWith(''),
                delay(0),
                map(val => {
                  if (this.zipCodeTypeAheadTrigger) {
                    clearInterval(this.zipCodeTypeAheadTrigger);
                    const currentSelectedValue = val ? val : this.zipCodeTypeAheadTrigger._element.nativeElement.value.trim();

                    this.filteredZipCodeOptions = Observable.of(
                      this.zipCodeOptions.filter(
                        option =>
                          option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                          option.zip.indexOf(currentSelectedValue) !== -1
                      )
                    );
                  } else {
                    this.filteredZipCodeOptions = Observable.of(this.zipCodeOptions);
                  }
                })
              )
              .subscribe();

            return;
          }

          const zip_inSearchText = searchText ? searchText.split('-')[0].trim() : '';
          var regex = new RegExp(/(\d{5}) - (\w{1,}), (\w{2})/);
          var wholezipcode = searchText.match(regex);
          const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
          vitalsZipCodeSearchRequest.place = wholezipcode ? '' : zip_inSearchText;
          vitalsZipCodeSearchRequest.page = 1;
          vitalsZipCodeSearchRequest.limit = this.viewPortWidth > 992 ? 10 : 6;
          if (wholezipcode && wholezipcode.length) {
            vitalsZipCodeSearchRequest.zip = wholezipcode[1] || '';
            vitalsZipCodeSearchRequest.city = wholezipcode[2] || '';
            vitalsZipCodeSearchRequest.state = wholezipcode[3] || '';
          }

          this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(
            vitalsZipCodeResponse => {
              try {
                this.landingPageService.vitalsZipCodeInfo = vitalsZipCodeResponse;
                this.zipcodeResponseValidator();
                this.clearServiceAlert();

                if (vitalsZipCodeResponse.cities) {
                  // remove zipcode error message if match found with response
                  if (
                    searchText &&
                    searchText.length >= 3 &&
                    vitalsZipCodeResponse.cities.length === 0 &&
                    this.zipCodeValidationErrors.noMatchFound.exists === false
                  ) {
                    this.zipCodeValidationErrors.noMatchFound.display = false;
                    this.zipCodeValidationErrors.invalidZipCode.display = false;
                  }

                  // display zipcode error message if no match found with response
                  if (
                    searchText &&
                    searchText.length >= 3 &&
                    this.zipCodeValidationErrors.invalidZipCode.exists === false &&
                    vitalsZipCodeResponse.cities.length === 0 &&
                    this.zipCodeValidationErrors.noMatchFound.exists === true
                  ) {
                    this.zipCodeValidationErrors.noMatchFound.display = true;
                    this.zipCodeValidationErrors.invalidZipCode.display = false;
                  }
                }
                // display error message if invalid zipcode exists like alphanumberic
                if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
                  this.zipCodeValidationErrors.noMatchFound.display = false;
                  this.zipCodeValidationErrors.invalidZipCode.display = true;
                }

                this.zipCodeOptions =
                  vitalsZipCodeResponse && vitalsZipCodeResponse.cities ? <FZCSRCity[]>vitalsZipCodeResponse.cities : <FZCSRCity[]>[];
                if (!this.zipCodeTypeAheadTrigger) {
                  return;
                }
                this.fadSearchResultsService.setLastSelectedZipCodeOption(this.zipCodeOptions[0]);
                this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);
                const zipFrag = searchText ? searchText.trim().split(' - ') : '';
                if (zipFrag[0] && Number(zipFrag[0].trim())) {
                  this.landingPageService.setCachedZipCodeLookupOptions(zipFrag[0].trim(), Object.assign([], this.zipCodeOptions));
                }

                this.searchControls.zipCodeTypeAheadControl.valueChanges
                  .pipe(
                    startWith(''),
                    delay(0),
                    map(val => {
                      if (this.zipCodeTypeAheadTrigger) {
                        clearInterval(this.zipCodeTypeAheadTrigger);
                        const currentSelectedValue = val ? val : this.zipCodeTypeAheadTrigger._element.nativeElement.value.trim();

                        this.filteredZipCodeOptions = Observable.of(
                          this.zipCodeOptions.filter(
                            option =>
                              option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                              option.zip.indexOf(currentSelectedValue) !== -1
                          )
                        );
                      } else {
                        this.filteredZipCodeOptions = Observable.of(this.zipCodeOptions);
                      }
                    })
                  )
                  .subscribe();
              } catch (exception) {
                this.bcbsmaErrorHandler.logError(
                  exception,
                  BcbsmaConstants.modules.fadModule,
                  FadConstants.components.fadLandingPageComponent,
                  FadConstants.methods.getVitalsZipCodeInfo
                );
              }
            },
            error => {
              this.bcbsmaErrorHandler.handleHttpError(
                error,
                BcbsmaConstants.modules.fadModule,
                FadConstants.services.landingPageService,
                FadConstants.methods.getVitalsZipCodeInfo
              );
            }
          );
        },
        error => {
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.searchTypeAheadControl_valueChanges,
            FadConstants.methods.valueChanges
          );
        }
      );

      // Start Handle Plan Option list data //
      if (!this.landingPageService.cachedResponse.planOptions) {
        const planOption = new FadAutoCompleteOptionForSearchText();
        if (this.fadInfo && this.fadInfo.result && this.fadInfo.result < 0) {
          this.setServiceAlert(this.fadInfo['displaymessage'], AlertType.Failure);

          return;
        } else if (this.fadInfo && this.fadInfo.networks) {
          this.clearServiceAlert();

          this.fadInfo.networks.map(_network => {
            const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
            const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
            planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
            if (plan.getPlanIndicator()) {
              this.userCurrentPlan = plan;
            }
          });
        } else {
          return;
        }

        this.planOptions.push(planOption);
        this.defaultPlanOptions = this.planOptions;
        this.landingPageService.cachedResponse.planOptions = this.planOptions;
        // this.landingPageService.getVitalsPlanInfo().delay(500).subscribe(response => {
        //   const planOption = new FadAutoCompleteOptionForSearchText();
        //   if (response && response.result && response.result < 0) {
        //     this.setServiceAlert(response['displaymessage'], AlertType.Failure);

        //     return;
        //   } else if (response && response.networks) {
        //     this.clearServiceAlert();

        //     response.networks.map(_network => {
        //       const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
        //       const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
        //       planOption.addOption((new FadAutoCompleteComplexOption()).setSimpleText(plan.getName()).setNetworkId(plan.getId()));
        //       if (plan.getPlanIndicator()) {
        //         this.userCurrentPlan = plan;
        //       }
        //     });
        //   } else {
        //     return;
        //   }

        //   this.planOptions.push(planOption);
        //   this.defaultPlanOptions = this.planOptions;
        //   this.landingPageService.cachedResponse.planOptions = this.planOptions;
        // },
        //   error => {
        //     this.bcbsmaErrorHandler.handleHttpError(error,
        //       BcbsmaConstants.modules.fadModule,
        //       FadConstants.services.landingPageService,
        //       FadConstants.methods.getVitalsPlanInfo);
        //   },
        //   () => {
        //     this.landingPageService.showAutoCompleteDropDownSpinner = false;
        //   });
      } else {
        this.planOptions = this.landingPageService.cachedResponse.planOptions;
        this.defaultPlanOptions = this.planOptions;
      }

      this.filteredPlanOptions = this.searchControls.planControl.valueChanges.pipe(
        startWith(''),
        delay(0),
        map(val => {
          try {
            if (this.planTypeAheadTrigger) {
              const currentSelectedValue = val ? val : this.planTypeAheadTrigger._element.nativeElement.value.trim();
              let searchPlanText = '';

              if (typeof currentSelectedValue === 'object') {
                searchPlanText = currentSelectedValue.getSimpleText(); // || currentSelectedValue.getSimpleText();
              }
              return this.filterAutoCompletePlanOptions(searchPlanText);
            } else {
              return this.filterAutoCompletePlanOptions('');
            }
          } catch (exception) {
            this.bcbsmaErrorHandler.logError(
              exception,
              BcbsmaConstants.modules.fadModule,
              FadConstants.components.fadLandingPageComponent,
              FadConstants.methods.initData
            );
          }
        })
      );
      // End Handle Plan Option list data

      this.searchControls.planControl.valueChanges
        .debounceTime(this.debounceTime)
        .distinctUntilChanged()
        .subscribe(
          searchText => {
            try {
              if (searchText && typeof searchText === 'object') {
                searchText = searchText.getSimpleText();
              }

              this.planOptions = this.defaultPlanOptions;

              this.filteredPlanOptions = this.searchControls.planControl.valueChanges.pipe(
                startWith(''),
                delay(0),
                map(val => {
                  const searchPlanText = searchText !== '' ? searchText : this.planTypeAheadTrigger._element.nativeElement.value.trim();
                  return this.filterAutoCompletePlanOptions(searchPlanText);
                })
              );
            } catch (exception) {
              this.bcbsmaErrorHandler.logError(
                exception,
                BcbsmaConstants.modules.fadModule,
                FadConstants.components.fadLandingPageComponent,
                FadConstants.methods.ngOnInit
              );
            }
          },
          error => {
            this.bcbsmaErrorHandler.handleHttpError(
              error,
              BcbsmaConstants.modules.fadModule,
              FadConstants.services.planControl_valueChanges,
              FadConstants.methods.valueChanges
            );
          }
        );

      // Karthik uncomment this for single search wait time strategy //
      this.searchControls.searchTypeAheadControl.valueChanges
        .debounceTime(this.debounceTime)
        .distinctUntilChanged()
        .subscribe(
          searchText => {
            try {
              searchText = searchText && searchText.trim ? searchText.trim() : '';
              if (searchText && searchText.length > 2) {
                const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
                const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
                const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
                  `${searchText}~${geoKey}`
                );
                if (cachedLookupOptions) {
                  this.autoCompleteOptionsForSearchText = cachedLookupOptions;
                  this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
                  return;
                }
                const vitalsAutoCompleteSearchRequest: GetSearchByProviderRequestModelInterface = new GetSearchByProviderRequestModel();

                let searchName = searchText;
                if (searchName && searchName.trim && searchName.trim().indexOf(FadConstants.text.allDoctorOptionText) >= 0) {
                  searchName = searchName.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
                } else if (
                  searchName &&
                  searchName.trim &&
                  searchName.trim().indexOf(FadConstants.text.allHospitalsOrFacilitiesText) >= 0
                ) {
                  searchName = searchName.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
                }

                const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();
                vitalsAutoCompleteSearchRequest
                  .setSearchParameter(searchName)
                  .setGeoLocation(selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '')
                  .setNetworkId(
                    this.fadSearchResultsService.getLastSelectedPlanOption()
                      ? this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()
                      : FadConstants.defaults.networkId
                  ) // have to check -
                  // networkid has to come from chosen plan - check with prag - kalagi01
                  .setLimit(FadConstants.defaults.autoCompleteSearchRequest_limit);

                const authUserId = this.authService.useridin;
                if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
                  vitalsAutoCompleteSearchRequest.useridin = this.authService.useridin;
                  vitalsAutoCompleteSearchRequest['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
                  const mleIndicator = this.authService.getMleEligibility();
                  console.log('session storage fad vendor member number', sessionStorage.getItem('fadVendorMemberNumber'));
                  if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
                    //vitalsAutoCompleteSearchRequest.useridin = "";
                    //vitalsAutoCompleteSearchRequest['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
                  }
                }

                this.landingPageService.getVitalsAutoCompleteSearchResponse(vitalsAutoCompleteSearchRequest).subscribe(
                  response => {
                    try {
                      if (response.result && response.result < 0) {
                        this.setServiceAlert(response['displaymessage'], AlertType.Failure);

                        return;
                      } else {
                        this.clearServiceAlert();
                      }

                      this.autoCompleteOptionsForSearchText = [];
                      const conditionList = new FadAutoCompleteOptionForSearchText().setCategory('');
                      const doctorsList = new FadAutoCompleteOptionForSearchText().setCategory(
                        `${FadConstants.text.allDoctorOptionText}"${searchText}"`
                      );
                      const facilityList = new FadAutoCompleteOptionForSearchText().setCategory(
                        `${FadConstants.text.allHospitalsOrFacilitiesText}"${searchText}"`
                      );

                      if (response.searchSpecialties) {
                        response.searchSpecialties.map(speciality => {
                          const conditionOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          conditionOption
                            .setSimpleText(speciality.name)
                            .setProcedure(speciality.isProcedure)
                            .setDescriptionText(speciality.procedureDescription)
                            .setInfoText(FadConstants.text.speciality)
                            .setResourceTypeCode(<FadResourceTypeCode>speciality.resourceTypeCode);

                          if (speciality.isProcedure === true) {
                            conditionOption.setProcedureId(speciality.id);
                          } else {
                            conditionOption.setSpecialityId(speciality.id);
                          }
                          conditionList.options.push(conditionOption);
                        });
                      }

                      if (response.professionals) {
                        response.professionals.map(professional => {
                          const doctorNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          doctorNameOption
                            .setContextText(professional.name)
                            .setInfoText(professional.specialty)
                            .setNetworkId(professional.id)
                            .setLocationId(professional.locationId)
                            .setResourceTypeCode(FadResouceTypeCodeConfig.professional);
                          doctorsList.options.push(doctorNameOption);
                        });
                      }

                      if (response.facilities) {
                        response.facilities.map(facility => {
                          const facilityNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          facilityNameOption
                            .setContextText(facility.name)
                            .setInfoText(facility.specialty)
                            .setNetworkId(facility.id)
                            .setLocationId(facility.locationId)
                            .setResourceTypeCode(FadResouceTypeCodeConfig.facility);
                          facilityList.options.push(facilityNameOption);
                        });
                      }

                      if (conditionList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(conditionList);
                      }

                      if (doctorsList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(doctorsList);
                      }

                      if (facilityList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(facilityList);
                      }
                      if (this.autoCompleteOptionsForSearchText && this.autoCompleteOptionsForSearchText.length > 0) {
                        this.landingPageService.setCachedSearchTextLookupOptions(
                          `${searchText}~${selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : ''}`,
                          Object.assign([], this.autoCompleteOptionsForSearchText)
                        );
                      }

                      this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
                    } catch (exception) {
                      this.bcbsmaErrorHandler.logError(
                        exception,
                        BcbsmaConstants.modules.fadModule,
                        FadConstants.components.fadLandingPageComponent,
                        FadConstants.methods.ngOnInit
                      );
                    }
                  },
                  error => {
                    this.bcbsmaErrorHandler.handleHttpError(
                      error,
                      BcbsmaConstants.modules.fadModule,
                      FadConstants.services.landingPageService,
                      FadConstants.methods.getVitalsAutoCompleteSearchResponse
                    );
                  },
                  () => {
                    this.landingPageService.showAutoCompleteDropDownSpinner = false;
                  }
                );
              } else {
                this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;
                this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
              }
            } catch (exception) {
              this.bcbsmaErrorHandler.logError(
                exception,
                BcbsmaConstants.modules.fadModule,
                FadConstants.components.fadLandingPageComponent,
                FadConstants.methods.ngOnInit
              );
            }
          },
          error => {
            this.bcbsmaErrorHandler.handleHttpError(
              error,
              BcbsmaConstants.modules.fadModule,
              FadConstants.services.searchTypeAheadControl_valueChanges,
              FadConstants.methods.valueChanges
            );
          }
        );

      /* this.filteredDependantsList = this.searchControls.dependantNameControl.valueChanges.pipe(
        startWith(''), delay(0),
        map(val => {
          try {
            let currentSelectedValue = '';
            if (this.dependantListTypeAheadTrigger) {
              clearInterval(this.dependantListTypeAheadTrigger);
              currentSelectedValue = val ? val : this.dependantListTypeAheadTrigger._element.nativeElement.value.trim();
            } else if (this.searchControls.dependantNameControl && this.searchControls.dependantNameControl.value) {
              currentSelectedValue = this.searchControls.dependantNameControl.value;
            }
            return this.dependantsList.filter(option => option.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1);
          } catch (exception) {
            this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
              FadConstants.components.fadLandingPageComponent,
              FadConstants.methods.ngOnInit);
          }
        })
      ); */
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.enhancedSearchAfterInitData
      );
    }
  }

  /**
   * @description update the zipcode field from local storage of application;
   */
  private updateZipCodeFieldFromApplicationStorage() {
    try {
      if (this.zipCodeTypeAheadTrigger && this.zipCodeTypeAheadTrigger._element) {
        let cachedCityZip: FZCSRCity = new FZCSRCity();

        if (this.getLocalStorageZipCodeOption) {
          const zipCodeOptionInLocalStorage = Object.assign(Object.create(new FZCSRCity()), this.getLocalStorageZipCodeOption);
          let _zipInLS: boolean = false;
          let _cityInLS: boolean = false;
          let _StateCodeInLS: boolean = false;
          if (zipCodeOptionInLocalStorage.zip && zipCodeOptionInLocalStorage.getZip()) {
            if (zipCodeOptionInLocalStorage.getZip().trim) {
              _zipInLS = !!zipCodeOptionInLocalStorage.getZip().trim();
            }
          }

          if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
            if (zipCodeOptionInLocalStorage.getCity().trim) {
              _cityInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
            }
          }

          if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
            if (zipCodeOptionInLocalStorage.getCity().trim) {
              _StateCodeInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
            }
          }

          if (_zipInLS && _cityInLS && _StateCodeInLS) {
            cachedCityZip = new FZCSRCity();
            cachedCityZip
              .setZip(this.getLocalStorageZipCodeOption.zip)
              .setCity(this.getLocalStorageZipCodeOption.city)
              .setState_code(this.getLocalStorageZipCodeOption.state_code)
              .setGeo(this.getLocalStorageZipCodeOption.geo); // '42.242921,-71.009972');
          }
        }

        if (cachedCityZip) {
          const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();

          this.fadSearchResultsService.setLastSelectedZipCodeOption(cachedCityZip);
          const zipCodeText = cachedCityZip.getDisplayValue();
          this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
          this.zipCodeTypeAheadTrigger._element.nativeElement.value = zipCodeText;
          this.zipCodeOptions.push(cachedCityZip);
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.updateZipCodeFieldFromApplicationStorage
      );
    }
  }

  /**
   * @description helps prepare a list of options to be displayed in the auto complete drop down list for the plan field
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete drop down typeahead list
   * for the plan field
   */
  private filterAutoCompletePlanOptions(searchText: string, escapeEmptyValueFlag?: boolean): FadAutoCompleteOptionForSearchText[] {
    this.textToHighlightInPlanOption = searchText;

    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      if (searchText && searchText.trim && searchText.trim().length && searchText.trim().length > 0) {
        this.planOptions.map(autoCompleteOption => {
          const matchingOptionTexts = autoCompleteOption.options.filter(option => {
            return (
              option.getSimpleText &&
              option.getSimpleText() &&
              option
                .getSimpleText()
                .toLowerCase()
                .indexOf(searchText.toLowerCase()) !== -1
            );
          });

          const matchingOption: FadAutoCompleteOptionForSearchText = new FadAutoCompleteOptionForSearchText();
          matchingOption.category = autoCompleteOption.category;

          if (matchingOptionTexts.length) {
            matchingOption.options = matchingOptionTexts;
          } else {
            matchingOption.options = autoCompleteOption.options;
          }
          filteredOptions.push(matchingOption);
        });

        if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
          // if (this.isAuthenticatedUser()) {
          filteredOptions.push(
            new FadAutoCompleteOptionForSearchText().addOption(
              new FadAutoCompleteComplexOption()
                .setInfoText(FadConstants.plans.myCurrentPlanOption)
                .setContextText(this.userCurrentPlan.getName())
                .setNetworkId(this.userCurrentPlan.getId())
            )
          );
        } else if (this.isAuthenticationRequired()) {
          filteredOptions.push(
            new FadAutoCompleteOptionForSearchText().addOption(
              new FadAutoCompleteComplexOption()
                .setInfoText(FadConstants.plans.dontKnowPlanOption)
                .setNetworkId(FadConstants.plans.dontKnowPlanOptionId)
            )
          );
        } else if (this.isAnonymousUser()) {
          filteredOptions.unshift(
            new FadAutoCompleteOptionForSearchText().addOption(
              new FadAutoCompleteComplexOption().setInfoText(FadConstants.plans.defaultOption)
            )
          );
        }
      } else {
        filteredOptions = this.pushDefaultAutoCompletePlanOption(searchText);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.filterAutoCompleteSearchOptions
      );
    }

    if (filteredOptions.length && filteredOptions[0].options.length) {
      const firstOption: FadAutoCompleteComplexOptionInterface = filteredOptions[0].options[0];
      if (!firstOption.getContextText()) {
        if (!firstOption.getInfoText()) {
          if (!firstOption.getSimpleText()) {
            filteredOptions.splice(0, 1);
          }
        }
      }
    }

    return filteredOptions;
  }

  /**
   * @description helps prepare a list of options for defaulted plan option
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete
   * drop down typeahead list
   * for the plan field
   */
  public pushDefaultAutoCompletePlanOption(searchText: string): FadAutoCompleteOptionForSearchTextInterface[] {
    const filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      const defaultPlanArrary = [
        FadConstants.plans.myCurrentPlanOption,
        FadConstants.plans.dontKnowPlanOption,
        FadConstants.plans.defaultOption
      ];

      if (
        this.landingPageService.getCachedSearchControlState() &&
        this.searchControls.planControl.value &&
        this.searchControls.planControl.value.profileId &&
        !defaultPlanArrary.includes(this.searchControls.planControl.value.infoText)
      ) {
        filteredOptions.push(new FadAutoCompleteOptionForSearchText().addOption(this.searchControls.planControl.value));
      }

      if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
        // if (this.isAuthenticatedUser()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.myCurrentPlanOption)
              .setContextText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId())
          )
        );
      } else if (this.isAuthenticationRequired()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.dontKnowPlanOption)
              .setNetworkId(FadConstants.plans.dontKnowPlanOptionId)
          )
        );
        // } else if (this.isAnonymousUser()) {
        //   filteredOptions.push((new FadAutoCompleteOptionForSearchText()).addOption((new FadAutoCompleteComplexOption())
        //     .setInfoText(FadConstants.plans.defaultOption)
        //   ));
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.pushDefaultAutoCompletePlanOption
      );
    }

    return filteredOptions;
  }

  /**
   * @description  helps prepare a list of options to be displayed in the auto complete search results when user types
   * a minimum of 3 characters in the Search for a doctor/facility/provider field
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete drop down typeahead list
   */
  private filterAutoCompleteSearchOptions(searchText: string): FadAutoCompleteOptionForSearchText[] {
    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      if (searchText && searchText.length > 2) {
        this.textToHighlightInSearchTextOption = searchText;
        this.autoCompleteOptionsForSearchText.map(autoCompleteOption => {
          if (
            autoCompleteOption.category ||
            (autoCompleteOption.category === '' && autoCompleteOption.options && autoCompleteOption.options.length > 0)
          ) {
            filteredOptions.push(autoCompleteOption);
          } else {
            const matchingOptionTexts = autoCompleteOption.options.filter(option => {
              return (
                option
                  .getSimpleText()
                  .toLowerCase()
                  .indexOf(searchText.toLowerCase()) !== -1
              );
            });

            if (matchingOptionTexts.length) {
              const matchingOption: FadAutoCompleteOptionForSearchText = new FadAutoCompleteOptionForSearchText();
              matchingOption.category = autoCompleteOption.category;
              matchingOption.options = matchingOptionTexts;

              filteredOptions.push(matchingOption);
            }
          }
        });
      }

      if (!filteredOptions.length) {
        filteredOptions = this.defaultAutoCompleteSearchOption;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.filterAutoCompleteSearchOptions
      );
    }
    return filteredOptions;
  }

  /**
   * @description get plan id from selected plan option
   */
  private getPlanIdFromPlanDetails() {
    try {
      return this.searchControls.planControl.value ? this.searchControls.planControl.value.profileId : null;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getPlanIdFromPlanDetails
      );
    }
  }

  /**
   * @description display the selected plan option name on the search text
   */
  public displaySelectedPlanOptionName(state) {
    try {
      if (state) {
        return state.contextText || state.simpleText;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displaySelectedPlanOptionName
      );
    }
  }

  /**
   * @description proceed with the auto complete option search
   */
  public async selectAutoCompleteSearchTextOption(optionObj: FadAutoCompleteComplexOption) {
    try {
      let zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      let plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
      if (zipCode && !plan) {
        this.autoCompleteWarningFlag = true;
      } else {
        this.autoCompleteWarningFlag = false;
      }
      const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);

      searchCriteria.setSearchText(optionObj);
      this.fadSearchResultsService.setLastSelectedSearchTextOption(optionObj);
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);

      if (
        this.searchControls.zipCodeTypeAheadControl.value &&
        this.searchControls.zipCodeTypeAheadControl.value.trim() &&
        this.searchControls.planControl.value
      ) {
        if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.professional) {
          const getDoctorProfileRequest: DoctorProfileSearchRequestModelInterface = new DoctorProfileSearchRequestModel();
          const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();

          getDoctorProfileRequest.professionalid = optionObj.getNetworkId().toString();
          getDoctorProfileRequest.geo_location = selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '';
          getDoctorProfileRequest.network_id = this.fadSearchResultsService.getLastSelectedPlanOption()
            ? this.fadSearchResultsService
                .getLastSelectedPlanOption()
                .getNetworkId()
                .toString()
            : '';
          getDoctorProfileRequest.locationId = optionObj.getLocationId().toString();

          this.doctorProfileService.doctorProfile = optionObj.getNetworkId();
          sessionStorage.setItem('professionalId', optionObj.getNetworkId().toString());
          sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
          this.router.navigate([FadConstants.urls.fadDoctorProfilePage]);
        } else if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.facility) {
          // const getFacilityProfileRequest: FacilityProfileSearchRequestModelInterface = new FacilityProfileSearchRequestModel();
          // getFacilityProfileRequest.network_id = this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId().toString();
          this.facilityProfileService.facilityProfile = optionObj.getNetworkId();
          sessionStorage.setItem('facilityProfileId', optionObj.getNetworkId().toString());

          sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
          this.router.navigate([FadConstants.urls.fadFacilityProfilePage]);
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.selectAutoCompleteSearchTextOption
      );
    }
  }

  /**
   * @description proceed with the auto complete optgroup option search
   */
  public searchTypeOptLableClickHandler(e) {
    try {
      let zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      let plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
      if (zipCode && !plan) {
        this.autoCompleteWarningFlag = true;
      } else {
        this.autoCompleteWarningFlag = false;
      }

      const optGroupParentElement: boolean = e.target.parentElement.classList.contains('clickable-label');
      this.isPageReload = false;
      if (optGroupParentElement && e.target.className.split(' ').indexOf('mat-optgroup-label') >= 0) {
        try {
          if (this.viewPortWidth < 993) {
            this.emboseSearchTextFieldOnScreen(false);
          }

          if (e.target && e.target.innerText && e.target.innerText.indexOf(FadConstants.text.allDoctorOptionText) === 0) {
            const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
            const searchTextOption = new FadAutoCompleteComplexOption();

            searchTextOption.setSimpleText(e.target.innerText.trim());
            searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);
            searchControlValues.setSearchText(searchTextOption);

            this.searchControls.setValues(searchControlValues);
            this.fadSearchResultsService.setSearchCriteria(searchControlValues);

            this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
            if (!this.isSearchButtonDisabled()) {
              this.searchControls.setValues(searchControlValues);
              this.doSearch();
            } else {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
              } finally {
                this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
              }
            }
          } else if (e.target && e.target.innerText && e.target.innerText.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0) {
            const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

            const searchTextOption = new FadAutoCompleteComplexOption();
            searchTextOption.setSimpleText(e.target.innerText.trim());
            searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);

            searchControlValues.setSearchText(searchTextOption);
            this.fadSearchResultsService.setSearchCriteria(searchControlValues);

            this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
            if (!this.isSearchButtonDisabled()) {
              this.searchControls.setValues(searchControlValues);
              if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
                this.doSearch();
              }
            } else {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
              } finally {
                this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
              }
            }
          } else {
            setTimeout(() => {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
                if (!this.isSearchButtonDisabled()) {
                  if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
                    this.doSearch();
                  }
                }
              } finally {
                // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
              }
            }, 100);
          }
        } catch (exception) {
          this.bcbsmaErrorHandler.logError(
            exception,
            BcbsmaConstants.modules.fadModule,
            FadConstants.components.fadLandingPageComponent,
            FadConstants.methods.searchTypeOptLableClickHandler
          );
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.searchTypeOptLableClickHandler
      );
    }
  }

  /**
   * @description display error message if there is an invalid input
   */
  zipcodeValidator(zipText) {
    try {
      setTimeout(() => {
        this.zipcodeResponseValidator();
      }, 1000);
      const validZipCodeRegxp = /^(?:[\d\s-]+|[a-zA-Z\s-]+)$/; // alphanumeric validator
      this.zipCodeValidationErrors.invalidZipCode.exists =
        !zipText || (zipText && (zipText.trim() === '' || !validZipCodeRegxp.test(zipText)));
      if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
        this.zipCodeValidationErrors.invalidZipCode.display = true;
        this.zipCodeValidationErrors.noMatchFound.display = false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.zipcodeValidator
      );
    }
  }

  planValidator(planName) {
    // clean up
    this.planValidationErrors.noMatchFound.display = false;
    this.planValidationErrors.invalidPlan.display = false;

    if (!planName || !planName.trim || planName.trim().length === 0) {
      this.fadSearchResultsService.setLastSelectedPlanOption(null);
      this.planValidationErrors.invalidPlan.display = true;
    } else if (planName.trim().length > 0) {
      this.planValidationErrors.noMatchFound.display =
        this.planOptions.length === 0 ||
        !this.planOptions[0] ||
        !this.planOptions[0].options ||
        this.planOptions[0].options.length === 0 ||
        !this.planOptions[0].options.some(
          planOption =>
            planOption && planName && planOption.getSimpleText && planOption.getSimpleText().toUpperCase() === planName.toUpperCase().trim()
        );

      // && this.searchControls.planControl.value && this.searchControls.planControl.value.toUpperCase
    }
  }

  /**
   * @description hide the location field error message
   */
  removeZipCodeError() {
    try {
      this.zipCodeValidationErrors.invalidZipCode.display = false;
      this.zipCodeValidationErrors.noMatchFound.display = false;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removeZipCodeError
      );
    }
  }

  /**
   * @description hide the location field error message
   */
  removePlanError() {
    try {
      this.planValidationErrors.invalidPlan.display = false;
      this.planValidationErrors.noMatchFound.display = false;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removePlanError
      );
    }
  }

  /**
   * @description display error message if there is no match found in response
   */
  private zipcodeResponseValidator() {
    try {
      let searchText =
        this.zipCodeTypeAheadTrigger &&
        this.zipCodeTypeAheadTrigger._element &&
        this.zipCodeTypeAheadTrigger._element.nativeElement &&
        this.zipCodeTypeAheadTrigger._element.nativeElement.value;
      // let searchText = this.searchControls.zipCodeTypeAheadControl.value + '';

      searchText = searchText && searchText.trim();
      if (searchText && searchText.length < 3) {
        return;
      }
      const zipFrag = searchText ? searchText.trim().split('-') : '';
      const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(
        zipFrag[0] ? zipFrag[0].trim() : ''
      );
      const alphaNumericRegex: RegExp = new RegExp(/^[a-z0-9]+$/i); // alpha numeric
      this.zipCodeValidationErrors.noMatchFound.exists = !!(
        searchText &&
        alphaNumericRegex.test(searchText) &&
        searchText.trim() !== '' &&
        (!cachedZipCodeLookupOptions || (cachedZipCodeLookupOptions && cachedZipCodeLookupOptions.length === 0))
      );

      if (
        alphaNumericRegex.test(searchText) &&
        cachedZipCodeLookupOptions === undefined &&
        this.zipCodeValidationErrors.noMatchFound.exists === undefined
      ) {
        this.zipCodeValidationErrors.noMatchFound.exists = true;
      }

      const cityFrag = zipFrag[1] ? zipFrag[1].trim().split(',') : '';
      if (cityFrag) {
        // it will compare each user input text with response to remove the error message
        const zipCodeOptionsIndex = this.zipCodeOptions.findIndex(
          x => x.zip === zipFrag[0].trim() && cityFrag[0] && cityFrag[1] && x.city === cityFrag[0] && x.state_code === cityFrag[1].trim()
        );
        if (zipCodeOptionsIndex !== -1) {
          this.zipCodeValidationErrors.invalidZipCode.exists = false;
          this.zipCodeValidationErrors.noMatchFound.exists = false;
          this.zipCodeValidationErrors.invalidZipCode.display = false;
          this.zipCodeValidationErrors.noMatchFound.display = false;
        }
      }

      // if user input is not present in cached lookup zipcode options then it will display no match found error message
      if (
        searchText &&
        searchText.length >= 3 &&
        cachedZipCodeLookupOptions &&
        cachedZipCodeLookupOptions.length === 0 &&
        this.zipCodeValidationErrors.invalidZipCode.exists === false &&
        this.zipCodeValidationErrors.noMatchFound.exists === true
      ) {
        this.zipCodeValidationErrors.noMatchFound.display = true;
        this.zipCodeValidationErrors.invalidZipCode.display = false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.zipcodeResponseValidator
      );
    }
  }

  /**
   * @description hide the search type ahead drop down on e
   */
  private hiddenSearchTypeAheadDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseSearchTextFieldOnScreen(false);
      }
      setTimeout(() => {
        try {
          this.searchTextTypeAheadTrigger.closePanel();
        } finally {
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenSearchTypeAheadDropDown
      );
    }
  }

  /**
   * @description set service alerts
   */
  private setServiceAlert(title, type = AlertType.Failure): void {
    try {
      this.fadService.setServiceAlert(title, type, FadConstants.components.fadLandingPageComponent);
      this.hiddenSearchTypeAheadDropDown();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.serviceAlert
      );
    }
  }

  /**
   * @description clearing the service alerts
   */
  private clearServiceAlert(view = FadConstants.flags.allView): void {
    try {
      switch (view) {
        case FadConstants.flags.allView:
          this.fadService.clearServiceAlert(FadConstants.components.fadLandingPageComponent);
          break;
        case FadConstants.flags.mobileView:
          if (this.viewPortWidth < 993) {
            this.fadService.clearServiceAlert(FadConstants.components.fadLandingPageComponent);
          }
          break;
        default:
          break;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.clearServiceAlert
      );
    }
  }

  public isAuthenticationRequired() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.authService.getScopeName();
      returnValue = scopeName !== 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAuthenticationRequired
      );
    }
    return returnValue;
  }

  public isAnonymousUser() {
    let returnValue = false;
    try {
      const userid = this.authService.useridin;
      returnValue = userid && userid !== 'undefined' && userid !== 'null' ? false : true;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAnonymousUser
      );
    }
    return returnValue;
  }

  public isAuthenticatedUser() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.authService.getScopeName();
      returnValue = scopeName === 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAuthenticatedUser
      );
    }
    return returnValue;
  }

  public noop(event?) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    return false;
  }

  public updateLastSelectedPlanOption() {
    try {
      if (this.planOptions && this.planOptions[0] && this.planOptions[0].options && this.planOptions[0].options.length > 0) {
        this.planOptions[0].options.some(planOption => {
          if (
            planOption &&
            planOption.getSimpleText &&
            this.searchControls.planControl.value &&
            this.searchControls.planControl.value.toUpperCase &&
            planOption.getSimpleText().toUpperCase() === this.searchControls.planControl.value.toUpperCase().trim()
          ) {
            this.fadSearchResultsService.setLastSelectedPlanOption(<FadAutoCompleteComplexOption>planOption);
            return true;
          }
        });
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.updateLastSelectedPlanOption
      );
    }
  }

  public isSearchButtonDisabled() {
    let returnValue: boolean = true;
    try {
      const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
      const userProvidedZipCode = this.searchControls.zipCodeTypeAheadControl.value;
      const userProvidedPlanControl = this.searchControls.planControl.value;

      const effectiveSearchText = userProvidedSearchText && userProvidedSearchText.trim ? userProvidedSearchText.trim() : null;
      const effectiveZipCode = userProvidedZipCode && userProvidedZipCode.trim ? userProvidedZipCode.trim() : null;
      let effectivePlanControl = null;
      if (userProvidedPlanControl) {
        if (userProvidedPlanControl.simpleText || userProvidedPlanControl.contextText) {
          effectivePlanControl = userProvidedPlanControl.simpleText.trim ? userProvidedPlanControl.simpleText.trim() : '';
          if (effectivePlanControl === '' && userProvidedPlanControl.contextText && userProvidedPlanControl.contextText.trim) {
            effectivePlanControl = userProvidedPlanControl.contextText.trim();
          }
        } else if (userProvidedPlanControl.trim) {
          effectivePlanControl = userProvidedPlanControl.trim();
        }
      }

      let validSearchText: boolean = false;
      if (effectiveSearchText && effectiveSearchText.length > 2) {
        validSearchText = true;
      }

      const zipCodeValue = this.searchControls.zipCodeTypeAheadControl.value;
      const zipCodeValueNotValid = !zipCodeValue || !zipCodeValue.trim || zipCodeValue.trim().length < 3;

      const errors: boolean =
        !!this.zipCodeValidationErrors.noMatchFound.display ||
        !!this.zipCodeValidationErrors.invalidZipCode.display ||
        !!this.planValidationErrors.noMatchFound.display ||
        !!this.planValidationErrors.invalidPlan.display ||
        zipCodeValueNotValid;

      // returnValue = errors || !(validSearchText && !!effectiveZipCode &&
      //   !!effectivePlanControl && !!this.getLocalStorageZipCodeOption);
      //console.log(errors || !(validSearchText && !!effectiveZipCode && !!effectivePlanControl));
      returnValue = errors || !(validSearchText && !!effectiveZipCode && !!effectivePlanControl);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isSearchButtonDisabled
      );
    }
    return returnValue;
  }

  private stripAllDoctorFacilityTextAndUpdateUI(searchText: string): string {
    if (searchText && searchText.trim) {
      this.isPageReload = false;
      searchText = searchText.trim();
      if (searchText.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) >= 0) {
        searchText = searchText.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
        setTimeout(() => {
          this.searchControls.searchTypeAheadControl.setValue(searchText);
        }, 10);
      } else if (searchText.indexOf(FadConstants.text.allDoctorOptionText) >= 0) {
        searchText = searchText.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
        setTimeout(() => {
          this.searchControls.searchTypeAheadControl.setValue(searchText);
        }, 10);
      }
    }
    return searchText;
  }

  public changeSelectedMember(event) {
    const chMemberId = event.value;
    const fadVendorMemberNumber = sessionStorage.setItem('fadVendorMemberNumber', event.value);
    console.log("sessionStorage.setItem('fadVendorMemberNumber " + this.selectedMember);
    this.fetchProcedureSummary();
    this.doSearch();
    const memberIndex = this.dependantsList
      .map(function(mem) {
        return mem.fadVendorMemberNumber;
      })
      .indexOf(chMemberId);
    this.selectedMember = this.dependantsList[memberIndex];

    sessionStorage.setItem('selMemIdx', memberIndex.toString());
  }

  getSelectedUserName(memberId?): string {
    const selectedUser =
      this.dependantsList &&
      this.dependantsList.filter(res => {
        return res.fadVendorMemberNumber === memberId;
      });
    if (selectedUser && selectedUser.length === 1) {
      return `${selectedUser[0].subscriberFirstName} ${selectedUser[0].subscriberLastName}`;
    } else {
      return '';
    }
  }
}
