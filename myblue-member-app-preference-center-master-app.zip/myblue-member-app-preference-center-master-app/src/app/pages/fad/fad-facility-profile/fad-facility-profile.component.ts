import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { Platform } from '@ionic/angular';
import { PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { TooltipPopoverComponent } from '../../../shared/components/tooltip-popover/tooltip-popover.component';
import { AlertService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { AppState } from '../../../store/state/app.state';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadFacilityProfileRequestModel, FadFacilityResponseModel } from '../modals/fad-facility-profile-details.model';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import {
  FadProfessionalInterface,
  GetSearchByProfessionalRequestModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { BreadCrumb } from '../utils/fad.utils';
import { FadFacilityProfileService } from './fad-facility-profile.service';

@Component({
  selector: 'app-fad-facility-profile',
  templateUrl: './fad-facility-profile.component.html',
  styleUrls: ['./fad-facility-profile.component.scss']
})
export class FadFacilityProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  @SelectSnapshot(AppSelectors.getMLEIndicator) mleIndicator: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  public facilityProfile: FadProfessionalInterface;
  public facilityName: string;
  public awards = [];
  public outOfNetworkFlag: boolean;
  public noNetworkSelectedFlag: boolean;
  public isShowFacilityDetialsSection = false;
  public fadFacilityResposeData: FadFacilityResponseModelInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public selectedLocationDetails: any;
  private selectedLocationIndex = 0;
  private hospitalQualityDefaultListLimit = 3;
  private hospitalQualityListLimit: number = this.hospitalQualityDefaultListLimit;
  public accordianToggleStatus: any = {};
  public isProcedure = false;
  public procedureTitle: string;
  public procedureID: string;
  public icon = false;
  public chapter224 = false;

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  public mleEligibility: string;
  showAffiliatedDoctors: boolean;
  private toolTipTxt: string;
  public tierTooltipDescription: string;
  public tierTooltip = [];
  public awardIndex = 0;
  public profileTooltip = new Array();
  public identifierToolTipDescription = '';
  public qmToolTipDescription = '';
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  public disclaimerBcbsBottomCostModule: any;
  public disclaimerBcbsTopProfile: any;
  public fadFacilityProfileData: FadFacilityResponseModelInterface = null;
  isActive = false;

  constructor(
    private facilityProfileService: FadFacilityProfileService,
    private router: Router,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private fadService: FadService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private clipboard: Clipboard,
    private callNumber: CallNumber,
    private platform: Platform,
    private popoverController: PopoverController,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {}

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_FAD_FacilityProfile);

      this.chapter224 = this.mleIndicator === 'lite';
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
        this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
      }
      this.fadSearchResultsService.setContextText('');

      this.getNPToolTipDescription();

      this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Facility Details').setUrl('/fad/facility-profile'));

      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      this.mleEligibility = this.mleIndicator;

      if (searchCriteria) {
        this.isProcedure = searchCriteria.getSearchText().isProcedure();
        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        this.procedureID = searchCriteria.getSearchText().getProcedureId();
      }

      const resolvedData =
        this.fadFacilityProfileData == null ? this.route.snapshot.data.fadFacilityResposeData : this.fadFacilityProfileData;
      if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
        this.isShowFacilityDetialsSection = false;
        this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
      } else {
        this.fadFacilityResposeData = new FadFacilityResponseModel();
        this.fadFacilityResposeData = resolvedData.facility;
        if (this.fadFacilityResposeData.disclaimers) {
          this.disclaimers = this.fadFacilityResposeData.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerProfileTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerProfileBottomList;
          });
          this.disclaimerBcbsBottomCostModule = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBcbsBottomCostModule;
          });
          this.disclaimerBcbsTopProfile = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBcbsTopProfile;
          });

          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        if (this.fadFacilityResposeData.onRecordDiclaimers) {
          this.onRecordDiclaimers = this.fadFacilityResposeData.onRecordDiclaimers;
          if (
            this.onRecordDiclaimers &&
            this.onRecordDiclaimers.category &&
            this.onRecordDiclaimers.category === 'on_record' &&
            this.onRecordDiclaimers.text
          ) {
            this.disclaimersFlag = true;
            this.disclaimersText = this.onRecordDiclaimers.text;
          }
        }
        this.networkChanged = sessionStorage.getItem('networkChange');
        console.log(this.networkChanged);
        const locationId = sessionStorage.getItem('locationId');
        this.loadDetailsBasedOnLocation(locationId, false);

        // this.loadDetailsBasedOnLocation(this.selectedLocationIndex);
        this.isShowFacilityDetialsSection = true;
        if (this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId) {
          sessionStorage.setItem('facilityname', this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
          sessionStorage.setItem(
            'linkedAffiliationId',
            this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId
          );
        }
        const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
        vitalsSearchRequestbyProfessional
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(FAD_CONSTANTS.defaults.page)
          .setNetworkId(searchCriteria.getPlanName().getNetworkId());
        this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).subscribe(data => {
          setTimeout(() => {
            if (data) {
              this.showAffiliatedDoctors = data.totalCount > 0;
            }
            // tslint:disable-next-line:no-magic-numbers
          }, 500);
        });
      }
  }

  getNPToolTipDescription() {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip.code === 'PPIN') {
          this.identifierToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PCQM') {
          this.qmToolTipDescription = tooltip.toolTip.description;
        }
      });
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  loadDetailsBasedOnLocation(locationsId, change: boolean) {
    this.awards = [];
    this.selectedLocationIndex = locationsId;
    sessionStorage.setItem('locationId', locationsId);
    if (change) {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));
      // this.fadFacilityProfileService.facilityProfile;
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FAD_CONSTANTS.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();
      // tslint:disable-next-line:no-shadowed-variable
      const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      if (facilityLocationFlag === 'true') {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId);
      } else {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId)
          .setLocationId(Number(locationId));
      }

      if (procedureID && facilityLocationFlag !== 'true') {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);

        fadDoctorProfileRequestParams.setRadius(
          // tslint:disable-next-line:no-magic-numbers
          sessionStorage.getItem('radius') !== 'null' ? Number(sessionStorage.getItem('radius')) : 25
        );
      }

      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }
      const mleIndicator = this.mleEligibility;
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {
        this.fadFacilityProfileData = data;
        this.ngOnInit();
      });
    }

    const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');
    if (facilityLocationFlag === 'true' && this.getDirections && this.fadFacilityResposeData.location.length) {
      this.selectedLocationDetails = this.fadFacilityResposeData.location[0];
      sessionStorage.setItem('facilityLocationFlag', 'false');
    } else {
      this.selectedLocationDetails = this.fadFacilityResposeData.location.find(p => p.locationId.toString() === locationsId);
    }

    if (this.selectedLocationDetails.quality.length) {
      const quality = this.selectedLocationDetails.quality;
      quality.sort((a, b) => b.score - a.score);

      this.selectedLocationDetails.quality = quality;
    }
    if (this.selectedLocationDetails.awards) {
      this.selectedLocationDetails.awards.forEach(award => {
        this.awards.push(award);
      });
    }
    if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
      this.getToolTipDescription(this.tierTooltip, this.selectedLocationDetails.tiers.description);
    }
    this.accordianToggleStatus = {};
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }

  getRating(reviews) {
    this.startRating = new StarRatingComponentInputModel();
    if (Object.keys(reviews).length === 0) {
      this.startRating.totalRatings = 0;
      this.startRating.overAllRating = 0;
    } else {
      this.startRating.totalRatings = reviews.totalRatings;
      this.startRating.overAllRating = parseFloat(reviews.overallRating);
    }
    return this.startRating;
  }

  getQualityRating(quality) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.totalRatings = quality.score;
    this.startRating.numberOfStars = 3;
    this.startRating.overAllRating = parseFloat(quality.score);
    return this.startRating;
  }

  public copyIdentifierValue(text: string): void {
    this.clipboard.copy(text);
  }

  toggleAccordion(listItem, $event) {
    if ($event) {
      $event.stopPropagation();
    }
    if (this.accordianToggleStatus[listItem] === undefined) {
      this.accordianToggleStatus[listItem] = false;
    }
    this.accordianToggleStatus[listItem] = !this.accordianToggleStatus[listItem];
  }

  hospitalQualityListLimitToggle() {
    this.hospitalQualityListLimit =
      this.hospitalQualityListLimit === this.hospitalQualityDefaultListLimit
        ? this.selectedLocationDetails.quality.length
        : this.hospitalQualityDefaultListLimit;
  }

  public getDirections(location): void {
    if (this.platform.is('android')) {
      window.open('geo:' + location, '_blank');
    } else {
      window.open('maps://maps.apple.com/?q=' + location, '_blank');
    }
  }

  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public showCostBreakdown(facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.parentPage = FAD_CONSTANTS.text.facilityPage;
    this.router.navigate(['/fad/cost-breakdown']);
  }

  public learnMoreAboutQuality() {
    // throw new Error('yet to be coded');
  }

  public searchAffiliatedDoctors() {
    // throw new Error('yet to be coded');
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    sessionStorage.setItem('facilityname', this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
    sessionStorage.setItem('linkedAffiliationId', this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId);

    if (searchCriteria) {
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
      this.fadSearchResultsService.setContextText('affiliated');
      this.router.navigate([FAD_CONSTANTS.urls.fadAffiliatedDoctorsSearch]);
    }
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public convertAmountToDecimalValue(value) {
    const intPart = Math.trunc(value);
    const floatPart = Number((value - intPart).toFixed(2));
    const decimal: string[] = floatPart.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  initCallNumber(selectedLocationDetails: any) {
    if (selectedLocationDetails && selectedLocationDetails.phone) {
      from(this.callNumber.callNumber(selectedLocationDetails.phone, true)).subscribe(() => console.log('Launched dialer'));
    }
  }

  async showPopover($event: any, description: any) {
    this.isActive = true;
    const popover = await this.popoverController.create({
      component: TooltipPopoverComponent,
      event: $event,
      componentProps: {
        tooltipText: description
      },
      mode: 'ios'
    });
    await popover.present();
    from(popover.onDidDismiss()).subscribe(() => (this.isActive = false));
  }
}
