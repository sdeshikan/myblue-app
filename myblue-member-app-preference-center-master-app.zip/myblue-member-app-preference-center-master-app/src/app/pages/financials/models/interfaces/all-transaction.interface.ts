import { TransactionDetailsSearchResponseModelInterface } from './filter-search-all-transaction.interface';

export interface TransactionSummaryResponseInterface {
  Completed: any[];
  Pending: any[];
  Action: any[];
  Others: any[];
}

export interface TransactionSummaryRequestInterface {
  userId: string;
}

export interface AllTransactionNoDocsFoundPageModelInterface {
  title: string;
  noDocsMessage: string;
  containerInfo: string;
}

export interface NoDocumentsFoundComponentModelInterface {
  mode: string;
  title: string;
  searchCriteria: TransactionDetailsSearchResponseModelInterface;
}

export interface IHash<T> {
  [key: string]: T;
}

export interface HashMapInterface<T> {
  // map: IHash<T>;
  size: number;
  get(key: string): T;
  put(key: string, value: T): HashMapInterface<T>;
  contains(key: string): boolean;
  remove(key: string): HashMapInterface<T>;
  removeAll(): HashMapInterface<T>;
  getKeys(): string[];
  getValues(): T[];
}
