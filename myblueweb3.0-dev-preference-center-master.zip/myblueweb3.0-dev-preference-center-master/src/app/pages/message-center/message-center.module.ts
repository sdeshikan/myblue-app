
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
// import { EobComponent } from './eob/eob.component';
// import { EOBService } from './eob/eob.service';
// import { EOBResolverService } from './eob/eob-resolver.service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { MaterialModule } from '../../material.module';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService, ConstantsService, SharedModule } from '../../shared/shared.module';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { authHttpFactory } from '../../shared/utils/authHttp.factory';
import { FeatureGuard } from '../../shared/utils/feature-guard';
import { DocumentDetailComponent } from './document-detail/document-detail.component';
import { DocumentDetailResolverService } from './document-detail/document-detail.resolver';
import { DocumentDetailService } from './document-detail/document-detail.service';
import { DocumentsListViewResolverService } from './documents-list-view/document-list-view.resolver';
import { DocumentsListViewComponent } from './documents-list-view/documents-list-view.component';
import { DocumentsOverallViewComponent } from './documents-overall-view/documents-overall-view.component';
import { BenefitCoverageListResolverService } from './documents/benefit-coverage-list.resolver';
import { DocumentsComponent } from './documents/documents.component';
import { DocumentsResolverService } from './documents/documents.resolver';
import { DocumentsService } from './documents/documents.service';
import { InboxComponent } from './inbox/inbox.component';
import { MessageCenterSearchComponent } from './message-center-search/message-center-search.component';
import { MessageCenterSearchService } from './message-center-search/message-center-search.service';
import { MessageCenterRouter } from './message-center.routing';
import { MessageCenterService } from './message-center.service';
import { MessageDetailComponent } from './message-detail/message-detail.component';
import { MessageDetailService } from './message-detail/message-detail.service';
import { MsgListingComponent } from './msg-listing/msg-listing.component';
import { MsgListingService } from './msg-listing/msg-listing.service';
import { NoDocumentsFoundComponent } from './no-documents-found/no-documents-found.component';
import { TaxFormsviewComponent } from './tax-forms-view/tax-forms-view.component';
import { TaxFormService } from './tax-forms-view/tax-forms-view.service';
import { UploadDetailComponent } from './upload-detail/upload-detail.component';
import { UploadDetailsService } from './upload-detail/upload-details.service';
import { UploadsComponent } from './uploads/uploads.component';
import { UploadsService } from './uploads/uploads.service';
import { TaxFormsOverallViewComponent } from './tax-forms-overall-view/tax-forms-overall-view.component';




@NgModule({
  imports: [CommonModule, MessageCenterRouter, SharedModule, MaterialModule, InfiniteScrollModule],
  exports: [],
  declarations: [
    NoDocumentsFoundComponent,
    InboxComponent,
    MessageDetailComponent,
    UploadsComponent,
    UploadDetailComponent,
    DocumentsComponent,
    DocumentsOverallViewComponent,
    DocumentsListViewComponent,
    MsgListingComponent,
    DocumentDetailComponent,
    MessageCenterSearchComponent,
    TaxFormsviewComponent,
    TaxFormsOverallViewComponent
    // EobComponent
  ],
  providers: [
    AuthGuard,
    {
      provide: AuthHttp,
      useFactory: authHttpFactory,
      deps: [HttpClient, AuthService, ConstantsService, AuthHttp]
    },
    FeatureGuard,
    MessageCenterService,
    DocumentsService,
    UploadsService,
    UploadDetailsService,
    MsgListingService,
    MessageCenterSearchService,
    MessageDetailService,
    AuthHttp,
    DocumentsResolverService,
    BenefitCoverageListResolverService,
    DocumentsListViewResolverService,
    DocumentDetailService,
    DocumentDetailResolverService,
    TaxFormService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MessageCenterModule { }
