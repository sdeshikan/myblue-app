import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';

export interface GetSearchByProcedureRequestModelInterface {
    useridin: string;
    locale: string;

    getUserId(): string;
    setUserId(useridin: string): GetSearchByProcedureRequestModelInterface;

    getLocale(): string;
    setLocale(locale: string): GetSearchByProcedureRequestModelInterface;

}
