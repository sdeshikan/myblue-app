// import { FadSearchRequestByProfessionalModel } from './../modals/fad-vitals-collection.model';
import {
  Component,
  OnInit,
  ChangeDetectorRef,
  ViewChild,
  OnDestroy,
  ElementRef,
  HostListener,
  EventEmitter,
  Output,
  Input
} from '@angular/core';
import { FadLandingPageConsumer, FadSearchFilterConsumer, FadSearchListConsumer } from '../modals/interfaces/fad.interface';
import { FadLandingPageCompInput, FadLandingPageSearchControlValues } from '../modals/fad-landing-page.modal';
import {
  FadLandingPageCompInputInterface,
  FadLandingPageCompOutputInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';
import { FadConstants } from '../constants/fad.constants';

import {
  FadSearchFilterComponentOutputModelInterface,
  FadFacilitySearchFilterComponentOutputModelInterface,
  FadSpecialtyFilterComponentOutputModelInterface
} from '../modals/interfaces/fad-search-filter.interface';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import {
  FadSearchListComponentInputModelInterface,
  FadSearchListComponentOutputModelInterface,
  FadFacilityListComponentInputModelInterface,
  FadFacilityListComponentOutputModelInterface,
  FadSpecialtyListComponentInputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import {
  FadSearchListComponentInputModel,
  FadFacilityListComponentInputModel,
  FadSearchListComponentOutputModel,
  FadSpecialtyListComponentInputModel
} from '../modals/fad-search-list.modal';
import { FadSearchResultsService } from './fad-search-results.service';
import { AuthService } from '../../../shared/services/auth.service';
import { FadProviderCompareService } from '../fad-provider-compare/fad-provider-compare.service';
import {
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface,
  FiltersMetadataInterface,
  SortMetadataInterface,
  CostDetails,
  Disclaimers,
  FadProfessionalInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface,
  FacilityFiltersMetadataInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { GetSearchByProfessionalRequestModel, FiltersMetadata, SortMetadata } from '../modals/getSearchByProfessional.model';
import { ActivatedRoute, Router } from '@angular/router';
import { FadResouceTypeCodeConfig, FadResourceTypeCode } from '../modals/types/fad.types';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
import { GetSearchByFacilityRequestModel, FacilityFiltersMetadataModel } from '../modals/getSearchByFacility.model';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { FadService } from './../fad.service';
import { BreadCrumb } from '../utils/fad.utils';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import * as _isEmpty from 'lodash/isEmpty';
import { FadFacilityCompareService } from '../fad-facility-compare/fad-facility-compare.service';
import { GlobalService } from '../../../shared/services/global.service';
import {
  GetSearchBySpecialityRequestModelInterface,
  GetSearchBySpecialtyResponseModelInterface,
  GetSearchBySpecialityResponseModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { FadProfileCardComponentInputModel } from '../modals/fad-profile-card.modal';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadProviderFacilityListService } from '../fad-provider-facility-list/fad-provider-facility-list.service';
import { FadFacilityListService } from '../fad-facility-list/fad-facility-list.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../shared/services/validation.service';
//import { $ } from 'protractor';
declare let $: any;

@Component({
  selector: 'app-fad-search-results',
  templateUrl: './fad-search-results.component.html',
  styleUrls: ['./fad-search-results.component.scss']
})
export class FadSearchResultsComponent
  implements OnInit, OnDestroy, FadLandingPageConsumer, FadSearchFilterConsumer, FadSearchListConsumer {
  @Output('componentOutput') componentOutput: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<
    FadSearchListComponentOutputModel
  >();

  @Input('componentInput') componentInput: FadSearchListComponentInputModelInterface;

  public fadConstants = FadConstants;
  public isNoSearchResults: boolean = false;
  emailEditForm: FormGroup;

  // fad-landing-page component consumption requirements
  public miniSearchBarData: FadLandingPageCompInputInterface = new FadLandingPageCompInput();

  // fad-search-filter component consumption requirement
  public mobileHideByFilterOverlay: boolean = false;

  // fad-search-list component consumption requirement
  public searchListComponentInput: FadSearchListComponentInputModelInterface;
  public facilityListComponentInput: FadFacilityListComponentInputModelInterface;
  public specialtyListComponentInput: FadSpecialtyListComponentInputModelInterface;
  public searchSpecialtyList: GetSearchBySpecialtyResponseModelInterface;
  public searchResults: GetSearchByProfessionalResponseModelInterface; // FadVitalsProfessionalsSearchResponseModelInterface;
  public totalCount: number;
  public costDetails: CostDetails;
  public disclaimers: Disclaimers[];
  public disclaimerToplist: Disclaimers[];
  public disclaimerBottomlist: Disclaimers[];
  public resourceTypeCode: FadResourceTypeCode = null;
  public locationID: number = 0;
  public providersList = [];
  public facilityName = null;
  private infiniteScrollIndexCache: number = 1;

  // Search type Content
  public isAllProcedures: Boolean = false;
  public isFilter: Boolean = false;
  public isAffiliatedDoctors: Boolean = false;

  @ViewChild(InfiniteScrollDirective) infiniteScroll: InfiniteScrollDirective;
  @ViewChild('optionalMessage') optionalMessage;
  public isDisplaySpinner: boolean = false;
  public isDisplaySpinnerProfessional: boolean = false;

  public facilityFilterCriteriaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
  public filterCriteriaData: FiltersMetadataInterface = new FiltersMetadata();
  public sortCriteriaData: SortMetadataInterface = new SortMetadata();

  showCompareResultsButton: boolean = false;
  selectedResultCount: number = 0;
  displayBannerInFixedPosition: boolean = false;
  specialtyFlag: boolean = false;
  procedureFlag: boolean = false;
  specialtyEmailFlag: boolean = false;
  professionalEmailFlag: boolean = false;
  facilityEmailFlag: boolean = false;
  public enableSendEmailBtn: boolean = false;
  public sendEmailAddress: string = '';
  public optionalMessageValue: string = '';
  public networkChanged: string;
  public isFormSubmitted = false;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadSearchListService,
    private fadFacilityListService: FadFacilityListService,
    private fadProviderFacilityListService: FadProviderFacilityListService,
    private cdRef: ChangeDetectorRef,
    public authService: AuthService,
    private fadProviderCompareService: FadProviderCompareService,
    private fadFacilityCompareService: FadFacilityCompareService,
    private activatedRoute: ActivatedRoute,
    private fadService: FadService,
    private router: Router,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private globalService: GlobalService,
    public elementRef: ElementRef,
    private authHttp: AuthHttp,
    private validationService: ValidationService,
    private fb: FormBuilder
  ) {
    this.emailEditForm = this.fb.group({
      emailAddress: ['', [Validators.required, this.validationService.emailValidator()]]
    });
  }

  @HostListener('window:scroll', ['$event'])
  showBannerFixedOnWindowScroll($event) {
    const msgListingPos = this.elementRef.nativeElement.offsetTop;
    const windowScrollPos = window.pageYOffset;
    if (windowScrollPos > msgListingPos && windowScrollPos > 300 && window.screen.width > 992) {
      this.displayBannerInFixedPosition = this.showCompareResultsButton;
    } else {
      this.displayBannerInFixedPosition = false;
    }
  }

  ngOnInit() {
    try {
      $('#openMaiSendWindow').modal({ dismissible: true });
      //$('#openMaiSendWindow').modal('open');
      // $('#openMaiSendWindow').modal('open');
      this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Search').setUrl('/fad/search-results'));

      this.miniSearchBarData.componentMode = FadConstants.flags.fadLandingPageComponentMode_Abstract;
      this.miniSearchBarData.fadBaseSearchModel = this.fadSearchResultsService.getSearchCriteria();

      this.isAllProcedures = this.miniSearchBarData.fadBaseSearchModel.getSearchText().isProcedure();

      if (this.router.url === FadConstants.urls.fadAffiliatedDoctorsSearch) {
        this.isAffiliatedDoctors = true;
        this.facilityName = sessionStorage.getItem('facilityname');
      } else {
        sessionStorage.removeItem('linkedAffiliationId');
        this.isAffiliatedDoctors = false;
      }

      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      if (searchCriteria) {
        // ensure that the a valid request is present before querying for a response
        this.resourceTypeCode = searchCriteria.getSearchText().getResourceTypeCode();
        this.locationID = searchCriteria.getSearchText().getLocationId();

        this.procedureFlag = searchCriteria.getSearchText().isProcedure();
        this.searchListComponentInput = new FadSearchListComponentInputModel();
        // this.searchListComponentInput.searchResults = this.searchResults;
        if (this.isAffiliatedDoctors) {
          this.resourceTypeCode = 'P';
          this.procedureFlag = false;
          console.log(this.activatedRoute.snapshot.data.fadLandingPageSearchResults);
          this.getFadProfileSearchResults(
            searchCriteria,
            false,
            <GetSearchByProfessionalResponseModelInterface>this.activatedRoute.snapshot.data.fadLandingPageSearchResults
          );
          //this.fadSearchResultsService.getAffiliatedDoctorsResults()
        } else if (this.resourceTypeCode === FadResouceTypeCodeConfig.professional && !searchCriteria.getSearchText().isProcedure()) {
          this.getFadProfileSearchResults(
            searchCriteria,
            false,
            <GetSearchByProfessionalResponseModelInterface>this.activatedRoute.snapshot.data.fadLandingPageSearchResults
          );
        } else if (this.resourceTypeCode == FadResouceTypeCodeConfig.facility && !searchCriteria.getSearchText().isProcedure()) {
          this.getFadFacilitySearchResults(
            searchCriteria,
            false,
            <GetSearchByFacilityResponseModelInterface>this.activatedRoute.snapshot.data.fadLandingPageSearchResults
          );
        } else {
          console.log('activated route snapshot data', this.activatedRoute.snapshot.data);
          this.getFadSpecialtySearchResults(
            searchCriteria,
            false,
            <GetSearchBySpecialtyResponseModelInterface>this.activatedRoute.snapshot.data.fadLandingPageSearchResults
          );
        }
      } else {
        this.isNoSearchResults = true;
      }
      this.fadSearchResultsService.setContextText('');
      this.networkChanged = sessionStorage.getItem('networkChange');
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }
  openEmailSendWindow() {
    $('#openMaiSendWindow').modal('open');
  }
  closeEmailModals() {
    $('#openMaiSendWindow').modal('close');
  }
  getSendEmail(event) {
    this.sendEmailAddress = event.target.value;
    if (event.target.value && this.validateEmail(event.target.value)) {
      this.enableSendEmailBtn = true;
    } else {
      this.enableSendEmailBtn = false;
    }
  }
  validateEmail(email) {
    let re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email);
  }

  ngOnDestroy(): void {
    this.infiniteScrollIndexCache = 1;
    this.fadService.resetServiceError();
    sessionStorage.removeItem('searchAffiliatedDoctors');
  }

  /**
   * @description helps obtain search results based on input parameters
   *  The method gets from ngOnInit event or through search button click on landing page component in abstract mode
   * @param request : FadLandingPageSearchControlValuesInterface - search parameters
   */
  private getFadProfileSearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchByProfessionalResponseModelInterface,
    filtersData?: FiltersMetadataInterface,
    sortData?: SortMetadataInterface
  ): void {
    sessionStorage.setItem('radius', null);
    //$('ng4-loading-spinner .spinner').addClass('visible');
    // PLEASE NOTE
    // THIS METHOD DOES NOT USE THE INPUT REQUEST YET
    // BUT THE SAME WILL BE USED ONCE ALL THE GET REQUESTS ARE CONVERTED INTO POST REQUESTS
    // PLEASE DONOT DELETE THE INPUT PARAMETER request: FadLandingPageSearchControlValuesInterface
    try {
      if (resolvedData) {
        this.updateProfessionalsDataToView(resolvedData, false, scroll);
        return;
      }

      this.isDisplaySpinnerProfessional = scroll;
      const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
      if (!scroll) {
        this.infiniteScrollIndexCache = 0;
      }
      if (this.isAffiliatedDoctors) {
        this.isDisplaySpinnerProfessional = true;
        vitalsSearchRequestbyProfessional
          .setLimit(FadConstants.defaults.limit)
          .setPage(++this.infiniteScrollIndexCache)
          .setNetworkId(
            request.getPlanName && request.getPlanName().getNetworkId()
              ? request.getPlanName().getNetworkId()
              : FadConstants.defaults.networkId
          );
        //.setNetworkId(311005002);
      } else {
        vitalsSearchRequestbyProfessional
          .setGeoLocation(request.getZipCode().geo)
          .setLimit(FadConstants.defaults.limit)
          .setPage(++this.infiniteScrollIndexCache)
          .setRadius(25)
          .setNetworkId(
            request.getPlanName && request.getPlanName().getNetworkId()
              ? request.getPlanName().getNetworkId()
              : FadConstants.defaults.networkId
          );

        if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
          vitalsSearchRequestbyProfessional.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
        } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
          vitalsSearchRequestbyProfessional.setSearchProcedureId(request.getSearchText().getProcedureId());
        } else {
          vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(request));
        }
      }

      // Start applying Sorting & filters //
      if (filtersData) {
        if (this.fadSearchListService.isFilterChangedFlag == true) this.clearSelectedResults();
        if (filtersData.filterPCP && filtersData.filterPCP.value) {
          vitalsSearchRequestbyProfessional.setisPcp(filtersData.filterPCP.value);
        }

        if (filtersData.filterTechSavvy && filtersData.filterTechSavvy.value) {
          vitalsSearchRequestbyProfessional.setTechSavvy(filtersData.filterTechSavvy.value);
        }

        if (filtersData.filterAcceptingNewPatients && filtersData.filterAcceptingNewPatients.value) {
          vitalsSearchRequestbyProfessional.setAcceptingNewPatients(filtersData.filterAcceptingNewPatients.value);
        }

        if (filtersData.filterInNetwork && filtersData.filterInNetwork.value) {
          vitalsSearchRequestbyProfessional.setInNetwork(filtersData.filterInNetwork.value);
        }

        if (filtersData.filterGender && filtersData.filterGender.value) {
          vitalsSearchRequestbyProfessional.setProfessionalGender(filtersData.filterGender.value);
        }

        if (filtersData.filterLanguage && filtersData.filterLanguage.value) {
          vitalsSearchRequestbyProfessional.setProfessionalLanguages(filtersData.filterLanguage.value);
        }

        if (filtersData.filterRating && filtersData.filterRating.value) {
          vitalsSearchRequestbyProfessional.setAggregateOverallRating(filtersData.filterRating.value);
        }

        if (filtersData.filterAges && filtersData.filterAges.value) {
          vitalsSearchRequestbyProfessional.setAgestreatedTypeCode(filtersData.filterAges.value);
        }

        if (filtersData.filterDisorders && filtersData.filterDisorders.value) {
          vitalsSearchRequestbyProfessional.setDisorderTreatedTypeCode(filtersData.filterDisorders.value);
        }

        if (filtersData.filterTreatment && filtersData.filterTreatment.value) {
          vitalsSearchRequestbyProfessional.setTreatmentMethodsTypeCode(filtersData.filterTreatment.value);
        }

        if (filtersData.filterSpecialities && filtersData.filterSpecialities.value) {
          vitalsSearchRequestbyProfessional.setSearchSpecialtyId(filtersData.filterSpecialities.value);
        }

        if (filtersData.filterLocation && filtersData.filterLocation.value) {
          vitalsSearchRequestbyProfessional.setRadius(Number(filtersData.filterLocation.value));
          if (Number(filtersData.filterLocation.value)) sessionStorage.setItem('radius', filtersData.filterLocation.value);
          else sessionStorage.setItem('radius', null);
        }
        if (filtersData.filterBcd && filtersData.filterBcd.value) {
          vitalsSearchRequestbyProfessional.setBcdTypeCodes(filtersData.filterBcd.value);
        }
        if (filtersData.filterCqms && filtersData.filterCqms.value) {
          vitalsSearchRequestbyProfessional.setCqms(filtersData.filterCqms.value);
        }
        if (filtersData.filterisChoicePcp && filtersData.filterisChoicePcp.value) {
          vitalsSearchRequestbyProfessional.setIsChoicePcp(filtersData.filterisChoicePcp.value);
        }
        if (filtersData.filterTiers && filtersData.filterTiers.value) {
          vitalsSearchRequestbyProfessional.setTiers(filtersData.filterTiers.value);
        }
        if (filtersData.filterAwards && filtersData.filterAwards.value) {
          vitalsSearchRequestbyProfessional.setAwardsTypeCodes(filtersData.filterAwards.value);
        }
        if (
          filtersData.filterHospitalAffilation &&
          (filtersData.filterHospitalAffilation.value || filtersData.filterHospitalAffilation.category)
        ) {
          if (filtersData.filterHospitalAffilation.value && filtersData.filterHospitalAffilation.value !== '') {
            vitalsSearchRequestbyProfessional.setHospitalAffiliationId(filtersData.filterHospitalAffilation.value);
          }

          if (filtersData.filterHospitalAffilation.category && filtersData.filterHospitalAffilation.category !== '') {
            vitalsSearchRequestbyProfessional.setHospitalAffiliationCategory(filtersData.filterHospitalAffilation.category);
          }
        }
        if (filtersData.filterGroupAffilation && (filtersData.filterGroupAffilation.value || filtersData.filterGroupAffilation.category)) {
          if (filtersData.filterGroupAffilation.value && filtersData.filterGroupAffilation.value !== '') {
            vitalsSearchRequestbyProfessional.setGroupAffiliationId(filtersData.filterGroupAffilation.value);
          }

          if (filtersData.filterGroupAffilation.category && filtersData.filterGroupAffilation.category !== '') {
            vitalsSearchRequestbyProfessional.setGroupAffiliationCategory(filtersData.filterGroupAffilation.category);
          }
        }
      }

      if (sortData) {
        if (sortData && sortData.value) {
          vitalsSearchRequestbyProfessional.setSort(sortData.value);
        }
      }
      // End applying Sorting & filters //

      console.log('vitals search request by professional', vitalsSearchRequestbyProfessional);
      const skipNoResultsValidationFlag: boolean = true;
      this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional, scroll).subscribe(
        data => {
          this.isDisplaySpinnerProfessional = false;
          //$('ng4-loading-spinner .spinner').removeClass('visible');

          if (data.totalCount >= 0) {
            this.updateProfessionalsDataToView(data, skipNoResultsValidationFlag, scroll);
            this.cdRef.detectChanges();
          }
        },
        error => {
          this.isDisplaySpinnerProfessional = false;

          this.isNoSearchResults = !skipNoResultsValidationFlag && true;
          this.cdRef.detectChanges();
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.fadSearchResultsService,
            FadConstants.methods.getFadProfileSearchResults
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.getFadProfileSearchResults
      );
    }
  }

  private updateProfessionalsDataToView(
    data: GetSearchByProfessionalResponseModelInterface,
    skipNoResultsValidationFlag?: boolean,
    scroll?: boolean
  ) {
    this.fadService.clearServiceAlert(FadConstants.components.fadSearchResultsComponent);

    if ((data && data.professionals && data.professionals.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        console.log('disclaimer top list ', this.disclaimerToplist);
      }
      // this.isNoSearchResults = false;

      if (!scroll) {
        this.fadSearchResultsService.searchResultCache = data;
        this.specialtyEmailFlag = false;
        this.professionalEmailFlag = true;
        this.facilityEmailFlag = false;
        this.searchListComponentInput = new FadSearchListComponentInputModel();
        this.searchListComponentInput.searchResults = data;
      } else {
        this.searchListComponentInput = {
          searchResults: {
            ...this.searchListComponentInput.searchResults,
            professionals: this.searchListComponentInput.searchResults.professionals.concat(data.professionals)
          }
        };
      }

      this.fadProviderCompareService.setSearchResult(this.searchListComponentInput.searchResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
      }
      this.searchListComponentInput = new FadSearchListComponentInputModel();
      this.searchListComponentInput.searchResults = data;
      this.fadProviderCompareService.setSearchResult(this.searchListComponentInput.searchResults);

      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FadConstants.components.fadSearchResultsComponent);
      }
    }
  }

  /**
   * @description helps obtain search results based on input parameters
   *  The method gets from ngOnInit event or through search button click on landing page component in abstract mode
   * @param request : FadLandingPageSearchControlValuesInterface - search parameters
   */
  private getFadFacilitySearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchByFacilityResponseModelInterface,
    filtersData?: FacilityFiltersMetadataInterface,
    sortData?: SortMetadataInterface
  ): void {
    sessionStorage.setItem('radius', null);
    // PLEASE NOTE
    // THIS METHOD DOES NOT USE THE INPUT REQUEST YET
    // BUT THE SAME WILL BE USED ONCE ALL THE GET REQUESTS ARE CONVERTED INTO POST REQUESTS
    // PLEASE DONOT DELETE THE INPUT PARAMETER request: FadLandingPageSearchControlValuesInterface
    try {
      if (resolvedData) {
        // this.updateFacilityDataToView(Object.assign(
        //   Object.create(new GetSearchByFacilityResponseModel()), resolvedData,scroll));
        this.updateFacilityDataToView(resolvedData, false, scroll);
        return;
      }

      this.isDisplaySpinner = scroll;
      if (!scroll) {
        this.infiniteScrollIndexCache = 0;
      }

      const vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface = new GetSearchByFacilityRequestModel();
      vitalsSearchRequestbyFacility
        .setGeoLocation(request.getZipCode().geo)
        .setLimit(FadConstants.defaults.limit)
        .setPage(++this.infiniteScrollIndexCache)
        .setRadius(25)
        .setNetworkId(
          request.getPlanName && request.getPlanName().getNetworkId()
            ? request.getPlanName().getNetworkId()
            : FadConstants.defaults.networkId
        );

      if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
        vitalsSearchRequestbyFacility.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
      } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
        vitalsSearchRequestbyFacility.setProcedureId(request.getSearchText().getProcedureId());
      } else {
        vitalsSearchRequestbyFacility.setName(this.fadSearchResultsService.getFilteredSearchName(request));
      }

      // Start applying Sorting & filters //
      if (filtersData) {
        if (this.fadFacilityListService.isFilterChangedFlag == true) this.clearSelectedResults();
        //this.clearSelectedResults();
        //this.isFilter = true;
        if (filtersData.filterInNetwork && filtersData.filterInNetwork.value) {
          // vitalsSearchRequestbyFacility.setInNetwork(filtersData.filterInNetwork.value);
        }

        if (filtersData.filterLocation && filtersData.filterLocation.value) {
          vitalsSearchRequestbyFacility.setRadius(Number(filtersData.filterLocation.value));
          if (Number(filtersData.filterLocation.value)) sessionStorage.setItem('radius', filtersData.filterLocation.value);
          else sessionStorage.setItem('radius', null);
        }

        if (filtersData.filterRating && filtersData.filterRating.value) {
          vitalsSearchRequestbyFacility.setAggregateOverallRating(filtersData.filterRating.value);
        }

        if (filtersData.filterSpecialities && filtersData.filterSpecialities.value) {
          vitalsSearchRequestbyFacility.setSearchSpecialtyId(filtersData.filterSpecialities.value);
        }

        if (filtersData.filterBDC && filtersData.filterBDC.value) {
          vitalsSearchRequestbyFacility.setBdcId(filtersData.filterBDC.value);
        }

        if (filtersData.filterAward && filtersData.filterAward.value) {
          vitalsSearchRequestbyFacility.setAwardId(filtersData.filterAward.value);
        }

        if (filtersData.filterCQMS && filtersData.filterCQMS.value) {
          vitalsSearchRequestbyFacility.setCqmId(filtersData.filterCQMS.value);
        }
        if (filtersData.filterTiers && filtersData.filterTiers.value) {
          vitalsSearchRequestbyFacility.setTiers(filtersData.filterTiers.value);
        }
      }

      if (sortData) {
        if (sortData && sortData.value) {
          //this.clearSelectedResults();
          //this.isFilter = true;
          vitalsSearchRequestbyFacility.setSort(sortData.value);
        }
      }
      // End applying Sorting & filters //

      const skipNoResultsValidationFlag: boolean = true;
      this.fadSearchResultsService.getFadFacilitySearchResults(vitalsSearchRequestbyFacility, scroll).subscribe(
        data => {
          this.isDisplaySpinner = false;
          this.updateFacilityDataToView(<GetSearchByFacilityResponseModelInterface>data, scroll, skipNoResultsValidationFlag);

          this.cdRef.detectChanges();
        },
        error => {
          this.isDisplaySpinner = false;

          this.isNoSearchResults = !skipNoResultsValidationFlag && true;
          this.cdRef.detectChanges();
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.fadSearchResultsService,
            FadConstants.methods.getFadProfileSearchResults
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.getFadProfileSearchResults
      );
    }
  }

  private updateFacilityDataToView(
    data: GetSearchByFacilityResponseModelInterface,
    scroll?: boolean,
    skipNoResultsValidationFlag?: boolean
  ) {
    this.fadService.clearServiceAlert(FadConstants.components.fadSearchResultsComponent);

    if ((data && data.facilities && data.facilities.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      this.isNoSearchResults = !skipNoResultsValidationFlag && false;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
      }
      if (!scroll) {
        this.fadSearchResultsService.facilityResultCache = data;
        this.specialtyEmailFlag = false;
        this.professionalEmailFlag = false;
        this.facilityEmailFlag = true;
        this.facilityListComponentInput = new FadFacilityListComponentInputModel();
        this.facilityListComponentInput.facilityResults = data;
      } else {
        // data.facilities.map(facilityRecord => {
        //   this.facilityListComponentInput.facilityResults.facilities.push(facilityRecord);
        // });
        this.facilityListComponentInput = {
          facilityResults: {
            ...this.facilityListComponentInput.facilityResults,
            facilities: this.facilityListComponentInput.facilityResults.facilities.concat(data.facilities)
          }
        };
      }

      //this.fadProviderCompareService.setSearchResult(this.facilityListComponentInput.facilityResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;

      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
      }
      this.facilityListComponentInput = new FadFacilityListComponentInputModel();
      this.facilityListComponentInput.facilityResults = data;
      //this.fadProviderCompareService.setSearchResult(this.facilityListComponentInput.facilityResults);

      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FadConstants.components.fadSearchResultsComponent);
      }
    }
  }

  private getFadSpecialtySearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchBySpecialtyResponseModelInterface,
    filtersData?: FiltersMetadataInterface,
    sortData?: SortMetadataInterface
  ): void {
    sessionStorage.setItem('radius', null);
    //alert("test1");
    //$('ng4-loading-spinner .spinner').addClass('visible');
    // PLEASE NOTE
    // THIS METHOD DOES NOT USE THE INPUT REQUEST YET
    // BUT THE SAME WILL BE USED ONCE ALL THE GET REQUESTS ARE CONVERTED INTO POST REQUESTS
    // PLEASE DONOT DELETE THE INPUT PARAMETER request: FadLandingPageSearchControlValuesInterface
    try {
      if (resolvedData) {
        this.updateSpecialtyDataToView(resolvedData, false, scroll);
        return;
      }

      this.isDisplaySpinnerProfessional = scroll;
      const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      if (!scroll) {
        this.infiniteScrollIndexCache = 0;
      }

      vitalsSearchRequestbySpeciality
        .setGeoLocation(request.getZipCode().geo)
        .setLimit(FadConstants.defaults.limit)
        .setPage(++this.infiniteScrollIndexCache)
        .setRadius(25)
        .setNetworkId(
          request.getPlanName && request.getPlanName().getNetworkId()
            ? request.getPlanName().getNetworkId()
            : FadConstants.defaults.networkId
        );

      if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
        vitalsSearchRequestbySpeciality.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
      } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
        vitalsSearchRequestbySpeciality.setProcedureId(request.getSearchText().getProcedureId());
        vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
      } else {
        vitalsSearchRequestbySpeciality.setName(this.fadSearchResultsService.getFilteredSearchName(request));
      }

      // Start applying Sorting & filters //
      if (filtersData) {
        if (this.fadProviderFacilityListService.isFilterChangedFlag == true) {
          this.clearSelectedResults();
          //this.fadProviderFacilityListService.isFilterChangedFlag = false;
        }

        if (filtersData.filterPCP && filtersData.filterPCP.value) {
          vitalsSearchRequestbySpeciality.setisPcp(filtersData.filterPCP.value);
        }

        if (filtersData.filterTechSavvy && filtersData.filterTechSavvy.value) {
          vitalsSearchRequestbySpeciality.setTechSavvy(filtersData.filterTechSavvy.value);
        }
        if (filtersData.filterisChoicePcp && filtersData.filterisChoicePcp.value) {
          vitalsSearchRequestbySpeciality.setIsChoicePcp(filtersData.filterisChoicePcp.value);
        }
        if (filtersData.filterAcceptingNewPatients && filtersData.filterAcceptingNewPatients.value) {
          vitalsSearchRequestbySpeciality.setAcceptingNewPatients(filtersData.filterAcceptingNewPatients.value);
        }

        if (filtersData.filterInNetwork && filtersData.filterInNetwork.value) {
          vitalsSearchRequestbySpeciality.setInNetwork(filtersData.filterInNetwork.value);
        }

        if (filtersData.filterGender && filtersData.filterGender.value) {
          vitalsSearchRequestbySpeciality.setProfessionalGender(filtersData.filterGender.value);
        }

        if (filtersData.filterProviderType && filtersData.filterProviderType.value) {
          vitalsSearchRequestbySpeciality.setproviderType(filtersData.filterProviderType.value);
        }

        if (filtersData.filterLanguage && filtersData.filterLanguage.value) {
          vitalsSearchRequestbySpeciality.setProfessionalLanguages(filtersData.filterLanguage.value);
        }

        if (filtersData.filterRating && filtersData.filterRating.value) {
          vitalsSearchRequestbySpeciality.setAggregateOverallRating(filtersData.filterRating.value);
        }

        if (filtersData.filterAges && filtersData.filterAges.value) {
          vitalsSearchRequestbySpeciality.setAgestreatedTypeCode(filtersData.filterAges.value);
        }

        if (filtersData.filterDisorders && filtersData.filterDisorders.value) {
          vitalsSearchRequestbySpeciality.setDisorderTreatedTypeCode(filtersData.filterDisorders.value);
        }

        if (filtersData.filterTreatment && filtersData.filterTreatment.value) {
          vitalsSearchRequestbySpeciality.setTreatmentMethodsTypeCode(filtersData.filterTreatment.value);
        }

        if (filtersData.filterSpecialities && filtersData.filterSpecialities.value) {
          vitalsSearchRequestbySpeciality.setSearchSpecialtyId(filtersData.filterSpecialities.value);
        }

        if (filtersData.filterLocation && filtersData.filterLocation.value) {
          vitalsSearchRequestbySpeciality.setRadius(Number(filtersData.filterLocation.value));
          if (Number(filtersData.filterLocation.value)) sessionStorage.setItem('radius', filtersData.filterLocation.value);
          else sessionStorage.setItem('radius', null);
        }
        if (filtersData.filterBcd && filtersData.filterBcd.value) {
          vitalsSearchRequestbySpeciality.setBcdTypeCodes(filtersData.filterBcd.value);
        }
        if (filtersData.filterCqms && filtersData.filterCqms.value) {
          vitalsSearchRequestbySpeciality.setCqms(filtersData.filterCqms.value);
        }

        if (filtersData.filterTiers && filtersData.filterTiers.value) {
          vitalsSearchRequestbySpeciality.setTiers(filtersData.filterTiers.value);
        }
        if (filtersData.filterAwards && filtersData.filterAwards.value) {
          vitalsSearchRequestbySpeciality.setAwardsTypeCodes(filtersData.filterAwards.value);
        }
        if (
          filtersData.filterHospitalAffilation &&
          (filtersData.filterHospitalAffilation.value || filtersData.filterHospitalAffilation.category)
        ) {
          if (filtersData.filterHospitalAffilation.value && filtersData.filterHospitalAffilation.value !== '') {
            vitalsSearchRequestbySpeciality.setHospitalAffiliationId(filtersData.filterHospitalAffilation.value);
          }

          if (filtersData.filterHospitalAffilation.category && filtersData.filterHospitalAffilation.category !== '') {
            vitalsSearchRequestbySpeciality.setHospitalAffiliationCategory(filtersData.filterHospitalAffilation.category);
          }
        }
        if (filtersData.filterGroupAffilation && (filtersData.filterGroupAffilation.value || filtersData.filterGroupAffilation.category)) {
          if (filtersData.filterGroupAffilation.value && filtersData.filterGroupAffilation.value !== '') {
            vitalsSearchRequestbySpeciality.setGroupAffiliationId(filtersData.filterGroupAffilation.value);
          }

          if (filtersData.filterGroupAffilation.category && filtersData.filterGroupAffilation.category !== '') {
            vitalsSearchRequestbySpeciality.setGroupAffiliationCategory(filtersData.filterGroupAffilation.category);
          }
        }
      }

      if (sortData) {
        if (sortData && sortData.value) {
          vitalsSearchRequestbySpeciality.setSort(sortData.value);
        }
      }
      // End applying Sorting & filters //

      const skipNoResultsValidationFlag: boolean = true;
      console.log('vitals search request by specilaity', vitalsSearchRequestbySpeciality);

      this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality, scroll).subscribe(
        data => {
          this.isDisplaySpinnerProfessional = false;
          //alert("hello");
          //$('ng4-loading-spinner .spinner').removeClass('visible');
          //this.isNoSearchResults = data.totalCount == 0 ? true : false;
          this.updateSpecialtyDataToView(data, skipNoResultsValidationFlag, scroll);
          this.cdRef.detectChanges();
        },
        error => {
          this.isDisplaySpinnerProfessional = false;
          //$('ng4-loading-spinner .spinner').removeClass('visible');

          this.isNoSearchResults = !skipNoResultsValidationFlag && true;
          this.cdRef.detectChanges();
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.fadSearchResultsService,
            FadConstants.methods.getFadSpecialtySearchResults
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.getFadSpecialtySearchResults
      );
    }
  }

  private updateSpecialtyDataToView(
    data: GetSearchBySpecialtyResponseModelInterface,
    skipNoResultsValidationFlag?: boolean,
    scroll?: boolean
  ) {
    this.fadService.clearServiceAlert(FadConstants.components.fadSearchResultsComponent);

    if ((data && data.providers && data.providers.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
      }
      // this.isNoSearchResults = false;

      if (!scroll) {
        this.fadSearchResultsService.specialtyResultCache = data;
        this.specialtyEmailFlag = true;
        this.professionalEmailFlag = false;
        this.facilityEmailFlag = false;
        this.specialtyListComponentInput = new FadSpecialtyListComponentInputModel();
        this.specialtyListComponentInput.specialtyResults = data;
      } else {
        // data.providers.map(profRecord => {
        //   this.specialtyListComponentInput.specialtyResults.providers.push(profRecord);
        // });
        this.specialtyListComponentInput = {
          specialtyResults: {
            ...this.specialtyListComponentInput.specialtyResults,
            providers: this.specialtyListComponentInput.specialtyResults.providers.concat(data.providers)
          }
        };
      }

      this.fadProviderCompareService.setSearchResult(this.specialtyListComponentInput.specialtyResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
      }
      this.specialtyListComponentInput = new FadSpecialtyListComponentInputModel();
      this.specialtyListComponentInput.specialtyResults = data;
      this.fadProviderCompareService.setSearchResult(this.specialtyListComponentInput.specialtyResults);
      //$('ng4-loading-spinner .spinner').removeClass('visible');
      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FadConstants.components.fadSearchResultsComponent);
      }
    }
  }

  /**
   * @description fad-search-list component consumption requirement.
   *  The method gets triggered when filter component produces an output
   * @param fadSeachListComponentOutput : FadSearchListComponentOutputModelInterface
   */
  public onSearchListComponentInteraction(fadSeachListComponentOutput): void {
    try {
      if (
        fadSeachListComponentOutput &&
        fadSeachListComponentOutput.selectedProfessionals &&
        fadSeachListComponentOutput.selectedProfessionals.length >= 2
      ) {
        this.showCompareResultsButton = true;
        this.selectedResultCount = fadSeachListComponentOutput.selectedProfessionals.length;
      } else {
        this.showCompareResultsButton = false;
        this.selectedResultCount = 0;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.onSearchListComponentInteraction
      );
    }
  }

  /**
   * @description action associated with search button in landing page in abstract mode
   * @param fadLandingPageCompOutputInterface : FadLandingPageCompOutputInterface
   */
  public onLandingPageSearchComponentInteraction(fadLandingPageCompOutputInterface: FadLandingPageCompOutputInterface): void {
    try {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      this.resourceTypeCode = searchCriteria.getSearchText().getResourceTypeCode();

      if (searchCriteria.getSearchText().getResourceTypeCode() === FadResouceTypeCodeConfig.professional) {
        this.getFadProfileSearchResults(fadLandingPageCompOutputInterface.searchCriteria, false);
      } else if (searchCriteria.getSearchText().getResourceTypeCode() === FadResouceTypeCodeConfig.facility) {
        this.getFadFacilitySearchResults(fadLandingPageCompOutputInterface.searchCriteria, false);
      } else {
        this.getFadSpecialtySearchResults(fadLandingPageCompOutputInterface.searchCriteria, false);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.onLandingPageSearchComponentInteraction
      );
    }
  }

  /**
   * @description fad-search-filter component consumption requirement.
   *  The method gets triggered when filter component produces an output
   * @param fadSearchFilterComponentOutput : FadSearchFilterComponentOutputModelInterface
   */
  public onSearchFilterComponentInteraction(fadSearchFilterComponentOutput: FadSearchFilterComponentOutputModelInterface): void {
    // toggle filter section display as necessary
    const filterOverlayFlag = fadSearchFilterComponentOutput.filterOverlayFlag;
    if (filterOverlayFlag) {
      this.mobileHideByFilterOverlay = true;
    } else {
      this.mobileHideByFilterOverlay = false;
    }

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadSearchFilterComponentOutput.filterCriteriaData || fadSearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.filterCriteriaData = fadSearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadSearchFilterComponentOutput.sortCriteriaData;
      this.getFadProfileSearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  /**
   * @description fad-search-filter component consumption requirement.
   *  The method gets triggered when facility search filter component produces an output
   * @param fadFacilitySearchFilterComponentOutput : FadFacilitySearchFilterComponentOutputModelInterface
   */
  public onFacilitySearchFilterComponentInteraction(
    fadFacilitySearchFilterComponentOutput: FadFacilitySearchFilterComponentOutputModelInterface
  ): void {
    const filterOverlayFlag = fadFacilitySearchFilterComponentOutput.filterOverlayFlag;
    if (filterOverlayFlag) {
      this.mobileHideByFilterOverlay = true;
    } else {
      this.mobileHideByFilterOverlay = false;
    }

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadFacilitySearchFilterComponentOutput.filterCriteriaData || fadFacilitySearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.facilityFilterCriteriaData = fadFacilitySearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadFacilitySearchFilterComponentOutput.sortCriteriaData;
      this.getFadFacilitySearchResults(searchCriteria, false, null, this.facilityFilterCriteriaData, this.sortCriteriaData);
    }
  }

  public onSpecialtySearchFilterComponentInteraction(
    fadSpecialtySearchFilterComponentOutput: FadSpecialtyFilterComponentOutputModelInterface
  ): void {
    // toggle filter section display as necessary
    const filterOverlayFlag = fadSpecialtySearchFilterComponentOutput.filterOverlayFlag;
    if (filterOverlayFlag) {
      this.mobileHideByFilterOverlay = true;
    } else {
      this.mobileHideByFilterOverlay = false;
    }

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadSpecialtySearchFilterComponentOutput.filterCriteriaData || fadSpecialtySearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.filterCriteriaData = fadSpecialtySearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadSpecialtySearchFilterComponentOutput.sortCriteriaData;
      this.getFadSpecialtySearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  public reviewBenefits(): void {
    //throw new Error('reviewBenefits Method not implemented.');
    this.fadService.reviewMyBenfits();
  }

  public getProfileCardInput(professional: FadProfessionalInterface): FadProfileCardComponentInputModel {
    return new FadProfileCardComponentInputModel(professional);
  }
  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  public isAnonymousUser() {
    return this.authService.useridin && this.authService.useridin !== 'undefined' ? false : true;
  }

  public isAuthenticatedUser() {
    const scopeName = this.authService.getScopeName();
    return scopeName === 'AUTHENTICATED-AND-VERIFIED' ? true : false;
  }

  public gotoAuthenticate() {
    this.globalService
      .redirectionRoute()
      .then(response => {})
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  public onFacilityScrollDown() {
    this.infiniteScroll.ngOnDestroy();
    this.infiniteScroll.setup();

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      !this.isDisplaySpinner &&
      this.totalCount > this.facilityListComponentInput.facilityResults.facilities.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadFacilitySearchResults(searchCriteria, true, null, this.facilityFilterCriteriaData, this.sortCriteriaData);
    }
  }

  public onProviderScrollDown() {
    this.infiniteScroll.ngOnDestroy();
    this.infiniteScroll.setup();
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      !this.isDisplaySpinnerProfessional &&
      this.totalCount > this.specialtyListComponentInput.specialtyResults.providers.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadSpecialtySearchResults(searchCriteria, true, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  public onProfessionalScrollDown() {
    this.infiniteScroll.ngOnDestroy();
    this.infiniteScroll.setup();

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      !this.isDisplaySpinnerProfessional &&
      this.totalCount > this.searchListComponentInput.searchResults.professionals.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadProfileSearchResults(searchCriteria, true, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  clearSelectedResults() {
    this.showCompareResultsButton = false;
    this.selectedResultCount = 0;
    if (
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      this.facilityListComponentInput.facilityResults.facilities.length > 0
    ) {
      this.facilityListComponentInput.facilityResults.facilities = this.facilityListComponentInput.facilityResults.facilities.map(item => {
        item.isChecked = false;
        item.isDisabled = false;
        return item;
      });
    }

    if (
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      this.searchListComponentInput.searchResults.professionals.length > 0
    ) {
      this.searchListComponentInput.searchResults.professionals = this.searchListComponentInput.searchResults.professionals.map(item => {
        item.isChecked = false;
        item.isDisabled = false;
        return item;
      });
    }

    if (
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      this.specialtyListComponentInput.specialtyResults.providers.length > 0
    ) {
      this.specialtyListComponentInput.specialtyResults.providers = this.specialtyListComponentInput.specialtyResults.providers.map(
        item => {
          item.isChecked = false;
          item.isDisabled = false;
          return item;
        }
      );
    }
  }

  compareSelectedResults() {
    //$('ng4-loading-spinner .spinner').addClass('visible');
    // TODO Redirect to the compare results page
    if (
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      this.facilityListComponentInput.facilityResults.facilities.length > 0
    ) {
      const selectedItems = this.facilityListComponentInput.facilityResults.facilities.filter(item => item.isChecked);
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.facilityId : item.facilityId;
        if (item.locations && item.locations[0] && item.locations[0].facilityCost && item.locations[0].facilityCost.memberCost) {
          costInfo[item.facilityId] = item.locations[0].facilityCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadFacilityCompareService.setCostInfo(costInfo);
        this.fadFacilityCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/facility-compare`]);
      }
    }

    if (
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      this.searchListComponentInput.searchResults.professionals.length > 0
    ) {
      const selectedItems = Object.create(this.searchListComponentInput.searchResults.professionals.filter(item => item.isChecked));
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.providerId : item.providerId;
        if (item.locations && item.locations[0] && item.locations[0].memberCost && item.locations[0].memberCost.memberCost) {
          costInfo[item.providerId] = item.locations[0].memberCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadProviderCompareService.setCostInfo(costInfo);
        this.fadProviderCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/professional-compare`]);
      }
    }

    if (
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      this.specialtyListComponentInput.specialtyResults.providers.length > 0
    ) {
      const selectedItems = this.specialtyListComponentInput.specialtyResults.providers.filter(item => item.isChecked);
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.providerId : item.providerId;
        if (item.locations && item.locations[0] && item.locations[0].providerCost && item.locations[0].providerCost.memberCost) {
          costInfo[item.providerId] = item.locations[0].providerCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadFacilityCompareService.setCostInfo(costInfo);
        this.fadFacilityCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/provider-compare`]);
      }
    }
  }

  fetchMoreResult(resourceType) {
    this.resourceTypeCode = resourceType;
    if (resourceType === FadResouceTypeCodeConfig.professional) {
      this.getFadProfileSearchResults(this.fadSearchResultsService.getSearchCriteria(), false);
    } else if (resourceType === FadResouceTypeCodeConfig.facility) {
      this.getFadFacilitySearchResults(this.fadSearchResultsService.getSearchCriteria(), false);
    } else {
      this.getFadSpecialtySearchResults(this.fadSearchResultsService.getSearchCriteria(), false);
    }
  }

  gotoMedicalGroup() {
    this.router.navigate([this.fadConstants.urls.fadFacilityProfilePage]);
  }
  sendEmail() {
    this.isFormSubmitted = true;
    this.sendEmailAddress = this.emailEditForm.value.emailAddress;
    console.log(this.emailEditForm.value.emailAddress);
    console.log(this.optionalMessage.nativeElement.value);
    if (this.specialtyEmailFlag == true && !this.procedureFlag) {
      console.log(this.fadSearchResultsService.specialtyResultCache.pdfRequest);
      console.log(this.emailEditForm.value.emailAddress);
      this.fadSearchResultsService
        .sendEmailRequest(
          this.fadSearchResultsService.specialtyResultCache.pdfRequest,
          this.sendEmailAddress,
          this.optionalMessage.nativeElement.value
        )
        .subscribe(data => {
          console.log(data);
          $('#openMaiSendWindow').modal('close');
        });
    } else if (this.professionalEmailFlag == true) {
      console.log(this.fadSearchResultsService.searchResultCache.pdfRequest);
      console.log(this.isAffiliatedDoctors);
      console.log(this.sendEmailAddress);
      this.fadSearchResultsService
        .sendEmailRequest(
          this.fadSearchResultsService.searchResultCache.pdfRequest,
          this.sendEmailAddress,
          this.optionalMessage.nativeElement.value
        )
        .subscribe(data => {
          console.log(data);
          $('#openMaiSendWindow').modal('close');
        });
    } else if (this.facilityEmailFlag == true) {
      console.log(this.fadSearchResultsService.facilityResultCache.pdfRequest);
      this.fadSearchResultsService
        .sendEmailRequest(
          this.fadSearchResultsService.facilityResultCache.pdfRequest,
          this.sendEmailAddress,
          this.optionalMessage.nativeElement.value
        )
        .subscribe(data => {
          console.log(data);
          $('#openMaiSendWindow').modal('close');
        });
    }
  }
}
