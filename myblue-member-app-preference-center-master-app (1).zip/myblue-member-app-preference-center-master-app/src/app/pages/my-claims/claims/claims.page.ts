import { animate, state, style, transition, trigger } from '@angular/animations';
import { Location } from '@angular/common';
import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatCalendar, MatRadioGroup, MatSelectionList, MatSelectionListChange, MatSidenav } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Platform, PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import moment from 'moment';
import { SubscriptionLike as ISubscription } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { MemberInfo } from '../../../shared/models/memberInfo.model';
import { Option } from '../../../shared/models/option.model';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { DependantsService } from '../../../shared/services/dependant.service';
import { FilterService } from '../../../shared/services/filter.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ClaimsService } from '../../../shared/services/myclaims/claims.service';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { SsoService } from '../../sso/sso.service';
import { RadioList } from '../claims.model';
import { ClaimMemberRecord } from '../models/claims-summary-data.model';
import { DependentsResponseModel } from '../models/dependants.model';
import {
  ClaimStatusMetaInterface,
  ClaimStatusSearchListInterface,
  CustomDateRangeMetaInterface,
  DateMetaInterface,
  DateSearchListInterface,
  MemberTypeMetaInterface,
  MemberTypeSearchListInterface,
  ProviderMetaInterface,
  ProviderSearchListInterface,
  VisitTypeMetaInterface,
  VisitTypeSearchListInterface
} from '../models/interfaces/claims-generic-models.interface';
import {
  ClaimFiltersMetadataInterface,
  ClaimMemberRecordInterface,
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface,
  ClaimSummaryMetadataInterface
} from '../models/interfaces/claims-summary-data-model.interface';
import { DependentsModelInterface, DependentsResponseModelInterface } from '../models/interfaces/dependants-model.interface';
import { ClaimSummarySortOrderType } from '../models/types/claims.types';
import { FilterClaimsComponent } from './filter-claims/filter-claims.component';

/* tslint:disable */
@Component({
  templateUrl: './claims.page.html',
  styleUrls: ['./claims.page.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class ClaimsPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getDependentsList) dependentsList: DependentsModelInterface;
  @SelectSnapshot(AppSelectors.getUserState) userState: string;

  isUserStateActive: boolean;
  dependant: string;
  subscription: ISubscription;
  claimsListing;
  claims: ClaimMemberRecord[] = [];
  filteredClaims: ClaimMemberRecordInterface[] = ClaimMemberRecord[''];
  memberData: MemberInfo;
  sideNavHeight: string;
  sideNavStatus: string;
  noClaimsAvailable = false;
  dateList: DateSearchListInterface[] = [];
  showClose: boolean;
  showCalender: boolean;
  sortList: RadioList[] = [
    {
      value: 'Most Recent',
      checked: true
    },
    {
      value: 'Oldest First',
      checked: false
    }
  ];
  sortSelectedFilter: string;
  searchval: string;
  isautosearch: boolean; // TO CHECK -> Always false
  isDisplayMessage = false;
  isDisplayResults = false;
  issearchShowing: boolean; // TO CHECK -> are we using search feature
  // Filter options
  dateSelectedFilter: DateSearchListInterface;
  showDate: boolean;
  fromMinDate: Date;
  calendarMaxDate = new Date();
  currentSelectedDate: Date = null;
  isCustomDateRangeInValid = false;
  isSelectedDateInvalid = false;
  sideNavMode: string; // TO CHECK -> not using side nav using PopUP
  lastDate: Date; // TO CHECK -> Not being used
  fromDate: string;
  toDate: string = moment().format('L');
  index: number; // TO CHECK -> Not being used
  isSidenavOpened: boolean; // TO CHECK -> not using side nav using PopUP
  ismobile: boolean; // To CHECK -> do we need this flag
  errorMessage: string; // TO CHECK -> Not being used
  collapsedHeight: string;
  collapsedSortHeight: string;
  expandedHeight: string;
  expandedSortHeight: string;
  mobileViewPort = 992; // To CHECK -> do we need this flag
  isexpanded: boolean; // TO CHECK -> Not being used
  isSortExpanded: boolean;
  isFormDateSelected = true;
  dateFormat = 'MM/DD/YYYY';
  currentSortValue: string;

  // Filters List
  visitTypeList: VisitTypeSearchListInterface[] = [];
  selectedVisitTypeList: any[];
  selectedMemberList: any[];
  providerList: ProviderSearchListInterface[] = [];
  selectedProviderList: any[];

  allClaimsStatuesString = 'All statuses';
  claimsStatuses = this.getDefaultClaimsStatuses();
  claimsStatusList: ClaimStatusSearchListInterface[] = [];
  selectedClaimsList: any[];
  membersList: MemberTypeSearchListInterface[] = [];
  dependentList: DependentsResponseModelInterface = new DependentsResponseModel();
  showClearLink = false;
  showResultsCount = false;
  searchString: string;
  claimsInfo: any;
  public allClaimsFilterOptions;
  public isDisplayCustomDateRange = false;
  public recordsPerPage = 50;
  public checkFromDate: boolean;
  public checkToDate: boolean;
  public isDisplaySpinner = false;
  public isClearFilter = false;
  step = [];
  fpoTargetUrl = '';
  fpoTargetListingUrl = '';
  showFinancialLink = false;
  showHEQALGFinancialLink = false;
  ssoFinancialLink = '';
  initialClaimsCount: number;
  private hasHEQ = false;
  private hasALG = false;

  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;
  @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;
  @ViewChild('matcalender') picker: MatCalendar<Date>;
  @ViewChild('fromDateInput') fromInputDate: ElementRef;
  @ViewChild('toDateInput') toInputDate: ElementRef;
  @ViewChild('searchInput') inputSearch: ElementRef;
  @ViewChild('memberFilter') memberFilter;
  @ViewChild('providerFilter') providerFilter;
  @ViewChild('visitTypeFilter') visitTypeFilter;
  @ViewChild('claimStatusFilter') claimStatusFilter;

  contactus = this.constants.contactus + this.authToken.scopename;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }

  constructor(
    private claimService: ClaimsService,
    private router: Router,
    private location: Location,
    public dependantsService: DependantsService,
    public filterService: FilterService,
    public globalService: GlobalService,
    private ssoService: SsoService,
    public constants: ConstantsService,
    private activatedRoute: ActivatedRoute,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef,
    private popoverController: PopoverController,
    private document: DocumentViewer,
    private file: File,
    private transfer: FileTransfer,
    private platform: Platform,
    private fileOpener: FileOpener,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {}

  private handleFinanceLinksInSideBar() {
    this.hasALG = this.authToken ? this.authToken.isALG === 'true' : false;
    this.hasHEQ = this.authToken ? this.authToken.isHEQ === 'true' : false;

    this.showHEQALGFinancialLink = false;
    this.showFinancialLink = false;
    if (this.hasALG) {
      if (this.hasHEQ) {
        // both are true - show 2 links
        this.showHEQALGFinancialLink = true;
        this.showFinancialLink = false;
      } else {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      }
    } else {
      if (this.hasHEQ) {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      } else {
        // both are false - show no links
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = false;
      }
    }

    // this.showFinancialLink = (hasALG || hasHEQ) ? true : false;
    this.ssoFinancialLink = this.hasHEQ ? 'sso/heathequity' : 'sso/alegeus';
  }

  openSSO(module?) {
    if (module === 'algOrHeq') {
      this.ssoService.openSSO(this.hasHEQ ? 'heq' : 'alg');
    } else {
      this.ssoService.openSSO(module);
    }
  }

  ngOnInit() {}
  ionViewWillEnter() {
    this.claimsInfo = [...this.activatedRoute.snapshot.data.claimsInfo];
    if (this.claimsInfo && this.claimsInfo[0] && this.claimsInfo[0].memberRecord) {
      this.initialClaimsCount = this.claimsInfo[0].memberRecord.length;
    }
    this.sortSelectedFilter = 'Most Recent';
    this.currentSortValue = this.sortSelectedFilter;
    this.isautosearch = false;
    this.isDisplayMessage = false;
    this.issearchShowing = false;
    this.showDate = false;
    this.sideNavMode = 'side';
    this.index = -1;
    this.isSidenavOpened = false;
    this.errorMessage = null;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '48px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isexpanded = false;
    this.sideNavHeight = '600';
    this.showCalender = false;
    this.searchString = '';
    this.isSortExpanded = false;
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.sideNavStatus = this.ismobile ? 'out' : 'in';
    this.dependentList = this.dependentsList;
    this.subscription = this.globalService.memberData$.subscribe(data => {
      this.memberData = data;
    });

    this.isUserStateActive = this.userState === 'Active';

    if (sessionStorage.getItem('claimsDepId')) {
      sessionStorage.removeItem('claimsDepId');
    }
    this.initAllClaimsFilterOptions();
    this.manageClaimsListing();
    this.handleFinanceLinksInSideBar();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyClaims);
  }

  formattedData(value: string) {
    value = value.substring(0, 11);
    return this.datePipe.transform(value, 'MM/dd/yyyy');
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.alertService.clearError();
  }

  toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    this.sideNavMode = window.innerWidth <= 992 ? 'over' : 'side';
  }

  closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  closeFilter() {
    if (this.ismobile) {
      this.sideNavStatus = 'out';
      this.isSidenavOpened = false;
    }
  }

  isOpened(value) {
    switch (value) {
      case 1:
        this.step[1] = 1;
        break;
      case 2:
        this.step[2] = 2;
        break;
      case 3:
        this.step[3] = 3;
        break;
      case 4:
        this.step[4] = 4;
        break;
      case 5:
        this.step[5] = 5;
        break;
      case 6:
        this.step[6] = 6;
        break;
      default:
        break;
    }
  }

  showClaimDetails(claim) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyClaims_ViewClaim);
    sessionStorage.setItem('claimId', claim.claimId);
    this.router.navigate(['/myClaims/claimdetails']);
  }

  validateFromDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.fromDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.fromDate ||
        this.fromDate.length !== 10 ||
        moment(this.fromDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }

    return this.isSelectedDateInvalid;
  }

  validateToDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.toDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.toDate ||
        moment(this.toDate, this.dateFormat).diff(moment(this.calendarMaxDate)) > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
    return this.isSelectedDateInvalid;
  }

  validateCustomRange() {
    if (this.toDate && this.fromDate) {
      this.isCustomDateRangeInValid = moment(this.toDate).diff(moment(this.fromDate)) < 0;
    }
  }

  clearCustomDateRangeSelections() {
    this.toDate = moment().format('L');
    this.fromDate = null;
    this.fromMinDate = null;
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    this.isDisplayCustomDateRange = false;
  }

  toggleCalender(selectedDateType: string) {
    const isControlChanged =
      (selectedDateType === 'to' && this.isFormDateSelected) || (selectedDateType === 'from' && !this.isFormDateSelected);
    this.isFormDateSelected = selectedDateType === 'from';
    this.currentSelectedDate = this.isFormDateSelected ? new Date(this.fromDate) : new Date(this.toDate);
    this.setCalendarMinimumDate();
    if (isControlChanged) {
      this.toggleCalendarDisplay();
    } else {
      this.showCalender = true;
    }
  }

  toggleCalendarDisplay() {
    this.showCalender = false;
    setTimeout(() => {
      this.showCalender = true;
      setTimeout(() => {
        if (this.isFormDateSelected) {
          this.fromInputDate.nativeElement.focus();
        } else {
          this.toInputDate.nativeElement.focus();
        }
      }, 1);
    }, 1);
  }

  getSelectedValue(date) {
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    if (this.isFormDateSelected) {
      this.fromDate = this.filterService.getFormatDateString(date);
    } else {
      this.toDate = this.filterService.getFormatDateString(date);
    }
    this.setCalendarMinimumDate();
    this.showCalender = false;
  }

  setCalendarMinimumDate() {
    if (!this.isFormDateSelected && this.fromDate) {
      this.fromMinDate = new Date(this.fromDate);
    } else {
      const minFormDate = this.filterService.getMinimumFromDate();
      this.fromMinDate = minFormDate;
    }
  }

  customDateInputKeyDownEvent(e) {
    return this.filterService.customDateInputKeyDownEvent(e);
  }

  getDefaultClaimsStatuses() {
    return [
      Option.getOption('Pending', 'Pending'),
      Option.getOption('Adjusted', 'Adjusted'),
      Option.getOption('Completed', 'Completed'),
      Option.getOption('Denied', 'Denied'),
      Option.getOption(this.allClaimsStatuesString)
    ];
  }

  openUrl() {
    window.open(this.contactus, '_self');
  }

  openUrlinNewWindow(url) {
    window.open(this.constants.directPayUrl, '_blank');
  }
  trackByFn(index, claim) {
    return claim ? claim.id : index;
  }

  /* Initialize all filter option for members, providers
     visits,status etc.
     Initialize all filter flag for the filter options
  */
  private initAllClaimsFilterOptions(): void {
    this.allClaimsFilterOptions = {
      plan: { text: 'plan', allOptRequired: false, all: { planName: 'All Plans', planCount: 0 } },
      date: { text: 'date', allOptRequired: false, custom: { dateRange: 'Custom Date Range', dateCount: 0 } },
      member: { text: 'member', allOptRequired: false, all: { memberName: 'All Members', memberCount: 0 } },
      provider: { text: 'provider', allOptRequired: false, all: { providerName: 'All Providers', providerCount: 0 } },
      visitType: { text: 'visit', allOptRequired: false, all: { visitType: 'All Visits', visitTypeCount: 0 } },
      claimStatus: { text: 'status', allOptRequired: false, all: { status: 'All Statuses', statusCount: 0 } }
    };
  }

  public manageClaimsListing(filterPaginationApiData?: ClaimsSummaryResponseModelInterface): void {
    if (!filterPaginationApiData) {
      if (this.claimsInfo && this.claimsInfo.length) {
        if (!this.claimsInfo[0].hasOwnProperty('result') && this.claimsInfo[0].result !== 0) {
          this.claimsListing = this.claimsInfo[0];
          if (!this.isClearFilter) {
            this.recordsPerPage = this.claimsListing.summaryMetaData.recordEndIndex;
            this.manageClaimsFilter(this.claimsListing);
          }
        }
      }
    } else {
      this.claimsListing = filterPaginationApiData;
    }

    if (this.claimsListing && this.claimsListing.hasOwnProperty('memberRecord') && this.claimsListing.memberRecord.length) {
      this.filteredClaims = this.claimsListing.memberRecord;
      this.fpoTargetUrl = this.constants.drupalClaimsrUrl;
    } else {
      this.fpoTargetUrl = this.constants.drupalNoClaimsrUrl;
      this.noClaimsAvailable = true;
    }

    this.fpoTargetListingUrl = environment.drupalTestUrl + '/page/mydoctors-listingscreen';
  }

  public manageClaimsFilter(claimsListing) {
    this.allClaimsFilterOptions.member.all.memberCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.provider.all.providerCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.visitType.all.visitTypeCount = claimsListing.summaryMetaData.totalRecordCount;
    this.allClaimsFilterOptions.claimStatus.all.statusCount = claimsListing.summaryMetaData.totalRecordCount;
    if (claimsListing.filtersMetadata.dateMetaData.hasOwnProperty('customDateRange')) {
      this.allClaimsFilterOptions.date.custom.dateCount = claimsListing.dateMetaData.customDateRange.customDateCount;
    }

    this.membersList = [...claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.membersList, this.allClaimsFilterOptions.member.all.memberName)) {
      this.membersList.push(this.allClaimsFilterOptions.member.all);
    }

    this.providerList = [...claimsListing.filtersMetadata.providerMetaData.providerMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.providerList, this.allClaimsFilterOptions.provider.all.providerName)) {
      this.providerList.push(this.allClaimsFilterOptions.provider.all);
    }

    this.visitTypeList = [...claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.visitTypeList, this.allClaimsFilterOptions.visitType.all.visitType)) {
      this.visitTypeList.push(this.allClaimsFilterOptions.visitType.all);
    }

    this.claimsStatusList = [...claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.claimsStatusList, this.allClaimsFilterOptions.claimStatus.all.status)) {
      this.claimsStatusList.push(this.allClaimsFilterOptions.claimStatus.all);
    }

    this.dateList = [...claimsListing.filtersMetadata.dateMetaData.dateMetaList];
    if (!this.checkExistingClaimsFilterOptions(this.dateList, this.allClaimsFilterOptions.date.custom.dateRange)) {
      this.dateList.push(this.allClaimsFilterOptions.date.custom);
    }
  }

  private checkExistingClaimsFilterOptions(filterList, allOptions: string) {
    return filterList.find(oFilterList => {
      return Object.values(oFilterList).includes(allOptions);
    });
  }

  public checkClaimsFilterOptions(selectionListChange: MatSelectionListChange, allOptions: string, filterList) {
    const selectAllOption = selectionListChange.option;
    let allOptRequired = false;
    if (Object.values(selectAllOption.value).includes(allOptions)) {
      if (selectAllOption.selected) {
        allOptRequired = true;
        selectionListChange.source.selectAll();
      } else {
        selectionListChange.source.deselectAll();
      }
      filterList = filterList.map(filterObj => {
        if (selectAllOption.selected) {
          filterObj.selected = true;
          filterObj.disabled = !Object.values(filterObj).includes(allOptions);
          allOptRequired = true;
        } else {
          filterObj.selected = false;
          filterObj.disabled = false;
        }
        return filterObj;
      });
    } else if (selectAllOption.selected) {
      if (selectAllOption.selectionList.selectedOptions.selected.length === filterList.length - 1) {
        allOptRequired = true;
        switch (allOptions) {
          case 'All Members': {
            const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Providers': {
            const selectedAllOption = filterList.find(listItem => listItem.providerName === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Visits': {
            const selectedAllOption = filterList.find(listItem => listItem.visitType === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
          case 'All Statuses': {
            const selectedAllOption = filterList.find(listItem => listItem.status === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
        }
        return filterList;
      }
    } else {
      switch (allOptions) {
        case 'All Members': {
          const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Providers': {
          const selectedAllOption = filterList.find(listItem => listItem.providerName === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Visits': {
          const selectedAllOption = filterList.find(listItem => listItem.visitType === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
        case 'All Statuses': {
          const selectedAllOption = filterList.find(listItem => listItem.status === allOptions);
          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
          }
          break;
        }
      }
      return filterList;
    }
    // this.cdr.detectChanges();
    return allOptRequired;
  }

  checkSelectAllOptionIfAllSelected(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && !selectedAllOption.selected) {
      selectedAllOption.selected = true;
    }
    return list;
  }

  unCheckSelectAllOption(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && selectedAllOption.selected) {
      selectedAllOption.selected = false;
    }
    return list;
  }

  selectAllOptions(list, selectedValue: boolean, selectAllOptionIdentifier: string) {
    return list.map(listItem => {
      listItem.selected = selectedValue;
      if (selectedValue) {
        listItem.selected = true;
        listItem.disabled = listItem.value !== selectAllOptionIdentifier;
      } else {
        listItem.selected = false;
        listItem.disabled = false;
      }

      return listItem;
    });
  }

  private getSelectedClaimsFilterOptions(list: MatSelectionList, allOptions: string) {
    if (list && list.selectedOptions.selected.length > 0) {
      const filteredItems = list.selectedOptions.selected.filter(selectedItem => !Object.values(selectedItem.value).includes(allOptions));
      return filteredItems.map(filteredOptions => {
        const selectedFilterOptions = {};
        for (const prop in filteredOptions.value) {
          if (!(prop === 'selected' || prop === 'disabled')) {
            selectedFilterOptions[prop] = filteredOptions.value[prop];
          }
        }
        return selectedFilterOptions;
      });
    }
    return null;
  }

  public applyFilter(
    providerList: MatSelectionList,
    claimStatusList: MatSelectionList,
    visitTypeList: MatSelectionList,
    memberList: MatSelectionList
  ) {
    this.filterService.scrollToTop();
    this.closeFilter();
    this.closeSideNavigation();
    this.isDisplaySpinner = false;
    this.showCalender = false;
    this.isDisplayMessage = false;
    this.alertService.clearError();

    this.selectedProviderList = this.getSelectedClaimsFilterOptions(providerList, this.allClaimsFilterOptions.provider.all.providerName);
    this.selectedClaimsList = this.getSelectedClaimsFilterOptions(claimStatusList, this.allClaimsFilterOptions.claimStatus.all.status);
    this.selectedVisitTypeList = this.getSelectedClaimsFilterOptions(visitTypeList, this.allClaimsFilterOptions.visitType.all.visitType);
    this.selectedMemberList = this.getSelectedClaimsFilterOptions(memberList, this.allClaimsFilterOptions.member.all.memberName);

    const reqParams = this.claimsFilterPaginationReqParams(
      this.selectedProviderList,
      this.selectedClaimsList,
      this.selectedVisitTypeList,
      this.selectedMemberList,
      this.sortSelectedFilter
    );

    // always send sort order for filter submit
    reqParams.summaryMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;

    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      this.claimService.getClaims(reqParams).subscribe(apiData => {
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            this.manageClaimsListing(apiData);
            this.isDisplayResults = true;
            this.showClearLink = true;
          } else {
            if (apiData.result === -90202) {
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.showClearLink = true;
              this.filteredClaims = [];
            } else {
              this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
            }
          }
        }
      });
    }
  }

  public clearFilter(
    providerList?: MatSelectionList,
    claimStatusList?: MatSelectionList,
    visitTypeList?: MatSelectionList,
    memberList?: MatSelectionList
  ) {
    this.step = [];

    this.closeFilter();
    sessionStorage.removeItem('claims');

    this.showClose = false;
    this.showCalender = false;
    this.showResultsCount = false;
    this.isSortExpanded = false;
    this.isClearFilter = true;
    this.isDisplayMessage = false;
    this.isDisplayResults = false;
    this.showClearLink = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      this.dateSelectedFilter = {} as DateSearchListInterface;
      this.clearCustomDateRangeSelections();
    }

    this.clearFilterOptionsFromView(memberList);
    this.clearFilterOptionsFromView(providerList);
    this.clearFilterOptionsFromView(visitTypeList);
    this.clearFilterOptionsFromView(claimStatusList);

    this.initClearFilterOptions(this.membersList);
    this.initClearFilterOptions(this.providerList);
    this.initClearFilterOptions(this.visitTypeList);
    this.initClearFilterOptions(this.claimsStatusList);

    this.selectedProviderList = [];
    this.selectedClaimsList = [];
    this.selectedVisitTypeList = [];
    this.selectedMemberList = [];

    this.manageClaimsListing();
    this.filterService.scrollToTop();
    this.closeSideNavigation();
    this.alertService.clearError();
  }

  private clearFilterOptionsFromView(filterList) {
    if (filterList && filterList.selectedOptions.selected.length > 0) {
      filterList = filterList.selectedOptions.selected.map(oFilterList => {
        oFilterList.selected = false;
        oFilterList.disabled = false;
        return oFilterList;
      });
    }
  }

  private initClearFilterOptions(filterList, filterType?: string) {
    if (filterList && filterList.length) {
      return filterList.map(oFilterList => {
        if (!filterType) {
          oFilterList.selected = false;
          oFilterList.disabled = false;
        } else {
          oFilterList.checked = false;
        }
        return oFilterList;
      });
    }
  }

  public paginationOnScrollDown(event) {
    this.alertService.clearError();

    if (
      this.claimsListing.summaryMetaData.totalRecordCount > this.recordsPerPage &&
      this.filteredClaims &&
      this.filteredClaims.length >= this.recordsPerPage &&
      this.filteredClaims.length < this.claimsListing.summaryMetaData.totalRecordCount &&
      !this.isSidenavOpened
    ) {
      this.isDisplaySpinner = true;
      let reqParams;
      reqParams = this.claimsFilterPaginationReqParams(
        this.selectedProviderList,
        this.selectedClaimsList,
        this.selectedVisitTypeList,
        this.selectedMemberList,
        this.sortSelectedFilter
      );
      reqParams.scrollIndicator = 'DOWN';

      this.claimService.getClaims(reqParams).subscribe(apiData => {
        this.isDisplaySpinner = false;
        this.claimsListing.summaryMetaData.hasMoreRecords = apiData.summaryMetaData.hasMoreRecords;
        this.claimsListing.summaryMetaData.recordStartIndex = apiData.summaryMetaData.recordStartIndex;
        this.claimsListing.summaryMetaData.recordEndIndex = apiData.summaryMetaData.recordEndIndex;
        this.claimsListing.summaryMetaData.totalRecordCount = apiData.summaryMetaData.totalRecordCount;
        if (apiData.summaryMetaData.sortOrder) {
          this.claimsListing.summaryMetaData.sortOrder = apiData.summaryMetaData.sortOrder;
        }
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            if (apiData.hasOwnProperty('memberRecord') && apiData.memberRecord.length) {
              apiData.memberRecord.map(oMemberRecord => {
                this.filteredClaims.push(oMemberRecord);
              });
            }
          } else {
            this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
          }
        }
      });
    }
    event.target.complete();
  }

  private claimsFilterPaginationReqParams(
    selectedProviderList,
    selectedClaimsList,
    selectedVisitTypeList,
    selectedMemberList,
    sortSelectedFilter
  ) {
    const providerMetaReqParams = {} as ProviderMetaInterface,
      visitTypeMetaReqParams = {} as VisitTypeMetaInterface,
      claimStatusMetaReqParams = {} as ClaimStatusMetaInterface,
      memberTypeMetaReqParams = {} as MemberTypeMetaInterface,
      claimFiltersMetaReqParams = {} as ClaimFiltersMetadataInterface,
      dateMetaReqParams = {} as DateMetaInterface,
      dateSearchListReqParams = {} as DateSearchListInterface,
      customDateRangeMetaReqParams = {} as CustomDateRangeMetaInterface,
      claimSummaryMetaReqParams = {} as ClaimSummaryMetadataInterface,
      claimsSummaryReqParams = {} as ClaimsSummaryRequestModelInterface;

    this.isSelectedDateInvalid = false;
    this.isCustomDateRangeInValid = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      if (this.dateSelectedFilter.dateRange.toLowerCase().indexOf('all') !== -1) {
        dateMetaReqParams.allDatesRequired = true;
      } else if (this.dateSelectedFilter.dateRange.indexOf(this.allClaimsFilterOptions.date.custom.dateRange) !== -1) {
        dateMetaReqParams.allDatesRequired = false;
        this.checkFromDate = this.validateFromDate();
        this.checkToDate = this.validateToDate();
        if (!this.checkFromDate && !this.checkToDate) {
          this.validateCustomRange();
          customDateRangeMetaReqParams.startDate = this.datePipe.transform(this.fromDate, 'yyyy-MM-dd');
          customDateRangeMetaReqParams.endDate = this.datePipe.transform(this.toDate, 'yyyy-MM-dd');
          dateMetaReqParams.customDateRange = customDateRangeMetaReqParams;
        } else {
          this.isSelectedDateInvalid = true;
        }
      } else {
        dateSearchListReqParams.dateRange = this.dateSelectedFilter.dateRange;
        dateMetaReqParams.dateMetaList = new Array(dateSearchListReqParams);
        dateMetaReqParams.allDatesRequired = false;
      }
      claimFiltersMetaReqParams.dateMetaData = dateMetaReqParams;
    }

    if (selectedProviderList && selectedProviderList.length) {
      providerMetaReqParams.allProvidersRequired = this.allClaimsFilterOptions.provider.allOptRequired;
      if (!providerMetaReqParams.allProvidersRequired) {
        providerMetaReqParams.providerMetaList = selectedProviderList;
      }
      claimFiltersMetaReqParams.providerMetaData = providerMetaReqParams;
    }

    if (selectedClaimsList && selectedClaimsList.length) {
      claimStatusMetaReqParams.allStatusesRequired = this.allClaimsFilterOptions.claimStatus.allOptRequired;
      if (!claimStatusMetaReqParams.allStatusesRequired) {
        claimStatusMetaReqParams.claimStatusMetaList = selectedClaimsList;
      }
      claimFiltersMetaReqParams.claimStatusMetaData = claimStatusMetaReqParams;
    }

    if (selectedVisitTypeList && selectedVisitTypeList.length) {
      visitTypeMetaReqParams.allVisitTypesRequired = this.allClaimsFilterOptions.visitType.allOptRequired;
      if (!visitTypeMetaReqParams.allVisitTypesRequired) {
        visitTypeMetaReqParams.visitTypeMetaList = selectedVisitTypeList;
      }
      claimFiltersMetaReqParams.visitTypeMetaData = visitTypeMetaReqParams;
    }

    if (selectedMemberList && selectedMemberList.length) {
      memberTypeMetaReqParams.allmembersRequired = this.allClaimsFilterOptions.member.allOptRequired;
      if (!memberTypeMetaReqParams.allmembersRequired) {
        memberTypeMetaReqParams.memberTypeMetaList = selectedMemberList;
      }
      claimFiltersMetaReqParams.memberTypeMetaData = memberTypeMetaReqParams;
    }

    claimsSummaryReqParams.useridin = this.useridin;
    // for pagination
    claimSummaryMetaReqParams.hasMoreRecords = this.claimsListing.summaryMetaData.hasMoreRecords;
    claimSummaryMetaReqParams.recordStartIndex = this.claimsListing.summaryMetaData.recordStartIndex;
    claimSummaryMetaReqParams.recordEndIndex = this.claimsListing.summaryMetaData.recordEndIndex;
    claimSummaryMetaReqParams.totalRecordCount = this.claimsListing.summaryMetaData.totalRecordCount;

    // check if here is a change in sort order?
    if (this.currentSortValue !== this.sortSelectedFilter) {
      this.currentSortValue = this.sortSelectedFilter;
      claimSummaryMetaReqParams.sortOrder = sortSelectedFilter;
    } else {
      delete claimSummaryMetaReqParams.sortOrder;
    }

    claimsSummaryReqParams.summaryMetaData = claimSummaryMetaReqParams;
    if (Object.keys(claimFiltersMetaReqParams).length) {
      claimsSummaryReqParams.filtersMetadata = claimFiltersMetaReqParams;
    }
    console.log(claimsSummaryReqParams);

    return claimsSummaryReqParams;
  }

  public openPDF() {
    /*open a pdf*/
    const absolutePath = this.file.applicationDirectory + 'www/assets/files/';
    if (this.platform.is('android')) {
      const fakeName = Date.now();
      this.file.copyFile(absolutePath, 'SubscriberSubmitClaimForm7307.pdf', this.file.dataDirectory, `${fakeName}.pdf`).then(result => {
        this.fileOpener
          .open(result.nativeURL, 'application/pdf')
          .then(() => console.log('File is opened'))
          .catch(e => console.log('Error opening file', e));
      });
    } else {
      this.document.viewDocument(`${absolutePath}SubscriberSubmitClaimForm7307.pdf`, 'application/pdf', {});
    }
  }

  public decimalFragment(sourceNumber): string {
    try {
      if (!sourceNumber) {
        return '00';
      }
      if (Number(sourceNumber)) {
        return Number(sourceNumber)
          .toFixed(2)
          .split('.')[1];
      } else {
        return '00';
      }
    } catch (error) {
      return '00';
    }
  }

  public appApplyFilter(
    claimStatusMetaInterface: ClaimStatusMetaInterface,
    dateMetaData: DateMetaInterface,
    memberTypeMetaData: MemberTypeMetaInterface,
    providerMetaData: ProviderMetaInterface,
    visitTypeMetaData: VisitTypeMetaInterface
  ) {
    this.isDisplayMessage = false;
    const claimsSummaryReqParams = {} as ClaimsSummaryRequestModelInterface;
    claimsSummaryReqParams.useridin = this.useridin;

    claimsSummaryReqParams.summaryMetaData = {} as ClaimSummaryMetadataInterface;
    claimsSummaryReqParams.summaryMetaData.hasMoreRecords = true;
    claimsSummaryReqParams.summaryMetaData.recordStartIndex = 1;
    claimsSummaryReqParams.summaryMetaData.recordEndIndex = 50;
    claimsSummaryReqParams.summaryMetaData.totalRecordCount = this.claimsListing.summaryMetaData.totalRecordCount;
    claimsSummaryReqParams.summaryMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;
    claimsSummaryReqParams.filtersMetadata = {} as ClaimFiltersMetadataInterface;
    claimsSummaryReqParams.filtersMetadata.claimStatusMetaData = claimStatusMetaInterface;
    claimsSummaryReqParams.filtersMetadata.dateMetaData = dateMetaData;
    claimsSummaryReqParams.filtersMetadata.memberTypeMetaData = memberTypeMetaData;
    claimsSummaryReqParams.filtersMetadata.providerMetaData = providerMetaData;
    claimsSummaryReqParams.filtersMetadata.visitTypeMetaData = visitTypeMetaData;

    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      this.claimService.getClaims(claimsSummaryReqParams).subscribe(apiData => {
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            this.manageClaimsListing(apiData);
            this.isDisplayResults = true;
            this.showClearLink = true;
          } else {
            if (apiData.result === -90202) {
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.showClearLink = true;
              this.filteredClaims = [];
            } else {
              this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
            }
          }
        }
      });
    }
  }

  async handleClaimsFilter(ev) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyClaims_Search);
    let popover: HTMLIonPopoverElement;
    popover = await this.popoverController.create({
      component: FilterClaimsComponent,
      event: ev,
      cssClass: 'my-claims-filter',
      translucent: true,
      componentProps: {
        showClearLink: this.showClearLink,
        sortSelectedFilter: this.sortSelectedFilter,
        dateList: this.dateList,
        memberList: this.membersList,
        memberFilterList: this.claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList,
        providerList: this.providerList,
        providerFilterList: this.claimsListing.filtersMetadata.providerMetaData.providerMetaList,
        visitTypeList: this.visitTypeList,
        visitTypeFilterList: this.claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList,
        claimStatusList: this.claimsStatusList,
        claimStatusFilterList: this.claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList,
        closeFilterAction: returnData => {
          if (popover) {
            popover.dismiss(returnData);
          }
        },
        getPopOver: () => {}
      }
    });

    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        this.sortSelectedFilter = dataReturned.data.sortSelectedFilter;

        this.appApplyFilter(
          dataReturned.data.claimStatusMetaInterface,
          dataReturned.data.dateMetaData,
          dataReturned.data.memberTypeMetaData,
          dataReturned.data.providerMetaData,
          dataReturned.data.visitTypeMetaData
        );
      } else if (dataReturned && dataReturned.role !== 'backdrop' && !dataReturned.data) {
        this.clearFilter();
      }
    });

    return popover.present();
  }

  goBack() {
    this.location.back();
  }
}
