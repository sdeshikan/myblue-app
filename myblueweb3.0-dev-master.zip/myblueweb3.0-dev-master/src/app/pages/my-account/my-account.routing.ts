import { Routes, RouterModule } from '@angular/router';
import { UnauthenticatedLayoutComponent } from '../../shared/layouts/UnauthenticatedLayoutComponent/UnauthenticatedLayout.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { CreatePasswordComponent } from './create-password/create-password.component';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { ConfirmidentityComponent } from './confirm-identity/confirmidentity.component';
import { ForgetUserNameFlowGuard } from './utils/forget-username-flow.guard';
import { ForgetPasswordFlowGuard } from './utils/forget-password-flow.guard';
import { VerifyAccessGuard } from './utils/verify-access.guard';
import { FpConfirmidentityComponent } from './fp-confirm-identity/fpconfirmidentity.component';
import { NoMenuResolver } from '../../shared/utils/nomenu.resolver';
import { VerifyOTPaccesscodeComponent } from './verifyOTPaccesscode/verifyaccesscode.component';
import { ImpersonationLoginGuard } from '../../shared/utils/impersonation-login.guard';

const ACCOUNT_ROUTER: Routes = [
  {
    path: '',
    canActivate: [ImpersonationLoginGuard],
    component: UnauthenticatedLayoutComponent,
    resolve: {
      menu: NoMenuResolver
    },
    children: [
      {
        path: 'forgotPassword/:user',
        component: ForgotPasswordComponent
      },
      {
        path: 'forgotPassword',
        component: ForgotPasswordComponent
      },
      {
        path: 'forgotusername',
        component: ForgotUsernameComponent
      },
      {
        path: 'createPassword',
        // canActivate: [CreatePasswordGuard],
        component: CreatePasswordComponent
      },
      {
        path: 'verifyAccessCode/:caller',
        canActivate: [VerifyAccessGuard],
        component: VerifyOTPaccesscodeComponent
      },
      {
        path: 'confirmidentity',
        canActivate: [ForgetUserNameFlowGuard],
        component: ConfirmidentityComponent
      },
      {
        path: 'fpconfirmidentity',
        canActivate: [ForgetPasswordFlowGuard],
        component: FpConfirmidentityComponent
      }
    ]
  }
];

export const MyAccountRouter = RouterModule.forChild(ACCOUNT_ROUTER);
