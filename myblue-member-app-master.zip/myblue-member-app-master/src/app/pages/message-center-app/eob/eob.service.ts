import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { EOBListRequestModelInterface } from './models/eob-data-model.interface';

@Injectable()
export class EOBService {
  constructor(private http: AuthHttp, private constants: ConstantsService, private authService: AuthService) {}

  getEobList(reqParams?: EOBListRequestModelInterface): Observable<any> {
    const request = reqParams || { useridin: this.authService.useridin };
    console.log(request);
    return this.http.encryptPost(this.constants.getEobListUrl, request);
  }
  getEOBDocumentLink(reqParams): Observable<any> {
    return this.http.encryptPost(this.constants.benefitsLinkUrl, reqParams);
  }
}
