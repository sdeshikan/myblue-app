import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { Keychain } from '@ionic-native/keychain/ngx';
import { SharedModule } from '../../shared/shared.module';
import { LoginAppPage } from './login-app.page';
import { AlertsModule } from '../../shared/alerts/alerts.module';


const routes: Routes = [
  {
    path: '',
    component: LoginAppPage,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, IonicModule, SharedModule, RouterModule.forChild(routes), AlertsModule],
  declarations: [LoginAppPage],
  providers: [FingerprintAIO, Keychain]
})
export class LoginAppPageModule {}
