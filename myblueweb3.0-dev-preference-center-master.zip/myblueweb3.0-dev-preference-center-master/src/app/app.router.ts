import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { MyDedCoResolver } from './pages/myded-co/myded-co.resolver';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { NotificationPreferencesResolver } from './pages/notification-preferences/notification-preferences.resolver';
import { SsoResolver } from './pages/sso/sso.resolver';
import { VdkComponent } from './pages/vdk/vdk.component';
import { AuthCentralLayoutComponent } from './shared/layouts/AuthCentralLayoutComponent/AuthCenralLayout.component';
import { AuthenticatedLayoutComponent } from './shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { OrderIdCardLayoutComponent } from './shared/layouts/OrderIdCardLayoutComponent/OrderIdCardLayout.component';
import { FadResolverService } from './shared/routeresolvers/FadResolverService';
import { HomepageResolver } from './shared/routeresolvers/homepage-resolver';
import { MyCardsResolverService } from './shared/routeresolvers/my-cards-resolver.service';
import { MyPlansResolverService } from './shared/routeresolvers/my-plans-resolver.service';
import { MyclaimsResolverService } from './shared/routeresolvers/myclaims-resolver.service';
import { MyEobsResolverService } from './shared/routeresolvers/myeobs-resolver.service';
import { MymedsResolverService } from './shared/routeresolvers/mymeds-resolver.service';
import { MyprofileResolverService } from './shared/routeresolvers/myprofile-resolver.service';
import { OrderreplacementResolverService } from './shared/routeresolvers/orderreplacement-resolver';
import { AuthGuard } from './shared/utils/auth.guard';
import { NoMenuResolver } from './shared/utils/nomenu.resolver';
import { PillGuard } from './shared/utils/pill.guard';
import { ScopeGuard } from './shared/utils/scope.guard';
import { YesGuard } from './shared/utils/yes.guard';
export const router: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'fad',
    // canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    resolve: {
      fadInfo: FadResolverService
    },
    // data: {
    //   breadcrumb: 'FAD'
    // },
    loadChildren: 'app/pages/fad/fad.module#FadModule'
  },
  {
    path: 'myclaims',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    resolve: {
      claimsInfo: MyclaimsResolverService
    },
    data: {
      breadcrumb: 'My Claims'
    },
    loadChildren: 'app/pages/myclaims/claims.module#ClaimsModule'
  },
  {
    path: 'myeobs',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    resolve: {
      eobInfo: MyEobsResolverService
    },
    data: {
      breadcrumb: 'My Eobs'
    },
    loadChildren: 'app/pages/myeobs/eobs.module#EobsModule'
  },
  {
    path: 'member-migration',
    canActivate: [ScopeGuard],
    resolve: {
      menu: NoMenuResolver
    },
    component: AuthCentralLayoutComponent,
    loadChildren:
      'app/pages/member-migration/member-migration.module#MemberMigrationModule'
  },
  {
    path: 'myplans',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    resolve: {
      plan: MyPlansResolverService
    },
    data: {
      breadcrumb: 'My Plans'
    },
    loadChildren: 'app/pages/myplans/myplans.module#MyplansModule'
  },
  {
    path: 'mycards',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    resolve: {
      cardsInfo: MyCardsResolverService
    },
    data: {
      breadcrumb: 'My Cards'
    },
    loadChildren: 'app/pages/mycards/mycards.module#MycardsModule'
  },
  {
    path: 'mypreferences',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren:
      'app/pages/mypreferences/mypreferences.module#MyPreferencesModule'
  },
  {
    path: 'mydedco',
    canActivate: [AuthGuard, ScopeGuard],
    resolve: {
      dedcoList: MyDedCoResolver
    },
    data: {
      breadcrumb: 'Deductible & Co-insurance'
    },
    loadChildren: 'app/pages/myded-co/myded-co.module#MyDedCoModule'
  },
  {
    path: 'request-estimate',
    canActivate: [AuthGuard, ScopeGuard],
    data: {
      breadcrumb: 'Request Written Estimate'
    },
    loadChildren:
      'app/pages/request-estimate/request-estimate.module#RequestEstimateModuleModule'
  },
  {
    path: 'orderreplacement',
    canActivate: [AuthGuard, ScopeGuard],
    component: OrderIdCardLayoutComponent,
    resolve: {
      cardsData: OrderreplacementResolverService
    },
    data: {
      breadcrumb: 'Order ID Card'
    },
    loadChildren:
      'app/pages/orderreplacement/orderreplacement.module#OrderreplacementModule'
  },
  {
    path: 'mymedications',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    data: {
      breadcrumb: 'My Medications'
    },
    loadChildren: 'app/pages/medications/medications.module#MyMedicationsModule'
  },
  {
    path: 'fad',
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'yes',
    canActivate: [AuthGuard, ScopeGuard, YesGuard],
    component: AuthenticatedLayoutComponent,
    data: {
      breadcrumb: 'Year-to-Date Summary'
    },
    loadChildren:
      'app/pages/year-end-summary/year-end-summary.module#YearEndSummaryModule'
  },
  {
    path: 'sso/vitals',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'sso/cerner',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'sso/alegeus',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'sso/heathequity',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'sso/connecture',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'sso/expressscript',
    canActivate: [AuthGuard, ScopeGuard],
    loadChildren: 'app/pages/sso/sso.module#SsoModule',
    resolve: {
      sso: SsoResolver
    }
  },
  {
    path: 'mydoctors',
    canActivate: [AuthGuard, ScopeGuard],
    data: {
      breadcrumb: 'My Doctors'
    },
    loadChildren:
      'app/pages/mydoctors-pcp/mydoctors-pcp.module#MyDoctorsPcpModule'
  },
  {
    path: 'register',
    loadChildren:
      'app/pages/registration/registration.module#RegistrationModule'
  },
  {
    path: 'login',
    component: LoginComponent,
    loadChildren: 'app/pages/login/login.module#LoginModule'
  },
  // {
  //   path: 'impersonation',
  //   loadChildren: 'app/pages/impersonation/impersonation.module#ImpersonationModule',
  // },
  {
    path: 'account',
    //canActivate: [AuthGuard],
    loadChildren: 'app/pages/my-account/my-account.module#MyAccountModule'
  },
  {
    path: 'myprofile',
    canActivate: [AuthGuard, ScopeGuard], // confirmed with leads (ANV users wont goto myprofile )
    loadChildren: 'app/pages/my-profile/profileHome.module#ProfileHomeModule',
    data: {
      breadcrumb: 'Profile'
    },
    resolve: {
      profile: MyprofileResolverService
    }
  },
  {
    path: 'message-center',
    canActivate: [AuthGuard, ScopeGuard],
    data: {
      breadcrumb: 'My Inbox'
    },
    loadChildren:
      'app/pages/message-center/message-center.module#MessageCenterModule'
  },
  {
    path: 'home',
    component: AuthenticatedLayoutComponent,
    loadChildren: 'app/pages/landing/landing.module#LandingModule',
    resolve: {
      home: HomepageResolver
    }
  },
  {
    path: 'myaccount',
    component: AuthenticatedLayoutComponent,
    data: {
      breadcrumb: 'My Account'
    },
    loadChildren: 'app/pages/myaccount/myaccount.module#MyaccountModule'
  },
  {
    path: 'vdk',
    component: VdkComponent
  },
  {
    path: 'notification-preferences',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthCentralLayoutComponent,
    data: {
      breadcrumb: 'Preferences'
    },
    loadChildren:
      'app/pages/notification-preferences/notification-preferences.module#NotificationPreferencesModule',
    resolve: {
      commstatus: NotificationPreferencesResolver
    }
  },
  {
    path: 'pages',
    loadChildren: 'app/pages/static/static.module#StaticModule'
  },
  {
    path: 'my-pillpack',
    canActivate: [AuthGuard, PillGuard],
    data: {
      breadcrumb: 'Sign Up for PillPack'
    },
    component: AuthenticatedLayoutComponent,
    loadChildren: 'app/pages/my-pillpack/my-pillpack.module#MyPillpackModule'
  },
  {
    path: 'fitness-and-weightloss',
    canActivate: [AuthGuard, ScopeGuard],
    component: AuthenticatedLayoutComponent,
    loadChildren: 'app/pages/fitness-and-weightloss/fitness-and-weightloss.module#FitnessAndWeightlossModule'
  },

  // {
  //   path: '404',
  //   component: NotfoundComponent
  // },
  {
    path: '**',
    component: NotfoundComponent
  }
];

export const appRouter: ModuleWithProviders = RouterModule.forRoot(router);
