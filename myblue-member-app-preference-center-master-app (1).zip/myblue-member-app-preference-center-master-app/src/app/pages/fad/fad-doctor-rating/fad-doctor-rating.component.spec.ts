import {} from 'jasmine';

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FadDoctorRatingComponent } from './fad-doctor-rating.component';

describe('FadDoctorRatingComponent', () => {
  let component: FadDoctorRatingComponent;
  let fixture: ComponentFixture<FadDoctorRatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule],
      declarations: [FadDoctorRatingComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadDoctorRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
