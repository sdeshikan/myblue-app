import { Component, OnInit } from '@angular/core';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { UploadDetailsService } from './upload-details.service';
import { UploadedDocInfoRequestModelInterface, UploadDataItemInterface } from '../modals/interfaces/uploads.interface';
import { UploadDataItem } from '../modals/uploads.modal';
import { MessageCenterSearchService } from '../message-center-search/message-center-search.service';

@Component({
  selector: 'app-upload-detail',
  templateUrl: './upload-detail.component.html',
  styleUrls: ['./upload-detail.component.scss']
})
export class UploadDetailComponent implements OnInit {
  public docInfo: UploadDataItemInterface;
  public messageCenterConstants;

  constructor(
    private route: ActivatedRoute,
    private uploadDetailsService: UploadDetailsService,
    private router: Router,
    private messageCenterSearchService: MessageCenterSearchService
  ) {
    this.messageCenterConstants = MessageCenterConstants;
  }

  ngOnInit() {
    try {
      this.route.paramMap
        .pipe(
          switchMap((params: ParamMap, index: number) => {
            const uploadedDocInfoRequest: UploadedDocInfoRequestModelInterface = {
              fileId: params.get('fileId')
            };
            return this.uploadDetailsService.getDocumentData(uploadedDocInfoRequest);
          })
        )
        .subscribe(
          data => {
            this.docInfo = new UploadDataItem();

            if (!data) {
              this.throwInvalidServiceResponseDataErrorInOnInit();
            }
            this.docInfo = data;
          },
          error => {
            this.docInfo = new UploadDataItem();

            console.error(error, null, 2);
          }
        );
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  private throwInvalidServiceResponseDataErrorInOnInit(): void {
    console.error(new Error(MessageCenterConstants.errorMessages.invalidServiceResponseData), null, 2);
  }

  public navigateToUploadsScreen(): void {
    try {
      this.messageCenterSearchService.isPersistSearchCriteria = true;
      this.router.navigate([`/message-center/uploads`]);
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public downloadCopy(): void {
    try {
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }
}
