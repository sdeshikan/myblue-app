import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { Platform } from '@ionic/angular';
import { Select, Store } from '@ngxs/store';
import { from, of, bindNodeCallback, throwError, Subject } from 'rxjs';
import { catchError, filter, map, takeUntil } from 'rxjs/operators';
import { AlertType } from '../../../../../shared/alerts/alertType.model';
import { AlertService } from '../../../../../shared/services/alert.service';
import { GetTaxForms } from '../../../../../store/actions/taxforms.action';
import { TaxFormsSelectors } from '../../../../../store/selectors/taxforms.selectors';

@Component({
  selector: 'app-tax-form-view',
  templateUrl: './tax-form-view.page.html',
  styleUrls: ['./tax-form-view.page.scss']
})
export class TaxFormViewPage implements OnInit {
  taxyear: number;
  @Select(TaxFormsSelectors.getTaxForms) taxForms$;
  destroy$: Subject<boolean> = new Subject<boolean>();
  constructor(
    private store: Store,
    private fileTransfer: FileTransfer,
    private file: File,
    private localNotifications: LocalNotifications,
    private fileOpener: FileOpener,
    private platform: Platform,
    private androidPermissions: AndroidPermissions,
    private alertService: AlertService,
    private route: ActivatedRoute
  ) {
    this.route.queryParams.pipe(
       filter(params => params.year)
    ).subscribe(params => {
      this.taxyear = params.year;
    });
  }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.store.dispatch(new GetTaxForms(this.taxyear));
  }

  hexToBase64(hexstring) {
    return btoa(
      hexstring
        .match(/\w{2}/g)
        .map(hexCode => {
          return String.fromCharCode(parseInt(hexCode, 16));
        })
        .join('')
    );
  }

  downloadFile(sFilename) {
    const ft: FileTransferObject = this.fileTransfer.create();
    from(ft.download(this.file.dataDirectory + sFilename + '.pdf', this.file.externalRootDirectory + sFilename + '.pdf'))
    .subscribe(
      entry => {
        const fileLocation = this.file.externalRootDirectory + sFilename + '.pdf';
        this.localNotifications.schedule({
          id: 0,
          title: sFilename + '.pdf',
          text: 'Download completed.',
          data: entry.nativeURL
        });
        this.localNotifications.on('click').subscribe(response => {
          from(this.fileOpener
            .open(response.data, 'application/pdf'))
            .pipe(catchError(
              error => { this.alertService.setAlert('File open error', error, AlertType.Failure);
              return of(error);
              }))
            .subscribe(result =>
              this.alertService.setAlert('File open ', result, AlertType.Success)
              );
        });
      }
    );
  }

  blobConversion(hexText) {
    const byteCharacters = atob(hexText);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      return blob;
  }

  writeBlock = (blob, fileWriter, callback) => {
    let bytesWritten = 0;
    // tslint:disable-next-line: no-magic-numbers
    const BLOCK_SIZE = 0.5 * 1024 * 1024;
    const blockSize = Math.min(BLOCK_SIZE, blob.size - bytesWritten);
    const block = blob.slice(bytesWritten, bytesWritten + blockSize);
    fileWriter.write(block);
    bytesWritten += blockSize;
    fileWriter.onwrite = () => {
      if (bytesWritten < blob.size) {
        this.writeBlock(blob, fileWriter, callback);
      } else {
        callback();
      }
    };
  }

  planDetailsList(year: number, name: string, file) {
    if (file) {
      const hexText = this.hexToBase64(file);
      const blob = this.blobConversion(hexText);
      const sFilename = year + "_" + name;
      this.fileCreation(blob, sFilename);
    }
  }

  fileCreation(blob, sFilename) {
    console.log('fileCreation()');
    let fileTransfer = null;
    let fileLocation = null;

    return from(this.file.createFile(this.file.dataDirectory, sFilename + '.pdf', true))
      .pipe(
        catchError(error => {
          console.log('ERROR ' + JSON.stringify(error, null, 2));
          this.alertService.setAlert('Error in File creation', error, AlertType.Failure);
          return of(error);
        }),
        map(fileEntry => bindNodeCallback(fileEntry.createWriter)()),
        map(fileWriter => bindNodeCallback(this.writeBlock)(blob, fileWriter)),
        map(() => {
          if (this.platform.is('android')) {
            console.log('Checking Android Permission');
            return from(this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE));
          } else if (this.platform.is('ios')) {
            fileLocation = this.file.dataDirectory + sFilename + '.pdf';
            fileTransfer = this.fileTransfer.create();
            console.log('FILE LOCATION BEFORE OPEN ' + JSON.stringify(fileLocation, null, 2));
            return from(this.fileOpener.open(fileLocation, 'application/pdf'));
          }
        }),
        map((result: any) => {
          if (this.platform.is('android') && !result.hasPermission) {
            return from(this.androidPermissions.requestPermissions([this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE]));
          } else if (this.platform.is('android') && result.hasPermission) {
            const ft: FileTransferObject = this.fileTransfer.create();
            return from(ft.download(this.file.dataDirectory + sFilename + '.pdf', this.file.externalRootDirectory + sFilename + '.pdf'));
          } else if (this.platform.is('ios')) {
            return from(fileTransfer.download(fileLocation, this.file.syncedDataDirectory + sFilename + '.pdf', true));
          }
        }),
        filter(() => this.platform.is('android')),
        map((result: any) => {
          if (this.platform.is('android') && result.hasPermission) {
            return this.fileCreation(blob, sFilename);
          } else if (this.platform.is('android') && result.nativeURL) {
            this.localNotifications.schedule({
              id: 0,
              title: sFilename + '.pdf',
              text: 'Download completed.',
              data: result.nativeURL
            });
            return from(this.localNotifications.on('click'));
          }
        }),
        map((response: any) => {
          if (response) {
            return this.fileOpener.open(response.data, 'application/pdf');
          }
        }),
        catchError(error => {
          console.log('ERROR ' + JSON.stringify(error, null, 2));
          this.alertService.setAlert('File open error', error, AlertType.Failure);
          return throwError(error);
        }),
        takeUntil(this.destroy$)
      )
      .subscribe();
  }

  iosDownload(sFilename: string) {
    const fileLocation = this.file.dataDirectory + sFilename + '.pdf';
    const fileTransfer = this.fileTransfer.create();
    this.fileOpener.open(fileLocation, 'application/pdf').catch(
      error =>
      this.alertService.setAlert("Error in open file", error, AlertType.Failure)
    );
    fileTransfer
      .download(fileLocation, this.file.syncedDataDirectory + sFilename + '.pdf', true)
      .catch(
        error => this.alertService.setAlert("Error in download file", error, AlertType.Failure)
      );
  }
}
