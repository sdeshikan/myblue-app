import { Directive, OnChanges, ElementRef, Input, SimpleChanges } from '@angular/core';

@Directive({
    selector: '[removeSelectArrow]'
})
export class RemoveSelectArrowDirective implements OnChanges {
    
    @Input('removeSelectArrow') removeSelectArrow: any;

    constructor(private _el: ElementRef) {
    }
    
    ngOnChanges(changes: SimpleChanges): void {
        const shadow = this._el.nativeElement.shadowRoot;
        let display = 'block';
        if (changes.removeSelectArrow && changes.removeSelectArrow.currentValue) {
            display = 'none';
        }
        if (shadow) {
            try {
                shadow.querySelector('.select-icon').style.display = display;
            } catch(e) {}
        }
    }

}