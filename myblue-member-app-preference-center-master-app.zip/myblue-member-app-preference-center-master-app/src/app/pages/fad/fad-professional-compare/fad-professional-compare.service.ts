import { Injectable } from '@angular/core';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadProfessionalCompareService {
  public searchResults: GetSearchByProfessionalResponseModelInterface;

  constructor() {}

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('doctorCostInfo');
    if (costInfo) {
      const costInfoJson = JSON.parse(costInfo);
      return costInfoJson;
    }
    return null;
  }
}
