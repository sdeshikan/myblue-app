import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ForgetPasswordFlowGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    //const isVerifiedUser = sessionStorage.getItem('isauthenticated');
    const isVerifiedAuth = sessionStorage.getItem('funconfirmidentityAuth');
    const isVerifiedWeb = sessionStorage.getItem('funconfirmidentityWeb');
    if (isVerifiedAuth && isVerifiedAuth === 'TRUE') {
      if (isVerifiedWeb && isVerifiedWeb === 'FALSE') {
        return true;
      }
    } else {
      sessionStorage.clear();
      this.router.navigate(['login']);
      return false;
    }
  }
}
