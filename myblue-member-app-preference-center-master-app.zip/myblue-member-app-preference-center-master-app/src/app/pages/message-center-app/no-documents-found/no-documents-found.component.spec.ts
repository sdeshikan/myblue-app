import { CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DynamicPromotionalContentComponent } from '../../../shared/components/dynamic-promotional-content/dynamic-promotional-content.component';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { MessageCenterUtilities } from '../utils/message-center.utilities';
import { NoDocumentsFoundComponent } from './no-documents-found.component';

xdescribe('NoDocumentsFoundComponent', () => {
  let noDocumentsFoundComponent: NoDocumentsFoundComponent;
  let child_dynamicPromotionalContentComponent: DynamicPromotionalContentComponent;
  const utils: MessageCenterUtilities = new MessageCenterUtilities();
  let fixture: ComponentFixture<NoDocumentsFoundComponent>;
  let childFixture: ComponentFixture<DynamicPromotionalContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NoDocumentsFoundComponent, DynamicPromotionalContentComponent, MessageCenterConstants],
      providers: [MessageCenterConstants],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoDocumentsFoundComponent);
    childFixture = TestBed.createComponent(DynamicPromotionalContentComponent);
    noDocumentsFoundComponent = fixture.componentInstance;
    fixture.detectChanges();
    child_dynamicPromotionalContentComponent = childFixture.componentInstance;
    childFixture.detectChanges();
  });
});
