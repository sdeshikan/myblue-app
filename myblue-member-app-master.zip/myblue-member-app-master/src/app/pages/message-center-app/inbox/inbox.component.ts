import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AuthService } from '../../registration/registration.module';
import { SwrveService, SwrveEventNames } from './../../../shared/services/swrve.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  public unreadMsgCount: number;
  fpoTargetUrl: string = `${this.constants.drupalTestUrl}/page/myinbox-landingscreen`;
  isMedicare = false;

  constructor(
    public headerService: HeaderService,
    private router: Router,
    private constants: ConstantsService,
    public authService: AuthService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private profileService: ProfileService
  ) {
    this.isMedicare = this.authService.authToken.userType
      ? this.authService.authToken.userType.toLowerCase() === 'medicare'
        ? true
        : false
      : true;
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox);
  }

  ionViewWillEnter() {
    this.profileService.setPreferencePromo();
  }

  goToDocumentsHome() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments);
    this.router.navigate(['/tabs/myInbox/documents/home']);
  }

  goToNotificationsAlerts() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewNotificationsAlerts);
    this.router.navigate(['/tabs/myInbox/notifications-alerts']);
  }

  public openComponent(targetComponent: string): void {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewMessage);

      switch (targetComponent) {
        case 'messages':
          this.router.navigate([`/tabs/myInbox/messages`]);
          break;
        case 'chats':
          break;
        default:
          break;
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }
}
