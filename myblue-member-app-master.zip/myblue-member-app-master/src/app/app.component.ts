﻿import { Component, OnInit, Input, ViewEncapsulation, OnDestroy, NgZone } from '@angular/core';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Storage } from '@ionic/storage';
import { AnalyticsService } from './shared/services/analytics.service';
import { DynamicScriptLoaderService } from './shared/services/dynamic-script-loader.service';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';

import { NavigationEnd, Router } from '@angular/router';
import { environment } from '../environments/environment';

import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { MenuController, ModalController, NavController, Platform, ToastController } from '@ionic/angular';
import { AuthService } from './shared/services/auth.service';
import { distinctUntilChanged, filter, takeUntil } from 'rxjs/operators';
import * as moment from 'moment-timezone';
import { GlobalService } from './shared/services/global.service';
import { AlertService } from './shared/shared.module';
import { Location } from '@angular/common';

import { SwrveService, SwrveEventNames } from './shared/services/swrve.service';
import { IabService } from './shared/services/iab/iab.service';
import { SsoService } from './pages/sso/sso.service';
import { HeaderService } from '../app/shared/layouts/header/header.service';
import { Subject } from 'rxjs';
import { PharmacyLinksService } from './shared/services/mypharmacy/pharmacylinks.service';
import { HomeService } from './shared/services/home.service';
import { FeatureToggleService } from './services/feature.service';
declare let $: any;

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  destroy$: Subject<boolean> = new Subject<boolean>();

  homeNavigationApiResponse: any;
  isRegisteredUser = false;
  isAuthenticatedUser = false;
  isAnonymousUser = false;
  memberFirstName: string;
  scopeName: string;
  submenu: any = {};
  estGreeting = '';
  buildVersion = '';
  mobileAppVersion = '';
  currentUrl: string;
  callNurseLineNumber = '';
  showMyPharmacy: boolean;
  pharmacyLinks: PharmacyLinkType[];
  isFitnessEnabled = false;

  constructor(
    private menu: MenuController,
    private platform: Platform,
    private router: Router,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private modalController: ModalController,
    private toastCtrl: ToastController,
    private authService: AuthService,
    private globalService: GlobalService,
    private alertService: AlertService,
    private location: Location,
    private analyticsService: AnalyticsService,
    private dynamicScriptLoaderService: DynamicScriptLoaderService,
    private appVersion: AppVersion,
    private storage: Storage,
    private deepLinks: Deeplinks,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    public headerService: HeaderService,
    public homeService: HomeService,
    private pharmacyLinkService: PharmacyLinksService,
    private ngZone: NgZone,
    private featureToggleService: FeatureToggleService,
    private navCtrl: NavController
  ) {
    this.dynamicScriptLoaderService
      .load('adobe-analytics')
      .then(data => {
        console.log('Analytics Service BCBSMA: adobe-analytics library loaded successfully');
        console.log((window as any)._satellite);
        this.analyticsService.initializeAdobe(this.authService, (window as any)._satellite);
      })
      .catch(error => console.log('Analytics Service BCBSMA: adobe-analytics library load failed' + error));

    this.initializeApp();
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe((event: any) => {
        this.currentUrl = event.url;
        this.menu.close();
        if (event.url !== '/register/updatessn' && event.url.indexOf('/myprofile/communication-preferences') === -1) {
          this.alertService.clearError();
        }
      });

    this.isFitnessEnabled = this.featureToggleService.isFeatureEnabled('fitness-benefits');

    // TODO: Does distinctUntilChanged even work here? It won't if it is a JSON object!
    this.authService
      .getUserData()
      .pipe(distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((res: any) => {
        this.scopeName = res.scopename;
        this.memberFirstName = '';
        if (this.scopeName === 'AUTHENTICATED-NOT-VERIFIED' || this.scopeName === 'AUTHENTICATED-AND-VERIFIED') {
          this.memberFirstName = res.firstname;
          this.isAuthenticatedUser = true;
          this.isRegisteredUser = false;
          this.isAnonymousUser = false;
        } else if (this.scopeName === 'REGISTERED-AND-VERIFIED' || this.scopeName === 'REGISTERED-NOT-VERIFIED') {
          this.isRegisteredUser = true;
          this.isAuthenticatedUser = false;
          this.isAnonymousUser = false;
        } else {
          this.isRegisteredUser = false;
          this.isAnonymousUser = true;
          this.isAuthenticatedUser = false;
        }
        this.pharmacyLinks = this.pharmacyLinkService.getPharmacyLinks();
        if (this.pharmacyLinks && this.pharmacyLinks.length > 0) {
          this.showMyPharmacy = true;
        } else {
          this.showMyPharmacy = false;
        }
      });
    this.platform.backButton.subscribeWithPriority(1, () => {
      if (this.currentUrl !== '/tabs/home') {
        // TODO: This should not be used for ionic back navigation, replace with navigationCtrl
        this.location.back();
      } else if (this.currentUrl === '/tabs/home') {
        this.menu.isOpen().then(isOpen => {
          isOpen ? this.menu.close() : (navigator as any).app.exitApp();
        });
      }
    });
  }

  ngOnInit() {
    if (this.authService.authToken && this.authService.authToken.unreadMsgCount) {
      this.headerService.unReadMsgCount = this.authService.authToken.unreadMsgCount.toString();
    }
    this.buildVersion = environment.buildVersion;
    this.mobileAppVersion = environment.mobileAppVersion;
    const hour = moment.tz(new Date(), 'America/New_York').hour();
    if (hour < 12) {
      this.estGreeting = 'Good morning';
    } else if (hour >= 12 && hour < 17) {
      this.estGreeting = 'Good afternoon';
    } else {
      this.estGreeting = 'Good evening';
    }
  }

  initializeApp() {
    this.platform.ready().then(() => {
      if (this.platform.is('cordova')) {
        this.checkDeeplinks();
        this.getLocalAppVersion();
        this.statusBar.styleDefault();
        this.statusBar.backgroundColorByHexString('#1866a3');
        this.splashScreen.hide();
        this.getLocalAppVersion();
      }
      this.homeService.setSessionLinks();
    });
  }

  checkDeeplinks() {
    this.deepLinks
      .route({
        '/home': 'home',
        '/register': 'register',
        '/registerdetail': 'register/register-detail',
        '/login': 'login-app',
        '/whatsnew': 'whatsnew',
        '/myplan': 'myPlan',
        '/mydoctor': 'my-doctor',
        '/myclaims': 'myClaims',
        '/myinbox': 'myInbox',
        '/my-financial': 'my-financial',
        '/myprofile': 'myprofile',
        '/mycards': 'mycards',
        '/account': 'account',
        '/request-estimate': 'request-estimate',
        '/mydedco-app': 'mydedco-app',
        '/med-lookup-tool': 'med-lookup-tool',
        '/fad': 'fad',
        '/fitness-and-weightloss': 'fitness-and-weightloss'
      })
      .subscribe(
        match => {
          console.log('Successfully matched route', match);
          this.ngZone.run(() => {
            this.storage.set('deepLinkRoute', match.$route).then(() => {
              this.router.navigateByUrl(match.$route);
            });
          });
        },
        nomatch => {
          console.error("Got a deeplink that didn't match", nomatch);
          this.storage.set('deepLinkRoute', false);
        }
      );
  }

  logOut() {
    this.globalService.logout();
    this.menu.close();
  }

  goToLogin() {
    this.router.navigateByUrl('login-app');
  }

  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        this.callNurseLineNumber = this.homeNavigationApiResponse.APPTextUrl2 || '';
      }
    });
  }

  closeMenu() {
    this.menu.close();
  }

  getLocalAppVersion() {
    this.storage.get('appVersion').then(storedAppVersion => {
      storedAppVersion ? this.checkIfAppUpdated(storedAppVersion) : this.setAppVersion();
    });
  }

  async checkIfAppUpdated(storedAppVersion: string) {
    const currentAppVersion = await this.appVersion.getVersionNumber();
    if (storedAppVersion !== currentAppVersion) {
      this.callUpdateAppMessage();
      this.setAppVersion();
    }
  }

  callUpdateAppMessage() {
    (window as any).plugins.swrve.event(
      'update',
      'custom.app_update',
      successCallBack => {
        console.log(successCallBack);
      },
      failureCallback => {
        console.log(failureCallback);
      }
    );
  }

  async setAppVersion() {
    const currentAppVersion = await this.getCurrentAppVersion();
    this.storage.set('appVersion', currentAppVersion);
  }

  getCurrentAppVersion() {
    return this.appVersion.getVersionNumber().then(version => {
      return version;
    });
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  findADoctorClicked() {
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    const isSmartShopperUser = postLoginInfo ? this.checkSmartShopperUser(JSON.parse(postLoginInfo)) : false;
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_FindaDoctor);
    if (isSmartShopperUser) {
      this.ssoService.openSSO('fad');
    } else {
      this.router.navigate(['tabs/fad']);
    }
  }

  wellConnectionClicked() {
    const url = 'https://myblue.bluecrossma.com/health-plan/well-connection';
    if (url) {
      this.iabService.create(url);
    }
  }

  contactUsClicked() {
    console.log('-- contactUsClicked -- Contact Us - Menu Click sent', this.swrveEventNames.AppClick_Menu_ContactUs);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_ContactUs);
  }

  openUrl() {
    this.iabService.create('http://20181129medication.test-bluecrossma.acsitefactory.com/?referer=mobile-app');
  }

  myInboxClicked() {
    // public readonly AppClick_Menu_MyInbox: string = 'AppClick.Menu.MyInbox';
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_Menu_MyInbox);
  }

  myFinancialsClicked() {
    const hasALG = this.authService.authToken ? this.authService.authToken.isALG === 'true' : false;
    const hasHEQ = this.authService.authToken ? this.authService.authToken.isHEQ === 'true' : false;
    if (hasALG) {
      this.ssoService.openSSO('alg');
    } else if (hasHEQ) {
      this.ssoService.openSSO('heq');
    }
  }

  navigate(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      console.log('-- openInAppBrowser  -- To SSO');
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      console.log('-- openInAppBrowser  -- To IAB');
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  openFitnessURL() {
    if (this.isFitnessEnabled) {
      this.navCtrl.navigateForward('/tabs/fitness-and-weightloss');
    } else {
      window.open('https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss', '_blank');
    }
  }
}

interface PharmacyLinkType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
  isExternal: boolean;
}
