import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadSearchListComponent } from './fad-search-list.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FadSearchListService } from './fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';

describe('FadSearchListComponent', () => {
  let component: FadSearchListComponent;
  let fixture: ComponentFixture<FadSearchListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadSearchListComponent],
      providers: [
        FadSearchListService,
        FadSearchResultsService,
        FadProfessionalCompareService,
        AuthHttp,
        AuthService,
        ConstantsService,
        FadLandingPageService,
        BcbsmaHttpService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadSearchListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
