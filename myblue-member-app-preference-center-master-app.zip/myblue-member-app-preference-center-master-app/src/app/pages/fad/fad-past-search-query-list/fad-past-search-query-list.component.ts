import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FadAutoCompleteComplexOption, FadLandingPageSearchControlValues } from '../modals/fad-landing-page.modal';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FVSHRSearchHistoryInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';

@Component({
  selector: 'app-fad-past-search-query-list',
  templateUrl: './fad-past-search-query-list.component.html',
  styleUrls: ['./fad-past-search-query-list.component.scss']
})
export class FadPastSearchQueryListComponent implements OnInit {
  public searchHistory: FVSHRSearchHistoryInterface[] = [];

  constructor(private fadPastSearchQueryListService: FadPastSearchQueryListService, public router: Router) {}

  ngOnInit() {
    this.fadPastSearchQueryListService.getVitalsSearchHistory().subscribe(response => {
      this.searchHistory = response.searchHistory;
    });
  }

  public populateSearchFields(searchHistoryItem: FVSHRSearchHistoryInterface): void {
    try {
      const searchControlValues: FadLandingPageSearchControlValuesInterface = new FadLandingPageSearchControlValues();

      // Kalagi01 - Temporary code - has to change after api arrives
      searchControlValues.setSearchText(new FadAutoCompleteComplexOption().setSimpleText(searchHistoryItem.searchKeyword));
      searchControlValues.setZipCode(
        new FZCSRCity()
          .setCity(searchHistoryItem.city)
          .setState(searchHistoryItem.state)
          .setZip(searchHistoryItem.zipcode)
      );
      searchControlValues.setDependantName(new FadAutoCompleteComplexOption().setSimpleText(searchHistoryItem.dependant));
      this.fadPastSearchQueryListService.searchControlValues = searchControlValues;
      this.router.navigate(['/fad']);
    } catch (exception) {}
  }

  public onSearchListItemKeyDown(event: KeyboardEvent, searchHistoryItem: FVSHRSearchHistoryInterface) {
    // tslint:disable-next-line:no-magic-numbers
    if (event.keyCode === 32 || event.keyCode === 13) {
      event.stopPropagation();
      this.populateSearchFields(searchHistoryItem);
      return false;
    }
  }
}
