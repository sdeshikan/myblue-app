import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthService } from '../../../shared/services/auth.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { MyAccountsConstants } from '../constants/my-accounts.constants';
import { MyAccountService } from '../my-account.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit, OnDestroy {
  forgotPwdForm: FormGroup;
  dobMask: any[];
  useridinMessages = {
    required: 'Please enter a valid username.'
  };

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private myAccountService: MyAccountService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService
  ) {
    try {
      this.forgotPwdForm = this.fb.group({
        useridin: ['', [Validators.required]]
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.constructor
      );
    }
  }

  ngOnInit() {
    try {
      this.route.params.subscribe(params => {
        let userId = params['user'];
        if (localStorage['login-user'] && !userId) {
          userId = localStorage['login-user'];
        }
        this.forgotPwdForm.patchValue({
          useridin: userId
        });
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.ngOnInit
      );
    }
  }

  onSubmit() {
    try {
      this.getToken();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.constructor
      );
    }
  }

  verifyUser() {
    try {
      // Security Fixes - Swapping Access Code with Confirm Identity

      this.alertService.clearError();
      this.myAccountService.verifyUser(this.forgotPwdForm.getRawValue()).subscribe(
        res => {
          if (res) {
            sessionStorage.setItem('otp', 'TRUE');
            this.router.navigate(['/account/verifyAccessCode', 'FPW']).then(() => {
              this.alertService.setAlert('Verification code sent.', '', AlertType.Success);
            });
          }
        },
        error => {
          console.log('Error in forgot password', error);
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.messageCenterModule,
            MyAccountsConstants.services.myAccountService,
            MyAccountsConstants.methods.getDocumentViewData
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.verifyUser
      );
    }
  }

  getToken() {
    try {
      this.authService.getTokens().subscribe(
        token => {
          this.authService.cryptoToken = token;
          this.authService.persistSession();
          this.verifyUser();
          //console.log('ATOKEN: Crypto token called! whats in UI session storage: ', sessionStorage['token']);
        },
        err => {
          this.bcbsmaErrorHandler.handleHttpError(
            err,
            BcbsmaConstants.modules.myAccountModule,
            MyAccountsConstants.components.forgotPasswordComponent,
            MyAccountsConstants.methods.getToken
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.getToken
      );
    }
  }

  ngOnDestroy() {
    try {
      this.alertService.clearError();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotPasswordComponent,
        MyAccountsConstants.methods.ngOnDestroy
      );
    }
  }
}
