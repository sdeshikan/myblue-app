import {} from 'jasmine';

import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadFacilityProfileService } from './fad-facility-profile.service';

describe('FadFacilityProfileComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadFacilityProfileService, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityProfileService], (service: FadFacilityProfileService) => {
    expect(service).toBeTruthy();
  }));
});
