import { GeneralError } from '../../../shared/models/generic-app.model';
import { AwardDetailInterface } from './interfaces/fad-doctor-profile-details.interface';
import { CostDetails, Disclaimers, FadTiersInterface, MemberCost } from './interfaces/getSearchByProfessional-models.interface';
import {
    FacetsList,
    FadLocationAwardsDetailsInterface,
    FadLocationDetailsInterface,
    FadPdfRequestInterface,
    FadReviewsListInterface,
    FadSearchParamsInterface,
    FadSpecialtyInterface,
    GetSearchByProcedureResponseSearchSpecialtiesInfoInterface,
    GetSearchBySpecialityRequestModelInterface,
    GetSearchBySpecialityResponseModelInterface,
    GetSearchBySpecialityResponseSearchSpecialtiesInfoInterface,
    GetSearchBySpecialtyResponseModelInterface,
    SpecialtyFacetsListInterface
} from './interfaces/getSearchBySpeciality-models.interface';

export class GetSearchBySpecialityRequestModel implements GetSearchBySpecialityRequestModelInterface {
    useridin: string;
    networkId: number;
    geoLocation: string;
    limit: number;
    page: number;
    radius: number;
    searchSpecialtyId: string;
    procedureId: string;
    name: string;

    sort: string;
    contractAcceptingNewPatients: string;
    techSavvy: string;
    inNetwork: string;
    professionalGender: string;
    isPcp: string;
    groupAffiliationCategory: string;
    hospitalAffiliationCategory: string;
    hospitalAffiliationId: string;
    groupAffiliationId: string;
    professionalLanguages: string;
    aggregateOverallRating: string;
    agestreatedTypeCode: string;
    treatmentMethodsTypeCode: string;
    disorderTreatedTypeCode: string;
    providerType: string;
    isChoicePcp: string;
    bdcId: string;
    cqmId: string;
    awardId: string;
    tiers: string;

    getGeoLocation(): string {
        return this.geoLocation;
    }

    setGeoLocation(geoLocation: string): GetSearchBySpecialityRequestModel {
        this.geoLocation = geoLocation;
        return this;
    }

    getLimit(): number {
        return this.limit;
    }

    setLimit(limit: number): GetSearchBySpecialityRequestModel {
        this.limit = limit;
        return this;
    }

    getPage(): number {
        return this.page;
    }

    setPage(page: number): GetSearchBySpecialityRequestModel {
        this.page = page;
        return this;
    }

    getRadius(): number {
        return this.radius;
    }

    setRadius(radius: number): GetSearchBySpecialityRequestModel {
        this.radius = radius;
        return this;
    }

    getNetworkId(): number {
        return this.networkId;
    }

    setNetworkId(networkId: number): GetSearchBySpecialityRequestModel {
        this.networkId = networkId;
        return this;
    }

    getProcedureId(): string {
        return this.procedureId;
    }
    setProcedureId(procedureId: string): GetSearchBySpecialityRequestModel {
        this.procedureId = procedureId;
        return this;
    }

    getSearchSpecialtyId(): string {
        return this.searchSpecialtyId;
    }

    setSearchSpecialtyId(searchSpecialtyId: string): GetSearchBySpecialityRequestModel {
        this.searchSpecialtyId = searchSpecialtyId;
        return this;
    }

    getUserId(): string {
        return this.useridin;
    }

    setUserId(useridin: string): GetSearchBySpecialityRequestModel {
        this.useridin = useridin;
        return this;
    }

    getName(): string {
        return this.name;
    }

    setName(name: string): GetSearchBySpecialityRequestModel {
        this.name = name;
        return this;
    }
    getSort(): string {
        return this.sort;
    }

    setSort(sort: string): GetSearchBySpecialityRequestModel {
        this.sort = sort;
        return this;
    }

    getAcceptingNewPatients(): string {
        return this.contractAcceptingNewPatients;
    }

    setAcceptingNewPatients(contractAcceptingNewPatients: string): GetSearchBySpecialityRequestModel {
        this.contractAcceptingNewPatients = contractAcceptingNewPatients;
        return this;
    }

    getTechSavvy(): string {
        return this.techSavvy;
    }

    setTechSavvy(techSavvy: string): GetSearchBySpecialityRequestModel {
        this.techSavvy = techSavvy;
        return this;
    }

    getInNetwork(): string {
        return this.inNetwork;
    }

    setInNetwork(inNetwork: string): GetSearchBySpecialityRequestModel {
        this.inNetwork = inNetwork;
        return this;
    }

    getProfessionalGender(): string {
        return this.professionalGender;
    }

    setProfessionalGender(professionalGender: string): GetSearchBySpecialityRequestModel {
        this.professionalGender = professionalGender;
        return this;
    }

    getisPcp(): string {
        return this.isPcp;
    }

    setisPcp(isPcp: string): GetSearchBySpecialityRequestModel {
        this.isPcp = isPcp;
        return this;
    }

    getIsChoicePcp(): string {
        return this.isChoicePcp;
    }
    setIsChoicePcp(isChoicePcp: string): GetSearchBySpecialityRequestModel {
        this.isChoicePcp = isChoicePcp;
        return this;
    }

    getTiers(): string {
        return this.tiers;
    }
    setTiers(tiers: string): GetSearchBySpecialityRequestModel {
        this.tiers = tiers;
        return this;
    }

    getAwardsTypeCodes(): string {
        return this.awardId;
    }
    setAwardsTypeCodes(awardId: string): GetSearchBySpecialityRequestModel {
        this.awardId = awardId;
        return this;
    }

    getBcdTypeCodes(): string {
        return this.bdcId;
    }
    setBcdTypeCodes(bdcId: string): GetSearchBySpecialityRequestModel {
        this.bdcId = bdcId;
        return this;
    }

    getCqms(): string {
        return this.cqmId;
    }
    setCqms(cqmId: string): GetSearchBySpecialityRequestModel {
        this.cqmId = cqmId;
        return this;
    }

    getHospitalAffiliationCategory(): string {
        return this.hospitalAffiliationCategory;
    }

    setHospitalAffiliationCategory(hospitalAffiliationCategory: string): GetSearchBySpecialityRequestModel {
        this.hospitalAffiliationCategory = hospitalAffiliationCategory;
        return this;
    }

    getGroupAffiliationCategory(): string {
        return this.groupAffiliationCategory;
    }

    setGroupAffiliationCategory(groupAffiliationCategory: string): GetSearchBySpecialityRequestModel {
        this.groupAffiliationCategory = groupAffiliationCategory;
        return this;
    }

    getHospitalAffiliationId(): string {
        return this.hospitalAffiliationId;
    }

    setHospitalAffiliationId(hospitalAffiliationId: string): GetSearchBySpecialityRequestModel {
        this.hospitalAffiliationId = hospitalAffiliationId;
        return this;
    }

    getGroupAffiliationId(): string {
        return this.hospitalAffiliationId;
    }

    setGroupAffiliationId(groupAffiliationId: string): GetSearchBySpecialityRequestModel {
        this.groupAffiliationId = groupAffiliationId;
        return this;
    }

    getProfessionalLanguages(): string {
        return this.professionalLanguages;
    }

    setProfessionalLanguages(professionalLanguages: string): GetSearchBySpecialityRequestModel {
        this.professionalLanguages = professionalLanguages;
        return this;
    }

    getproviderType(): string {
        return this.providerType;
    }

    setproviderType(providerType: string): GetSearchBySpecialityRequestModel {
        this.providerType = providerType;
        return this;
    }
    getAggregateOverallRating(): string {
        return this.aggregateOverallRating;
    }

    setAggregateOverallRating(aggregateOverallRating: string): GetSearchBySpecialityRequestModel {
        this.aggregateOverallRating = aggregateOverallRating;
        return this;
    }

    getAgestreatedTypeCode(): string {
        return this.agestreatedTypeCode;
    }

    setAgestreatedTypeCode(agestreatedTypeCode: string): GetSearchBySpecialityRequestModel {
        this.agestreatedTypeCode = agestreatedTypeCode;
        return this;
    }

    getTreatmentMethodsTypeCode(): string {
        return this.treatmentMethodsTypeCode;
    }

    setTreatmentMethodsTypeCode(treatmentMethodsTypeCode: string): GetSearchBySpecialityRequestModel {
        this.treatmentMethodsTypeCode = treatmentMethodsTypeCode;
        return this;
    }

    getDisorderTreatedTypeCode(): string {
        return this.disorderTreatedTypeCode;
    }

    setDisorderTreatedTypeCode(disorderTreatedTypeCode: string): GetSearchBySpecialityRequestModel {
        this.disorderTreatedTypeCode = disorderTreatedTypeCode;
        return this;
    }
}

export class GetSearchBySpecialityResponseModel extends GeneralError implements GetSearchBySpecialityResponseModelInterface {
    searchSpecialties: GetSearchBySpecialityResponseSearchSpecialtiesInfo[];
    proceduresList: GetSearchByProcedureResponseSearchSpecialtiesInfo[];
}

export class GetSearchBySpecialityResponseSearchSpecialtiesInfo implements GetSearchBySpecialityResponseSearchSpecialtiesInfoInterface {
    id: string; // This is the id
    name: string; // This is the name of the Specialty
    resourceTypeCode: string; // This is the resourceTypeCode
    isProcedure: boolean;
    procedureDescription: string; // Procedure Description Text
}

export class GetSearchByProcedureResponseSearchSpecialtiesInfo implements  GetSearchByProcedureResponseSearchSpecialtiesInfoInterface {
    id: number; // This is the id
    name: string; // This is the name of the Procedure
    resourceTypeCode: string; // This is the resourceTypeCode
    description: string; // This is for Procedure description
    isProcedure = true; // This is the isProcedure
    procedureDescription: string; // Procedure Description Text
}

export class GetSearchBySpecialtyResponseModel extends GeneralError implements GetSearchBySpecialtyResponseModelInterface {
    result: number;
    errormessage: string;
    displaymessage: string;
    totalCount: number;
    providers: FadSpecialtyInterface[];
    sort: string;
    disclaimers: Disclaimers[];
    facets: FacetsList;
    costDetails: CostDetails;
    pdfRequest: FadPdfRequest;
}


export class FadPdfRequest implements FadPdfRequestInterface {
    filters: string[];
    queryUrl: string;
    queue: boolean;
    source: string;
    searchParams: FadSearchParams;
}

export class FadSearchParams implements FadSearchParamsInterface {
    accountId: string;
    ci: string;
    dataLanguage: string;
    geoLocation: string;
    limit: string;
    memberNumber: string;
    name: string;
    networkId: string;
    page: string;
    radius: string;
    sort: string;
}

export class FadSpecialty implements FadSpecialtyInterface {
    isDisabled: boolean;
    isChecked: boolean;
    providerName: string; // This is the city/state of the location
    specialty: string; // This is the name of the city
    locations: FadLocationDetails[];
    reviews: FadReviewsListInterface;
    providerId: string;
    reviewIdentifier: string;
    providerType: string;
    // tiers: FadProffessionalTierInterface;
}

export class FadLocationDetails implements FadLocationDetailsInterface {
    id: number; //    This is the location
    name: string; //     This is the location name
    address: string; //     This is the address info
    phone: string; //     This is the phone info
    awards: FadawardsDetails[];
    providerCost?: MemberCost;
    facilityCost?: MemberCost;
    tiers: FadTiersInterface;
}

export class FadawardsDetails implements FadLocationAwardsDetailsInterface {
    name: string;
    typeCode: string;
    awardDetails: AwardDetailInterface[];
}

export class FadReviewsList implements FadReviewsListInterface {
    overallRating: number; //     This is the city/state of the location
    percentRecommended: number; //     This is the percentRecommended
    totalRatings: number; //     This is the totalRatings
}

