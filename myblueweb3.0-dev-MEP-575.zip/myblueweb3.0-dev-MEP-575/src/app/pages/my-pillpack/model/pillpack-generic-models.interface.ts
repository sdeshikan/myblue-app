import {
  GeneralErrorInterface,
  MyBlueGeneralAPIRequestModelInterface
} from '../../../shared/models/interfaces/generic-app-models.interface';
import { BaseProfilesRequestModelInterface } from '../../my-profile/models/interfaces/member-profile-generics.interface';

/* const addMedicationsRequest = {
    useridin:"frank.wayman@yopmail.com",
    partner:{
       id:"5d358fac7633a4532d192abb1"
    },
    medications:[
       {
          ndcCd:"00143301801",
          rxcui:"12345678",
          description:"capculase",
          isSelfPrescribed:true,
          shouldChase:false,
          doseTimes:"10:00AM",
          genericName:"Colchicine",
          form:'capsule',
          daysSupply:28,
          lastFill:'4/17/2019',
          strength:"5G of 0.1%",
          directions:"after dinner",
          pharmacy:{
             id:"70010002242787",
             name:"CVS",
             phoneNumber:"8977703858",
             address:{
                address1:"152 ELM ST",
                address2:"",
                city:"QUINCY",
                state:"MA",
                zipcode:"01089"
             }
          },
          prescriber:{
             firstName:"KATHLEEN",
             lastName:"FORTINI",
             middleInitial:"NP",
             id:"70010000NP2408",
             deaNumber:"l67979",
             phoneNumber:"781-826-2131",
             address:{
                address1:"104 ELM ST",
                address2:"",
                city:"NORWELL",
                state:"MA",
                zipcode:"02061"
             }
          }
       }
    ],
    "key2id":"816e3f16e4e0462fa22a77154025914e"
 }
} */

export interface UpdatePharmacyMedicationModelInterface extends MyBlueGeneralAPIRequestModelInterface {
  partner: PartnerModelInterface;
  medications: MaintenanceMedicationModelInterface[];
  key2id: string;
}
export interface MaintenanceMedicationModelInterface {
  ndcCd?: string;
  rxcui: string;
  description?: string;
  isSelfPrescribed?: boolean;
  shouldChase?: boolean;
  doseTimes?: string;
  genericName?: string;
  form?: string;
  daysSupply?: number;
  lastFill?: string;
  strength?: string;
  directions?: string;
  pharmacy?: PharmacyModelInterface;
  prescriber?: PrescriberModelInterface;
  isSelected?: boolean;
  copay?: number;
}
export interface PharmacyModelInterface {
  id: string;
  name: string;
  phoneNumber: string;
  address: PharmacyAddressModelInterface;
}
export interface PharmacyAddressModelInterface {
  address1: string;
  address2: string;
  city: string;
  state: string;
  zipcode: string;
}
export interface PrescriberModelInterface {
  firstName: string;
  lastName: string;
  middleInitial: string;
  id: string;
  deaNumber: string;
  phoneNumber: string;
  address: PharmacyAddressModelInterface;
}
export interface PartnerModelInterface {
  id: string;
}
