import { TestBed, inject } from '@angular/core/testing';
import { FadFacilityListService } from './fad-facility-list.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { NgxsModule } from '@ngxs/store';
import { RouterTestingModule } from '@angular/router/testing';

describe('FadFacilityListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([])],
      providers: [FadFacilityListService, FadSearchResultsService, BcbsmaHttpService, AuthHttp, AuthService, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityListService], (service: FadFacilityListService) => {
    expect(service).toBeTruthy();
  }));
});
