import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { SetLoader } from '../../store/actions/app.actions';

@Injectable()
export class FadLoadingInterceptor implements HttpInterceptor {
  reqCount = 0;
  isLoaderShowing = false;
  noLoader = ['gettokens', 'refreshtoken'];

  constructor(private store: Store) {}

  private isLoaderApplicable(req: HttpRequest<any>): boolean {
    // Not showing loader for some services as they are called more often
    const { url } = req;
    const serviceName = url.split('/').reverse()[0];
    if (req.headers['Global-Spinner'] === false) {
      return req.headers['Global-Spinner'];
    } else {
      return this.noLoader.indexOf(serviceName) === -1;
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.isLoaderApplicable(req)) {
      this.showLoader();
    }
    return next.handle(req);
  }

  private async showLoader() {
    this.reqCount++;
    if (this.reqCount > 0 && !this.isLoaderShowing) {
      // this.store.dispatch(new SetLoader(true));
    }
  }

  private async hideLoader(req) {
    this.reqCount--;
    if (this.reqCount <= 0 && this.isLoaderShowing) {
      // this.store.dispatch(new SetLoader(false));
      this.isLoaderShowing = false;
    }
  }
}
