import { TestBed, inject } from '@angular/core/testing';

import { FadMedicalIndexService } from './fad-medical-index.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';

describe('FadMedicalIndexService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadMedicalIndexService, BcbsmaHttpService, AuthHttp, AuthService, ConstantsService]
    });
  });

  it('should be created', inject([FadMedicalIndexService], (service: FadMedicalIndexService) => {
    expect(service).toBeTruthy();
  }));
});
