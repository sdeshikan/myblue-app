import { Component, OnInit, OnDestroy, ViewChild, HostListener } from '@angular/core';
import { Member } from '../model/medications.interface';
import { Store } from '@ngrx/store';
import { State, getMedications } from './../store/reducer';
import { UpdateMedications, LoadMedications } from '../store/actions';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators, ValidatorFn } from '@angular/forms';
import { Subscription, Observable } from 'rxjs';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { map, partition } from 'rxjs/operators';
import { ConstantsService } from '../../../shared/services/constants.service';
import { AuthService } from '../../../shared/shared.module';
import { ActivatedRoute, Router } from '@angular/router';
import { ValidationService } from '../../../shared/services/validation.service';
import { GetMemberProfileResponseModel } from '../../my-profile/models/get-member-profile-request.model';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AlertService } from '../../../shared/services/alert.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import * as moment from 'moment';
import { rxOrderSummaryModel } from '../../../shared/models/rxordersummary.model';
import { RxOrderSummaryComponent } from '../components/rx-order-summary/rx-order-summary.component';
import { VerifyEmailMobileComponent } from '../../my-profile/verify-email-mobile/verify-email-mobile.component';
import { CreditCardComponent } from '../../my-pillpack/components/credit-card/credit-card.component';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatAutocomplete } from '@angular/material/autocomplete';

import { MyPillpackService } from '../../../shared/services/mypillpack/my-pillpack.service';
import {
  UpdatePharmacyMedicationModelInterface,
  PartnerModelInterface,
  MaintenanceMedicationModelInterface
} from '../model/pillpack-generic-models.interface';
import { UpdatePharmacyMedicationRequestModel, MaintenanceMedicationModel } from '../model/pillpack-generic.models';
declare let $: any;

@Component({
  selector: 'app-medications',
  templateUrl: './medications.component.html',
  styleUrls: ['./medications.component.scss']
})
export class MedicationsComponent implements OnInit, OnDestroy {
  @ViewChild('creditCard') creditCard: CreditCardComponent;
  profile: GetMemberProfileResponseModel;
  error: any;
  profileEditForm: FormGroup;
  addressEditForm: FormGroup;
  rxOrderSummary: rxOrderSummaryModel;
  addOTCFlag: boolean = false;
  hasNonPharmacyMed: any;
  medications: any[];
  selectedMedications: any[];
  selectedOTCs: any[];
  pillpackForm: FormGroup;
  pillpackQuestionsForm: FormGroup;
  currentStep = 1;
  popupCnt = 'Email';
  popuplink = 'email';
  diplayEmailAdress: string = '';
  sendingpageUrl = 'my-pillpack';
  memberName: string = '';
  isMemberPregnancy = false;
  isAddingOTC = false;
  hasOTCs = false;
  editAddress = true;
  editEmail = true;
  editPhone = true;
  alreadyEmailExist = false;
  registeredUserOnly: boolean = false;
  address3: string = '';
  showDependantDisclaimer = false;
  isVerifyEmailProcessComplete: boolean;
  isVerifiedEmail: boolean;
  otcSummaryTotal: number;
  maintenanceMedicationsSummaryTotal: number;
  estimatedOrderTotal: number;
  hasMaintenanceMeds: boolean;
  selectedMaintenanceMedications: any[];
  selectedOTCsToTransfer: any[];
  partnerId: string;
  tokenId: string;
  isIncompleteHandoff: boolean;
  isPillPackEnrolledThisSession: boolean;
  phoneMask: Array<any>;
  isStepOneFail: boolean = false;
  isStepTwoFail: boolean = false;
  isStepThreeFail: boolean = false;
  isCPDPPromotion: boolean = false;
  shippingAddress: any = [
    {
      address1: '',
      address2: '',
      city: '',
      state: '',
      zipcode: '',
      phoneNumber: '',
      emailAddress: ''
    }
  ];
  statesList = [
    { label: 'Alabama', value: 'AL' },
    { label: 'Alaska', value: 'AK' },
    { label: 'Arizona', value: 'AZ' },
    { label: 'Arkansas', value: 'AR' },
    { label: 'California', value: 'CA' },
    { label: 'Colorado', value: 'CO' },
    { label: 'Connecticut', value: 'CT' },
    { label: 'Delaware', value: 'DE' },
    { label: 'District of Columbia', value: 'DC' },
    { label: 'Florida', value: 'FL' },
    { label: 'Georgia', value: 'GA' },
    { label: 'Hawaii', value: 'HI' },
    { label: 'Idaho', value: 'ID' },
    { label: 'Illinois', value: 'IL' },
    { label: 'Indiana', value: 'IN' },
    { label: 'Iowa', value: 'IA' },
    { label: 'Kansas', value: 'KS' },
    { label: 'Kentucky', value: 'KY' },
    { label: 'Louisiana', value: 'LA' },
    { label: 'Maine', value: 'ME' },
    { label: 'Maryland', value: 'MD' },
    { label: 'Massachusetts', value: 'MA' },
    { label: 'Michigan', value: 'MI' },
    { label: 'Minnesota', value: 'MN' },
    { label: 'Mississippi', value: 'MS' },
    { label: 'Missouri', value: 'MO' },
    { label: 'Montana', value: 'MT' },
    { label: 'Nebraska', value: 'NE' },
    { label: 'Nevada', value: 'NV' },
    { label: 'New Hampshire', value: 'NH' },
    { label: 'New Jersey', value: 'NJ' },
    { label: 'New Mexico', value: 'NM' },
    { label: 'New York', value: 'NY' },
    { label: 'North Carolina', value: 'NC' },
    { label: 'North Dakota', value: 'ND' },
    { label: 'Ohio', value: 'OH' },
    { label: 'Oklahoma', value: 'OK' },
    { label: 'Oregon', value: 'OR' },
    { label: 'Pennsylvania', value: 'PA' },
    { label: 'Rhode Island', value: 'RI' },
    { label: 'South Carolina', value: 'SC' },
    { label: 'South Dakota', value: 'SD' },
    { label: 'Tennessee', value: 'TN' },
    { label: 'Texas', value: 'TX' },
    { label: 'Utah', value: 'UT' },
    { label: 'Vermont', value: 'VT' },
    { label: 'Virginia', value: 'VA' },
    { label: 'Washington', value: 'WA' },
    { label: 'West Virginia', value: 'WV' },
    { label: 'Wisconsin', value: 'WI' },
    { label: 'Wyoming', value: 'WY' }
  ];

  ismobile: boolean;
  mobileViewPort = 992;
  selectedTime = new Array();

  options: any = [
    {
      question: 'Do you have any allergies?',
      choices: ['Yes', 'No'],
      placeholder: 'Please list your allergies, separated by commas.',
      hint: 'Allergy 1, Allergy 2'
    },
    {
      question: 'Do you have any health conditions?',
      choices: ['Yes', 'No'],
      placeholder: 'Please list your health conditions, separated by commas.',
      hint: 'Health Condition 1, Health Condition 2'
    },
    {
      question: 'Are you pregnant or nursing?',
      choices: ['Yes', 'No']
    }
  ];
  emailMessages = {
    required: 'You must enter your email address.',
    invalidEmail: 'You must enter a valid email address.'
  };
  mobileNumberMessages = {
    required: 'You must enter a valid phone number.',
    invalidNumber: 'You must enter a valid phone number.',
    invalidMobile: 'You must enter a valid phone number.'
  };
  mask: Object = { mask: this.validationService.phoneMask, guide: false };

  allowedChars = new Set('0123456789'.split('').map(c => c.charCodeAt(0)));

  check(event: KeyboardEvent) {
    // 31 and below are control keys, don't block them.
    if (event.keyCode > 31 && !this.allowedChars.has(event.keyCode)) {
      event.preventDefault();
    }
  }
  zipCode(event) {
    if (event.target.value.length > 0) {
      let zipValid = /^[0-9]+$/.test(event.target.value);
      if (!zipValid) {
        event.target.value = '';
      }
    }
  }
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }
  constructor(
    private router: Router,
    private store: Store<State>,
    private _fb: FormBuilder,
    private authService: AuthService,
    private alertService: AlertService,
    private http: AuthHttp,
    private constants: ConstantsService,
    private validationService: ValidationService,
    private activatedRoute: ActivatedRoute,
    private profileService: ProfileService,
    private myPillpackService: MyPillpackService,
    private titleCase: TitleCasePipe,
    private _router: Router,
    private _pillPackService: MyPillpackService
  ) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.rxOrderSummary = new rxOrderSummaryModel(42.0, 106.0, this.isAddingOTC, 148.0, 0, 0);
    this.isVerifyEmailProcessComplete = false;
    this.isIncompleteHandoff = false;
    this.memberName = this.authService.authToken.firstName;

    this.pillpackForm = this._fb.group({
      medications: new FormArray([], minSelectedCheckboxes(1)),
      hasNonPharmacyMed: [false]
    });
    this.myPillpackService.getDiscountedVitaminsAndOTCs();
    this.profileEditForm = this._fb.group({
      useridin: '',
      isEditableAddress: false,
      userState: '',
      isDirectPay: false,
      address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
      dob: ['', []],
      city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      state: ['', this.editAddress ? [Validators.required] : []],
      zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []],
      emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
      fullName: '',
      healthInfo: this._fb.array([]),
      health: this._fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      }),
      phoneNumber: [
        this.editPhone ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
      ],
      isVerifiedEmail: false,
      isVerifiedMobile: false,
      isEmailOptedIn: false,
      isMobileOptedIn: false
    });

    function minSelectedCheckboxes(min = 1) {
      const validator: ValidatorFn = (formArray: FormArray) => {
        const totalSelected = formArray.controls
          // get a list of checkbox values (boolean)
          .map(control => control.value)
          // total up the number of checked checkboxes
          .reduce((prev, next) => (next ? prev + next : prev), 0);

        // if the total is not greater than the minimum, return the error message
        return totalSelected >= min ? null : { required: true };
      };

      return validator;
    }

    this.pillpackQuestionsForm = this._fb.group({
      healthInfo: this._fb.array([]),
      health: this._fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      })
    });

    this.profileService.fetchProfileInfo().subscribe(profileInfo => {
      var dob_date = new Date(profileInfo.dob);
      var timeDiff = Math.abs(Date.now() - +dob_date);
      var memberAge = Math.floor(timeDiff / (1000 * 3600 * 24) / 365);
      this.diplayEmailAdress = profileInfo.emailAddress;
      this.isVerifiedEmail = profileInfo.isVerifiedEmail;
      this.isMemberPregnancy = memberAge >= 13 && memberAge <= 60 && profileInfo.gender == 'F';
      this.options.map((healthOptions, i) => {
        if (i < 2 || this.isMemberPregnancy) {
          (<FormArray>this.pillpackQuestionsForm.get('healthInfo')).push(this.addQuesFormGroup());
        }
      });
      (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').setValue(profileInfo.health.allergies);
      if (profileInfo.health.allergies.length > 0) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
          .get('healthquestion')
          .setValue(profileInfo.health.allergies.length > 0);
      }
      (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').setValue(profileInfo.health.conditions);
      if (profileInfo.health.conditions.length > 0) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
          .get('healthquestion')
          .setValue(profileInfo.health.conditions.length > 0);
      }
    });
    this.store.select(getMedications).subscribe((medications: Array<MaintenanceMedicationModel>) => {
      this.medications = medications;
      if (this.medications.length > 0) {
        this.hasMaintenanceMeds = true;
      } else {
        this.hasMaintenanceMeds = false;
      }
      const medicationsArrray = this.pillpackForm.controls.medications as FormArray;
      this.medications.map(medication => {
        medicationsArrray.push(new FormControl(false));
      });
    });
  }

  processComplete($event) {
    this.isVerifyEmailProcessComplete = event.returnValue;
    this.gotoStep(5);
    //CALL COMPLETE HANDOFF TO PILLPACK HERE
    // this._pillPackService = null;
    // sessionStorage.removeItem('otcTotal');
    // sessionStorage.removeItem('selectedOTCs');
    //Goes To Confirmation Page
    //this.gotoStep(6);
    //console.log('stop-' + this.isVerifyEmailProcessComplete)
  }

  getStpsArray(n: number = 4) {
    return Array.from(Array(n), (x, index) => index + 1);
  }

  onQuestionClick(index: number) {
    let isValid: boolean = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[index].get('healthquestion').value;
    const healthHintAnswer = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[index].get('healthHintAns');
    if (isValid && index < 2) {
      healthHintAnswer.setValidators([Validators.required]);
      healthHintAnswer.setValue(healthHintAnswer.value);
    } else {
      healthHintAnswer.setValidators([]);
      healthHintAnswer.setValue('');
      healthHintAnswer.updateValueAndValidity();
    }
  }

  maintenanceTotalChange(checkbox: MatCheckbox, medications: MaintenanceMedicationModelInterface) {
    const myVar = checkbox;
    const myOtherVar = myVar.value;
    const myMeds = medications;
    const mystop = 'stop';
    this.selectedMedications = this.medications.filter(med => med.isSelected === true);
    console.log('this.selectedMedications' + JSON.stringify(this.selectedMedications));
    if (sessionStorage.getItem('selectedOTCs')) {
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
    console.log('this.selectedOTCs' + JSON.stringify(this.selectedOTCs));

    if (checkbox.checked) {
      this.maintenanceMedicationsSummaryTotal = this.maintenanceMedicationsSummaryTotal + medications.copay;
      this.estimatedOrderTotal = this.estimatedOrderTotal + medications.copay;
    } else {
      this.maintenanceMedicationsSummaryTotal = this.maintenanceMedicationsSummaryTotal - medications.copay;
      this.estimatedOrderTotal = this.estimatedOrderTotal - medications.copay;
    }
  }

  selectedOptions() {
    // right now: ['1','3']
    return this.medications.filter(opt => opt.isSelected).map(opt => opt.isSelected);
  }

  async completePillPackHandoff() {
    const handoffRequest = {
      useridin: this.authService.useridin,
      partner: {
        id: this.partnerId,
        status: this.isIncompleteHandoff ? 'incomplete' : 'done',
        token: this.tokenId
      },
      key2id: this.authService.cryptoToken.key2id
    };

    console.log('completeHandoffRequest::' + handoffRequest);
    const isSuccess = await this._pillPackService.completePillPackHandoff(handoffRequest).then(res => {
      console.log('completeHandoffResponse::' + JSON.stringify(res));
      if (Number(res.result) < 0) {
        this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
        sessionStorage.setItem('isCompleteHanddoff', 'false');
        this.gotoStep(4);
        return false;
      } else {
        sessionStorage.setItem('isCompleteHanddoff', 'true');
        this.http.postlogin().then(response => {
          if (response && response.error !== true) {
            sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
          }
          console.log('postLoginInfo after Hand off :::', JSON.stringify(response));
        });
        this.navigatToConformationScreen();
        return true;
      }
    });
  }

  async sendPillPackMedications(request) {
    //MAKE COMPLERTE HANDOFF CALL TO PILLPACK HERE.

    console.log('addMedicationsRequest::' + JSON.stringify(request));
    const isSuccess = await this._pillPackService.addMedications(request).then(res => {
      console.log('addMedications::' + JSON.stringify(res));
      if (Number(res.result) < 0) {
        this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
        sessionStorage.setItem('isAddedMedicationsComplete', 'false');
        this.isIncompleteHandoff = true;
        this.gotoStep(4);
        return false;
      } else {
        sessionStorage.setItem('isAddedMedicationsComplete', 'true');
        this.completePillPackHandoff();
        return true;
      }
    });
  }

  createAddMedicationsRequest() {
    //Get Selected Maintenance Medications
    let selectedMedications = this.medications.filter(med => med.isSelected === true);

    //Get Selected OTCs
    if (sessionStorage.getItem('selectedOTCs')) {
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
    if (!this.partnerId) {
      this.partnerId = sessionStorage.getItem('partnerId');
    }
    //CALL Add Medications API here

    const request: UpdatePharmacyMedicationModelInterface = new UpdatePharmacyMedicationRequestModel();
    const thisPartner = {} as PartnerModelInterface;
    const theseMedications = {} as MaintenanceMedicationModelInterface;
    thisPartner.id = this.partnerId;

    //Add Partner to Request
    request.partner = thisPartner;

    request.useridin = this.authService.useridin;

    this.selectedMaintenanceMedications = selectedMedications.map(function(med) {
      return {
        ndcCd: med.prescription.ndcCd,
        rxcui: med.prescription.ndcCd,
        description: med.prescription.description,
        isSelfPrescribed: false,
        shouldChase: true,
        doseTimes: '',
        genericName: med.prescription.genericName,
        form: '',
        daysSupply: 30,
        lastFill: med.prescription.lastFill ? med.prescription.lastFill : '0000-00-00',
        strength: '',
        copay: med.prescription.copay,
        pharmacy: {
          id: med.pharmacy.id,
          name: med.pharmacy.name,
          phoneNumber: med.pharmacy.phoneNumber,
          address: med.pharmacy.address
            ? {
                address1: med.pharmacy.address.address1,
                address2: med.pharmacy.address.address2,
                city: med.pharmacy.address.city,
                state: med.pharmacy.address.state,
                zipcode: med.pharmacy.address.zipcode
              }
            : undefined
        },
        prescriber: {
          firstName: med.prescriber.firstName,
          lastName: med.prescriber.lastName,
          middleInitial: med.prescriber.middleInitial,
          id: med.prescriber.id,
          deaNumber: med.prescriber.deaNumber,
          phoneNumber: med.prescriber.phoneNumber,
          address: med.prescriber.address
            ? {
                address1: med.prescriber.address.address1,
                address2: med.prescriber.address.address2,
                city: med.prescriber.address.city,
                state: med.prescriber.address.state,
                zipcode: med.prescriber.address.zipcode
              }
            : undefined
        }
      };
    });
    if (this.selectedOTCs) {
      this.selectedOTCsToTransfer = this.selectedOTCs.map(function(med) {
        let sNonInPacketOTC: any = [];
        if (med.orderDetails && !med.inPackets) {
          med.orderDetails.forEach(orderDetail => {
            sNonInPacketOTC.push(orderDetail.orderCount + '  of ' + orderDetail.strength + ', Requested');
          });
        }

        if (sNonInPacketOTC.length > 0) {
          sNonInPacketOTC = sNonInPacketOTC.join(',');
        } else {
          sNonInPacketOTC = '';
        }

        let sDossage: any = [];
        let totalCount: number = 0;
        if (med.orderDetails) {
          med.orderDetails.forEach(orderDetail => {
            sDossage.push(orderDetail.strength);
            totalCount += orderDetail.orderCount;
          });
        }

        if (sDossage.length > 0) {
          sDossage = sDossage.join(',');
        } else {
          sDossage = '';
        }

        let sPacketTimePacketCount: any = [];
        if (med.orderDetails) {
          med.orderDetails.forEach(orderDetail => {
            if (med.inPackets) {
              for (let i = 0; i < orderDetail.orderCount; i++) {
                sPacketTimePacketCount.push(orderDetail.time + ':' + orderDetail.minute + orderDetail.mer);
              }
            }
          });
        }

        if (sPacketTimePacketCount.length > 0) {
          sPacketTimePacketCount = sPacketTimePacketCount.join(',');
        } else {
          sPacketTimePacketCount = '';
        }

        return {
          ndcCd: med.upc,
          rxcui: med.rxcui,
          description: '',
          isSelfPrescribed: true,
          shouldChase: false,
          doseTimes: sPacketTimePacketCount,
          dosage: sNonInPacketOTC,
          inPackets: med.inPackets,
          genericName: med.name,
          form: med.doseType,
          daysSupply: 30,
          lastFill: '0000-00-00',
          copay: '',
          strength: med.strength,
          count: totalCount
        };
      });
    }

    //Add Selected Maintenance Meds to Request
    request.medications = this.selectedMaintenanceMedications;

    //Add Selected OTC
    if (this.selectedOTCsToTransfer) {
      request.medications = request.medications.concat(this.selectedOTCsToTransfer);
    }
    //Add Encrypt Key
    request.key2id = this.authService.cryptoToken.key2id;
    return request;
  }

  onCompleteHandHandoffClicked($event) {
    //goto step 5
    this.currentStep = $event.number;
    this.tokenId = $event.tokenId;
    this.gotoStep(5);
  }

  async updatePharmacyUser(req, step) {
    this._pillPackService
      .updatePharmacyUser(req)
      .toPromise()
      .then(res => {
        if (res.errormessage) {
          if (step == 3) {
            this.isStepTwoFail = true;
          } else if (step == 4) {
            this.isStepThreeFail = true;
          }
        }
        if (!this.isStepTwoFail && !this.isStepThreeFail) {
          this.isIncompleteHandoff == false;
        } else {
          this.isIncompleteHandoff = true;
        }
        if (!res.errormessage) {
          this.isIncompleteHandoff = false;
        } else if (res.errormessage) {
          if (res.result === -95026) {
            this.alreadyEmailExist = true;
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            this.gotoStep(3);
          }
        }
        if (step == 4 && res.result !== -95026) {
          this.profileEmailUpdate();
        }
      });
  }

  navigatToConformationScreen() {
    //Navigate to confimation page
    this._router.navigate(['my-pillpack/confirmation']);
    this.sendNotification();
    sessionStorage.removeItem('otcTotal');
    sessionStorage.removeItem('selectedOTCs');
  }

  async gotoStep(step: number, disableFlag: boolean = false) {
    if (disableFlag) {
      return;
    }
    const { hasNonPharmacyMed } = this.pillpackForm.value;
    document.getElementById('payment-section').classList.add('hide');
    if (step == 5 && (this.isVerifiedEmail || this.isVerifyEmailProcessComplete)) {
      const request = this.createAddMedicationsRequest();
      const isSuccess = await this.sendPillPackMedications(request);
    }

    if (step == 4 && !this.isVerifiedEmail && !this.isVerifyEmailProcessComplete) {
      this.currentStep = 5;
      this.gotoStep(5);
    }
    if (step == 1) {
      this.alertService.clearError();
    }
    if (step == 2) {
      this.alertService.clearError();
      this.isStepTwoFail = false;
    }

    if (step == 3) {
      if (!this.alreadyEmailExist) {
        this.alertService.clearError();
      }
      this.isStepThreeFail = false;
      if (!this.alertService.errors['displaymessage']) {
        const prfEdtFrm = this.profileEditForm.value;
        const pillPackFrm = this.profileEditForm.value;
        prfEdtFrm.useridin = this.profile.useridin;
        prfEdtFrm.health.allergies = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').value;
        prfEdtFrm.health.conditions = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').value;
        if ((this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[2]) {
          prfEdtFrm.healthInfo.pregnant = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[2].get(
            'healthquestion'
          ).value;
        }
        var allergiestr = prfEdtFrm.health.allergies + '';
        var conditionstr = prfEdtFrm.health.conditions + '';

        var allerarr = allergiestr != null && allergiestr != '' ? allergiestr.replace(' ', '').split(',') : '';
        var condarr = conditionstr != null && conditionstr != '' ? conditionstr.replace(' ', '').split(',') : '';
        const req = {
          useridin: this.authService.useridin,
          member: {
            partner: {
              id: this.partnerId
            },
            pregnant: prfEdtFrm.healthInfo.pregnant,
            conditions: condarr.length > 0 ? condarr : undefined,
            allergies: allerarr.length > 0 ? allerarr : undefined,
            key2id: this.authService.cryptoToken.key2id
          }
        };
        const isSuccess = await this.updatePharmacyUser(req, step);
      }
    }

    if (step == 4) {
      console.log('address form', this.addressEditForm);

      // return false;

      document.getElementById('payment-section').classList.remove('hide');
      const prfEdtFrm = this.profileEditForm.value;
      const pillPackFrm = this.profileEditForm.value;

      prfEdtFrm.useridin = this.profile.useridin;
      const req = {
        useridin: this.authService.useridin,
        member: {
          partner: {
            id: this.partnerId
          },
          address: {
            street: this.addressEditForm.get('address1').value,
            street2: this.addressEditForm.get('address2').value,
            city: this.addressEditForm.get('city').value,
            state: this.addressEditForm.get('state').value,
            zipcode: this.addressEditForm.get('zipcode').value
          },
          key2id: this.authService.cryptoToken.key2id,
          mobileNumber: (this.addressEditForm.get('phoneNumber').value + '').replace(/-/g, ''),
          emailAddress: this.addressEditForm.get('emailAddress').value
        }
      };

      prfEdtFrm.phoneNumber = (this.addressEditForm.get('phoneNumber').value + '').replace(/-/g, '');
      prfEdtFrm.phoneType = 'MOBILE';
      const isSuccess = await this.updatePharmacyUser(req, step);
      const profilePhoneNumber = (this.profile.phoneNumber + '').replace(/-/g, '');
      if (!this.profile.isVerifiedMobile && this.profile.phoneNumber !== prfEdtFrm.phoneNumber) {
        this.profileService
          .updateProfile(prfEdtFrm, false, false, true, false, false)
          .flatMap(result => {
            return this.profileService.fetchProfileInfo();
          })
          .subscribe(
            profile => {},
            err => {
              // this.globalService.handleError(err.error, this.constants.displayMessage);
            }
          );
      }
      /*const currentEmail = this.profile.emailAddress;
      const updatedEmail = (this.addressEditForm.get('emailAddress').value + '');
      if (!this.isVerifiedEmail && !(currentEmail === updatedEmail) && !this.alreadyEmailExist) {
        prfEdtFrm.emailAddress = (this.addressEditForm.get('emailAddress').value + '');
        alert("Work"+this.alreadyEmailExist);
        this.profileService.updateProfile(prfEdtFrm, false, true, false, false, false).flatMap(result => {
          this.profileService.fetchProfileInfo().subscribe((res) => {
            this.profileService.setProfile(res);
          });
          return this.profileService.fetchProfileInfo();
        })
          .subscribe(
            profile => {
              this.diplayEmailAdress =profile.emailAddress;
             },
            err => {
              // this.globalService.handleError(err.error, this.constants.displayMessage);
            }
          );
      }*/
    }

    if (step == 6) {
      this._router.navigate(['my-pillpack/confirmation']);
      this.sendNotification();
    }

    if (this.currentStep == 2) {
      const prfEdtFrm = this.profileEditForm.value;
      const pillPackFrm = this.profileEditForm.value;

      prfEdtFrm.useridin = this.profile.useridin;
      prfEdtFrm.health.allergies = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').value;
      prfEdtFrm.health.conditions = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').value;
      this.profileService
        .updateProfile(prfEdtFrm, false, false, false, false, true)
        .flatMap(result => {
          return this.profileService.fetchProfileInfo();
        })
        .subscribe(
          profile => {},
          err => {
            // this.globalService.handleError(err.error, this.constants.displayMessage);
          }
        );
    }
    if (hasNonPharmacyMed && this.currentStep === 1) {
      this.isAddingOTC = true;
      if (step === 1 && this.currentStep === 1 && hasNonPharmacyMed) {
        this.isAddingOTC = false;
      }
      // this._router.navigate(['my-pillpack/add-otc']);
    } else {
      setTimeout(() => (this.currentStep = step), 0);
    }
    window.scrollTo(0, 0);
  }

  addQuesFormGroup(): FormGroup {
    return this._fb.group({
      healthHintAns: [''],
      healthquestion: ['', Validators.required]
    });
  }

  ngOnInit() {
    $('#ProfileWindow').modal({ dismissible: true });
    this.partnerId = sessionStorage.getItem('partnerId');
    const cachedPostLoginInformation = sessionStorage.getItem('postLoginInfo');
    if (cachedPostLoginInformation) {
      const myPostLoginInfo = JSON.parse(cachedPostLoginInformation);
      console.log('myPostLoginInfo', myPostLoginInfo);
      this.isCPDPPromotion = myPostLoginInfo.isCPDPPromotion;
    }

    if (!this.isCPDPPromotion) {
      this._router.navigate(['home']);
    }

    if (this.isCPDPPromotion && !this.partnerId) {
      this._router.navigate(['my-pillpack/landing']);
    }

    this.otcSummaryTotal = 0;
    this.maintenanceMedicationsSummaryTotal = 0;
    this.estimatedOrderTotal = 0;

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }
    sessionStorage.setItem('selectedOTCs', JSON.stringify([]));

    this.store.dispatch(new LoadMedications());
    if (this.profileService.getProfile() === null) {
      this.profileService.fetchProfileInfo().subscribe(res => {
        this.profileService.setProfile(res);
        this.updateProfile();
      });
    } else {
      this.updateProfile();
    }
  }

  profileEmailUpdate() {
    const prfEdtFrm = this.profileEditForm.value;
    prfEdtFrm.useridin = this.profile.useridin;
    const currentEmail = this.profile.emailAddress;
    const updatedEmail = this.addressEditForm.get('emailAddress').value + '';
    if (!this.isVerifiedEmail && !(currentEmail === updatedEmail)) {
      prfEdtFrm.emailAddress = this.addressEditForm.get('emailAddress').value + '';
      this.profileService
        .updateProfile(prfEdtFrm, false, true, false, false, false)
        .flatMap(result => {
          this.profileService.fetchProfileInfo().subscribe(res => {
            this.profileService.setProfile(res);
          });
          return this.profileService.fetchProfileInfo();
        })
        .subscribe(
          profile => {
            this.diplayEmailAdress = profile.emailAddress;
          },
          err => {
            // this.globalService.handleError(err.error, this.constants.displayMessage);
          }
        );
    }
  }

  ProfileModal(emailText) {
    if (emailText === 'mobile') {
      this.popupCnt = 'mobile phone';
      this.popuplink = 'phone';
    } else {
      this.popupCnt = 'email';
      this.popuplink = 'email';
    }
    $('#ProfileWindow').modal('open');
  }
  closeProfileModel() {
    $('#ProfileWindow').modal('close');
  }
  navigateProfilePage() {
    $('#ProfileWindow').modal('close');
    this._router.navigate(['/myprofile']);
  }

  updateProfile() {
    this.profile = this.profileService.getProfile();
    if (this.profile) {
      if (!this.profile.phoneType) {
        this.profile.phoneType = 'MOBILE';
      }
      const userRole = this.profileService.getUserRole();
      this.registeredUserOnly = userRole === 'REGISTERED-NOT-VERIFIED' || userRole === 'REGISTERED-AND-VERIFIED' ? true : false;
      this.address3 = '';
      this.shippingAddress.address1 = this.profile.address1;
      this.shippingAddress.address2 = this.profile.address2;
      this.shippingAddress.city = this.profile.city;
      this.shippingAddress.state = this.profile.state;
      this.shippingAddress.zipcode = this.profile.zip;
      this.shippingAddress.phoneNumber = this.profile.phoneNumber;
      this.shippingAddress.emailAddress = this.profile.emailAddress;
      const numericNumberReg = '^-?[0-9]\\d*(\\.\\d{1,2})?$';
      const defaultNumber = this.shippingAddress.phoneNumber ? this.formatPhone(this.shippingAddress.phoneNumber) : '';
      this.addressEditForm = this._fb.group({
        address1: [
          this.shippingAddress.address1,
          this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []
        ],
        address2: [this.shippingAddress.address2, this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
        city: [
          this.shippingAddress.city,
          this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []
        ],
        state: [this.shippingAddress.state, this.editAddress ? [Validators.required] : []],
        zipcode: [
          this.shippingAddress.zipcode,
          this.editAddress ? [Validators.required, Validators.minLength(5), Validators.pattern(numericNumberReg)] : []
        ],
        phoneNumber: [
          defaultNumber,
          this.editAddress ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
        ],
        emailAddress: [
          this.shippingAddress.emailAddress,
          this.editAddress ? [Validators.required, this.validationService.emailValidator()] : []
        ]
      });

      if ((this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls.length >= 2) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
          .get('healthHintAns')
          .setValue(this.profile.health.allergies);
        if (this.profile.health.allergies.length > 0) {
          (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
            .get('healthquestion')
            .setValue(this.profile.health.allergies.length > 0);
        }
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
          .get('healthHintAns')
          .setValue(this.profile.health.conditions);
        if (this.profile.health.conditions.length > 0) {
          (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
            .get('healthquestion')
            .setValue(this.profile.health.conditions.length > 0);
        }
      }
    }
  }
  AddOTCVitamin() {
    this.addOTCFlag = !this.addOTCFlag;
    if (!this.addOTCFlag) {
      this.selectedOTCs = [];
      sessionStorage.setItem('selectedOTCs', JSON.stringify(this.selectedOTCs));
      this.otcSummaryTotal = 0.0;
      this.estimatedOrderTotal = this.maintenanceMedicationsSummaryTotal + this.otcSummaryTotal;
    }
  }
  getBasePrice(price: number) {
    return ('' + price).split('.')[0];
  }

  getFloatPrice(price: number) {
    return price.toFixed(2).split('.')[1];
  }

  getSelfInfoForTitle(member: Member) {
    return member.relationship === 'self' ? ' (You)' : '';
  }

  ngOnDestroy() {}

  addedOTC($event) {
    console.log($event);
    this.otcSummaryTotal = $event;
    this.estimatedOrderTotal = this.maintenanceMedicationsSummaryTotal + this.otcSummaryTotal;
  }

  onDoneAddingOTC($event) {
    console.log($event);
    this.isAddingOTC = false;
    if ($event.length < 1) {
      if (this.selectedMaintenanceMedications.length < 1) {
        setTimeout(() => (this.currentStep = 1), 0);
      } else {
        setTimeout(() => (this.currentStep = 2), 0);
      }
    } else {
      setTimeout(() => (this.currentStep = 2), 0);
    }
  }

  formatPhone(inputPhoneNumber) {
    if (inputPhoneNumber !== undefined && inputPhoneNumber !== null && inputPhoneNumber !== '') {
      let phoneNumber: string = inputPhoneNumber;
      phoneNumber = phoneNumber.replace(/-/g, '');
      const areaCode = phoneNumber.slice(0, 3);
      const number = phoneNumber.slice(3);
      return areaCode + '-' + number.slice(0, 3) + '-' + number.slice(3);
    } else {
      return '';
    }
  }

  getFormatDateString(date) {
    return moment(date).format('L');
  }

  verifyEmail(emailId?: string) {
    if (!this.isVerifiedEmail) {
      this.alertService.clearError();
      const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
      if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
        this.sendcommchlaccesscode(emailId ? emailId : this.diplayEmailAdress, '').subscribe(
          res => {
            if (res['result'] === '0') {
              console.log('sendaccesscode success', res);
              this.alertService.clearError();
              // only if success
              this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.diplayEmailAdress);
              sessionStorage.setItem('maskedVerifyPhone', 'N');
              sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
              this.navigateToVerifyScreen();
            } else {
              if (res['displaymessage']) {
                this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
              }
            }
          },
          err => {
            console.log('error', err);
          }
        );
      } else {
        this.sendaccesscode('EMAIL', emailId ? emailId : this.diplayEmailAdress).subscribe(
          res => {
            if (res['result'] === '0') {
              const communicationChannel = this.http.handleDecryptedResponse(res);
              sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
              console.log('sendaccesscode success', res);
              this.alertService.clearError();
              // only if success
              const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
              const userId = sentMailId && sentMailId['commChannel'];
              this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
              sessionStorage.setItem('maskedVerifyPhone', 'N');
              sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
              this.navigateToVerifyScreen();
            } else {
              if (res['displaymessage']) {
                this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
              }
            }
          },
          err => {
            console.log('error', err);
          }
        );
      }
    }
  }

  navigateToVerifyScreen() {
    this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
  }

  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }

  private sendaccesscode(commChannelType, commChannel) {
    return this.profileService.sendaccesscode(commChannelType, commChannel);
  }

  private sendNotification() {
    const shippingAmt = this.rxOrderSummary.shippingAmount == 0 ? 'No Cost' : this.rxOrderSummary.shippingAmount + '';
    const dispenserAmt = this.rxOrderSummary.dispenserAmount == 0 ? 'No Cost' : this.rxOrderSummary.dispenserAmount + '';
    const medicationAmt = this.maintenanceMedicationsSummaryTotal != null ? this.maintenanceMedicationsSummaryTotal.toFixed(2) : 0.0;
    const vitaminsAmt = this.otcSummaryTotal != null ? this.otcSummaryTotal.toFixed(2) : 0.0;
    const totalAmt = this.estimatedOrderTotal != null ? this.estimatedOrderTotal.toFixed(2) : 0.0;
    const yourMedications = 'Your Medications~$' + medicationAmt;
    const yourVitaminsAndOTCs = 'Your Vitamins & OTCs~$' + vitaminsAmt;
    const shipping = 'Shipping~' + shippingAmt;
    const dispenser = 'Reusable Dispenser~' + dispenserAmt;
    const yourTotal = 'Your Estimated Total~$' + totalAmt;
    console.log('yourMedications :: ' + yourMedications + ' :: yourVitaminsAndOTCs :: ' + yourVitaminsAndOTCs + 'yourTotal ::' + yourTotal);
    const notificationRequest = {
      useridin: this.authService.useridin,
      commChannel: this.diplayEmailAdress,
      commChannelType: 'EMAIL',
      templateKeyword: 'CPDPNOTIFICATION_EMAIL',
      key2id: this.authService.cryptoToken.key2id,
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue:
            this.authService && this.authService.authToken && this.authService.authToken.firstName
              ? this.titleCase.transform(this.authService.authToken.firstName)
              : ''
        },
        {
          keyName: 'OrderDetails',
          keyValue: [yourMedications, yourVitaminsAndOTCs, shipping, dispenser, yourTotal]
        }
      ]
    };
    console.log('notificationRequest=', notificationRequest);
    this.profileService.sendUpdateNotification(notificationRequest).subscribe(res => {});
  }

  sendUpdateNotification(request) {
    return this.http.post(this.constants.sendUpdateNotification, this.http.handleRequest(request));
  }

  private sendcommchlaccesscode(email, mobile) {
    return this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, ''));
  }
}
