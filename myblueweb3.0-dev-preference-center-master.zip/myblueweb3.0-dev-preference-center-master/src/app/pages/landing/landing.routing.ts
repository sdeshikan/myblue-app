import { RouterModule, Routes } from '@angular/router';
import { AuthUserResolverService } from '../../shared/routeresolvers/authenticateduser-resolver.service';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { AuthUserLandingComponent } from './authenticated-user/authenticated-user.component';
import { AllowAVOnlyGuard } from './landing.guard';
const LANDING_ROUTER: Routes = [
  {
    path: '',
    component: AuthUserLandingComponent,
    resolve: {
      postLoginInfo: AuthUserResolverService
    },
    canActivate: [AuthGuard, AllowAVOnlyGuard]
  }
];

export const LandingRouter = RouterModule.forChild(LANDING_ROUTER);
