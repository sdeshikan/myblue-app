import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from '../../../shared/services/auth.service';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { ActivatedRoute, Router } from '@angular/router';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import {
  GetPlansBenefitsListResponseModelInterface,
  GetPlansBenefitsListPlanItemInterface
} from '../modals/interfaces/get-plans-benefits-list-models.interface';
import { GetBenefitCoverageResponseModelInterface, EocPolicyInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { ConstantsService, AlertService } from '../../../shared/shared.module';
import { HomePageInfoModel } from '../../landing/landing.model';
import { FeatureToggleService } from '../../../services/feature-service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';

@Component({
  selector: 'app-tax-forms-overall-view',
  templateUrl: './tax-forms-overall-view.component.html',
  styleUrls: ['./tax-forms-overall-view.component.scss']
})
export class TaxFormsOverallViewComponent implements OnInit {

  public memberInfo: HomePageInfoModel;
  public breadCrumbs: BreadCrumb[] = [];
  public planBenefitsList: GetPlansBenefitsListResponseModelInterface = null;
  public benefitCoverageDocs: GetBenefitCoverageResponseModelInterface = null;
  public policiesInBenefitCoverage: EocPolicyInterface = null;
  public hasContents: boolean;
  title: string = 'Explanation of Benefits';
  public oMemberInboxLinks;
  fpoHomeTargetUrl: string = this.constants.drupalTestUrl + '/page/mydocuments';
  fpoMyPlanDocumentTargetUrl: string = this.constants.drupalTestUrl + '/page/myplan-documents';
  fpobenefitCoverageListTargetUrl: string = this.constants.drupalTestUrl + '/page/bluecare-documents';
  public no_doc_found_component_mode: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public selectedPlan: GetPlansBenefitsListPlanItemInterface;
  public isMedicareUser: boolean = false;
  fpoPreferenceUrl: string;
  preferenceObject: any;
  selectedFilterId: string;
  isTaxFormsEnabled: boolean = false;
  years: string[] = [new Date().getFullYear() - 1 + '', new Date().getFullYear() - 2 + ''];
  // showPreferenceModal: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private constants: ConstantsService,

    private profileService: ProfileService,
    private authService: AuthService,
    private featureToggleService: FeatureToggleService
  ) {
    this.no_doc_found_component_mode.mode = MessageCenterConstants.flags.documentsMode;
    this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
  }

  ngOnInit() {
    this.isTaxFormsEnabled = this.featureToggleService.isFeatureEnabled('tax-forms');
    //Show paperless promo
    setTimeout(() => {
      this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
      if (this.preferenceObject.Preferences) {
        this.preferenceObject.Preferences.map(item => {
          if (item.PreferenceType === '1') {
            this.selectedFilterId = item.FilterID;
          }
        });
        if (this.selectedFilterId === 'DOCS_PLAN_MAIL') {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
        } else {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/home-promoblock2';
        }
      } else {
        this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
      }
      this.profileService.preferencePromo(this.fpoPreferenceUrl);
    }, 200);

    this.prepareChildBreadCrumbs(this.router.url.split('/')[this.router.url.split('/').length - 1]);

  }



  openTaxForms(year: string) {
    this.router.navigate(['/message-center/documents/tax-forms/details'], { queryParams: { year: year } });
  }

  prepareChildBreadCrumbs(folderId) {
    console.log('folderid', folderId, this.breadCrumbs);
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
    });
    this.breadCrumbs.push({
      label: 'My Inbox',
      url: ['/message-center']
    });
    this.breadCrumbs.push({
      label: 'My Documents',
      url: ['/message-center/documents/home']
    });
    this.breadCrumbs.push({
      label: 'Tax Forms',
      url: ['/message-center/documents/tax-forms']
    });

  }

}
