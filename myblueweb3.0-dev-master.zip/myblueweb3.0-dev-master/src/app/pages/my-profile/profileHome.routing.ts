import { RouterModule, Routes } from '@angular/router';
import { MyprofileResolverService } from '../../shared/routeresolvers/myprofile-resolver.service';
import { ProfileComponent } from './profile/profile.component';
// import { RaceLanguageEthinicityComponent } from './race-language-ethinicity/race-language-ethinicity.component';
import { VerifyEmailMobileComponent } from './verify-email-mobile/verify-email-mobile.component';
// import { UpdatePasswordComponent } from './account-security/update-password/update-password.component';
import { AboutMeComponent } from './about-me/about-me.component';
import { AccountSecurityComponent } from './account-security/account-security.component';
import { CommunicationPreferenceComponent } from './communication-preference/communication-preference.component';
import { AuthCentralLayoutComponent } from '../../shared/layouts/AuthCentralLayoutComponent/AuthCenralLayout.component';
import { AuthenticatedLayoutComponent } from '../../shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { ContactInformationComponent } from './contact-information/contact-information.component';
import { ScopeGuard } from '../../shared/utils/scope.guard';
import { ContactInformationResolver } from './contact-information/contact-information.resolver';

const REGISTER_ROUTER: Routes = [
  {
    path: '',
    component: AuthenticatedLayoutComponent,
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService
        },
        component: ProfileComponent
      }
    ]
  },
  // {
  //   path: 'race',
  //   component: AuthenticatedLayoutComponent,
  //   data: {
  //     pageTitle: 'Race Ethnicity Language',
  //     breadcrumb: 'Race Ethnicity Language'
  //   },
  //   children: [
  //     {
  //       path: '',
  //       resolve: {
  //         profile: MyprofileResolverService
  //       },
  //       component: RaceLanguageEthinicityComponent
  //     }
  //   ],
  // },
  {
    path: 'verify',
    component: AuthCentralLayoutComponent,
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService
        },
        component: VerifyEmailMobileComponent
      }
    ]
  },
  // {
  //   path: 'updatePassword',
  //   component: AuthCentralLayoutComponent ,
  //   data: {
  //     pageTitle: 'Update Password',
  //     breadcrumb: 'Update Password'
  //   },
  //   children: [
  //     {
  //       path: '',
  //       resolve: {
  //         profile: MyprofileResolverService
  //       },
  //       component: UpdatePasswordComponent
  //     }
  //   ]
  // },
  {
    path: 'about-me',
    component: AuthenticatedLayoutComponent,
    data: {
      pageTitle: 'About Me',
      breadcrumb: 'About Me'
    },
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService
        },
        component: AboutMeComponent
      }
    ]
  },
  {
    path: 'contact-info',
    component: AuthenticatedLayoutComponent,
    data: {
      pageTitle: 'Contact Information',
      breadcrumb: 'Contact Information'
    },
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService,
          commstatus: ContactInformationResolver
        },
        component: ContactInformationComponent
      }
    ]
  },
  {
    path: 'account-security',
    component: AuthenticatedLayoutComponent,
    data: {
      pageTitle: 'Account Security',
      breadcrumb: 'Account Security'
    },
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService
        },
        component: AccountSecurityComponent
      }
    ]
  },
  {
    path: 'communication-preferences',
    canActivate: [ScopeGuard],
    component: AuthenticatedLayoutComponent,
    data: {
      pageTitle: 'Paperless Preferences',
      breadcrumb: 'Paperless Preferences'
    },
    children: [
      {
        path: '',
        resolve: {
          profile: MyprofileResolverService
        },
        component: CommunicationPreferenceComponent
      }
    ]
  }
];

export const ProfileHomeRouter = RouterModule.forChild(REGISTER_ROUTER);
