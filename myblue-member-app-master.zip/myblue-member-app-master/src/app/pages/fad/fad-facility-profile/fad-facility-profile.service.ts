import { Injectable } from '@angular/core';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { Observable } from 'rxjs/Observable';
import { HttpParams } from '@angular/common/http';
import { FadConstants } from '../constants/fad.constants';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../../shared/shared.module';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';
import { map } from "rxjs/operators";

@Injectable()
export class FadFacilityProfileService {
  public facilityProfile: any;
  constructor(private http: AuthHttp, private authService: AuthService) {}

  getFadGetprofessionalprofileDetails(request: FadFacilityProfileRequestModelInterface): Observable<FadFacilityResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    // this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(FadConstants.urls.facilityProfile, request)
  }

}
