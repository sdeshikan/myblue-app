export interface TaxFormDataModel {
    name: string;
    year: number;
    file: string;
}
