import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '../../../../../shared/services/alert.service';
import { TaxFormsState } from '../../../../../store/state/taxforms.state';
import { TaxFormViewPage } from './tax-form-view.page';
import { of } from 'rxjs';

describe('TaxFormViewPage', () => {
  let component: TaxFormViewPage;
  let fixture: ComponentFixture<TaxFormViewPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaxFormViewPage],
      providers: [FileTransfer, File, LocalNotifications, FileOpener, AndroidPermissions, AlertService],
      imports: [HttpClientTestingModule, IonicModule, RouterTestingModule, NgxsModule.forRoot([TaxFormsState])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxFormViewPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Checking the Default componet and template value.', () => {
    it('Identify the title Text', () => {
      const element = document.querySelector('ion-title');
      expect(element.innerHTML).toEqual('Tax Forms');
    });

    it('Check hexToBase64 functions', () => {
      const txt = component.hexToBase64('Test Pdf');
      expect(txt).toEqual('AAAA');
    });
    it('Child Node counts', () => {
      const element = document.querySelector('.tax_form_content');
      expect(element.childElementCount).toEqual(1);
    });
  });

  describe('Tax Form Page View With Mock Data', () => {
    it('Checking Tax Form File name', () => {
      Object.defineProperty(component, 'taxForms$', { writable: true });
      component.taxForms$ = of({
        formData: [
          {
            year: 2019,
            name: '2019-HC1099',
            file: '255044462d312e340a25e2e3cfd3'
          }
        ]
      });
      component = fixture.componentInstance;
      fixture.detectChanges();
      const element = document.querySelector('.m-r-5');
      expect(element.innerHTML).toEqual('2019-HC1099');
    });
    it('Checking Tax Form Year', () => {
      Object.defineProperty(component, 'taxForms$', { writable: true });
      component.taxForms$ = of({
        formData: [
          {
            year: 2019,
            name: '2019-HC1099',
            file: '255044462d312e340a25e2e3cfd3'
          }
        ]
      });
      component = fixture.componentInstance;
      fixture.detectChanges();
      const element = document.querySelector('.center-align ion-grid ion-row');
      expect(element.childNodes[1].childNodes[0].textContent).toEqual(' 2019 ');
    });
  });

  describe('Tax Form Page View With Mock Data as empty', () => {
    it('Checking the Tax Form Not Available', () => {
      Object.defineProperty(component, 'taxForms$', { writable: true });
      component.taxForms$ = of({
        formData: []
      });
      component = fixture.componentInstance;
      fixture.detectChanges();
      const element = document.querySelector('.no-tax-available-grid .no-tax-forms-top');
      expect(element.innerHTML).toEqual(' Your tax forms are not available it. ');
    });
  });
});
