import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { DocumentsService } from '../documents/documents.service';
import { GetBenefitTextRequestModel } from '../modals/getBenefitText.model';
import { GetPlansBenefitsListPlanItemInterface } from '../modals/interfaces/get-plans-benefits-list-models.interface';
import {
  GetBenefitTextRequestModelInterface,
  GetBenefitTextResponseModelInterface
} from '../modals/interfaces/getBenefitText-models.interface';
import { MessageCenter_BenefitTextType } from '../modals/types/message-center.types';

@Injectable()
export class DocumentDetailService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  private benefitTextType: MessageCenter_BenefitTextType = null;

  constructor(private http: HttpClient, private constants: ConstantsService, private documentsService: DocumentsService) {}

  public getBenefitTextType(): number {
    const cachedBenefitTextType: string = sessionStorage.getItem('messageCenter_BenefitTextType');
    const cachedBenefitTextTypeNumber = cachedBenefitTextType ? Number(cachedBenefitTextType) : null;
    return this.benefitTextType ? this.benefitTextType : cachedBenefitTextTypeNumber;
  }

  public setBenefitTextType(benefitTextType) {
    sessionStorage.setItem('messageCenter_BenefitTextType', benefitTextType);
    this.benefitTextType = benefitTextType;
  }

  public getBenefitTextData(): Observable<GetBenefitTextResponseModelInterface> {
    const benefitTextResponseRequest: GetBenefitTextRequestModelInterface = new GetBenefitTextRequestModel();

    const selectedPlan: GetPlansBenefitsListPlanItemInterface = this.documentsService.getSelectedPlan();

    benefitTextResponseRequest
      .setUseridin(this.useridin)
      .setPlanName(selectedPlan.planName)
      .setCoveragePackageCode(selectedPlan.coveragePackageCode);

    return this.http.post<GetBenefitTextResponseModelInterface>(this.constants.getBenefitsTextUrl, benefitTextResponseRequest).pipe(
      map(response => {
        if (response.result < 0) {
          sessionStorage.setItem('messageCenter_GetBenefitTextResponse', null);
          return response as GetBenefitTextResponseModelInterface;
        } else {
          const getBenefitsTextResponse: GetBenefitTextResponseModelInterface = response as GetBenefitTextResponseModelInterface;
          if (getBenefitsTextResponse.result && getBenefitsTextResponse.result < 0) {
            sessionStorage.setItem('messageCenter_GetBenefitTextResponse', null);
            return;
          } else {
            sessionStorage.setItem('messageCenter_GetBenefitTextResponse', JSON.stringify(getBenefitsTextResponse));
            return getBenefitsTextResponse;
          }
        }
      })
    );
  }
}
