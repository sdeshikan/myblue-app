import { AccumulatorModel } from './accumulator.model';
import { MemberDeductibleModel } from './member-deductible.model';

export class FamilyDeductibleResponseModel {
  hasFamily: boolean;
  members: MemberDeductibleModel[];
  accums: AccumulatorModel[];
}
