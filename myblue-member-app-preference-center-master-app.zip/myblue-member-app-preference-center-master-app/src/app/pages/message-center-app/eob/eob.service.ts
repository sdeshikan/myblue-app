import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { EOBListRequestModelInterface } from './models/eob-data-model.interface';

@Injectable()
export class EOBService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private http: HttpClient, private constants: ConstantsService) {}

  getEobList(reqParams?: EOBListRequestModelInterface): Observable<any> {
    const request = reqParams || { useridin: this.useridin };
    return this.http.post(this.constants.getEobListUrl, request);
  }
  getEOBDocumentLink(reqParams): Observable<any> {
    return this.http.post(this.constants.benefitsLinkUrl, reqParams);
  }
}
