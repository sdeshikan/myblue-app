import { Component, OnDestroy, OnInit } from '@angular/core';
import { FadDoctorProfileService } from './fad-doctor-profile.service';

import { FAD_CONSTANTS } from '../constants/fad.constants';

import { ActivatedRoute, Router } from '@angular/router';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';

import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/shared.module';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import {
  FadDoctorProfileRequestModel,
  FadDoctorRatingsRequestModel,
  FadDoctorRatingsResponseModel,
  FadProfessionalResponseModel
} from '../modals/fad-doctor-profile-details.model';
import {
  FadDoctorProfileRequestModelInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface,
  FadLocationDetailsInterface,
  FadProfessionalResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';

import { PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { TooltipPopoverComponent } from '../../../shared/components/tooltip-popover/tooltip-popover.component';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadService } from '../fad.service';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { BreadCrumb } from '../utils/fad.utils';

@Component({
  selector: 'app-fad-doctor-profile',
  templateUrl: './fad-doctor-profile.component.html',
  styleUrls: ['./fad-doctor-profile.component.scss']
})
export class FadDoctorProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getMLEIndicator) mleIndicator: string;
  @SelectSnapshot(AppSelectors.getMLEEligibility) mleEligibility: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  public doctorName: string;
  public identifiers = [];
  public languages = [];
  public education = {};
  public awards = [];
  submenu: any = {};
  public outOfNetworkFlag: boolean;
  public noNetworkSelectedFlag: boolean;
  public isDisplaySpinnerProfessional = false;
  public isShowProfessionalDetialsSection = false;
  private selectedLocationIndex = 0;
  public fadProfessionalResposeData: FadProfessionalResponseModelInterface;
  public selectedLocationDetails: FadLocationDetailsInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public accordianToggleStatus: any = {};
  fadDoctorRatingsResponseData: FadDoctorRatingsResponseModelInterface;

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  networkId: number;

  reviewsListLimit = 3;
  reviewsLoadMoreLimit = 5;

  // Procedure details
  public isProcedure = false;
  public procedureTitle = '';
  public procedureId = 0;
  public icon = false;
  public chapter224 = false;
  public eligibility: string;
  public medicareuser = true;
  public tierTooltipDescription: string;
  public tierTooltip = [];
  public displayRatealinkdentalnetwork = true;
  public awardIndex = 0;
  public profileTooltip = [];
  public npToolTipDescription = '';
  public identifierToolTipDescription = '';
  public bcToolTipDescription = '';
  public gawdToolTipDescription = '';
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  public fadDoctorProfileData: FadProfessionalResponseModelInterface = null;
  disclaimerBcbsBottomCostModule: any;
  disclaimerBcbsTopProfile: any;
  isActive = false;
  tooltips = { patient: false, tier: false };

  constructor(
    private doctorProfileService: FadDoctorProfileService,
    private router: Router,
    private fadDoctorProfileService: FadDoctorProfileService,
    private fadSearchResultsService: FadSearchResultsService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private fadService: FadService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private facilityProfileService: FadFacilityProfileService,
    private popoverController: PopoverController,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {}

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_FAD_DoctorProfile);

    this.chapter224 = this.mleIndicator === 'lite';

    if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
      this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
    }

    if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
      this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
    }

    if (this.authToken != null) {
      if (this.authToken.userType != null || this.authToken.userType !== undefined) {
        this.medicareuser = this.authToken.userType.toLowerCase() !== 'medicare';
      }
    }

    this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Doctor Details').setUrl('/fad/doctor-profile'));
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    const affiliatedlinkedid = sessionStorage.getItem('linkedAffiliationId');

    this.eligibility = this.mleEligibility;

    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
      this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
      if (affiliatedlinkedid === '' || affiliatedlinkedid == null || affiliatedlinkedid === 'null') {
        this.isProcedure = searchCriteria.getSearchText().isProcedure();
        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
      } else {
        this.isProcedure = false;
      }
      this.networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;


      // tslint:disable-next-line:no-magic-numbers
      if (this.networkId === 311005006 || this.networkId === 311005007) {
        this.displayRatealinkdentalnetwork = false;
      }
    }

    const resolvedData =
      this.fadDoctorProfileData == null ? this.route.snapshot.data.fadProfessionalResposeData : this.fadDoctorProfileData;
    if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
      this.isShowProfessionalDetialsSection = false;
      this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
    } else {
      this.fadProfessionalResposeData = new FadProfessionalResponseModel();
      this.fadProfessionalResposeData = resolvedData;
      console.log(resolvedData);
      if (this.fadProfessionalResposeData && this.fadProfessionalResposeData.disclaimers) {
        this.disclaimers = this.fadProfessionalResposeData.disclaimers;
        this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
          return disclaimers.category === FAD_CONSTANTS.text.disclaimerProfileTopList;
        });
        this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
          return disclaimers.category === FAD_CONSTANTS.text.disclaimerProfileBottomList;
        });
        this.disclaimerBcbsBottomCostModule = this.disclaimers.filter(disclaimers => {
          return disclaimers.category === FAD_CONSTANTS.text.disclaimerBcbsBottomCostModule;
        });
        this.disclaimerBcbsTopProfile = this.disclaimers.filter(disclaimers => {
          return disclaimers.category === FAD_CONSTANTS.text.disclaimerBcbsTopProfile;
        });
        this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
      }
      if (this.fadProfessionalResposeData && this.fadProfessionalResposeData.onRecordDiclaimers) {
        this.onRecordDiclaimers = this.fadProfessionalResposeData.onRecordDiclaimers;
        if (
          this.onRecordDiclaimers &&
          this.onRecordDiclaimers.category &&
          this.onRecordDiclaimers.category === 'on_record' &&
          this.onRecordDiclaimers.text
        ) {
          this.disclaimersFlag = true;
          this.disclaimersText = this.onRecordDiclaimers.text;
        }
      }
      // this.fadProfessionalResposeData.locations = resolvedData.locations;
      this.fadProfessionalResposeData = {
        ...this.fadProfessionalResposeData,
        ...{ locations: resolvedData ? resolvedData.locations : null }
      };
      this.networkChanged = sessionStorage.getItem('networkChange');
      const locationId = sessionStorage.getItem('locationId');
      this.loadDetailsBasedOnLocation(locationId, false);
      this.isShowProfessionalDetialsSection = true;
    }
    this.getNPToolTipDescription();
    this.getProfessionalratings();
  }
  getNPToolTipDescription() {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip.code === 'PANP') {
          this.npToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPIN') {
          this.identifierToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PBCH') {
          this.bcToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPAA') {
          this.gawdToolTipDescription = tooltip.toolTip.description;
        }
      });
    }
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  toggleAccordion(listItem, $event) {
    if ($event) {
      $event.stopPropagation();
    }
    if (this.accordianToggleStatus[listItem] === undefined) {
      this.accordianToggleStatus[listItem] = false;
    }
    this.accordianToggleStatus[listItem] = !this.accordianToggleStatus[listItem];
  }
  getRating(ratings, totalReviews) {
    this.startRating = new StarRatingComponentInputModel();

    this.startRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.startRating;
  }

  public getReviewRating(ratings) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);

    this.startRating.showReviewCount = false;
    return this.startRating;
  }

  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
  }

  redirectToFacility(facilityId) {
    if (facilityId) {
      this.facilityProfileService.facilityProfile = facilityId;
      sessionStorage.setItem('facilityProfileId', facilityId.toString());
      sessionStorage.setItem('facilityLocationFlag', 'true');
      this.router.navigate([FAD_CONSTANTS.urls.fadFacilityProfilePage]);
    }
  }

  loadDetailsBasedOnLocation(locationsId, change: boolean) {
    this.awards = [];
    sessionStorage.setItem('locationId', locationsId);
    this.selectedLocationIndex = locationsId;
    if (change) {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const professionalId = parseInt(sessionStorage.getItem('professionalId'));

      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FAD_CONSTANTS.defaults.geo;

      const locationId = locationsId;

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setProfessional(professionalId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));
      if (sessionStorage.getItem('linkedAffiliationId')) {
        fadDoctorProfileRequestParams['linkedAffiliationId'] = sessionStorage.getItem('linkedAffiliationId');
      } else if (searchCriteria && searchCriteria.getSearchText().isProcedure()) {
        const procedureID = searchCriteria.getSearchText().getProcedureId();
        fadDoctorProfileRequestParams.setProcedureId(procedureID);

        fadDoctorProfileRequestParams.setRadius(
          // tslint:disable-next-line:no-magic-numbers
          sessionStorage.getItem('radius') !== 'null' ? Number(sessionStorage.getItem('radius')) : 25
        );
      }

      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }

      fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');

      this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {
        this.fadDoctorProfileData = data;
        this.ngOnInit();
      });
    }

    this.selectedLocationDetails = this.fadProfessionalResposeData.locations
      ? this.fadProfessionalResposeData.locations.find(p => p.id.toString() === locationsId)
      : null;

    if (this.selectedLocationDetails && this.selectedLocationDetails.awards) {
      this.selectedLocationDetails.awards.forEach(award => {
        this.awards.push(award);
      });
    }
    if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
      this.getToolTipDescription(this.tierTooltip, this.selectedLocationDetails.tiers.description);
    }
    this.accordianToggleStatus = {};
  }

  public copyIdentifierValue(event, inputId: string): void {
    const element: any = document.querySelector('#' + inputId);
    element.select();
    document.execCommand('copy');
    element.setSelectionRange(0, 0);
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  public showCostBreakdown(facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.parentPage = FAD_CONSTANTS.text.doctorPage;
    this.router.navigate([`/fad/cost-breakdown`]);
  }

  public getDirections(location, event): void {
    const locationURL = 'http://maps.google.com/?q=' + encodeURI(location);
    window.open(locationURL, '_self');
  }

  public isAnonymousUser() {
    let returnValue = false;
    try {
      const userid = this.useridin;
      returnValue = userid && userid !== 'undefined' && userid !== 'null' ? false : true;
    } catch (exception) {}
    return returnValue;
  }

  private getProfessionalratings(): void {
    this.isDisplaySpinnerProfessional = true;
    const fadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    const ratingsIdentifier: string = this.fadProfessionalResposeData['ratingsIdentifier'];
    const reviewIdentifier: string = this.fadProfessionalResposeData['reviewIdentifier'];
    try {
      fadDoctorProfileRequestParams.setRatingIdentifier(ratingsIdentifier);
      fadDoctorProfileRequestParams.setReviewIdentifier(reviewIdentifier);
      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }
      this.fadDoctorProfileService.getProfessionalratings(fadDoctorProfileRequestParams).subscribe(
        responseData => {
          if (responseData) {
            this.fadDoctorRatingsResponseData = new FadDoctorRatingsResponseModel();
            this.fadDoctorRatingsResponseData = responseData;
          }
        },
        error => {
          this.isDisplaySpinnerProfessional = false;
        }
      );
    } catch (exception) {
      this.isDisplaySpinnerProfessional = false;
    }
  }

  public loadMoreReviews() {
    this.reviewsListLimit += this.reviewsLoadMoreLimit;
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public reviewPage() {
    if (this.authToken && this.scopeName === 'AUTHENTICATED-AND-VERIFIED') {
      sessionStorage.setItem('doctorreviewer', this.fadProfessionalResposeData['doctorName'].toString());
      sessionStorage.setItem('reviewIdentifier', this.fadProfessionalResposeData['reviewIdentifier'].toString());
      this.router.navigate(['/fad/review']);
    } else if (this.scopeName === 'REGISTERED-NOT-VERIFIED') {
      this.router.navigate(['/register/register-detail']);
    } else {
      this.router.navigate(['./login']);
    }
  }
  public convertAmountToDecimalValue(value) {
    const intPart = Math.trunc(value);
    const floatPart = Number((value - intPart).toFixed(2));
    const decimal: string[] = floatPart.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }
  public reviewBenefits(): void {
    // throw new Error('reviewBenefits Method not implemented.');
    this.fadService.reviewMyBenfits();
  }

  async showPopover($event: any, toolTipDescription: any, key: string) {
    this.tooltips[key] = true;
    const popover = await this.popoverController.create({
      component: TooltipPopoverComponent,
      event: $event,
      mode: 'ios',
      componentProps: {
        tooltipText: toolTipDescription
      }
    });
    await popover.present();
    from(popover.onDidDismiss()).subscribe(() => (this.tooltips[key] = false));
  }
}
