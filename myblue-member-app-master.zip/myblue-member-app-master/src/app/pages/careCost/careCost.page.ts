import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SsoService } from '../sso/sso.service';
import { IabService } from '../../shared/services/iab/iab.service';
import { AuthService } from '../../shared/services/auth.service';
import { ConstantsService } from '../../shared/shared.module';
import { HomeService } from '../../shared/services/home.service';

@Component({
  selector: 'app-careCost',
  templateUrl: 'careCost.page.html',
  styleUrls: ['careCost.page.scss']
})
export class CareCostPage implements OnInit {
  homeNavigationApiResponse: any;
  listItems: CareCostItemType[];
  isAuthenticatedUser: boolean;
  callNurseLine: CallNurseLine;

  constructor(
    private router: Router,
    private ssoService: SsoService,
    private iabService: IabService,
    private authService: AuthService,
    private constants: ConstantsService,
    public homeService: HomeService
  ) {}

  ngOnInit() {}

  ionViewWillEnter() {
    const scopeName = this.authService.getScopeName();
    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
    this.initializeItemList();
  }

  initializeItemList() {
    this.homeService.setSessionLinks();

    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        const findADoctorUrl = this.homeNavigationApiResponse.APPTextUrl3 || '';
        const callNurseLinkUrl = this.homeNavigationApiResponse.APPTextUrl2 || '';
        this.callNurseLine = { labelText: 'Call the 24-Hour Nurse Line', phoneNumber: callNurseLinkUrl, icon: 'fal fa-phone fa-lg' };
        this.listItems = [
          {
            label: 'Find a Doctor & Estimate Costs',
            icon: 'fal fa-stethoscope fa-lg',
            url: findADoctorUrl,
            isSSO: true,
            ssoType: 'fad',
            isPhone: false
          },
          {
            label: 'Live Video Visits with Well Connection',
            icon: 'fal fa-comment-medical fa-lg',
            url: this.constants.wellConnectionUrl,
            isSSO: false,
            ssoType: '',
            isPhone: false
          }
        ];
      }
    });
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  navigate(item: CareCostItemType) {
    if (item.url.endsWith('fad')) {
      const postLoginInfo = sessionStorage.getItem('postLoginInfo');
      const isSmartShopperUser = postLoginInfo ? this.checkSmartShopperUser(JSON.parse(postLoginInfo)) : false;
      if (isSmartShopperUser) {
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['tabs/fad']);
      }
      return;
    }
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else {
      this.iabService.create(item.url);
    }
  }
}

interface CareCostItemType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
}

interface CallNurseLine {
  labelText: string;
  phoneNumber: string;
  icon: string;
}
