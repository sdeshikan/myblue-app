import {
  GetDemographicInfoRequestModelInterface,
  GetDemographicInfoResponseModelInterface
} from './interfaces/get-demographic-info.interface';
import {
  BaseDemographicInfoModel,
  MemberProfileGenericListEntityModel,
  MemberProfileGenericRequestModel
} from './member-profile-generics.model';

// tslint:disable-next-line:no-empty-interface
export class GetDemographicInfoRequestModel extends MemberProfileGenericRequestModel implements GetDemographicInfoRequestModelInterface {}

export class GetDemographicInfoResponseModel extends BaseDemographicInfoModel implements GetDemographicInfoResponseModelInterface {
  ethnicityList: MemberProfileGenericListEntityModel[];
  raceList: MemberProfileGenericListEntityModel[];
  languageList: MemberProfileGenericListEntityModel[];
  latinoOriginList: MemberProfileGenericListEntityModel[];
}
