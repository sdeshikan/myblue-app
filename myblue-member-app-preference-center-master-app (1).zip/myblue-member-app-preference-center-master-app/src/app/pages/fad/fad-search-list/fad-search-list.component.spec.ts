import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSearchListComponent } from './fad-search-list.component';
import { FadSearchListService } from './fad-search-list.service';

describe('FadSearchListComponent', () => {
  let component: FadSearchListComponent;
  let fixture: ComponentFixture<FadSearchListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadSearchListComponent],
      providers: [
        FadSearchListService,
        FadSearchResultsService,
        FadProfessionalCompareService,
        ConstantsService,
        FadLandingPageService,
        BcbsmaHttpService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadSearchListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
