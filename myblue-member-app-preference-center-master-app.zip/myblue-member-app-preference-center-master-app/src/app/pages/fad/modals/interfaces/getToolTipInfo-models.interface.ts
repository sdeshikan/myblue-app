import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';

export interface GetToolTipInfoRequestModelInterface {
    useridin: string;
    getUserId(): string;
    setUserId(useridin: string): GetToolTipInfoRequestModelInterface;
}
