import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { AuthGuard } from '../../shared/utils/auth.guard';
// import { AuthHttp } from '../../shared/services/authHttp.service';
import { SharedModule, AuthService, ConstantsService } from '../../shared/shared.module';
// import { authHttpFactory } from '../../shared/utils/authHttp.factory';
import { FadLandingPageComponent } from './fad-landing-page/fad-landing-page.component';
import { FadService } from './fad.service';
import { FadRouter } from './fad.routing';
import { FadLandingPageService } from './fad-landing-page/fad-landing-page.service';
import { FadMedicalIndexComponent } from './fad-medical-index/fad-medical-index.component';
import { FadMedicalIndexService } from './fad-medical-index/fad-medical-index.service';
// import { HttpClient } from '@angular/common/http';
import { FadSearchResultsComponent } from './fad-search-results/fad-search-results.component';
import { FadNoDocsPageComponent } from './fad-no-docs-page/fad-no-docs-page.component';
import { FadSearchResultsService } from './fad-search-results/fad-search-results.service';
import { FadNoDocsPageService } from './fad-no-docs-page/fad-no-docs-page.service';
import { FadSearchFilterComponent } from './fad-search-filter/fad-search-filter.component';
import { FadSearchListComponent } from './fad-search-list/fad-search-list.component';
import { FadSearchListService } from './fad-search-list/fad-search-list.service';

import { FadDoctorProfileComponent } from './fad-doctor-profile/fad-doctor-profile.component';
import { FadDoctorProfileService } from './fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileComponent } from './fad-facility-profile/fad-facility-profile.component';
import { FadFacilityProfileService } from './fad-facility-profile/fad-facility-profile.service';
import { FadProfileCardComponent } from './fad-profile-card/fad-profile-card.component';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list/fad-past-search-query-list.component';
import { FadPastSearchQueryListService } from './fad-past-search-query-list/fad-past-search-query-list.service';
import { FadProviderCompareComponent } from './fad-provider-compare/fad-provider-compare.component';
import { FadProviderCompareService } from './fad-provider-compare/fad-provider-compare.service';
import { FadProfessionalCompareComponent } from './fad-professional-compare/fad-professional-compare.component';
import { FadProfessionalCompareService } from './fad-professional-compare/fad-professional-compare.service';
import { FadFacilityCompareComponent } from './fad-facility-compare/fad-facility-compare.component';
import { FadFacilityCompareService } from './fad-facility-compare/fad-facility-compare.service';
import { FadCostBreakdownComponent } from './fad-cost-breakdown/fad-cost-breakdown.component';
import { FadDoctorRatingComponent } from './fad-doctor-rating/fad-doctor-rating.component';
import { FadCostBreakdownService } from '../fad/fad-cost-breakdown/fad-cost-breakdown.service';
import { FadSearchResultsResolver } from './fad-search-results/fad-search-results.resolver';
import { FadFacilityListComponent } from './fad-facility-list/fad-facility-list.component';
import { FadFacilityCardComponent } from './fad-facility-card/fad-facility-card.component';
import { FadFacilityListService } from './fad-facility-list/fad-facility-list.service';

import { FadProviderFacilityListComponent } from './fad-provider-facility-list/fad-provider-facility-list.component';
import { FadProviderFacilityCardComponent } from './fad-provider-facility-card/fad-provider-facility-card.component';
import { FadProviderFacilityListService } from './fad-provider-facility-list/fad-provider-facility-list.service';

import { FadDoctorProfileResolver } from './fad-doctor-profile/fad-doctor-profile.resolver';
import { FadFacilityProfileResolver } from './fad-facility-profile/fad-facility-profile.resolver';
import { FadFacilitySearchFilterComponent } from './fad-facility-search-filter/fad-facility-search-filter.component';
import { FadSpecialtySearchFilterComponent } from './fad-specialty-search-filter/fad-specialty-search-filter.component';
import { FadBreadCrumbsComponent } from './fad-bread-crumbs/fad-bread-crumbs.component';
import { FadBreadCrumbsService } from './fad-bread-crumbs/fad-bread-crumbs.service';
import { FadGuard } from './fad.guard';
import { FadReviewComponent } from './fad-review/fad-review.component';
import { FadReviewService } from './fad-review/fad-review.service';
import { FadReviewQuestionComponent } from './fad-review/fad-review-question/fad-review-question.component';
import { RatingComponent } from './fad-review/rating/rating.component';
import { FadTooltipComponent } from './fad-tooltip/fad-tooltip.component';
import { TooltipService } from './fad-tooltip/fad-tooltip.service';
import { MaterialModule } from '../../material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { PopoverComponent } from './popover/popover.component';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FadLoadingInterceptor } from './fad-loading.interceptor';
import { RemoveSelectArrowDirective } from '../../directives/remove-select-arrow.directive';

@NgModule({
  imports: [CommonModule, FadRouter, SharedModule, MaterialModule, ReactiveFormsModule, FormsModule, IonicModule, HttpClientModule],
  exports: [],
  declarations: [
    FadLandingPageComponent,
    FadMedicalIndexComponent,
    FadSearchResultsComponent,
    FadNoDocsPageComponent,
    FadSearchFilterComponent,
    FadSearchListComponent,
    FadDoctorProfileComponent,
    FadFacilityProfileComponent,
    FadProfileCardComponent,
    FadPastSearchQueryListComponent,
    FadProviderCompareComponent,
    FadProfessionalCompareComponent,
    FadFacilityCompareComponent,
    FadCostBreakdownComponent,
    FadDoctorRatingComponent,
    FadFacilityListComponent,
    FadFacilityCardComponent,
    FadFacilitySearchFilterComponent,
    FadSpecialtySearchFilterComponent,
    FadBreadCrumbsComponent,
    FadReviewComponent,
    FadReviewQuestionComponent,
    RatingComponent,
    FadProviderFacilityListComponent,
    FadProviderFacilityCardComponent,
    FadTooltipComponent,
    PopoverComponent,
    RemoveSelectArrowDirective
  ],
  entryComponents: [
    FadProfileCardComponent,
    FadFacilityCardComponent,
    FadProviderFacilityCardComponent,
    FadSearchFilterComponent,
    FadFacilitySearchFilterComponent,
    FadSpecialtySearchFilterComponent,
    PopoverComponent
  ],
  providers: [
    FadService,
    FadLandingPageService,
    FadMedicalIndexService,
    FadSearchResultsService,
    FadNoDocsPageService,
    FadSearchListService,
    FadDoctorProfileService,
    FadFacilityProfileService,
    FadPastSearchQueryListService,
    FadProviderCompareService,
    FadProfessionalCompareService,
    FadFacilityCompareService,
    FadCostBreakdownService,
    FadSearchResultsResolver,
    FadDoctorProfileResolver,
    FadFacilityProfileResolver,
    FadFacilityListService,
    FadBreadCrumbsService,
    FadGuard,
    FadReviewService,
    FadProviderFacilityListService,
    TooltipService,
    Clipboard,
    { provide: HTTP_INTERCEPTORS, useClass: FadLoadingInterceptor, multi: true }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FadModule {}
