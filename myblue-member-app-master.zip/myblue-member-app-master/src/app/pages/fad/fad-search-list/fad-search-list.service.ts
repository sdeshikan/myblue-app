import { Injectable } from '@angular/core';
import { FadConstants } from '../constants/fad.constants';
import { Observable } from 'rxjs/Observable';

import { interval } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable()
export class FadSearchListService {
  public isFilterChangedFlag = false;

  onMapContainerCreated(): Observable<Element> {
    return interval(500).pipe(
      switchMap(() => {
        return document.querySelectorAll('#' + FadConstants.elementRef.fadSearchListMapContent);
      })
    );
  }

  isFilterChanged(value) {
    this.isFilterChangedFlag = value;
  }
}
