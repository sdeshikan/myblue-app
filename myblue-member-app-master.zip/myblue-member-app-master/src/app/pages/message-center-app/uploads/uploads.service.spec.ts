import { TestBed, inject } from '@angular/core/testing';

import { UploadsService } from './uploads.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UploadsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UploadsService, BcbsmaHttpService]
    });
  });

  it('should be created', inject([UploadsService], (service: UploadsService) => {
    expect(service).toBeTruthy();
  }));
});
