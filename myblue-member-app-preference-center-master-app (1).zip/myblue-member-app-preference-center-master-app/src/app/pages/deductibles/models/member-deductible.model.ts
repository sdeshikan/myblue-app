export interface MemberDeductibleModel {
  "coverageType": string;
  "futureEffFlag":  string;
  "hasDependentsFlg": string;
  "loggedinUserSuffix": string;
  "subscriberNo": string;
  "hasActivePLanFlg": string;
  "cobundledPlanFlag": string;
  "name": string;
  "planName": string;
  "planEffDate": string;
  "memSuffix": string;
}
