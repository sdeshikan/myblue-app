import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadFacilityCompareService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public compareString = '';
  public costInfo: any;

  constructor() {}

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem('compareString', compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem('faciltyCostInfo', JSON.stringify(costInfo));
    this.costInfo = costInfo;
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('faciltyCostInfo');
    if (costInfo) {
      return JSON.parse(costInfo);
    }
    return null;
  }
}
