import { ActionReducerMap } from '@ngrx/store';
import { PostLoginInfo } from './shared/models/postlogininfo.model';


export const INIT_POSTLOGININFO = 'INIT_POSTLOGININFO'; 

export interface State {
   readonly postLoginInfo : PostLoginInfo
}

export const reducers: ActionReducerMap<State> = {
    postLoginInfo : initPostLoginInfoReducer
};

export function initPostLoginInfoReducer(state: PostLoginInfo, action) {
        switch (action.type) {
            case INIT_POSTLOGININFO:
                return { ...state, ...action.payload};
            default:
                return state;
        }
} 