import {
  Component,
  OnInit,
  Output,
  Input,
  EventEmitter,
  ComponentFactoryResolver,
  Injector,
  ApplicationRef,
  ChangeDetectorRef,
  SimpleChanges,
  OnChanges,
  ViewChild,
  ElementRef,
  HostListener
} from '@angular/core';
import {
  FadSearchListComponentOutputModelInterface,
  FadSearchListComponentInputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import { FadSearchListComponentOutputModel } from '../modals/fad-search-list.modal';
import { FadNoSearchResultsPageConsumer, FadProfileCardConsumer } from '../modals/interfaces/fad.interface';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import { FadConstants } from '../constants/fad.constants';
import * as leafLet from 'leaflet';
import { Subscription } from 'rxjs/Subscription';
import { FadSearchListService } from './fad-search-list.service';
import { FadProfileCardComponent } from '../fad-profile-card/fad-profile-card.component';
import { FadProfileCardComponentInputModel } from '../modals/fad-profile-card.modal';
import { FadZipCodeSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';

import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadProfileCardComponentMode, FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import { FadProfileCardComponentOutputModelInterface } from '../modals/interfaces/fad-profile-card.interface';

import { Router } from '@angular/router';
import {
  GetSearchByProfessionalResponseModelInterface,
  FadProfessionalInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';

@Component({
  selector: 'app-fad-search-list',
  templateUrl: './fad-search-list.component.html',
  styleUrls: ['./fad-search-list.component.scss']
})
export class FadSearchListComponent implements OnInit, OnChanges, FadNoSearchResultsPageConsumer, FadProfileCardConsumer {
  @Output() componentOutput: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<
    FadSearchListComponentOutputModel
  >();

  @Output() clearFilter: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<FadSearchListComponentOutputModel>();

  @Input() componentInput: FadSearchListComponentInputModelInterface;

  @ViewChild('profileCardList') profileCardList: ElementRef;

  public isDisplayBanner = false;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public filteredSearchResponse: GetSearchByProfessionalResponseModelInterface;
  public searchResponse: GetSearchByProfessionalResponseModelInterface;
  public professionalsList: FadProfessionalInterface[] = null;
  public selectedProfessionals: FadProfessionalInterface[] = [];
  private maxSelectionAllowed = 5;

  private mapInstance: leafLet.Map;
  private cachedAllZipCodeInfo: FadZipCodeSearchResponseModelInterface;
  public idValues: number[];
  public list: number[] = [];
  isFilterChanged: boolean;

  constructor(
    private router: Router,
    private fadSearchListService: FadSearchListService,
    private resolver: ComponentFactoryResolver,
    private fadProfessionalCompareService: FadProfessionalCompareService,
    private injector: Injector,
    private appRef: ApplicationRef,
    private fadSearchResultsService: FadSearchResultsService,
    private landingPageService: FadLandingPageService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef,
    private authHttp: AuthHttp
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.professional;
  }

  // Show banner section on window scroll to clear and delete message listing
  @HostListener('window:scroll', ['$event'])
  showBannerOnWindowScroll($event) {
    const fadSearchListPos = this.el.nativeElement.offsetTop,
      windowScrollPos = window.pageYOffset;

    if (windowScrollPos > fadSearchListPos) {
      this.isDisplayBanner = true;
    } else {
      this.isDisplayBanner = false;
    }
  }
  ngOnInit() {
    this.cachedAllZipCodeInfo = this.landingPageService.vitalsZipCodeInfo;
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      console.log(changes);
      if (changes) {
        // this.authHttp.showSpinnerLoading();
        this.componentInput = Object.assign({}, changes.componentInput.currentValue);
        this.isFilterChanged = this.fadSearchResultsService.filterChanged;
        if (this.componentInput) {
          this.searchResponse = this.componentInput.searchResults;
          if (this.searchResponse) {
            if (this.fadSearchListService.isFilterChangedFlag == true) {
              this.fadSearchListService.isFilterChangedFlag = false;
              // this.selectedProfessionals = [];
              this.clearProfileSelections();
            }
            if (this.fadProfessionalCompareService.getSearchResult() == null) {
              this.clearProfileSelections();
            }

            console.log(this.searchResponse.professionals);
            this.professionalsList = this.searchResponse.professionals;
            const disableFurtherSelection =
              this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed ? true : false;
            this.professionalsList = this.professionalsList.map(item => ({
              ...item,
              isDisabled: item.isChecked ? false : disableFurtherSelection
            }));
            this.isNoSearchResults = false;
          } else {
            this.isNoSearchResults = true;
            // this.authHttp.hideSpinnerLoading();
          }
          this.cdRef.detectChanges();
        }
      } else {
        // this.authHttp.hideSpinnerLoading();
      }
    } catch (exception) {}
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(professional: FadProfessionalInterface): FadProfileCardComponentInputModel {
    return new FadProfileCardComponentInputModel(professional);
  }

  public onSearchListComponentInteraction(event) {
    console.log(event);
    this.clearFilter.emit(event);
  }
  public onProfileCardComponentInteraction(profileCardCompOutput: FadProfileCardComponentOutputModelInterface) {
    console.log(profileCardCompOutput);
    // if (profileCardCompOutput.isSelected) {
    //   // add selected professional
    //   this.selectedProfessionals.push(profileCardCompOutput.professional);
    // } else {
    //   // remove selected professional
    //   const remainingSelectedProfessionals: FadProfessionalInterface[] =
    //     this.selectedProfessionals.filter(selectedProfessional => {
    //       if (!objectEquals(selectedProfessional, profileCardCompOutput.professional)) {
    //         return selectedProfessional;
    //       }
    //     });
    //   this.selectedProfessionals = remainingSelectedProfessionals;
    // }

    const index = this.professionalsList.findIndex(item => item.providerId === profileCardCompOutput.professional.providerId);
    const selectedItem = this.professionalsList[index];
    selectedItem.isChecked = profileCardCompOutput.isSelected;
    this.selectedProfessionals = this.professionalsList.filter(item => item.isChecked);
    const fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection =
      this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed ? true : false;
    this.professionalsList = this.professionalsList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });
    console.log(this.selectedProfessionals);
    this.fadProfessionalCompareService.setSearchResult(this.selectedProfessionals);
    console.log(fadSeachListComponentOutput);
    this.componentOutput.emit({ fadSeachListComponentOutput, index, isChecked: profileCardCompOutput.isSelected });
  }

  // end: FadProfileCardConsumer consumption requirement

  public compareSelectedProfiles() {
    for (let i = 0; i < this.selectedProfessionals.length; i++) {
      // kalagi01 - CAUTION ************ DO NOT DELETE ********************
      // a replacement to the id attribute has to be identified and the following code has to be modified
      // this.list[i] = this.selectedProfessionals[i].id;
    }

    // this.fadSearchListService.setSelectedId(this.list);
    this.router.navigate([FadConstants.urls.fadProfessionalCompareUrl]);
  }

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList !== undefined) {
      const checkBoxList: NodeListOf<Element> = this.profileCardList.nativeElement.querySelectorAll('[type="checkbox"]');
      Array.from(checkBoxList).forEach(checkBox => {
        const chkBox = checkBox as HTMLInputElement;
        chkBox.removeAttribute('checked');
        chkBox.checked = false;
      });
    }
  }

  public onTabSelectionChange(selectedIndex) {
    let selectedLatitude: number;
    let selectedLongitude: number;

    try {
      if (selectedIndex === 0) {
      } else if (selectedIndex === 1) {
        if (!this.fadSearchResultsService.getSearchCriteria()) {
          if (this.mapInstance && this.mapInstance.remove) {
            this.mapInstance.off();
            this.mapInstance.remove();
          }
          return;
        }

        const zipCodeInSearch: FZCSRCity = this.fadSearchResultsService.getSearchCriteria().getZipCode();
        let targetIndex = -1;
        this.cachedAllZipCodeInfo.cities.some((city, index) => {
          if (zipCodeInSearch && zipCodeInSearch.zip.indexOf(city.zip) >= 0) {
            targetIndex = index;
            return true;
          }
        });

        if (targetIndex < 0) {
          const fadLastSelectedCityZip = JSON.parse(localStorage.getItem('fadLastSelectedCityZip')) as FZCSRCity;
          if (fadLastSelectedCityZip && zipCodeInSearch.zip === fadLastSelectedCityZip.zip) {
            selectedLatitude = Number(fadLastSelectedCityZip.lat);
            selectedLongitude = Number(fadLastSelectedCityZip.lng);
          } else {
            throw new Error('Invalid zipcode');
          }
        } else {
          selectedLatitude = Number(this.cachedAllZipCodeInfo.cities[targetIndex].lat);
          selectedLongitude = Number(this.cachedAllZipCodeInfo.cities[targetIndex].lng);
        }

        const onMapCreatedEventWatcher: Subscription = this.fadSearchListService.onMapContainerCreated().subscribe(data => {
          this.createInteractiveMap(FadConstants.elementRef.fadSearchListMapContent, [selectedLatitude, selectedLongitude], 13);
          onMapCreatedEventWatcher.unsubscribe();
        });
      }
    } catch (exception) {}
  }

  private createInteractiveMap(mapContainerId: string, coords: leafLet.LatLngExpression, zoomLevel: number) {
    try {
      if (this.mapInstance && this.mapInstance.remove) {
        this.mapInstance.off();
        this.mapInstance.remove();
      }
      this.mapInstance = leafLet.map(mapContainerId).setView(coords, zoomLevel);
      // leafLet.tileLayer('https://api.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
      //   attribution: `Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors,
      // <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>`,
      //   maxZoom: 18,
      //   id: 'mapbox.streets',
      //   accessToken: 'pk.eyJ1Ijoib3ppbmlzbGUiLCJhIjoiY2ppYWJoaGR3MHp3ZTNxa3p3dnNnM2NiaCJ9.6k4AQo0CenMExQL9iObioQ'
      // }).addTo(this.mapInstance);

      this.addMarkers();
    } catch (exception) {}
  }

  private addMarkers() {
    try {
      this.professionalsList.map(professional => {
        professional.locations.map(location => {
          // const lattitude: number = location.address.latitude;
          // const longitude: number = location.address.longitude;
          // const latLng: leafLet.LatLngExpression = [lattitude, longitude];
          // const marker: leafLet.Marker = leafLet.marker(latLng).addTo(this.mapInstance);
          // marker.bindPopup(this.fetchPopupContent(professional));
        });
      });
    } catch (exception) {}
  }

  private fetchPopupContent(professional: FadProfessionalInterface): HTMLElement {
    try {
      const cmpFactory = this.resolver.resolveComponentFactory(FadProfileCardComponent);
      const fadProfileCardComponenttRef = cmpFactory.create(this.injector);
      fadProfileCardComponenttRef.instance.componentInput = new FadProfileCardComponentInputModel(professional);
      fadProfileCardComponenttRef.instance.componentInput.mode = 'MapItem' as FadProfileCardComponentMode;

      this.appRef.attachView(fadProfileCardComponenttRef.hostView);

      return fadProfileCardComponenttRef.location.nativeElement;
    } catch (exception) {}
  }
}
