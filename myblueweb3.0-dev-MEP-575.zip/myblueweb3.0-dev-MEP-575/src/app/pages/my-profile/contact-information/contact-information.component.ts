import { Component, OnInit, OnDestroy } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { AlertService, ValidationService, AuthService, ConstantsService } from '../../../shared/shared.module';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ContactInformationService } from './contact-information.service';
import { PreferenceModalService } from '../../../shared/services/myprofile/preference-modal.service';

declare let $: any;

@Component({
    selector: 'app-contact-information',
    templateUrl: './contact-information.component.html',
    styleUrls: ['./contact-information.component.scss']
})
export class ContactInformationComponent implements OnInit, OnDestroy {

    profile: any;
    registeredUserOnly: boolean = false;
    useridin: string = '';
    preferenceInfo: any;
    disableSave: boolean = true;
    fpoPreferenceUrl;
    preferenceObject: any;
    selectedFilterId: string;
    impersonate: boolean = true;
    repPayeeFalg;
    emailChanged:boolean = false;
    phoneChanged:boolean = false;

    //Mailing Address
    profileAddressEditForm: FormGroup;
    editAddress: boolean = false;
    address3: string = '';
    diplayEmailAdress: string = '';
    statesList = [
        { label: 'Alabama', value: 'AL' },
        { label: 'Alaska', value: 'AK' },
        { label: 'Arizona', value: 'AZ' },
        { label: 'Arkansas', value: 'AR' },
        { label: 'California', value: 'CA' },
        { label: 'Colorado', value: 'CO' },
        { label: 'Connecticut', value: 'CT' },
        { label: 'Delaware', value: 'DE' },
        { label: 'District of Columbia', value: 'DC' },
        { label: 'Florida', value: 'FL' },
        { label: 'Georgia', value: 'GA' },
        { label: 'Hawaii', value: 'HI' },
        { label: 'Idaho', value: 'ID' },
        { label: 'Illinois', value: 'IL' },
        { label: 'Indiana', value: 'IN' },
        { label: 'Iowa', value: 'IA' },
        { label: 'Kansas', value: 'KS' },
        { label: 'Kentucky', value: 'KY' },
        { label: 'Louisiana', value: 'LA' },
        { label: 'Maine', value: 'ME' },
        { label: 'Maryland', value: 'MD' },
        { label: 'Massachusetts', value: 'MA' },
        { label: 'Michigan', value: 'MI' },
        { label: 'Minnesota', value: 'MN' },
        { label: 'Mississippi', value: 'MS' },
        { label: 'Missouri', value: 'MO' },
        { label: 'Montana', value: 'MT' },
        { label: 'Nebraska', value: 'NE' },
        { label: 'Nevada', value: 'NV' },
        { label: 'New Hampshire', value: 'NH' },
        { label: 'New Jersey', value: 'NJ' },
        { label: 'New Mexico', value: 'NM' },
        { label: 'New York', value: 'NY' },
        { label: 'North Carolina', value: 'NC' },
        { label: 'North Dakota', value: 'ND' },
        { label: 'Ohio', value: 'OH' },
        { label: 'Oklahoma', value: 'OK' },
        { label: 'Oregon', value: 'OR' },
        { label: 'Pennsylvania', value: 'PA' },
        { label: 'Rhode Island', value: 'RI' },
        { label: 'South Carolina', value: 'SC' },
        { label: 'South Dakota', value: 'SD' },
        { label: 'Tennessee', value: 'TN' },
        { label: 'Texas', value: 'TX' },
        { label: 'Utah', value: 'UT' },
        { label: 'Vermont', value: 'VT' },
        { label: 'Virginia', value: 'VA' },
        { label: 'Washington', value: 'WA' },
        { label: 'West Virginia', value: 'WV' },
        { label: 'Wisconsin', value: 'WI' },
        { label: 'Wyoming', value: 'WY' }
    ];
    addressMessages = {
        'required': 'You must enter a valid mailing address.',
        'invalidCharacters': 'You must enter a valid mailing address.'
    };
    cityMessages = {
        'required': 'You must enter the city.',
        'invalidCharacters': 'You must enter a valid city.'
    };
    stateMessages = {
        'required': 'State is required'
    };
    zipMessages = {
        'required': 'You must enter your ZIP code.',
        'minlength': 'You must enter a valid ZIP code.'
    };
    mailingAddressToolTipVisible: boolean = false;
    addressEditCancelText: string = "edit";
    contactus = this.constants.contactus + this.authService.authToken.scopename;

    //Email
    profileEmailEditForm: FormGroup;
    editEmail: boolean = false;
    emailEditCancelText: string = "edit";
    isUseridAEmail: boolean = false;
    // optInEmail: boolean = false;
    // preferenceEmailBackUp: boolean;
    mcIsVerifiedEmail: boolean = false;
    emailToolTipVisible: boolean = false;
    optInEmailChanged: boolean = false;
    emailMessages = {
        'required': 'You must enter your email address.',
        'invalidEmail': 'You must enter a valid email address.'
    };

    //Mobile
    profilePhoneEditForm: FormGroup;
    phoneEditCancelText: string = "edit";
    isUseridAPhone: boolean = false;
    // preferenceMobileBackUp: boolean;
    // optInMobile: boolean = false;
    phoneToolTipVisible: boolean = false;
    editPhone: boolean = false;
    optInPhoneChanged: boolean = false;
    isMedicare: boolean = false;
    mask: Object = { mask: this.validationService.phoneMask, guide: false };
    phoneNumberTypeValues = [
        { label: 'Mobile', value: 'MOBILE' },
        { label: 'Home', value: 'HOME' },
        { label: 'Work', value: 'WORK' }
    ];
    mobileNumberMessages = {
        'required': 'You must enter a valid phone number.',
        'invalidNumber': 'You must enter a valid phone number.',
        'invalidMobile': 'You must enter a valid phone number.'
    };
    nonDigitRegex = /\D/g;

    constructor(
        private activatedRoute: ActivatedRoute,
        private fb: FormBuilder,
        private router: Router,
        private alertService: AlertService,
        private validationService: ValidationService,
        private profileService: ProfileService,
        private constants: ConstantsService,
        private globalService: GlobalService,
        private http: AuthHttp,
        private contactInfoService: ContactInformationService,
        private authService: AuthService,
        private modalService: PreferenceModalService,
    ) {
        // this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
        this.profileAddressEditForm = this.fb.group({
            useridin: '',
            isEditableAddress: false,
            userState: '',
            isDirectPay: false,
            address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
            address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
            dob: ['', []],
            city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
            state: ['', this.editAddress ? [Validators.required] : []],
            zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []]
        });
        this.profileEmailEditForm = this.fb.group({
            useridin: '',
            emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
            fullName: '',
            isVerifiedEmail: false
        });
        this.profilePhoneEditForm = this.fb.group({
            useridin: '',
            isVerifiedMobile: false,
            phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
            phoneNumber: [this.editPhone ? [Validators.required, this.validationService.phoneValidator(),
            this.validationService.mobileValidator()] : []],

        })
        this.useridin = sessionStorage.getItem('useridin');
        const numberRegEx = new RegExp('^[0-9]{10}');
        const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        this.isUseridAPhone = numberRegEx.test(this.useridin) ? true : false;
        this.isUseridAEmail = emailRegex.test(this.useridin) ? true : false;
        this.mask = { mask: this.validationService.phoneMask, guide: false };
        this.isMedicare = this.authService.authToken.userType ? (this.authService.authToken.userType.toLowerCase() === "medicare" ? true : false) : false;
        this.repPayeeFalg = JSON.parse(sessionStorage.getItem('postLoginInfo')).repPayeeFalg;
        this.repPayeeFalg = (this.repPayeeFalg === 'true' || this.repPayeeFalg === 'unknown') ? true : false;
        console.log('rePayeeFlag', this.repPayeeFalg);
        // this.contactInfoService.contactInfoDataChange$.subscribe((data) => {
        //     if (data == new Date()) {
        //         this.disableSave = true;
        //         this.updateCommStatus();
        //     }
        // })
        
    }
    getPreferenceInfo() {
        const postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
        let hasAltAdd =
          postLoginInfo && postLoginInfo.repPayeeFalg.toLowerCase() === 'false';
        let isMedicare =
          this.authService.authToken.userType &&
          this.authService.authToken.userType.toLowerCase() === 'medicare';
        let showPreference = !hasAltAdd ? false : isMedicare ? false : true;
        return showPreference
      }

    ngOnInit(){
        this.profileService.fetchProfileInfo().subscribe(profile => {
            this.profile = Object.assign({}, profile);
            this.memProfileSuccess();
          });
          if (this.getPreferenceInfo()) {
            this.globalService.getConsent().subscribe(res => {
                if((res.modalFlag == null || res.modalFlag === 'N') && (res.consentFlag == null || res.consentFlag === 'N')){
                    this.modalService.fetchPreferenceModalInfo();
                }
                    this.http.hideSpinnerLoading();
                });
        }
    }

    memProfileSuccess() {
        //Show paperless promo
        this.profileService.swapPromo();

        const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
        if (this.profile) {
            if (!this.profile.phoneType) {
                this.profile.phoneType = 'MOBILE';
            }
            this.diplayEmailAdress = this.profile.emailAddress;
            const userRole = this.profileService.getUserRole();
            this.registeredUserOnly = (userRole === 'REGISTERED-NOT-VERIFIED' || userRole === 'REGISTERED-AND-VERIFIED') ? true : false;
            this.address3 = '';
            this.address3 = this.profile.city ? this.address3 + this.profile.city + ', ' : this.address3;
            this.address3 = this.profile.state ? this.address3 + this.profile.state + ' ' : this.address3;
            this.address3 = this.profile.zip ? this.address3 + this.profile.zip : this.address3;
            this.profile.phoneNumber = this.formatPhone(this.profile.phoneNumber);
            this.profileAddressEditForm.patchValue(this.profile);
            this.profileEmailEditForm.patchValue(this.profile);
            this.profilePhoneEditForm.patchValue(this.profile);
            this.profileService.setProfile(this.profile);
        }
        this.preferenceInfo = this.activatedRoute.snapshot.data.commstatus.commstatus;
        // this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
        // this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
        // this.preferenceEmailBackUp = this.optInEmail;
        // this.preferenceMobileBackUp = this.optInMobile;
        this.mcIsVerifiedEmail = this.getPreferenceValue('IsVerifiedEmail') === 'true';
    }

    // fetchUpdatedProfileInfo() {
    //     this.profileService.fetchProfileInfo().subscribe(profile => {
    //       this.profile = Object.assign({}, profile);
    //     });
    // }

    impersonation() {
        this.impersonate = this.authService.impersonation();
        return this.impersonate;
    }
    resetAllEdits() {
        this.editAddress = false;
        this.editEmail = false;
        this.editPhone = false;
    }
    private sendaccesscode(commChannelType, commChannel) {
        return this.profileService.sendaccesscode(commChannelType, commChannel);
    }
    private sendcommchlaccesscode(email, mobile) {
        return this.profileService.sendcommchlaccesscode(
            email, mobile.replace(/\D/g, ''));
    }
    navigateToVerifyScreen() {
        this.router.navigate(['/myprofile/verify']).then(() => {
            this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
        });
    }
    getPreferenceValue(keyName) {
        const preferenceItem = this.preferenceInfo.preferences.filter((item) => {
            return item['memKeyName'] === keyName;
        });
        return preferenceItem && preferenceItem[0] ? preferenceItem[0]['memKeyValue'] : '';
    }
    openConsentToReceiveCommunicationModal(value: string) {
        $('#consentToReceiveCommunications').modal('open');
        this.showToolTip(value);
    }
    showToolTip(value: string) {
        switch (value) {
            case 'mailingAddress':
                this.mailingAddressToolTipVisible = !this.mailingAddressToolTipVisible;
                break;
            case 'email':
                this.emailToolTipVisible = !this.emailToolTipVisible;
                break;
            case 'phone':
                this.phoneToolTipVisible = !this.phoneToolTipVisible;
                break;
        }
    }

    /*
        MEP-539 - LOE is to remove the Marketing Communications opt-in and opt-in checkbox and copy from Contact Information page. 
    */
    // updateCommStatus() {
    //     this.alertService.clearError();
    //     const preferences = [];
    //     this.optInEmail = sessionStorage.getItem('optInEmail') ? JSON.parse(sessionStorage.getItem('optInEmail')) : this.optInEmail;
    //     this.optInMobile = sessionStorage.getItem('optInMobile') ? JSON.parse(sessionStorage.getItem('optInMobile')) : this.optInMobile;
    //     console.log("opt in status", this.optInEmail, this.optInMobile);
    //     preferences.push({ 'memKeyName': 'EmailOptInStatus', 'memKeyValue': this.optInEmail.toString() }),
    //         preferences.push({ 'memKeyName': 'EmailOptInSource', 'memKeyValue': 'WEB' });
    //     preferences.push({ 'memKeyName': 'MobileOptInStatus', 'memKeyValue': this.optInMobile.toString() }),
    //         preferences.push({ 'memKeyName': 'MobileOptInSource', 'memKeyValue': 'WEB' });
    //     this.contactInfoService.updateCommStatus({ 'preferences': preferences }).subscribe((res) => {
    //         if (res) {
    //             this.preferenceEmailBackUp = this.optInEmail;
    //             this.preferenceMobileBackUp = this.optInMobile;
    //             console.log('Profile Update Response', res);

    //             let message = '';
    //             message = this.disableSave ? 'Success! Notifications updated!' : message;

    //             if (res && (res['result'] === 0 || res['result'] === '0')) {
    //                 if (this.registeredUserOnly) {
    //                     this.router.navigate(['/register/register-detail']).then(() => {
    //                         this.alertService.setAlert(message, '', AlertType.Success);
    //                     })
    //                 } else {
    //                     this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfo');
    //                     window.scrollTo(0, 0);
    //                 }
    //                 this.resetAllEdits();
    //                 this.emailEditCancelText = 'edit';
    //                 this.phoneEditCancelText = 'edit';
    //                 sessionStorage.removeItem('optInEmail');
    //                 sessionStorage.removeItem('optInMobile');
    //                 setTimeout(() => {
    //                     this.profileService.getcommStatus().subscribe(res => {
    //                         this.preferenceInfo = res;
    //                         this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
    //                         this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
    //                     })
    //                 }, 0)
    //             }
    //         } else {
    //             this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', 'contactinfo');
    //             window.scrollTo(0, 0);
    //         }
    //     });
    // }

    mapErrorCodeWithMsg(result, alertMessageFinal) {
        let alertType = '';
        if (result.result === -90129) {
            alertType = 'success';
            alertMessageFinal = result.displaymessage;
        } else if (result.result === -90124 || result.result === -90126) {
            alertType = 'error';
            alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
            alertMessageFinal = result.displaymessage;
            console.log('result.displaymessage=', result.displaymessage);
        }
        return alertMessageFinal;
    }

    updateEmail() {
        let alertMessageFinal = '';
        let resultCode = 0;
        this.profileService.updateProfile(this.profileEmailEditForm.value,
            false, this.editEmail, false, false)
            .flatMap(result => {
                resultCode = result.result;
                alertMessageFinal = this.mapErrorCodeWithMsg(result, alertMessageFinal);
                return this.profileService.fetchProfileInfo();
            })
            .subscribe(
                profile => {
                    this.profile = profile;
                    this.profileEmailEditForm.patchValue(profile);
                    this.profileService.setProfile(this.profile);
                    let message = '';
                    if (alertMessageFinal === '') {
                        message = this.editEmail ? 'Your Email Address has been updated!' : message;
                        this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfo');
                        if (this.editEmail) {
                            this.emailChanged = true;
                            this.updateConsentInfo();
                            // this.verifyEmail(this.profile.emailAddress);
                        }
                        this.resetAllEdits();
                        this.emailEditCancelText = 'edit';
                        window.scrollTo(0, 0);
                    } else {
                        message = alertMessageFinal;
                        this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'emailfailure');
                    }
                },
                err => {
                    this.globalService.handleError(err.error, this.constants.displayMessage);
                });
    }

    updateConsentInfo() {
            let reqParamater = {
                useridin: this.authService.useridin,
                consentLanguageId: null,
                consentLanguage: null,
                consentFlag: 'N',
                consentTS: null,
                modalFlag: 'N'
              };
            this.globalService
              .updateConsent(reqParamater)
              .subscribe((updateconsent: any) => {
                if (updateconsent) {
                    if(this.emailChanged){
                        this.verifyEmail(this.profile.emailAddress);
                    } else if(this.phoneChanged){
                        this.verifyPhone(this.profile.phoneNumber);
                    }
                    sessionStorage.setItem('communicationPreferencePath', 'myprofile/contact-info');
                    this.http.hideSpinnerLoading();
                }
              });
      }
    updatePhone() {
        if (this.profilePhoneEditForm.value.phoneNumber) {
            this.profilePhoneEditForm.value.phoneNumber = (this.profilePhoneEditForm.value.phoneNumber + '').replace(/-/g, '');
        }
        let alertMessageFinal = '';
        let resultCode = 0;
        this.profileService.updateProfile(this.profilePhoneEditForm.value,
            false, false, this.editPhone, false)
            .flatMap(result => {
                resultCode = result.result;
                console.log("res", result);
                alertMessageFinal = this.mapErrorCodeWithMsg(result, alertMessageFinal);
                return this.profileService.fetchProfileInfo();
            })
            .subscribe(
                profile => {
                    // this.canEdit = this.profileService.authService.isSubscriber;
                    this.profile = profile;
                    this.profilePhoneEditForm.patchValue(profile);
                    this.profileService.setProfile(this.profile);

                    let message = '';
                    let addressSuccessMessage = '';
                    if (resultCode === -90129) {
                        addressSuccessMessage = alertMessageFinal;
                        alertMessageFinal = '';
                    } else if (this.editAddress && resultCode === 0) {
                        alertMessageFinal = 'Your Mailing Address has been updated!';
                    }
                    if (alertMessageFinal === '') {
                        message = this.editPhone ? 'Your Phone number has been updated!' : message;
                        if (this.editPhone && this.profilePhoneEditForm.value.phoneType && this.profilePhoneEditForm.value.phoneType.toUpperCase() === 'MOBILE') {
                            this.phoneChanged = true;
                            this.updateConsentInfo();
                            // this.verifyPhone(this.profile.phoneNumber);
                        }
                        this.resetAllEdits();
                        this.phoneEditCancelText = 'edit';
                        window.scrollTo(0, 0);
                    } else {
                        message = alertMessageFinal;
                        this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'phonefailure');
                    }
                },
                err => {
                    this.globalService.handleError(err.error, this.constants.displayMessage);
                });
    }

    //Mailing address
    showEdit() {
        let rtnVal: boolean;
        rtnVal = this.profile.userState !== 'REGISTERED-NOT-VERIFIED';
        rtnVal = rtnVal && !this.profileService.authService.isSubscriber;
        rtnVal = rtnVal && this.profileAddressEditForm.value.isEditableAddress;
        return rtnVal;
    }
    toggleAddressVisibility() {
        this.editEmail = false;
        this.editPhone = false;
        this.phoneEditCancelText = "edit";
        this.emailEditCancelText = "edit";
        this.alertService.clearError();
        this.editAddress = !this.editAddress;
        if (this.editAddress) {
            this.addressEditCancelText = "cancel";
            this.getAddressFormDefinition();
        } else {
            this.addressEditCancelText = "edit";
        }
    }
    getAddressFormDefinition() {
        this.profile = this.profileService.getProfile();
        console.log(this.profileAddressEditForm);
        this.profileAddressEditForm = this.fb.group({
            useridin: '',
            isEditableAddress: false,
            userState: '',
            isDirectPay: false,
            address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
            address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
            dob: ['', []],
            city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
            state: ['', this.editAddress ? [Validators.required, this.validationService.validateState()] : []],
            zip: ['', this.editAddress ? [Validators.required] : []]
        });
        this.profileAddressEditForm.patchValue(this.profile);
    }
    onSubmit() {
        let alertMessageFinal = '';
        let resultCode = 0;
        this.profileService.updateProfile(this.profileAddressEditForm.value,
            this.editAddress, false, false, false)
            .flatMap(result => {
                resultCode = result.result;
                alertMessageFinal = this.mapErrorCodeWithMsg(result, alertMessageFinal);
                return this.profileService.fetchProfileInfo();
            })
            .subscribe(
                profile => {
                    // this.canEdit = this.profileService.authService.isSubscriber;
                    this.profile = profile;
                    this.profileAddressEditForm.patchValue(profile);
                    this.profileService.setProfile(this.profile);
                    let message = '';
                    let addressSuccessMessage = '';
                    if (resultCode === -90129) {
                        addressSuccessMessage = alertMessageFinal;
                        alertMessageFinal = '';
                    } else if (this.editAddress && resultCode === 0) {
                        alertMessageFinal = 'Your Mailing Address has been updated!';
                    }
                    if (alertMessageFinal === '') {
                        message = this.editAddress ? addressSuccessMessage : message;
                        this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfo');
                        this.resetAllEdits();
                        this.addressEditCancelText = "edit";
                        window.scrollTo(0, 0);
                    } else {
                        message = alertMessageFinal;
                        this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'addressfailure');
                    }
                },
                err => {
                    this.globalService.handleError(err.error, this.constants.displayMessage);
                });
    }
    cancelAddress() {
        this.editAddress = false;
        this.addressEditCancelText = "edit";
    }

    //Email    
    toggleEmailVisibility() {
        this.editAddress = false;
        this.editPhone = false;
        this.phoneEditCancelText = "edit";
        this.addressEditCancelText = "edit";
        this.alertService.clearError();
        this.http.showSpinnerLoading();
        this.profileService.getcommStatus().subscribe(res => {
            console.log('res', res);
            res.preferences.map(item => {
                this.preferenceInfo = res;
                // this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
            })
            this.http.hideSpinnerLoading();
        })

        this.editEmail = !this.editEmail;
        if (this.editEmail) {
            this.emailEditCancelText = "cancel";
            this.optInEmailChanged = false;
            // this.optInEmail = sessionStorage.getItem('optInEmail')?JSON.parse(sessionStorage.getItem('optInEmail')): false;

            this.getEmailFormDefinition();
        } else {
            this.emailEditCancelText = "edit";
        }
    }
    getEmailFormDefinition() {
        this.profile = this.profileService.getProfile();
        console.log(this.profileEmailEditForm);
        this.profileEmailEditForm = this.fb.group({
            useridin: '',
            emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
            fullName: '',
            isVerifiedEmail: false
        });
        this.profileEmailEditForm.patchValue(this.profile);
    }
    onEmailSubmit() {
        if (!this.profile.isVerifiedEmail) {
            this.updateEmail();
        } else {
            if (this.profile.emailAddress !== this.profileEmailEditForm.value.emailAddress) {
                this.updateEmail();
            }
            // else {
            //     if (!this.disableSave) {
            //         this.disableSave = true;
            //         this.updateCommStatus();
            //     }
            // }
        }
    }
    cancelEmail() {
        this.editEmail = false;
        this.emailEditCancelText = "edit";
        this.profileEmailEditForm.patchValue(this.profile);
        // if (this.optInEmailChanged) {
        //     this.optInEmail = !this.optInEmail;
        // }
    }
    verifyEmail(emailId?: string) {
        this.alertService.clearError();
        const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
        if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
            this.sendcommchlaccesscode(emailId ? emailId : this.diplayEmailAdress, '').subscribe(res => {
                if (res['result'] === '0') {
                    console.log('sendaccesscode success', res);
                    this.alertService.clearError();
                    // only if success
                    this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.diplayEmailAdress);
                    sessionStorage.setItem('maskedVerifyPhone', 'N');
                    sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
                    this.navigateToVerifyScreen();
                } else {
                    if (res['displaymessage']) {
                        this.alertService.setAlert(res['displaymessage'],
                            '', AlertType.Failure, 'component', 'contactinfo');
                        window.scrollTo(0, 0);
                    }
                }
            }, err => {
                console.log('error', err);
            });
        } else {
            this.sendaccesscode('EMAIL', emailId ? emailId : this.diplayEmailAdress).subscribe(res => {
                if (res['result'] === '0') {
                    const communicationChannel = this.http.handleDecryptedResponse(res);
                    sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
                    console.log('sendaccesscode success', res);
                    this.alertService.clearError();
                    // only if success  
                    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
                    const userId = sentMailId && sentMailId['commChannel'];
                    this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
                    sessionStorage.setItem('maskedVerifyPhone', 'N');
                    sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
                    this.navigateToVerifyScreen();
                } else {
                    if (res['displaymessage']) {
                        this.alertService.setAlert(res['displaymessage'],
                            '', AlertType.Failure, 'component', 'contactinfo');
                        window.scrollTo(0, 0);
                    }
                }
            }, err => {
                console.log('error', err);
            });
        }
    }
    maskEmailId(userId: string): string {
        const maskedUserId = userId ? userId.replace(/^(.{3})(.*)(@.*)$/,
            (_, firstCharacter, charToMasked, domain) => {
                return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
            }) : userId;
        return maskedUserId;
    }
    onEmailChange() {
        this.optInEmailChanged = true;
        // this.optInEmail = !this.optInEmail;
        // sessionStorage.setItem('optInEmail', JSON.stringify(this.optInEmail));
        // this.allowSaveOnChange();
    }
    // allowSaveOnChange() {
    //     if (this.preferenceMobileBackUp !== this.optInMobile || this.preferenceEmailBackUp !== this.optInEmail) {
    //         this.disableSave = false;
    //     } else {
    //         this.disableSave = true;
    //     }
    // }
    // onEmailRegSubmit() {
    //     this.updateEmail();
    // }



    //Mobile
    getPhoneFormDefinition() {
        this.profile = this.profileService.getProfile();
        const defaultPhoneNumber = this.formatPhone('');
        console.log(this.profilePhoneEditForm);
        this.profilePhoneEditForm = this.fb.group({
            useridin: '',
            phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
            phoneNumber: [defaultPhoneNumber, this.editPhone ?
                [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []],
            isVerifiedMobile: false,
        });
        if (!this.profile.phoneType) {
            this.profile.phoneType = 'MOBILE';
        }
        this.profilePhoneEditForm.patchValue(this.profile);
    }
    formatPhone(inputPhoneNumber) {
        if (inputPhoneNumber !== undefined && inputPhoneNumber !== null && inputPhoneNumber !== '') {
            let phoneNumber: string = inputPhoneNumber;
            phoneNumber = phoneNumber.replace(/-/g, '');
            const areaCode = phoneNumber.slice(0, 3);
            const number = phoneNumber.slice(3);
            return areaCode + '-' + number.slice(0, 3) + '-' + number.slice(3);
        } else {
            return '';
        }
    }
    verifyPhone(phoneNumber?: string) {
        this.alertService.clearError();
        const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
        if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
            this.sendcommchlaccesscode('', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(res => {
                if (res['result'] === '0') {
                    console.log('sendaccesscode success', res);
                    this.alertService.clearError();
                    // only if success
                    this.profileService.maskedVerify = this.maskPhoneNumber(phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, ''));
                    sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
                    sessionStorage.setItem('maskedVerifyPhone', 'Y');
                    this.navigateToVerifyScreen();
                } else {
                    if (res['displaymessage']) {
                        this.alertService.setAlert(res['displaymessage'],
                            '', AlertType.Failure, 'component', 'contactinfo');
                        window.scrollTo(0, 0);
                    }
                }
            }, err => {
                console.log('error', err);
            });
        } else {
            this.sendaccesscode('MOBILE', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(res => {
                if (res['result'] === '0') {
                    const communicationChannel = this.http.handleDecryptedResponse(res);
                    sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
                    console.log('sendaccesscode success', res);
                    this.alertService.clearError();
                    // only if success
                    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
                    const userId = sentMailId && sentMailId['commChannel'];
                    this.profileService.maskedVerify =
                        this.maskPhoneNumber(phoneNumber ? phoneNumber : userId);
                    sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
                    sessionStorage.setItem('maskedVerifyPhone', 'Y');
                    this.navigateToVerifyScreen();
                } else {
                    if (res['displaymessage']) {
                        this.alertService.setAlert(res['displaymessage'],
                            '', AlertType.Failure, 'component', 'contactinfo');
                        window.scrollTo(0, 0);
                    }
                }
            }, err => {
                console.log('error', err);
            });
        }
    }
    getDefaultOptionForPhoneNumberType() {
        if (this.profile) {
            this.profile.phoneType = 'MOBILE';
            return this.profile.phoneType;
        }
    }
    maskPhoneNumber(userId: string): string {
        const regex = /^(.{3})(.{3})(.{4})(.*)/;
        let maskedUserId = userId ? userId.replace(/^(.*)(.{4})$/,
            (_, digitsToMasked, lastFourDigits) => {
                return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
            }) : userId;
        const str = maskedUserId;
        const subst = `$1-$2-$3`;
        maskedUserId = str.replace(regex, subst);
        return maskedUserId;
    }
    onPhoneChange() {
        // console.log('phone changed optin')
        this.optInPhoneChanged = true;
        // this.optInMobile = !this.optInMobile;
        // sessionStorage.setItem('optInMobile', JSON.stringify(this.optInMobile));
        // this.allowSaveOnChange();
    }
    cancelPhone() {
        this.editPhone = false;
        this.phoneEditCancelText = "edit";
        this.profilePhoneEditForm.patchValue(this.profile);
        // if (this.optInPhoneChanged) {
        //     this.optInMobile = !this.optInMobile;
        // }
    }
    togglePhoneVisibility() {
        this.editAddress = false;
        this.editEmail = false;
        this.emailEditCancelText = "edit";
        this.addressEditCancelText = "edit";
        this.alertService.clearError();
        this.http.showSpinnerLoading();
        this.profileService.getcommStatus().subscribe(res => {
            console.log('res', res);
            res.preferences.map(item => {
                this.preferenceInfo = res;
                // this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
            })
            this.http.hideSpinnerLoading();
        })
        this.editPhone = !this.editPhone;
        if (this.editPhone) {
            this.phoneEditCancelText = "cancel";
            this.optInPhoneChanged = false;
            this.getPhoneFormDefinition();
        } else {
            this.phoneEditCancelText = "edit";
        }
    }
    isWebMigrated(): boolean {
        return (!this.isUseridAPhone && !this.isUseridAPhone &&
            !this.profilePhoneEditForm.value.phoneNumber);
    }
    onPhoneSubmit() {
        if (!this.profile.isVerifiedMobile) {
            this.updatePhone();
        } else {
            if (this.profile.phoneNumber !== this.profilePhoneEditForm.value.phoneNumber) {
                this.updatePhone();
            }
            // else {
            //     if (!this.disableSave) {
            //         this.disableSave = true;
            //         this.updateCommStatus();
            //     }
            // }

        }
    }
    // onPhoneRegSubmit() {
    //     this.updatePhone();
    // }


    ngOnDestroy() {
        this.alertService.clearError();
    }
}
