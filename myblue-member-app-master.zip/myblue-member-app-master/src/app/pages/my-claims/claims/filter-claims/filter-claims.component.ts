import { Component, OnInit, Input } from '@angular/core';
import { ModalController, NavParams, PopoverController } from '@ionic/angular';
import { RadioList } from '../../claims.model';
import {
  ProviderSearchListInterface,
  MemberTypeSearchListInterface,
  VisitTypeSearchListInterface,
  ClaimStatusSearchListInterface,
  // DateMetaInterface,
  DateSearchListInterface,
  ClaimStatusMetaInterface,
  DateMetaInterface,
  MemberTypeMetaInterface,
  ProviderMetaInterface,
  VisitTypeMetaInterface,
  CustomDateRangeMetaInterface,
} from '../../models/interfaces/claims-generic-models.interface';
import moment from "moment";

@Component({
  selector: 'app-filter-claims',
  templateUrl: './filter-claims.component.html',
  styleUrls: ['./filter-claims.component.scss'],
})
export class FilterClaimsComponent implements OnInit {
  @Input() sortSelectedFilter: string;
  @Input() dateList: DateSearchListInterface[] = [];
  @Input() memberList: MemberTypeSearchListInterface[] = [];
  @Input() memberFilterList: { memberName: string, memberCount: number }[];
  @Input() providerList: ProviderSearchListInterface[] = [];
  @Input() providerFilterList: { providerName: string, providerCount: number }[];
  @Input() visitTypeList: VisitTypeSearchListInterface[] = [];
  @Input() visitTypeFilterList: { visitType: string, visitTypeCount: number }[];
  @Input() claimStatusList: ClaimStatusSearchListInterface[] = [];
  @Input() claimStatusFilterList: { status: string, statusCount: number }[];
  @Input() closeFilterAction: any;
  // @Input() popOverElement: HTMLIonPopoverElement;
  @Input() getPopOver: any;
  submenu: any = {};
  selectedDateLabel = true;
  showClearLink = false;

  sortState: SortState = null;
  dateState: DateState = null;
  memberState: MemberState = null;
  providerState: ProviderState = null;
  visitTypeState: VisitTypeState = null;
  claimStatusState: ClaimStatusState = null;

  constructor(
    private modalController: ModalController,
    private navParams: NavParams) {
  }

  ngOnInit() {
    const thisState = this;
    this.showClearLink = this.navParams.data.showClearLink;
    this.sortState = new SortState();
    this.sortState.setSelected(this.sortSelectedFilter);
    this.dateState = new DateState(this.dateList);
    this.memberState = new MemberState(this.memberList, this.memberFilterList, () => this.saveStateToSessionStorage());
    this.providerState = new ProviderState(this.providerList, this.providerFilterList, () => this.saveStateToSessionStorage());
    this.visitTypeState = new VisitTypeState(this.visitTypeList, this.visitTypeFilterList, () => this.saveStateToSessionStorage());
    this.claimStatusState = new ClaimStatusState(this.claimStatusList, this.claimStatusFilterList, () => this.saveStateToSessionStorage());
    this.loadSessionState();
    const popOver = this.getPopOver();  // Always returning null -not sure why
    if (popOver) {
      popOver.onWillDismiss().then(() => {
        console.log("this will be dismissed");
        this.saveStateToSessionStorage();
      });
    }
  }

  saveStateToSessionStorage() {
    const state = {
      sort: this.sortState,
      date: this.dateState,
      member: this.memberState,
      provider: this.providerState,
      visitType: this.visitTypeState,
      claimStatus: this.claimStatusState
    };
    sessionStorage.setItem('claims', JSON.stringify(state));
  }

  loadSessionState() {
    this.selectedDateLabel = false;
    const sessionClaimsData = JSON.parse(sessionStorage.getItem('claims')) as ClaimSessionInterface;
    if (sessionClaimsData) {
      // this.sortState = sessionClaimsData.sort;
      sessionClaimsData.sort.radioList.forEach((item, index) => {
        this.sortState.radioList[index].checked = item.checked;
      });

      // this.dateState = sessionClaimsData.date;
      sessionClaimsData.date.radioList.forEach((item, index) => {
        this.dateState.radioList[index].checked = item.checked;
      });
      // this.memberState = sessionClaimsData.member;
      sessionClaimsData.member.checkboxList.forEach((item, index) => {
        this.memberState.checkboxList[index].selected = item.selected;
      });
      this.memberState.allCheckboxItem.selected = sessionClaimsData.member.allCheckboxItem.selected;
      // this.providerState = sessionClaimsData.provider;
      sessionClaimsData.provider.checkboxList.forEach((item, index) => {
        this.providerState.checkboxList[index].selected = item.selected;
      });
      this.providerState.allCheckboxItem.selected = sessionClaimsData.provider.allCheckboxItem.selected;

      // this.visitTypeState = sessionClaimsData.visitType;
      sessionClaimsData.visitType.checkboxList.forEach((item, index) => {
        this.visitTypeState.checkboxList[index].selected = item.selected;
      });
      this.visitTypeState.allCheckboxItem.selected = sessionClaimsData.visitType.allCheckboxItem.selected;

      // this.claimStatusState = sessionClaimsData.claimStatus;
      sessionClaimsData.claimStatus.checkboxList.forEach((item, index) => {
        this.claimStatusState.checkboxList[index].selected = item.selected;
      });
      this.claimStatusState.allCheckboxItem.selected = sessionClaimsData.claimStatus.allCheckboxItem.selected;
    } else {
      this.clearFilter();
    }

  }

  onStartDateChange($event) {
    this.dateState.startRangeValue = $event.target.value.split('T')[0];
    // this.checkSelected();
  }
  onEndDateChange($event) {
    this.dateState.endRangeValue = $event.target.value.split('T')[0];
    // this.checkSelected();
  }

  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) { this.submenu[menu] = false; }
    this.submenu[menu] = !this.submenu[menu];
  }
  closeFilter() {
    this.saveStateToSessionStorage();


    const metaDataInterface = {} as DateMetaInterface;
    metaDataInterface.allDatesRequired = this.dateState.isAllDatesSelected();
    if (this.dateState.getStartDate()) {
      metaDataInterface.customDateRange = {} as CustomDateRangeMetaInterface;
      metaDataInterface.customDateRange.startDate = this.dateState.getStartDate();
      metaDataInterface.customDateRange.endDate = this.dateState.getEndDate();
    } else {
      if (this.dateState.anySelected()) {
        metaDataInterface.dateMetaList = this.dateState.getSelected(); // .radioList;
      }
    }
    const onClosedData = {
      sortSelectedFilter: this.sortState.getSelected(),
      dateMetaData: metaDataInterface,
      memberTypeMetaData: this.memberState.getSelected(),
      claimStatusMetaInterface: this.claimStatusState.getSelected(),
      providerMetaData: this.providerState.getSelected(),
      visitTypeMetaData: this.visitTypeState.getSelected()
    };
    this.closeFilterAction(onClosedData);
  }
  clearFilter() {
    console.log('Clear Filters');
    this.sortState.reset();
    this.dateState.reset();
    this.memberState.reset();
    this.providerState.reset();
    this.visitTypeState.reset();
    this.claimStatusState.reset();
    this.selectedDateLabel = true;
    this.showClearLink = false;
    this.closeFilterAction(false);
  }
  sortFilterRadioSelected(event) {
    console.log('sort item selected', event);
    this.sortState.setSelected(event.detail.value);
  }
  dateFilterRadioSelected(event) {
    console.log('date item selected', event);
    if (event.detail.value === "Custom Date Range") {
      this.selectedDateLabel = false;
    } else {
      this.selectedDateLabel = true;
    }
    this.dateState.setSelected(event.detail.value);
  }
  memberFilterCheckboxSelected(event) {
    this.memberState.setSelected(event.detail);
  }
  memberFilterCheckboxAllSelected(event) {
    this.memberState.setAllItemSelected();
  }
  providerFilterCheckboxSelected(event) {
    this.providerState.setSelected(event.detail);
  }
  providerFilterCheckboxAllSelected(event) {
    this.providerState.setAllItemSelected();
  }
  visitTypeFilterCheckboxSelected(event) {
    this.visitTypeState.setSelected(event.detail);
  }
  visitFilterCheckboxAllSelected(event) {
    this.visitTypeState.setAllItemSelected();
  }
  claimStatusFilterCheckboxSelected(event) {
    this.claimStatusState.setSelected(event.detail);
  }
  claimStatusFilterCheckboxAllSelected(event) {
    this.claimStatusState.setAllItemSelected();
  }
}

class StateHelper {
  initializeSelectedAndDisabledStates(item: any): any {
    item = { ...item, selected : this.ifUndefinedSetToFalse(item.selected), disabled: this.ifUndefinedSetToFalse(item.disabled)};
    return item;
    // item.selected = this.ifUndefinedSetToFalse(item.selected);
    // item.disabled = this.ifUndefinedSetToFalse(item.disabled);
  }
  ifUndefinedSetToFalse(nullableBool?: boolean): any {
    return nullableBool == undefined ? false : nullableBool;
  }
}
class SortState {
  public radioList: RadioList[] = [
    {
      value: 'Most Recent',
      checked: false
    },
    {
      value: 'Oldest First',
      checked: false
    }
  ];

  setSelected(selectedValue: string) {
    this.radioList.forEach((item) => item.checked = item.value === selectedValue);
  }
  getSelected(): string {
    const selectedItem = this.radioList.find(item => item.checked);
    return selectedItem ? selectedItem.value : '';
  }
  reset() {
    this.setSelected('Most Recent');
  }
}
class DateState {
  public radioList: DateSearchListInterface[] = [];
  public maxDate: string;
  public minDate: string;
  public startRangeValue: string;
  public endRangeValue: string;
  dateFormat = 'MM-DD-YYYY';

  constructor(memberList: DateSearchListInterface[]) {
    this.radioList = memberList.map(item => {
      item = { ...item, checked : false};
      return item;
    });
    this.maxDate = moment().format();
    this.minDate = moment().subtract('years', 2).format();
    this.startRangeValue = this.maxDate;
    this.endRangeValue = this.maxDate;
  }

  setSelected(selectedValue: string) {
    this.radioList.forEach((item) => item.checked = item.dateRange === selectedValue);
  }
  getSelected(): DateSearchListInterface[] {
    const selectedItems =  this.radioList
      .filter(item => item.checked)
      .map(item => {
        item.checked = undefined;
        return item;
      });
    return selectedItems;
  }
  getStartDate() {
    const userSelectedDate = this.radioList[this.radioList.length - 1];
    return userSelectedDate.checked ? moment(this.startRangeValue).format('YYYY-MM-DD') : null;
  }
  getEndDate() {
    const userSelectedDate = this.radioList[this.radioList.length - 1];
    return userSelectedDate.checked ? moment(this.endRangeValue).format('YYYY-MM-DD') : null;
  }
  isAllDatesSelected() {
    const allDatesItem = this.radioList.filter(item => item.dateRange.startsWith('All '))[0];
    return allDatesItem.checked;
  }
  reset() {
    this.radioList.forEach(item => item.checked = false);
  }
  anySelected() {
    return (this.radioList.find(item => item.checked)) ? true : false;
  }
}
class MemberState {
  public checkboxList: MemberTypeSearchListInterface[] = [];
  public allCheckboxItem: MemberTypeSearchListInterface;
  stateHelper: StateHelper = new StateHelper();

  constructor(memberList: MemberTypeSearchListInterface[],
              memberFilterList: { memberName: string, memberCount: number }[],
              private saveToSessionStorage: any) {
    // Handle 'All Items' record seperately
    const allItemList = memberList.filter(item => item.memberName.startsWith('All '));
    if (allItemList && allItemList.length > 0) {
      this.allCheckboxItem = this.stateHelper.initializeSelectedAndDisabledStates(allItemList[0]);
    }

    // Initialize rest of the items
    this.checkboxList = memberList.filter(item => !item.memberName.startsWith('All ')).map(item => {
      return this.stateHelper.initializeSelectedAndDisabledStates(item);
    });
    this.checkboxList.forEach(item => item.disabled = true);
    memberFilterList.forEach(item => {
      const member = this.checkboxList.find(member => member.memberName === item.memberName);
      if (member) {
        member.disabled = false;
      }
    });
  }

  setSelected(selectedItem: { value: string, checked: boolean }) {
    const item = this.checkboxList.find((item) => item.memberName === selectedItem.value);
    if (item.selected != selectedItem.checked) {
      item.selected = selectedItem.checked;

      // determine the state of All Checked Item
      if (selectedItem.checked) {
        const atleastOneItemIsnotChecked = this.checkboxList.some(item => item.selected == false);
        this.allCheckboxItem.selected = !atleastOneItemIsnotChecked;
      } else {
        this.allCheckboxItem.selected = false;
      }
      this.saveToSessionStorage();
    }

  }
  setAllItemSelected() {
    this.allCheckboxItem.selected = !this.allCheckboxItem.selected;
    this.checkboxList.forEach(item => item.selected = this.allCheckboxItem.selected);
    this.saveToSessionStorage();
  }
  getSelected(): MemberTypeMetaInterface {
    const memberTypeMetaData = {} as MemberTypeMetaInterface;
    memberTypeMetaData.allmembersRequired = this.allCheckboxItem.selected;
    memberTypeMetaData.memberTypeMetaList = this.checkboxList
      .filter(item => item.selected)
      .map(item => {
        item.selected = undefined;
        item.disabled = undefined;
        return item;
      });

    return memberTypeMetaData;
  }
  reset() {
    this.allCheckboxItem.selected = false;
    this.checkboxList.forEach(item => item.selected = false);
  }
  showMemberFilter() {
    return this.checkboxList.length > 1;
  }
}

class ProviderState {
  public checkboxList: ProviderSearchListInterface[] = [];
  public allCheckboxItem: ProviderSearchListInterface;
  stateHelper: StateHelper = new StateHelper();

  constructor(providerList: ProviderSearchListInterface[],
              providerFilterList: { providerName: string, providerCount: number }[],
              private saveToSessionStorage: any) {
    // Handle 'All Items' record seperately
    const allItemList = providerList.filter(item => item.providerName.startsWith('All '));
    if (allItemList && allItemList.length > 0) {
      this.allCheckboxItem = this.stateHelper.initializeSelectedAndDisabledStates(allItemList[0]);
    }
    // Initialize rest of the items
    this.checkboxList = providerList.filter(item => !item.providerName.startsWith('All ')).map(item => {
      return this.stateHelper.initializeSelectedAndDisabledStates(item);
    });
    this.checkboxList.forEach(item => item.disabled = true);
    providerFilterList.forEach(item => {
      const provider = this.checkboxList.find(member => member.providerName === item.providerName);
      if (provider) {
        provider.disabled = false;
      }
    });
  }

  setSelected(selectedItem: { value: string, checked: boolean }) {
    const item = this.checkboxList.find((item) => item.providerName === selectedItem.value);
    if (item.selected != selectedItem.checked) {
      item.selected = selectedItem.checked;

      // determine the state of All Checked Item
      if (selectedItem.checked) {
        const atleastOneItemIsnotChecked = this.checkboxList.some(item => item.selected == false);
        this.allCheckboxItem.selected = !atleastOneItemIsnotChecked;
      } else {
        this.allCheckboxItem.selected = false;
      }
      this.saveToSessionStorage();
    }
  }
  setAllItemSelected() {
    this.allCheckboxItem.selected = !this.allCheckboxItem.selected;
    this.checkboxList.forEach(item => item.selected = this.allCheckboxItem.selected);
    this.saveToSessionStorage();
  }
  getSelected(): ProviderMetaInterface {
    const providerMetaInterface = {} as ProviderMetaInterface;
    providerMetaInterface.allProvidersRequired = this.allCheckboxItem.selected;
    providerMetaInterface.providerMetaList = this.checkboxList
      .filter(item => item.selected)
      .map(item => {
        item.selected = undefined;
        item.disabled = undefined;
        return item;
      });
    return providerMetaInterface;
  }
  reset() {
    this.allCheckboxItem.selected = false;
    this.checkboxList.forEach(item => item.selected = false);
  }
}

class VisitTypeState {
  public checkboxList: VisitTypeSearchListInterface[] = [];
  public allCheckboxItem: VisitTypeSearchListInterface;
  stateHelper: StateHelper = new StateHelper();

  constructor(visitTypeList: VisitTypeSearchListInterface[],
              visitTypeFilterList: { visitType: string, visitTypeCount: number }[],
              private saveToSessionStorage: any) {
    // Handle 'All Items' record seperately
    const allItemList = visitTypeList.filter(item => item.visitType.startsWith('All '));
    if (allItemList && allItemList.length > 0) {
      this.allCheckboxItem = this.stateHelper.initializeSelectedAndDisabledStates(allItemList[0]);
    }
    // Initialize rest of the items
    this.checkboxList = visitTypeList.filter(item => !item.visitType.startsWith('All ')).map(item => {
      return this.stateHelper.initializeSelectedAndDisabledStates(item);
    });
  }

  setSelected(selectedItem: { value: string, checked: boolean }) {
    const item = this.checkboxList.find((item) => item.visitType === selectedItem.value);
    if (item.selected != selectedItem.checked) {
      item.selected = selectedItem.checked;
      // determine the state of All Checked Item
      if (selectedItem.checked) {
        const atleastOneItemIsnotChecked = this.checkboxList.some(item => item.selected == false);
        this.allCheckboxItem.selected = !atleastOneItemIsnotChecked;
      } else {
        this.allCheckboxItem.selected = false;
      }
    }
  }
  setAllItemSelected() {
    this.allCheckboxItem.selected = !this.allCheckboxItem.selected;
    this.checkboxList.forEach(item => item.selected = this.allCheckboxItem.selected);
  }
  getSelected(): VisitTypeMetaInterface {
    const memberTypeMetaData = {} as VisitTypeMetaInterface;
    memberTypeMetaData.allVisitTypesRequired = this.allCheckboxItem.selected;
    memberTypeMetaData.visitTypeMetaList = this.checkboxList
      .filter(item => item.selected)
      .map(item => {
        item.selected = undefined;
        item.disabled = undefined;
        return item;
      });

    return memberTypeMetaData;
  }
  reset() {
    this.allCheckboxItem.selected = false;
    this.checkboxList.forEach(item => item.selected = false);
  }
}

class ClaimStatusState {
  public checkboxList: ClaimStatusSearchListInterface[] = [];
  public allCheckboxItem: ClaimStatusSearchListInterface;
  stateHelper: StateHelper = new StateHelper();

  constructor(claimStatusList: ClaimStatusSearchListInterface[],
              claimStatusFilterList: { status: string, statusCount: number }[],
              private saveToSessionStorage: any) {
    // Handle 'All Items' record seperately
    const allItemList = claimStatusList.filter(item => item.status.startsWith('All '));
    if (allItemList && allItemList.length > 0) {
      this.allCheckboxItem = this.stateHelper.initializeSelectedAndDisabledStates(allItemList[0]);
    }
    // Initialize rest of the items
    this.checkboxList = claimStatusList.filter(item => !item.status.startsWith('All ')).map(item => {
      return this.stateHelper.initializeSelectedAndDisabledStates(item);
    });
    this.checkboxList.forEach(item => item.disabled = true);
    claimStatusFilterList.forEach(item => {
      const claimStatus = this.checkboxList.find(member => member.status === item.status);
      if (claimStatus) {
        claimStatus.disabled = false;
      }
    });
  }

  setSelected(selectedItem: any) {
    const item = this.checkboxList.find((item) => item.status === selectedItem.value);
    if (item.selected != selectedItem.checked) {
      item.selected = selectedItem.checked;

      // determine the state of All Checked Item
      if (selectedItem.checked) {
        const atleastOneItemIsnotChecked = this.checkboxList.some(item => item.selected == false);
        this.allCheckboxItem.selected = !atleastOneItemIsnotChecked;
      } else {
        this.allCheckboxItem.selected = false;
      }
      this.saveToSessionStorage();
    }
  }
  setAllItemSelected() {
    this.allCheckboxItem.selected = !this.allCheckboxItem.selected;
    this.checkboxList.forEach(item => item.selected = this.allCheckboxItem.selected);
    this.saveToSessionStorage();
  }
  getSelected(): ClaimStatusMetaInterface {
    const memberTypeMetaData = {} as ClaimStatusMetaInterface;
    memberTypeMetaData.allStatusesRequired = this.allCheckboxItem.selected;
    memberTypeMetaData.claimStatusMetaList = this.checkboxList
      .filter(item => item.selected)
      .map(item => {
        item.selected = undefined;
        item.disabled = undefined;
        return item;
      });

    return memberTypeMetaData;
  }
  reset() {
    this.allCheckboxItem.selected = false;
    this.checkboxList.forEach(item => item.selected = false);
  }
}

interface CheckBoxDetail {
  value: string;
  checked: boolean;
}

interface ClaimSessionInterface {
  sort: SortState;
  date: DateState;
  member: MemberState;
  provider: ProviderState;
  visitType: VisitTypeState;
  claimStatus: ClaimStatusState;
}
