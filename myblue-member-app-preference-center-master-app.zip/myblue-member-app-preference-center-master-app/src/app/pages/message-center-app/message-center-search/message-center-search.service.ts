import { Injectable } from '@angular/core';
import { MessageDetailsSearchResponseModelInterface } from '../modals/interfaces/message-center-search.interface';

@Injectable()
export class MessageCenterSearchService {
  public cachedSearchCriteriaData: MessageDetailsSearchResponseModelInterface;
  public isPersistSearchCriteria = false;

  constructor() {}
}
