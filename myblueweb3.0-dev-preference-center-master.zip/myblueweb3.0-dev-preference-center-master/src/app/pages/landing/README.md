

Registeration (creates username/password) -> 
unverified Registeration (ANV) ->
Authentication -> 
A and V ->