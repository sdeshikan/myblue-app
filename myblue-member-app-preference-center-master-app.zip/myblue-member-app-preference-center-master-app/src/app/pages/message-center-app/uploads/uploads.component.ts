import { Component } from '@angular/core';
import { Router } from '@angular/router';
import moment from 'moment';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import {
  MessageCenterSearchCompOutputModelInterface,
  MessageCenterSearchFilterConsumer,
  MessageCenterSearchFilterDateRanges,
  MessageDetailsSearchResponseModelInterface
} from '../modals/interfaces/message-center-search.interface';
import {
  NoDocumentsFoundComponentConsumer,
  NoDocumentsFoundComponentModelInterface,
  NoSearchResultsFoundComponentConsumer
} from '../modals/interfaces/message-center.interface';
import { UploadDataItemInterface, UploadsResponseDataModelInterface } from '../modals/interfaces/uploads.interface';
import { MessageDetailsSearchResponseModel, SearchCriteriaItem } from '../modals/message-center-search.model';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import { UploadsResponseDataModel } from '../modals/uploads.modal';
import { MessageCenterUtilities } from '../utils/message-center.utilities';
import { UploadsService } from './uploads.service';

@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.scss']
})
export class UploadsComponent
  implements NoDocumentsFoundComponentConsumer, NoSearchResultsFoundComponentConsumer, MessageCenterSearchFilterConsumer {
  public noDocsFound: NoDocumentsFoundComponentModelInterface = new NoDocumentsFoundComponentModel();
  public noSearchResultsFound: NoDocumentsFoundComponentModelInterface = new NoDocumentsFoundComponentModel();
  public searchCriteriaData: MessageDetailsSearchResponseModelInterface = new MessageDetailsSearchResponseModel();
  public uploadedData: UploadsResponseDataModelInterface;
  public uploadsList: UploadDataItemInterface[];
  public hasDocuments: boolean = null;
  public isNoSearchResults = false;
  public mobileHideByFilterOverlay: boolean;

  private utils: MessageCenterUtilities = new MessageCenterUtilities();

  constructor(private uploadsService: UploadsService, private router: Router) {
    this.noDocsFound.mode = MessageCenterConstants.flags.uploadsMode;
    this.noSearchResultsFound.mode = MessageCenterConstants.flags.noSearchResultsMode;

    this.uploadedData = new UploadsResponseDataModel();
    this.uploadsList = this.uploadedData.uploadedData;

    this.uploadsService.getUploadedData().subscribe(
      data => {
        if (data) {
          this.uploadedData = data;
          this.uploadsList = data.uploadedData;
          this.hasDocuments = this.uploadsList.length > 0;
        }

        this.createSearchCriteria();
      },
      error => {
        console.error(error, null, 2);
      }
    );
  }

  public createSearchCriteria(): MessageDetailsSearchResponseModelInterface {
    const keywordList: string[] = [];
    const searchCriteriaData: MessageDetailsSearchResponseModelInterface = new MessageDetailsSearchResponseModel();

    const now = moment(new Date());
    let dateRangeInfo: MessageCenterSearchFilterDateRanges = {
      all_dates: 0,
      last_30_days: 0,
      last_60_days: 0,
      last_90_days: 0,
      year_to_date: 0
    };

    this.uploadsList.map(msgListItem => {
      keywordList.push(msgListItem.ShortText);
      keywordList.push(msgListItem.LongText);
      dateRangeInfo = this.utils.trackAgeOfEntity(now, msgListItem.dateStamp, dateRangeInfo);
    });

    searchCriteriaData
      .addSortByFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.sortByFilters.mostRecent))
      .addSortByFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.sortByFilters.oldestFirst))

      .addDateFilter(
        new SearchCriteriaItem()
          .setCriteriaName(MessageCenterConstants.filters.dateFilters.last30Days)
          .setMatchingResultsCount(dateRangeInfo.last_30_days)
      )
      .addDateFilter(
        new SearchCriteriaItem()
          .setCriteriaName(MessageCenterConstants.filters.dateFilters.last60Days)
          .setMatchingResultsCount(dateRangeInfo.last_60_days)
      )
      .addDateFilter(
        new SearchCriteriaItem()
          .setCriteriaName(MessageCenterConstants.filters.dateFilters.last90Days)
          .setMatchingResultsCount(dateRangeInfo.last_90_days)
      )
      .addDateFilter(
        new SearchCriteriaItem()
          .setCriteriaName(MessageCenterConstants.filters.dateFilters.yearToDate)
          .setMatchingResultsCount(dateRangeInfo.year_to_date)
      )
      .addDateFilter(
        new SearchCriteriaItem()
          .setCriteriaName(MessageCenterConstants.filters.dateFilters.allDates)
          .setMatchingResultsCount(dateRangeInfo.all_dates)
      )
      .addDateFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.dateFilters.customDateRange));

    searchCriteriaData.keywordList = keywordList;
    this.noSearchResultsFound.searchCriteria = searchCriteriaData;
    this.searchCriteriaData = searchCriteriaData;

    return searchCriteriaData;
  }

  public onSearch(searchFilterOptions: MessageCenterSearchCompOutputModelInterface): void {
    const searchCriteriaData: MessageDetailsSearchResponseModelInterface = searchFilterOptions.searchCriteriaData;
    this.mobileHideByFilterOverlay = searchFilterOptions.filterOverlayFlag;
    // if the emit event has not been triggered by apply or clear filters then do nothing
    if (searchCriteriaData === null) {
      return;
    }

    let uploadsList: UploadDataItemInterface[];

    // clear previous search results from view
    this.uploadsList = this.utils.clearPreviousSearchFlags(this.uploadsList) as UploadDataItemInterface[];

    // clone the existing msg list to avoid performance issues due to intermitten model changes in view
    uploadsList = Object.assign([], this.uploadsList);

    // sort the message list as necessary based on the user selection
    const sortFilterKeys: string[] = searchCriteriaData.sortByFilterMap.getKeys();
    for (const sortKey of sortFilterKeys) {
      const sortCriteria = searchCriteriaData.sortByFilterMap.get(sortKey);
      if (sortCriteria.criteriaName === MessageCenterConstants.filters.sortByFilters.mostRecent && sortCriteria.criteriaSelected) {
        // tslint:disable-next-line:variable-name
        uploadsList.sort((msgItem_a, msgItem_b) => {
          const date1 = moment(new Date(msgItem_a.dateStamp));
          const date2 = moment(new Date(msgItem_b.dateStamp));
          return moment.duration(date2.diff(date1)).asDays();
        });
        break;
      } else if (sortCriteria.criteriaName === MessageCenterConstants.filters.sortByFilters.oldestFirst && sortCriteria.criteriaSelected) {
        // tslint:disable-next-line:variable-name
        uploadsList.sort((msgItem_a, msgItem_b) => {
          const date1 = moment(new Date(msgItem_a.dateStamp));
          const date2 = moment(new Date(msgItem_b.dateStamp));
          return moment.duration(date1.diff(date2)).asDays();
        });
        break;
      }
    }

    // apply date filters to the result obtained from the previous step
    uploadsList = this.utils.doDateFilter(
      uploadsList,
      searchCriteriaData,
      MessageCenterConstants.attributes.dateStamp
    ) as UploadDataItemInterface[];

    uploadsList = this.utils.doKeywordFilter(uploadsList, searchCriteriaData) as UploadDataItemInterface[];

    // check if atleast one file item matches the search results. if not display the 'no-documents-found-component'
    // tslint:disable-next-line:prefer-conditional-expression
    if (
      !uploadsList.some(msgListItem => {
        return !msgListItem.hideEntityFromDisplay;
      })
    ) {
      this.isNoSearchResults = true;
    } else {
      this.isNoSearchResults = false;
    }

    // return the result to enable view-model binding
    this.uploadsList = uploadsList;
  }

  public openFile(uploadedFileItem: UploadDataItemInterface): void {
    if (uploadedFileItem && uploadedFileItem.messageId) {
      this.router.navigate([`/message-center/upload-detail/${uploadedFileItem.messageId}`]);
    }
  }
}
