import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './../../shared/shared.module';

@Injectable()
export class HomeGuard implements CanActivate {

  constructor(private router: Router, private authService: AuthService) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {

    const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';

    switch (scopename) {
      case 'AUTHENTICATED-NOT-VERIFIED': {
        if (this.authService.authToken.migrationtype !== 'NONE') {
          this.router.navigate(['member-migration']);
        }
        else {
          sessionStorage.setItem('accesscode', 'true');
          sessionStorage.setItem('isReqCode', 'true');
          this.router.navigate(['/register/verifyaccesscode']);
          return false;
        }
      }
      case 'AUTHENTICATED-AND-VERIFIED': {
        if (this.authService.authToken.migrationtype !== 'NONE') {
          this.router.navigate(['member-migration']);
          return false;
        } else {
          return true;
        }
      }
      default:
        return true;
    }

  }

}