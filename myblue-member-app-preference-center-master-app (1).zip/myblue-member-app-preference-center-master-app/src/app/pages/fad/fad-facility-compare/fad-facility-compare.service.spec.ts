import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { NgxsModule } from '@ngxs/store';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadFacilityCompareService } from './fad-facility-compare.service';

describe('FadFacilityCompareService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadFacilityCompareService, BcbsmaHttpService, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityCompareService], (service: FadFacilityCompareService) => {
    expect(service).toBeTruthy();
  }));
});
