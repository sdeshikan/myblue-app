import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class CommunicationPreferenceService {
  private preferenceDataChange = new BehaviorSubject<any>(null);
  public preferenceDataChange$ = this.preferenceDataChange;

  private selectedChannel = new BehaviorSubject<any>(null);
  public selectedChannel$ = this.selectedChannel;

  constructor() { }

  setDataChange() {
    this.preferenceDataChange.next(new Date().toString());
  }

  selectedPreferenceChannel(data) {
    this.selectedChannel.next(data);
  }
}
