import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { ConstantsService } from '../../../shared/services/constants.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import {
  MessageListingRequestModelInterface,
  UpdateMsgListingAndMemberAlertsRequestInterface
} from '../modals/interfaces/message.interface';
import {
  MessageListingRequestModel,
  MessageListingResponseModel,
  UpdateMsgListingAndMemberAlertsRespModel
} from '../modals/messages.model';

@Injectable()
export class MsgListingService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private constants: ConstantsService, private http: HttpClient) {}

  getMsgListing(): Observable<MessageListingResponseModel> {
    const msgListingReqParams: MessageListingRequestModelInterface = new MessageListingRequestModel();
    msgListingReqParams.useridin = this.useridin;

    return this.http.post<MessageListingResponseModel>(this.constants.msgListingUrl, msgListingReqParams);
  }

  getUpdateMsgListingAndMemberAlerts(
    msgListingAndMemberAlertsReqParams: UpdateMsgListingAndMemberAlertsRequestInterface
  ): Observable<UpdateMsgListingAndMemberAlertsRespModel> {
    return this.http.post<UpdateMsgListingAndMemberAlertsRespModel>(
      this.constants.updateMsgListingAndMemAlertsUrl,
      msgListingAndMemberAlertsReqParams
    );
  }
}
