module.exports = {
    copyMaterialThemeCSS: {
        src: ['{{ROOT}}/node_modules/@angular/material/prebuilt-themes/deeppurple-amber.css'],
        dest: '{{WWW}}'
    }
}
