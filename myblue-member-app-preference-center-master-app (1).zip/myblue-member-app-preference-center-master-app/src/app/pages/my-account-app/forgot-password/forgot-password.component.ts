import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { MyAccountService } from '../my-account.service';

// TODO: This one will need to be tested due to NGXS updates
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit, OnDestroy {
  forgotPwdForm: FormGroup;
  dobMask: Array<any>;
  useridinMessages = {
    required: 'Please enter a valid username.'
  };

  constructor(
    private fb: FormBuilder,
    private validationService: ValidationService,
    private globalService: GlobalService,
    private constants: ConstantsService,
    private myAccountService: MyAccountService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.forgotPwdForm = this.fb.group({
      useridin: ['', [Validators.required]]
    });
  }

  ngOnInit() {
    console.log('-- sendSwrveEventsForClicks -- AppScreen_ForgotPassword', this.swrveEventNames.AppScreen_ForgotPassword);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ForgotPassword);

    this.route.params.subscribe(params => {
      let userId = params['user'];
      if (localStorage['login-user'] && !userId) {
        userId = localStorage['login-user'];
      }
      this.forgotPwdForm.patchValue({
        useridin: userId
      });
    });
  }

  onSubmit() {
    this.getToken();
  }

  verifyUser() {
    this.alertService.clearError();
    this.myAccountService.verifyUser(this.forgotPwdForm.getRawValue()).subscribe((result: any) => {
      if (result.isAuthenticated || result.isAuthenticated === 'TRUE') {
        this.myAccountService.hintQuestion = result.hintQuestion;
        sessionStorage.setItem('isauthenticated', 'TRUE');
        this.router.navigate(['/account/fpconfirmidentity']);
      } else {
        sessionStorage.setItem('isauthenticated', 'FALSE');
        sessionStorage.setItem('otp', 'TRUE');
        this.router.navigate(['/account/verifyAccessCode', 'FPW']).then(() => {
          this.alertService.setAlert('Verification code sent.', '', AlertType.Success);
        });
      }
    });
  }

  getToken() {
    this.verifyUser();
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
