import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { v4 as uuid } from 'uuid';
import { AppSelectors } from '../store/selectors/app-selectors';
import { encryptPayload } from '../utils/app.utils';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  constructor() {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // console.log('REQUEST >>>>>>>>>>>>> ' + JSON.stringify(request, null, 2));

    if (this.token && request.url.includes('refreshtoken')) {
      const newHeaders = new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: 'Bearer ' + this.token,
        // uitxnid: 'WEB_v3.0_' + uuid()
        uitxnid: 'APP_v5.0_' + uuid()
      });
      const authRequest = request.clone({ headers: newHeaders });
      return next.handle(authRequest);
    } else if (this.token && request.method === 'POST') {
      if (request.body instanceof FormData) {
        const newHeaders = new HttpHeaders({
          Authorization: `Bearer ${this.token}`,
          // uitxnid: 'WEB_v3.0_' + uuid()
          uitxnid: 'APP_v5.0_' + uuid()
        });

        const authRequest = request.clone({ headers: newHeaders });
        return next.handle(authRequest);
      } else {
        const newHeaders = new HttpHeaders({
          Authorization: `Bearer ${this.token}`,
          'Content-Type': 'application/json',
          // uitxnid: 'WEB_v3.0_' + uuid()
          uitxnid: 'APP_v5.0_' + uuid()
        });
        const encryptedBody = encryptPayload(request.body, this.cryptoToken, false);
        const authRequest = request.clone({ headers: newHeaders, body: encryptedBody });

        return next.handle(authRequest);
      }
    } else {
      return next.handle(request);
    }
  }
}
