import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {FadBreadCrumbsService} from './fad-bread-crumbs.service';

@Component({
  selector: 'app-fad-bread-crumbs',
  templateUrl: './fad-bread-crumbs.component.html',
  styleUrls: ['./fad-bread-crumbs.component.scss']
})
export class FadBreadCrumbsComponent implements OnInit {


  constructor(public fadBreadCrumbsService: FadBreadCrumbsService, private router: Router) {
  }

  ngOnInit() {

  }

  redirectToUrl(url?) {
    this.router.navigate([url]);
  }

}
