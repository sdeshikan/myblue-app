import { Component, OnInit, Input } from '@angular/core';
import { MessageCenterNoDocsFoundPageModelInterface } from '../modals/interfaces/message-center.interface';
import {
  MessageCenterNoUploadsFoundPageModel,
  MessageCenterNoMessagesFoundPageModel,
  MessageCenterNoDocumentsFoundPageModel,
  NoDocumentsFoundComponentModel,
  MessageCenterNoSearchResultsFoundPageModel
} from '../modals/message-center.modal';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';

@Component({
  selector: 'app-no-documents-found',
  templateUrl: './no-documents-found.component.html',
  styleUrls: ['./no-documents-found.component.scss']
})
export class NoDocumentsFoundComponent implements OnInit {
  @Input() componentMode: NoDocumentsFoundComponentModel;
  @Input() fpoUrl: string;

  public messageCenterNoDocsFoundPageModel: MessageCenterNoDocsFoundPageModelInterface;
  public noSearchResultsMode = false;

  ngOnInit() {
    try {
      if (this.componentMode.mode === MessageCenterConstants.flags.messagesMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoMessagesFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.documentsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoDocumentsFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.uploadsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoUploadsFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.noSearchResultsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoSearchResultsFoundPageModel();
        this.noSearchResultsMode = true;
      } else {
        throw new Error(MessageCenterConstants.errorMessages.noDocsFound_InvalidComponentModeError);
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }
}
