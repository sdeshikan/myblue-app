import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { GetMemberProfileResponseModel } from '../models/get-member-profile-request.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy {
  profile: GetMemberProfileResponseModel;
  isMedicare = false;
  fpoPreferenceUrl: string;
  preferenceObject: any;
  selectedFilterId: string;
  showPreferenceModal: boolean = false;
  repPayeeFalg;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private constants: ConstantsService,
    private profileService: ProfileService,
    private alertService: AlertService,
    private authService: AuthService
  ) {
    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    this.isMedicare = this.authService.authToken.userType ? (this.authService.authToken.userType.toLowerCase() === "medicare") : false;
    this.repPayeeFalg = JSON.parse(sessionStorage.getItem('postLoginInfo')).repPayeeFalg;
    this.repPayeeFalg = (this.repPayeeFalg === 'true' || this.repPayeeFalg === 'unknown');
    console.log('repPayeeFalg', this.repPayeeFalg, 'authTOken123', this.authService.authToken);


  }

  ngOnInit() {
    this.profileService.setProfile(this.profile);

    this.profileService.swapPromo();
  }

  navigateUrl(url) {
    this.router.navigate([url]);
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
