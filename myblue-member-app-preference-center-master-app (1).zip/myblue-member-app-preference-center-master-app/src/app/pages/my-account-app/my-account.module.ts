import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { RegistrationService } from '../registration/registration.service';
import { ConfirmidentityComponent } from './confirm-identity/confirmidentity.component';
import { CreatePasswordComponent } from './create-password/create-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { FpConfirmidentityComponent } from './fp-confirm-identity/fpconfirmidentity.component';
import { MyAccountRouter } from './my-account.routing';
import { MyAccountService } from './my-account.service';
import { CreatePasswordGuard } from './utils/create-password.guard';
import { ForgetPasswordFlowGuard } from './utils/forget-password-flow.guard';
import { ForgetUserNameFlowGuard } from './utils/forget-username-flow.guard';
import { VerifyAccessGuard } from './utils/verify-access.guard';
import { VerifyOTPaccesscodeComponent } from './verifyOTPaccesscode/verifyaccesscode.component';
import { AlertsModule } from '../../shared/alerts/alerts.module';

@NgModule({
  declarations: [
    ForgotPasswordComponent,
    ForgotUsernameComponent,
    CreatePasswordComponent,
    ConfirmidentityComponent,
    FpConfirmidentityComponent,
    VerifyOTPaccesscodeComponent
  ],
  exports: [
  ],
  imports: [
    CommonModule,
    MyAccountRouter,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    TextMaskModule,
    IonicModule,
    AlertsModule
  ],
  providers: [
    AuthGuard,
    ForgetUserNameFlowGuard,
    ForgetPasswordFlowGuard,
    VerifyAccessGuard,
    CreatePasswordGuard,
    MyAccountService,
    RegistrationService,
    SmsRetriever
  ]
})
export class MyAccountModule { }
