export interface IndividualDeductibleRequestModel {
  useridin: string;
  subscriberNo: string;
  memberSuffix: string;
  coverageType: string;
}
