import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FeatureToggleService } from '../../../services/feature-service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AuthService } from '../../../shared/services/auth.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AlertService, ConstantsService } from '../../../shared/shared.module';
import { HomePageInfoModel } from '../../landing/landing.model';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import {
  GetPlansBenefitsListPlanItemInterface,
  GetPlansBenefitsListResponseModelInterface
} from '../modals/interfaces/get-plans-benefits-list-models.interface';
import { EocPolicyInterface, GetBenefitCoverageResponseModelInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import { DocumentsService } from './documents.service';


@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit, OnDestroy {
  public memberInfo: HomePageInfoModel;
  public breadCrumbs: BreadCrumb[];
  public planBenefitsList: GetPlansBenefitsListResponseModelInterface = null;
  public benefitCoverageDocs: GetBenefitCoverageResponseModelInterface = null;
  public policiesInBenefitCoverage: EocPolicyInterface = null;
  public hasContents: boolean;
  private clearAlertOnDestroy = true;
  title = 'Explanation of Benefits';
  public oMemberInboxLinks;
  fpoHomeTargetUrl: string = this.constants.drupalTestUrl + '/page/mydocuments';
  fpoMyPlanDocumentTargetUrl: string = this.constants.drupalTestUrl + '/page/myplan-documents';
  fpobenefitCoverageListTargetUrl: string = this.constants.drupalTestUrl + '/page/bluecare-documents';
  public no_doc_found_component_mode: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public selectedPlan: GetPlansBenefitsListPlanItemInterface;
  public isMedicareUser: boolean = false;
  public isMedicareOnlyUser: boolean = false;
  fpoPreferenceUrl: string;
  preferenceObject: any;
  selectedFilterId: string;
  repPayeeFalg;
  isTaxFormsEnabled = false;
  // showPreferenceModal: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private documentsService: DocumentsService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private profileService: ProfileService,
    private authService: AuthService,
    private featureToggleService: FeatureToggleService
  ) {
    this.no_doc_found_component_mode.mode = MessageCenterConstants.flags.documentsMode;
    // this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/promo-block/preference-center';
    // this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
  }

  ngOnInit() {
    this.isTaxFormsEnabled = this.featureToggleService.isFeatureEnabled('tax-forms');
    //Show paperless promo
    this.profileService.swapPromo();

    try {
      const oMemberData = this.route.snapshot.data.memberData;
      console.log(oMemberData);
      if (oMemberData) {
        if (Object.keys(oMemberData).length && 'ROWSET' in oMemberData && 'ROW' in oMemberData.ROWSET) {
          this.memberInfo = oMemberData.ROWSET.ROW;
        }
      }
      const t = sessionStorage.getItem('authToken');
      if (t) {
        const authToken = JSON.parse(t);
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Explanation of Your Dental Benefits';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Your Dental Benefits';
        }
      }

      this.breadCrumbs = [];
      this.prepareChildBreadCrumbs(this.router.url.split('/')[this.router.url.split('/').length - 1]);
      // console.log('router', this.router.url.split('/')[this.router.url.split('/').length - 1]);

      this.policiesInBenefitCoverage = this.route.snapshot.data.policiesInBenefitCoverage;
      this.planBenefitsList = this.route.snapshot.data.planDocuments;
      this.benefitCoverageDocs = this.route.snapshot.data.benefitCoverageDocs;

      if (this.planBenefitsList && this.planBenefitsList.result && this.planBenefitsList.result < 0) {
        this.alertService.setAlert(this.planBenefitsList.displaymessage, ' ', AlertType.Failure);
      } else {
        if (this.documentsService.getSelectedPlan()) {
          this.selectedPlan = this.documentsService.getSelectedPlan();
        }
      }
      //Hide the Well Connection banner for Medicare users ( MEDICARE/MEDEX)
      if (
        this.authService.authToken.userType.toLowerCase() === 'medicare' ||
        this.authService.authToken.userType.toLowerCase() === 'medex'
      ) {
        this.isMedicareUser = true;
      }

      //Check for MEDICARE user only 
      if (this.authService.authToken.userType.toLowerCase() === "medicare") {
        this.isMedicareOnlyUser = true;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.messageCenterModule,
        MessageCenterConstants.components.documentsComponent,
        MessageCenterConstants.methods.ngOnInit
      );
    }
    this.repPayeeFalg = JSON.parse(sessionStorage.getItem('postLoginInfo')).repPayeeFalg;
    this.repPayeeFalg = (this.repPayeeFalg === 'true' || this.repPayeeFalg === 'unknown') ? true : false;
    // // Show Paperless Promo content 
    // if(this.preferenceObject.Preferences){          
    //   this.preferenceObject.Preferences.map(item =>{
    //     if(item.PreferenceType == '1'){
    //       this.showPreferenceModal = (item.FilterID === 'DOCS_PLAN_MAIL')? true : false;
    //     }
    //   })
    // }else if(this.preferenceObject.errormessage){
    //   this.showPreferenceModal = true;
    // }else{
    //   this.showPreferenceModal = false;
    // }
  }

  ngOnDestroy(): void {
    this.planBenefitsList = null;
    this.benefitCoverageDocs = null;
    if (this.clearAlertOnDestroy) {
      this.alertService.clearError();
    }
  }

  planDetailsList() {
    this.router.navigate(['/message-center/documents/planDocuments']);
  }

  openBenefitCoverageDocsList(plan: GetPlansBenefitsListPlanItemInterface) {
    this.documentsService.setSelectedPlan(plan);
    this.router.navigate(['/message-center/documents/planDocuments/benefitCoverageList']);
  }

  openOverAllPlanInformation(): void {
    this.router.navigate(['/message-center/documents/document-overall-view']);
  }

  openBenefitCoverage(policy: EocPolicyInterface) {
    this.documentsService.setSelectedPolicy(policy);
    this.router.navigate(['/message-center/documents/documents-list-view']);
  }

  openTaxForms() {
    this.router.navigate(['/message-center/documents/tax-forms']);
  }

  eobListing() {
    this.router.navigate(['../myeobs']);
  }

  prepareChildBreadCrumbs(folderId) {
    console.log('floderid', folderId, this.breadCrumbs);
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
      // url: ['/message-center', 'documents', folderId]
    });
    this.breadCrumbs.push({
      label: 'My Inbox',
      url: ['/message-center']
      // url: ['/message-center', 'documents', folderId]
    });
    switch (folderId) {
      case 'home':
        this.breadCrumbs.push({
          label: 'My Documents',
          url: ['/message-center/documents/home']
          // url: ['/message-center', 'documents', folderId]
        });
        break;
      case 'planDocuments':
        this.breadCrumbs.push({
          label: 'My Documents',
          // url: ['/message-center', 'documents', folderId]
          url: ['/message-center/documents/home']
        });
        this.breadCrumbs.push({
          label: 'My Plan Documents',
          url: ['/message-center/documents/planDocuments']
          // url: ['/message-center', 'documents', folderId]
        });
        break;
      case 'benefitCoverageList':
        this.breadCrumbs.push({
          label: 'My Documents',
          url: ['/message-center/documents/home']
          // url: ['/message-center', 'documents', 'home']
        });
        this.breadCrumbs.push({
          label: 'My Plan Documents',
          url: ['/message-center/documents/planDocuments']
        });
        this.breadCrumbs.push({
          label: this.documentsService.getSelectedPlan().planName + ' Documents',
          url: ['/message-center/documents/planDocuments/benefitCoverageList']
        });
        break;
      // case 'document-overall-view':
      //   this.breadCrumbs.push({
      //     label: 'My Documents',
      //     url: ['/message-center', 'documents', 'home']
      //   });
      //   this.breadCrumbs.push({
      //     label: 'Plan Documents',
      //     url: ['/message-center', 'documents', folderId]
      //   });
      //   break;
      // case 'document-list-view':
      //   this.breadCrumbs.push({
      //     label: 'My Documents',
      //     url: ['/message-center', 'documents', 'home']
      //   });
      //   this.breadCrumbs.push({
      //     label: 'Benefit Summaries',
      //     url: ['/message-center', 'documents', folderId]
      //   });
      //   break;
      case '601':
        this.breadCrumbs.push({
          label: 'My Documents',
          url: ['/message-center', 'documents', 'home']
        });
        this.breadCrumbs.push({
          label: 'Plan Documents',
          url: ['/message-center', 'documents', '501']
        });
        this.breadCrumbs.push({
          label: 'Blue Care Elect Program',
          url: ['/message-center', 'documents', folderId]
        });
        break;
    }
    console.log('this.breadCrumbs', this.breadCrumbs);
  }
  initBreadcrumbs() {
    this.breadCrumbs = [
      {
        label: 'Home',
        url: ['/home']
      },
      {
        label: 'My Inbox',
        url: ['/message-center']
      }
    ];
  }
}
