import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FitnessService } from './fitness.service';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';

describe('FitnessService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, IonicModule, NgxsModule.forRoot([])],
      providers: [ConstantsService]
    })
  );

  it('should be created', () => {
    const service: FitnessService = TestBed.get(FitnessService);
    expect(service).toBeTruthy();
  });
});
