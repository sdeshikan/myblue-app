import { Injectable } from '@angular/core';
import { ErrorDialogService } from '../shared/services/error-dialog.service';
import { EMPTY } from 'rxjs';

import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router, NavigationExtras } from '@angular/router';
import { AlertService } from '../shared/services/alert.service';

@Injectable()
export class HttpResponseInterceptor implements HttpInterceptor {
  constructor(private errorDialogService: ErrorDialogService, private alertService: AlertService, private router: Router) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      map((event: HttpEvent<any>) => {
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('-- http-response-interceptor -- catchError', error);

        if (error.status === 0) {
          const link = this.router.url;
          console.log('failed route', link);
          const navigationExtras: NavigationExtras = {
            state: {
              message: `You are offline, some features might be unavailable, <a href="${link}">try again</a>`
            }
          };
          this.router.navigateByUrl('/tabs/alert-page', navigationExtras);
        } else if (error.status === 401) {
          // this.router.navigateByUrl('login-app');
          return throwError(error);
        } else {
          this.errorDialogService.openDialog();
        }

        return EMPTY;
      })
    );
  }
}
