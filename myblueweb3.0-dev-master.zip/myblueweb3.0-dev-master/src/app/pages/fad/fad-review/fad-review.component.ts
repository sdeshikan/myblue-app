import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { FadReviewService } from './fad-review.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FadReviewQuestion } from '../modals/fad-review-questions.modal';
import { Location } from '@angular/common';
import { AlertService } from '../../../shared/services/alert.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { FadDoctorRatingsRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadDoctorRatingsRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { AuthService } from '../../../shared/shared.module';

@Component({
  selector: 'app-fad-review',
  templateUrl: './fad-review.component.html',
  styleUrls: ['./fad-review.component.scss']
})
export class FadReviewComponent implements OnInit, StarRatingComponentConsumer {
  reviewForm: FormGroup;
  reviewquestions: FadReviewQuestion[] = [];
  reviewSubmitSuccess: boolean = false;
  reviewSubmitErrorfailed: boolean = false;
  reviewAlreadyDone: boolean = false;
  forModeration: boolean = false;
  canReview: boolean = false;
  impersonate: boolean = true;

  public doctorInfo: any;
  reviewSubmitSuccessMessage: any;
  constructor(
    private fadReviewService: FadReviewService,
    private location: Location,
    private alertService: AlertService,
    private fadDoctorProfileService: FadDoctorProfileService,
    public authService: AuthService
  ) {}

  ngOnInit() {
    const FadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    FadDoctorProfileRequestParams.setReviewIdentifier(sessionStorage.getItem('reviewIdentifier'));
    const authUserId = this.authService.useridin;
    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      FadDoctorProfileRequestParams.useridin = this.authService.useridin;
    }
    this.fadDoctorProfileService.getAcceptableReviewers(FadDoctorProfileRequestParams).subscribe(responseData => {
      console.log(responseData);
      this.canReview = responseData.canReview;
      if (this.canReview == true) {
        this.fadReviewService.getReviewQuestions().subscribe(response => {
          if (response && response.questionsList && response.questionsList.length > 0) {
            this.generateQuestionsForm(response.questionsList);
          }
        });
      } else {
        this.doctorInfo = sessionStorage.getItem('doctorreviewer');
        this.reviewAlreadyDone = true;
        this.reviewSubmitSuccessMessage = responseData.displaymessage;
        this.alertService.setAlert('', "Oops! You can't review yet.", AlertType.Failure);
      }
    });
    // fetch the quetions details
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  generateQuestionsForm(questions) {
    const group = {};
    for (const question of questions) {
      this.reviewquestions.push({ ...question, value: '' });
      group[question.id] = question.required ? new FormControl('', Validators.required) : new FormControl('');
    }
    this.reviewForm = new FormGroup(group);
  }

  onSubmit() {
    const questions = [];
    this.doctorInfo = sessionStorage.getItem('doctorreviewer');

    for (const [key, value] of Object.entries(this.reviewForm.value)) {
      questions.push({ questionNumber: key, questionValue: value });
    }

    this.fadReviewService.postReviewSubmitQuestions(questions).subscribe(response => {
      if (response && response.hasOwnProperty('result') && response.result == 0) {
        this.reviewSubmitSuccess = true;
        this.reviewSubmitSuccessMessage = response.displaymessage;
        this.alertService.setAlert('', 'Thank you for your review!', AlertType.Success);
        //this.location.back();
      } else {
        this.reviewAlreadyDone = true;
        this.reviewSubmitSuccessMessage = response.displaymessage;
        this.alertService.setAlert('', "Oops! You can't review yet.", AlertType.Failure);
        //this.reviewSubmitErrorfailed = true;
      }
    });
  }

  onCancel() {}

  closeScreen(): void {
    this.location.back();
  }
  gotoDoctorProfile() {
    this.location.back();
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }
}
