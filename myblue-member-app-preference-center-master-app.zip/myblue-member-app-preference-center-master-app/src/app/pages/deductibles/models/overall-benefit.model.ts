export interface OverallBenefitModel {
  networkIndicatorOverallBenefit: string;
  overallBenefitMax: number;
  overallBenefitMaxContributed: number;
  overallBenefitMaxRemainingToMeet: string;
  overallBenefitexclusionExcep: string;
  overallBenefitMaxLimitationContent: string;
}
