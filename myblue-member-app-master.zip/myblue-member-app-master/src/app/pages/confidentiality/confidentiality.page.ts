import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { HomeService } from '../../shared/services/home.service';

@Component({
  selector: 'app-confidentiality',
  templateUrl: './confidentiality.page.html',
  styleUrls: ['./confidentiality.page.scss']
})
export class ConfidentialityPage implements OnInit {
  text: string;
  from: any;
  confidentialityPageApiResponse: any;

  constructor(private route: ActivatedRoute, private location: Location, private homeService: HomeService) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.from = params.from;
    });
    this.homeService.getConfidentialityPageResponse().subscribe(response => {
      this.confidentialityPageApiResponse = Array.isArray(response) ? response[0] : response;
    });
  }
  close() {
    this.location.back();
  }
  get isFromRegister() {
    return this.from === 'register';
  }
}
