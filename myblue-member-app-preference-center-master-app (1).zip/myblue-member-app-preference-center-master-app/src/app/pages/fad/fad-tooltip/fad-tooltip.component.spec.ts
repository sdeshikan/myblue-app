import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadTooltipComponent } from './fad-tooltip.component';
import { TooltipService } from './fad-tooltip.service';

describe('FadTooltipComponent', () => {
  let component: FadTooltipComponent;
  let fixture: ComponentFixture<FadTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [TooltipService],
      declarations: [FadTooltipComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
