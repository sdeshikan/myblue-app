import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { StorageServiceModule } from 'angular-webstorage-service';
import { MomentModule } from 'angular2-moment';
import { TextMaskModule } from 'angular2-text-mask';
import { AppComponent } from './app.component';
import { LandingService } from './shared/services/landing.service';
import { MyMedicationDetailsService } from './pages/medications/myMedicationDetails/my-medication-details.service';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { NotificationPreferencesService } from './pages/notification-preferences-app/notification-preferences.service';
import { AppmodalsComponent } from './shared/modals/appmodals.component';
import { ConsentMeansComponent } from './shared/modals/consent-means/consent-means.component';
import { HomepageResolver } from './shared/routeresolvers/homepage-resolver';
import { MyCardsResolverService } from './shared/routeresolvers/my-cards-resolver.service';
import { MyPlansResolverService } from './shared/routeresolvers/my-plans-resolver.service';
import { MyclaimsResolverService } from './shared/routeresolvers/myclaims-resolver.service';
import { MymedsResolverService } from './shared/routeresolvers/mymeds-resolver.service';
import { MyprofileResolverService } from './shared/routeresolvers/myprofile-resolver.service';
import { AuthService } from './shared/services/auth.service';
import { AuthHttp } from './shared/services/authHttp.service';
import { DependantsService } from './shared/services/dependant.service';
import { FilterService } from './shared/services/filter.service';
import { GlobalService } from './shared/services/global.service';
import { MedicationsService } from './shared/services/medications/medications.service';
import { MyCardsService } from './shared/services/mycards/mycards.service';
import { ClaimsService } from './shared/services/myclaims/claims.service';
import { ProfileService } from './shared/services/myprofile/profile.service';
import { OrderreplacementService } from './shared/services/orderreplacement/orderreplacement.service';
import { OrderreplacementResolverService } from './shared/routeresolvers/orderreplacement-resolver';
import { AlertService, ConstantsService, SharedModule } from './shared/shared.module';
import { NoMenuResolver } from './shared/utils/nomenu.resolver';
import { MyplansService } from './pages/myplans-app/myplans.service';
import { NotificationPreferencesResolver } from './pages/notification-preferences-app/notification-preferences.resolver';
import { SsoResolver } from './pages/sso/sso.resolver';
import { SsoService } from './pages/sso/sso.service';
import { MyDedCoResolver } from './pages/myded-co-app/myded-co.resolver';
import { MyDedCoService } from './pages/myded-co-app/myded-co.service';
import { HeaderService } from './shared/layouts/header/header.service';
import { MyaccountResolver } from './pages/myaccount/myaccount.resolver';
import { MyAccountService } from './pages/myaccount/myaccount.service';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppRoutingModule, rootRoutes } from './app-routing.module';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicStorageModule } from '@ionic/storage';
import { TabsPageModule } from './pages/tabs/tabs.module';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { File } from '@ionic-native/file/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { environment } from '../environments/environment';
import { AnalyticsService } from './shared/services/analytics.service';
import { DynamicScriptLoaderService } from './shared/services/dynamic-script-loader.service';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { SwrveService, SwrveEventNames } from './shared/services/swrve.service';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { HomePageModule } from './pages/home/home.module';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { NGXS_PLUGINS, NgxsModule } from '@ngxs/store';
import { FitnessState } from './store/state/fitness.state';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { NgxsRouterPluginModule } from '@ngxs/router-plugin';
import { HttpResponseInterceptor } from './interceptors/http-response.interceptor';
import { logoutPlugin } from './store/ngxs-plugins/app.plugins';
import { AppState } from './store/state/app.state';
import { ErrorDialogService } from './shared/services/error-dialog.service';
import { MaterializeModule } from 'angular2-materialize';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { LoadingHelperClass } from './shared/classes/loadingHelper.class';
import { Camera } from '@ionic-native/camera/ngx';
import { ProgressModalComponent } from './modals/progress-modal/progress-modal.component';
import { ProgressModalModule } from './modals/progress-modal/progress-modal.module';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { JumpScreenComponent } from './pages/sso/jump-screen/jump-screen.component';
import { ProfileModalComponent } from './pages/my-pillpack-app/profile-modal/profile-modal.component';

import { AppInitService } from './services/app.service';

export function init_app(appLoadService: AppInitService) {
  return () => appLoadService.init();
}

@NgModule({
  declarations: [AppComponent, NotfoundComponent, AppmodalsComponent, JumpScreenComponent, ProfileModalComponent, ConsentMeansComponent],
  exports: [RouterModule],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    IonicModule.forRoot(),
    CommonModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot(rootRoutes, { onSameUrlNavigation: 'reload' }),
    CommonModule,
    NgIdleKeepaliveModule.forRoot(),
    IonicStorageModule.forRoot(),
    NgxsModule.forRoot([AppState, FitnessState], { developmentMode: !environment.production }),
    NgxsRouterPluginModule.forRoot(),
    NgxsReduxDevtoolsPluginModule.forRoot({ disabled: environment.production }),
    TabsPageModule,
    HomePageModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    TextMaskModule,
    MomentModule,
    MaterializeModule,
    StorageServiceModule,
    ProgressModalModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot({ showMaskTyped: true })
  ],
  entryComponents: [AppmodalsComponent, ProgressModalComponent, JumpScreenComponent, ProfileModalComponent, ConsentMeansComponent],
  providers: [
    AlertService,
    ErrorDialogService,
    AuthService,
    NoMenuResolver,
    ConstantsService,
    DependantsService,
    GlobalService,
    FilterService,
    AuthHttp,
    Camera,
    DatePipe,
    TitleCasePipe,
    OrderreplacementResolverService,
    OrderreplacementService,
    MyprofileResolverService,
    ProfileService,
    MyCardsResolverService,
    MyCardsService,
    MymedsResolverService,
    MedicationsService,
    MyDedCoResolver,
    MyDedCoService,
    MyaccountResolver,
    MyAccountService,
    ClaimsService,
    MyclaimsResolverService,
    SsoResolver,
    SsoService,
    LandingService,
    HomepageResolver,
    MyMedicationDetailsService,
    NotificationPreferencesService,
    NotificationPreferencesResolver,
    MyPlansResolverService,
    MyplansService,
    HeaderService,
    DynamicScriptLoaderService,
    AnalyticsService,
    SplashScreen,
    StatusBar,
    SmsRetriever,
    CallNumber,
    { provide: HTTP_INTERCEPTORS, useClass: HttpResponseInterceptor, multi: true },
    { provide: NGXS_PLUGINS, useValue: logoutPlugin, multi: true },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    AppInitService,
    {
      provide: APP_INITIALIZER,
      useFactory: init_app,
      deps: [AppInitService],
      multi: true
    },
    DocumentViewer,
    FileTransfer,
    File,
    FileOpener,
    EmailComposer,
    AppVersion,
    SwrveService,
    SwrveEventNames,
    Deeplinks,
    LocalNotifications,
    AndroidPermissions,
    Geolocation,
    LocationAccuracy,
    Keyboard,
    LoadingHelperClass
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
