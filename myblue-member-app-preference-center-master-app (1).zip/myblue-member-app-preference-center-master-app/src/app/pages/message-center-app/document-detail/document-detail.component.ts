import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { DocumentsService } from '../documents/documents.service';
import { GetBenefitTextResponseModelInterface } from '../modals/interfaces/getBenefitText-models.interface';
import { MessageCenter_BenefitTextType } from '../modals/types/message-center.types';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { DocumentDetailService } from './document-detail.service';

@Component({
  selector: 'app-document-detail',
  templateUrl: './document-detail.component.html',
  styleUrls: ['./document-detail.component.scss']
})
export class DocumentDetailComponent implements OnInit {
  public benefitText: GetBenefitTextResponseModelInterface;
  public benefitTextType: MessageCenter_BenefitTextType;
  public benefitTypeText: string;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private documentDetailService: DocumentDetailService,
    private documentsService: DocumentsService,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.onBackPressed();
    });
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_BenefitLists_DocumentsDetails);
    this.benefitText = this.route.snapshot.data.benefitText;
    this.benefitTextType = this.documentDetailService.getBenefitTextType();
    if (this.benefitTextType === 0) {
      this.benefitTypeText = 'Eligibility Provisions';
    } else if (this.benefitTextType === 1) {
      this.benefitTypeText = 'Claims Filling Limit';
    } else if (this.benefitTextType === 2) {
      this.benefitTypeText = 'Coordination of Benefits';
    } else if (this.benefitTextType === 3) {
      this.benefitTypeText = 'Overall Plan Limitations & Exclusions';
    }
  }

  public onBackPressed(): void {
    this.location.back();
  }
}
