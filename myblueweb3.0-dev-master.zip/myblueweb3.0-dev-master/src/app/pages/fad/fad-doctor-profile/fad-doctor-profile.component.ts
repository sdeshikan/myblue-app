import { Component, OnInit, ChangeDetectorRef, OnDestroy, ViewChild } from '@angular/core';
import { FadDoctorProfileService } from './fad-doctor-profile.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
// import { FVProSRProfessionalInSearchEntity, FVProSRLocation, FVProSRAffilitatedHospital }
// from '../modals/fad-vitals-professionals-search-response.model';
import { CustomizedAddressInfoForDisplayInterface, LinkInterface } from '../modals/interfaces/fad-doctor-profile.interface';
import { CustomizedAddressInfoForDisplay, Link } from '../modals/fad-doctor-profile.modal';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { Router, ActivatedRoute } from '@angular/router';
import { FadProfessionalInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  FadDoctorProfileRequestModelInterface,
  FadProfessionalResponseModelInterface,
  FadLocationDetailsInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import {
  FadDoctorProfileRequestModel,
  FadProfessionalResponseModel,
  FadDoctorRatingsRequestModel,
  FadDoctorRatingsResponseModel
} from '../modals/fad-doctor-profile-details.model';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AlertService } from '../../../shared/shared.module';
import { AlertType } from '../../../shared/alerts/alertType.model';
import * as moment from 'moment';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { BreadCrumb } from '../utils/fad.utils';
import { AuthService } from '../../../shared/shared.module';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadService } from '../fad.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';

@Component({
  selector: 'app-fad-doctor-profile',
  templateUrl: './fad-doctor-profile.component.html',
  styleUrls: ['./fad-doctor-profile.component.scss']
})
export class FadDoctorProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  public doctorProfile: any;
  public doctorName: string;
  public doctorDegree: string;
  public specialityNames: string = '';
  public identifiers = new Array();
  public languages = new Array();
  public certificates = new Array();
  public education = {};
  public awards = new Array();
  public doctorLocationsCustomizedAddressList: CustomizedAddressInfoForDisplayInterface[] = [];
  public hospitalAffiliationsList: any[] = []; // FVProSRAffilitatedHospital[] = [];  ***** temporary code change  DO NOT DELETE
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public doctorsStarRating = new Array();
  public doctorReviews = new Array();
  public acceptedNetworks = new Array();
  public locationDetails = new Array();

  public pcpidVisibleFlag: boolean;
  public inNetworkFlag: boolean;
  public outOfNetworkFlag: boolean;
  public noNetworkSelectedFlag: boolean;
  public registeredUserFlag: boolean;
  public anonymousUserFlag: boolean;
  private specialityNamesList: string[] = [];
  public isDisplaySpinnerProfessional: boolean = false;
  public isShowProfessionalDetialsSection: boolean = false;
  private selectedLocationIndex: number = 0;
  public fadProfessionalResposeData: FadProfessionalResponseModelInterface;
  public selectedLocationDetails: FadLocationDetailsInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public accordianToggleStatus: any = {};
  fadDoctorRatingsResponseData: FadDoctorRatingsResponseModelInterface;
  public fadLandingpagesearchcriteria: any = {};

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  networkId: number;

  reviewsListLimit: number = 3;
  reviewsLoadMoreLimit: number = 5;

  // Procedure details
  public isProcedure: boolean = false;
  public procedureTitle: string = '';
  public procedureId: number = 0;
  public acceptableReviews: boolean = false;
  public icon: boolean = false;
  public chapter224: boolean = false;
  public mleEligibility: string;
  public medicareuser: boolean = true;
  public toolTipTxt: string;
  public tierTooltipDescription: string;
  public fasFlag: boolean = false;
  public tierTooltip = new Array();
  public fasFlagAward: boolean = false;
  public displayRatealinkdentalnetwork: boolean = true;
  public awardIndex: number = 0;
  public npFlag: boolean = false;
  public profileTooltip = new Array();
  public npToolTipDescription: string = '';
  public identifierToolTipDescription: string = '';
  public identifierFlag: boolean = false;
  public bcToolTipDescription: string = '';
  public bcFlag: boolean = false;
  public gawdToolTipDescription: string = '';
  public gawdFlag: boolean = false;
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  constructor(
    private doctorProfileService: FadDoctorProfileService,
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private fadSearchResultsService: FadSearchResultsService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    public authService: AuthService,
    private fadService: FadService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private facilityProfileService: FadFacilityProfileService
  ) {}

  ngOnInit() {
    try {
      this.chapter224 = this.authService.getMLEIndicator() === 'lite';

      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }

      if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
        this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
      }
      /* this.doctorProfileService.getToolTipInfo().subscribe(data=>{
        if(data.toolTipInfo.awards){
        /*if(this.selectedLocationDetails.awards){
          this.awards.map((award)=>{
            let toolTipValue = this.getToolTipText(data.toolTipInfo.awards,award.name);
            award.toolTipInfo = toolTipValue;   
          });
        }
      }
    });*/
      if (this.authService.authToken != null) {
        if (this.authService.authToken.userType != null || this.authService.authToken.userType != undefined)
          this.medicareuser = this.authService.authToken.userType.toLowerCase() == 'medicare' ? false : true;
      }

      this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Doctor Details').setUrl('/fad/doctor-profile'));
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      var affiliatedlinkedid = sessionStorage.getItem('linkedAffiliationId');
      this.mleEligibility = this.authService.getMleEligibility();
      if (searchCriteria) {
        this.isProcedure = searchCriteria.getSearchText().isProcedure();
        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        if (affiliatedlinkedid == '' || affiliatedlinkedid == null || affiliatedlinkedid == 'null') {
          this.isProcedure = searchCriteria.getSearchText().isProcedure();
          this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        } else {
          this.isProcedure = false;
        }
        this.networkId =
          searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
            ? searchCriteria.getPlanName().getNetworkId()
            : FadConstants.defaults.networkId;
        if (this.networkId == 311005006 || this.networkId == 311005007) {
          this.displayRatealinkdentalnetwork = false;
        }
      }
      const resolvedData = this.route.snapshot.data.fadProfessionalResposeData;
      if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
        this.isShowProfessionalDetialsSection = false;
        this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
      } else {
        this.fadProfessionalResposeData = new FadProfessionalResponseModel();
        this.fadProfessionalResposeData = resolvedData;
        if (this.fadProfessionalResposeData.disclaimers) {
          this.disclaimers = this.fadProfessionalResposeData.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        if (this.fadProfessionalResposeData.onRecordDiclaimers) {
          this.onRecordDiclaimers = this.fadProfessionalResposeData.onRecordDiclaimers;
          if (
            this.onRecordDiclaimers &&
            this.onRecordDiclaimers.category &&
            this.onRecordDiclaimers.category == 'on_record' &&
            this.onRecordDiclaimers.text
          ) {
            this.disclaimersFlag = true;
            this.disclaimersText = this.onRecordDiclaimers.text;
          }
        }
        this.fadProfessionalResposeData.locations = resolvedData.locations;
        this.networkChanged = sessionStorage.getItem('networkChange');
        console.log(this.networkChanged);
        //const {locationId} = (<any>JSON.parse(sessionStorage.getItem("FadLandingPageSearchCriteria")) || {}).searchText;
        const locationId = sessionStorage.getItem('locationId');
        this.loadDetailsBasedOnLocation(locationId);
        this.isShowProfessionalDetialsSection = true;
      }
      this.getNPToolTipDescription();
      this.getProfessionalratings();
    } catch (exception) {
      this.isShowProfessionalDetialsSection = false;
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadDoctorProfileComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }
  getNPToolTipDescription() {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip.code === 'PANP') {
          this.npToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPIN') {
          this.identifierToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PBCH') {
          this.bcToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PPAA') {
          this.gawdToolTipDescription = tooltip.toolTip.description;
        }
      });
    }
    console.log('profile ToolTip', this.profileTooltip);
  }

  getToolTipText(toolTip, awardname) {
    this.toolTipTxt = '';
    /* toolTip.forEach(toolTipValue=>{
      if(toolTipValue.toolTip.name.toLowerCase()===awardname.toLowerCase()){
        this.toolTipTxt=toolTipValue.toolTip.description;   
      }
    }); */
    return this.toolTipTxt;
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }
  fasIcon() {
    this.fasFlag = !this.fasFlag;
  }
  newNPIcon() {
    this.npFlag = !this.npFlag;
  }
  bcIcon() {
    this.bcFlag = !this.bcFlag;
  }
  gawdIcon() {
    this.gawdFlag = !this.gawdFlag;
  }
  identifierIcon() {
    this.identifierFlag = !this.identifierFlag;
  }
  fasIconAward(index) {
    this.fasFlagAward = !this.fasFlagAward;
    this.awardIndex = index;
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  getRating(ratings, totalReviews) {
    this.startRating = new StarRatingComponentInputModel();

    this.startRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.startRating;
  }

  public getReviewRating(ratings) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.overAllRating = parseFloat(!ratings ? 0 : ratings);

    this.startRating.showReviewCount = false;
    return this.startRating;
  }

  formatMobileNumer(primaryPhone) {
    if (primaryPhone && primaryPhone.length > 9) {
      return `(${primaryPhone.substring(0, 3)}) ${primaryPhone.substring(3, 6)}-${primaryPhone.substring(6, 10)}`;
    } else {
      return primaryPhone;
    }
  }

  redirectToFacility(facilityId) {
    if (facilityId) {
      this.facilityProfileService.facilityProfile = facilityId;
      sessionStorage.setItem('facilityProfileId', facilityId.toString());
      sessionStorage.setItem('facilityLocationFlag', 'true');
      this.router.navigate([FadConstants.urls.fadFacilityProfilePage]);
    }
  }

  loadDetailsBasedOnLocation(locationId) {
    this.awards = [];
    this.selectedLocationIndex = locationId;
    //this.selectedLocationDetails = this.fadProfessionalResposeData.locations[locationId];
    this.selectedLocationDetails = this.fadProfessionalResposeData.locations.find(p => p.id.toString() == locationId);
    // this.selectedLocationDetails.tiers = { description: 'TierValue' };
    if (this.selectedLocationDetails.awards) {
      this.selectedLocationDetails.awards.forEach(award => {
        this.awards.push(award);
      });
    }
    if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
      this.getToolTipDescription(this.tierTooltip, this.selectedLocationDetails.tiers.description);
    }
    this.accordianToggleStatus = {};

    /* this.selectedLocationDetails.facilityCost = {
      copay: 0,
      coinsuranceAmount: 3750,
      deductibleAmount: 450,
      memberCost: 28071,
      employerCost: 0,
      procedureCost: 28071
    };
    this.selectedLocationDetails.costBenefits = {
      individualDeductibleLimit: 1200,
      individualDeductibleAccumulated: 700,
      individualOutofPocketLimit: 4500,
      individualOutofPocketAccumulated: 2500,
      overallDeductibleLimit: 1500,
      overallDeductibleAccumulated: 1000,
      familyOutofPocketLimit: 2000,
      familyOutofPocketAccumulated: 1000
    } */
  }

  public copyIdentifierValue(event, inputId: string): void {
    const element: any = document.querySelector('#' + inputId);
    element.select();
    document.execCommand('copy');
    element.setSelectionRange(0, 0);
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  public showCostBreakdown(facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.parentPage = FadConstants.text.doctorPage;
    this.router.navigate([`/fad/cost-breakdown`]);
  }

  public searchInNetworkDoctors() {
    throw new Error('yet to be coded');
  }

  public getDirections(location, event): void {
    const locationURL = 'http://maps.google.com/?q=' + encodeURI(location);
    window.open(locationURL, '_self');
  }

  public openFacility(event): void {
    // try {
    //   // this.doctorProfileService.doctorProfile = this.componentInput.professional;
    //   setTimeout(() => {
    //     this.router.navigate(['/fad/facility-profile']);
    //   }, 1);
    // } catch (exception) {
    //   this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
    //     FadConstants.components.fadDoctorProfileComponent,
    //     FadConstants.methods.openProfile);
    // }
  }
  public isAnonymousUser() {
    let returnValue = false;
    try {
      const userid = this.authService.useridin;
      returnValue = userid && userid !== 'undefined' && userid !== 'null' ? false : true;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAnonymousUser
      );
    }
    return returnValue;
  }

  private getProfessionalratings(): void {
    this.isDisplaySpinnerProfessional = true;
    const FadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    const ratingsIdentifier: string = this.fadProfessionalResposeData['ratingsIdentifier'];
    const reviewIdentifier: string = this.fadProfessionalResposeData['reviewIdentifier'];
    try {
      FadDoctorProfileRequestParams.setRatingIdentifier(ratingsIdentifier);
      FadDoctorProfileRequestParams.setReviewIdentifier(reviewIdentifier);
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        FadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      this.fadDoctorProfileService.getProfessionalratings(FadDoctorProfileRequestParams).subscribe(
        responseData => {
          if (responseData) {
            this.fadDoctorRatingsResponseData = new FadDoctorRatingsResponseModel();
            this.fadDoctorRatingsResponseData = responseData;
          }
        },
        error => {
          this.isDisplaySpinnerProfessional = false;
        }
      );
      if (this.isAnonymousUser() != true) {
        // this.fadDoctorProfileService.getAcceptableReviewers(FadDoctorProfileRequestParams).subscribe((responseData) => {
        //   this.acceptableReviews = responseData.canReview;
        // })
      }
    } catch (exception) {
      this.isDisplaySpinnerProfessional = false;
    }
  }

  public loadMoreReviews() {
    this.reviewsListLimit += this.reviewsLoadMoreLimit;
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public reviewPage() {
    if (
      this.authService.isAuthenticated() &&
      this.authService.isLogin() &&
      this.authService.getScopeName() == 'AUTHENTICATED-AND-VERIFIED'
    ) {
      sessionStorage.setItem('doctorreviewer', this.fadProfessionalResposeData['doctorName'].toString());
      sessionStorage.setItem('reviewIdentifier', this.fadProfessionalResposeData['reviewIdentifier'].toString());
      this.router.navigate(['/fad/review']);
    } else if (this.authService.getScopeName() == 'REGISTERED-NOT-VERIFIED') {
      this.router.navigate(['/register/register-detail']);
    } else {
      this.router.navigate(['./login']);
    }
  }
  public convertAmountToDecimalValue(value) {
    const int_part = Math.trunc(value);
    const float_part = Number((value - int_part).toFixed(2));
    const decimal: string[] = float_part.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }

  convertDate(date) {
    if (date) {
      return moment(date, 'YYYYMMDD').format();
    } else {
      return '';
    }
  }

  additionalCostExpantion() {
    this.icon = !this.icon;
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }
  public reviewBenefits(): void {
    //throw new Error('reviewBenefits Method not implemented.');
    this.fadService.reviewMyBenfits();
  }
}
