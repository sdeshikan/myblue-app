import { CommonModule, CurrencyPipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { InfoModalComponent } from '../../../../modals/info-modal/info-modal.component';
import { InfoModalModule } from '../../../../modals/info-modal/info-modal.module';
import { InfoPopoverComponent } from '../../../../popovers/info-popover/info-popover.component';
import { InfoPopoverModule } from '../../../../popovers/info-popover/info-popover.module';
import { ReimbursementDetailsPage } from './reimbursement-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InfoModalModule,
    InfoPopoverModule,
    ReactiveFormsModule,
    RouterModule,
    NgxCurrencyModule,
    NgxMaskModule
  ],
  providers: [CurrencyPipe],
  declarations: [ReimbursementDetailsPage],
  entryComponents: [InfoModalComponent, InfoPopoverComponent]
})
export class ReimbursementDetailsPageModule {}
