import { TaxFormDataModel } from './tax-forms-data-models';

export interface TaxFormsModel {
    formData: TaxFormDataModel[];
}
