import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FadGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.isUserAuthenticatedAndVerified()) {
      const postLoginInfo = sessionStorage.getItem('postLoginInfo');
      if (postLoginInfo) {
        const postLoginInfoJson = JSON.parse(postLoginInfo);
        if (postLoginInfoJson.hasCI || (postLoginInfoJson.hasSS && postLoginInfoJson.hasSSO)) {
          this.router.navigate(['/home']);
          return false;
        }
      } else {
        this.router.navigate(['/home']);
        return false;
      }
    }
    return true;
  }

  isUserAuthenticatedAndVerified() {
    const authTokenDetails = sessionStorage.getItem('authToken');
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      const authTokenDetailsJson = JSON.parse(authTokenDetails);
      if (authTokenDetailsJson && authTokenDetailsJson.scopename === 'AUTHENTICATED-AND-VERIFIED') {
        return true;
      }
    }
    return false;
  }
}
