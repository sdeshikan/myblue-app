import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { FinancialComponent } from './financial.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [FinancialComponent],
  declarations: [FinancialComponent]
})
export class FinancialModule {}
