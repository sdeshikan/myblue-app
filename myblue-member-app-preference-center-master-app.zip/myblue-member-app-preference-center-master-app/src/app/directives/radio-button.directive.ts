import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[innercircle]'
})
export class RadioButtonDirective implements OnChanges {
  @Input() innercircle: any;
  constructor(private el: ElementRef) {}

  ngOnChanges(): void {
    setTimeout(() => {
      const shadow = this.el.nativeElement.shadowRoot;
      if (shadow) {
        try {
          shadow.querySelector('.radio-icon').style.cssText = '--color-checked: #76767675;--color:#76767675;visibility: visible;display:block;';
          shadow.querySelector('.radio-inner').style.cssText = 'height: 85%; width: 85%; --color-checked:#1866a3b3;border-radius:50%;margin-top: 2px;margin-left: 2px;';
        } catch (e) {}
      }
    }, 200);
  }
}
