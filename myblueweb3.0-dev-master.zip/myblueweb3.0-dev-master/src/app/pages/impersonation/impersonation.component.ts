import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalService } from '../../shared/services/global.service';
import { AlertService } from '../../shared/shared.module';
import { ImpersonationService } from './impersonation.service';

@Component({
  selector: 'app-impersonation',
  templateUrl: './impersonation.component.html',
  styleUrls: ['./impersonation.component.scss']
})
export class ImpersonationComponent implements OnInit {
  isApiCalled = false;
  impersonationAccessError: string;
  useridin: string;

  constructor(
    private impersonationService: ImpersonationService,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    //console.log(this.route.snapshot.params.useridin);
    let user = this.route.snapshot.params.useridin;
    let decodeduser: string = decodeURIComponent(user);
    let userid = decodeduser.trim();
    let search = '__';
    let re1 = new RegExp(search, 'g');
    const mock = userid.replace(re1, '/');

    console.log('encrypted:' + userid);
    const decryptedUserName = this.impersonationService.decryptData(mock);
    //  const decryptedUserName = window.atob(userid);
    console.log('decrypted:' + decryptedUserName);

    // 1. convert to json
    const stringPayloadFromMSST = decryptedUserName;
    const jsonPalyloadFromMyblue = JSON.parse(stringPayloadFromMSST);
    console.log('jsonPalyloadFromMyblue', jsonPalyloadFromMyblue);
    // check no of keys and exact key name in json
    if (
      Object.keys(jsonPalyloadFromMyblue).length > 4 ||
      !('timestamp' in jsonPalyloadFromMyblue) ||
      !('username' in jsonPalyloadFromMyblue) ||
      !('dob' in jsonPalyloadFromMyblue) ||
      !('memberid' in jsonPalyloadFromMyblue)
    ) {
      this.router.navigate(['/impersonation/error']);
      console.log('Invalid json for Impersonation');
      //console.log("no of keys from msst: "+Object.keys(jsonPalyloadFromMyblue).length);
    } else {
      //console.log("no of keys from msst: "+Object.keys(jsonPalyloadFromMyblue).length);
      // 2. check - diff from time.now() and look for 30  seconds value
      const timeDiff = 30 * 1000;
      console.log(Date.now() - jsonPalyloadFromMyblue['timestamp']);
      if (Date.now() - jsonPalyloadFromMyblue['timestamp'] > timeDiff) {
        // 3. redirect to login  - which inturn will take to error page.
        this.router.navigate(['/impersonation/error']);
        return;
      }

      //const impersonationData = {useridin:'finance4@yopmail.com'};
      //const impersonationData = {useridin: this.route.snapshot.params.useridin};
      const impersonationUserName = jsonPalyloadFromMyblue['username'];
      const impersonationMemberId = jsonPalyloadFromMyblue['memberid'];
      const impersonationDOB = jsonPalyloadFromMyblue['dob'];
      const data = impersonationMemberId + '|' + impersonationDOB;

      const impersonationData = { useridin: impersonationUserName + '|' + impersonationMemberId + '|' + impersonationDOB };
      //const impersonationData = {useridin:jsonPalyloadFromMyblue['username']};
      console.log('ImpersonationData: ' + impersonationData);
      //const impersonationData = {useridin:userid};

      sessionStorage.setItem('key', null);
      this.alertService.clearError();
      this.impersonationService.impersonation(impersonationData).subscribe(
        response => {
          if (response.scopename === 'AUTHENTICATED-AND-VERIFIED' && response.migrationtype === 'NONE') {
            if (response) {
              this.globalService.setAdobe();
              console.log('Redirecting from Impersonation to Home ');
              console.log(response);
              this.router.navigate(['/home']);
            }
          } else {
            console.log('ID doesnt belong to a AV user');
            this.router.navigate(['/impersonation/error']);
          }
        },
        err => {
          this.isApiCalled = false;
          if (err.status >= 403) {
            console.log(err.status);
            console.log(err.error);
            // let message = err.error.displaymessage;
            let message = err.error;
            console.log(message);
            this.impersonationAccessError = message;
            this.router.navigate(['/impersonation/error']);
            console.log('Redirecting from Impersonation to Error page');
          } else {
            console.log('Impersonation error response');
          }
        }
      );
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
