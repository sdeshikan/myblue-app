import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { TitleCasePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatExpansionModule,
} from '@angular/material';
import { IonicModule } from "@ionic/angular";
import { FilterPipeModule } from 'ngx-filter-pipe';
import { FilterPipe } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { SharedModule } from '../../shared/shared.module';
import { ClaimDetailsPage } from './claim-details/claim-details.page';
import { ClaimStatusDetailsPage } from './claim-status-details/claim-status-details.page';
import { ClaimsAppRouter } from './claims.routing';
import { ClaimsService } from './claims.service';
import { ClaimsPage } from './claims/claims.page';
import { FilterClaimsComponent } from './claims/filter-claims/filter-claims.component';
import { ClaimIdModule } from '../../pipes/claim-id/claim-id.module';
import { PromoImagesModule } from '../../shared/components/promo/promo-images/promo-images.module';

@NgModule({
  declarations: [ClaimsPage, ClaimDetailsPage, ClaimStatusDetailsPage, FilterClaimsComponent],
  imports: [
    CommonModule,
    ClaimsAppRouter,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MatExpansionModule,
    FilterPipeModule,
    OrderModule,
    IonicModule,
    ClaimIdModule,
    PromoImagesModule
  ],
  providers: [ClaimsService, DatePipe, FilterPipe, TitleCasePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [FilterClaimsComponent]
})
export class ClaimsAppModule {}
