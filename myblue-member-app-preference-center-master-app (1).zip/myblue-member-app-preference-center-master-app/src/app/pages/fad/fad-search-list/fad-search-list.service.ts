import { Injectable } from '@angular/core';

@Injectable()
export class FadSearchListService {
  public isFilterChangedFlag = false;

  isFilterChanged(value) {
    this.isFilterChangedFlag = value;
  }
}
