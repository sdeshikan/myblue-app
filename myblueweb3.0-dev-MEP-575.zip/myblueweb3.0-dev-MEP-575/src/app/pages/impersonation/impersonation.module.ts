import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
//import { LoginComponent } from './login.component';
//import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { LoginRouter } from './login.routing';
//import { LoginService } from './login.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ImpersonationErrorComponent } from './impersonation-error/impersonation-error.component';
import { ImpersonationComponent } from './impersonation.component';
import { ImpersonationRouter } from './impersonation.routing';
import { ImpersonationService } from './impersonation.service';

@NgModule({
  declarations: [ImpersonationComponent, ImpersonationErrorComponent],
  exports: [],
  imports: [
    CommonModule,
    ImpersonationRouter,
    //HttpClientModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [
    //LoginService
    ImpersonationService
  ]
})
export class ImpersonationModule {}
