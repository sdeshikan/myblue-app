import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { HttpClientModule } from '@angular/common/http';
import { MatGridListModule } from '@angular/material/grid-list';
import { StorageServiceModule } from 'angular-webstorage-service';
import { VerifyEmailMobileComponent } from '../../my-profile/verify-email-mobile/verify-email-mobile.component';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule
  ],
  providers: [
 
  ],
  declarations: [
    VerifyEmailMobileComponent
  ],
  exports:[
      VerifyEmailMobileComponent
  ],
})
export class verifyEmail { }
