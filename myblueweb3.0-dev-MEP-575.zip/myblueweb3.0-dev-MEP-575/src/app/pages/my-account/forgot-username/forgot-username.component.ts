import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthService } from '../../../shared/services/auth.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { MyAccountsConstants } from '../constants/my-accounts.constants';
import { MyAccountService } from '../my-account.service';

@Component({
  selector: 'app-forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.scss']
})
export class ForgotUsernameComponent implements OnDestroy, OnInit {
  forgotUsernameForm: FormGroup;
  dobMask: any[];
  phoneMask: any[];
  mobileNumberMessages = {
    required: 'Please enter a valid phone number.'
  };
  emailMessages = {
    required: 'Please enter a valid email.'
  };

  constructor(
    private fb: FormBuilder,
    private myAccountService: MyAccountService,
    private authService: AuthService,
    private authHttp: AuthHttp,
    private alertService: AlertService,
    private router: Router,
    private validationService: ValidationService,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService
  ) {
    try {
      this.forgotUsernameForm = this.fb.group({
        email: ['', [Validators.required, this.validationService.emailValidator()]],
        mobile: ['', [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()]]
      });
      this.phoneMask = this.validationService.phoneMask;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.constructor
      );
    }
  }

  handleSuccessResponse() {
    try {
      // Security Fixes - Swapping  Confirm Identity with Access Code
      sessionStorage.setItem('otp', 'TRUE');
      this.router.navigate(['/account/verifyAccessCode', 'FUN']).then(() => {
        this.alertService.setAlert('Verification code sent.', '', AlertType.Success);
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.handleSuccessResponse
      );
    }
  }

  getToken() {
    try {
      this.authService.getTokens().subscribe(
        token => {
          this.authService.cryptoToken = token;
          this.authService.persistSession();
          this.verifyIsUserValid();
          console.log('ATOKEN: Crypto token called! whats in UI session storage: ', sessionStorage['token']);
        },
        err => {
          console.log('Error in forgot username', err);
          this.authHttp.handleError(err);
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.getToken
      );
    }
  }

  verifyIsUserValid() {
    try {
      const request = this.forgotUsernameForm.value;
      request.mobile = request.mobile ? request.mobile.replace(/-/g, '') : request.mobile;
      request.email = request.email ? request.email.toLowerCase().trim() : request.email;
      this.myAccountService.verifyUserValid(request).subscribe(
        res => {
          if (res) {
            this.handleSuccessResponse();
            //Security Fixes

            this.myAccountService.funverifyuserResponse = res;
          }
        },
        error => {
          console.log('Error in forgot username', error);
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.messageCenterModule,
            MyAccountsConstants.services.myAccountService,
            MyAccountsConstants.methods.getDocumentViewData
          );
        }
      );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.verifyIsUserValid
      );
    }
  }

  onSubmit() {
    try {
      this.alertService.clearError();
      this.getToken();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.onSubmit
      );
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  ngOnInit() {
    try {
      this.alertService.clearError();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myAccountModule,
        MyAccountsConstants.components.forgotUsernameComponent,
        MyAccountsConstants.methods.ngOnInit
      );
    }
  }
}
