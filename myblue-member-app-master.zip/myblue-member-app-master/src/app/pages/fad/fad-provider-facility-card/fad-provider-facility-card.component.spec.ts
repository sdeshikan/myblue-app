import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FadFacilityCardComponent } from '../fad-facility-card/fad-facility-card.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PhoneNumberPipe } from '../../../shared/pipes/phone/phoneNumber.pipe';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';

describe('FadProviderFacilityCardComponent', () => {
  let component: FadFacilityCardComponent;
  let fixture: ComponentFixture<FadFacilityCardComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadFacilityCardComponent, PhonePipe, PhoneNumberPipe],
      providers: [
        FadSearchResultsService,
        AuthHttp,
        AuthService,
        ConstantsService,
        FadFacilityProfileService,
        CallNumber,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
