import { NgModule } 
    from '@angular/core';
import { ProfileInfoAppPage } 
    from './profile-info-app/profile-info-app.page';
import { UpdatePasswordAppPage } 
    from '../member-migration-app/profile-info-update-app/update-password-app/update-password-app.page';
import { VerifyEmailMobileAppPage } 
    from '../member-migration-app/profile-info-update-app/verify-email-mobile-app/verify-email-mobile-app.page';
import { MigrationSuccessAppPage } 
    from '../member-migration-app/profile-info-update-app/migration-success-app/migration-success-app.page';
import { Routes, RouterModule } 
    from '@angular/router';
import { MigrationConfirmationAppPage } 
    from './profile-info-update-app/migration-confirmation-app/migration-confirmation-app.page';
import { MigrationAppGuard } 
    from './migration-app.guard';

const MEM_MIGRATION_APP_ROUTER: Routes = [
  {
    path: '',
    component: ProfileInfoAppPage,
    data: {
      pageTitle: 'Member-Migration'
    },
    canActivate: [MigrationAppGuard]
  },
  {
    path: 'verify',
    component: VerifyEmailMobileAppPage,
    canActivate: [MigrationAppGuard]
  },
  {
    path: 'updatePassword',
    component: UpdatePasswordAppPage,
    canActivate: [MigrationAppGuard]
  },
  {
    path: 'success',
    component: MigrationSuccessAppPage
  },
  {
    path: 'confirm',
    component: MigrationConfirmationAppPage,
    canActivate: [MigrationAppGuard]
  }
];

export const MigrationAppRouter = RouterModule.forChild(MEM_MIGRATION_APP_ROUTER);
