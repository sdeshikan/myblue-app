import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { PostLoginModel } from '../../models/post-login.model';
import { HomeService } from '../../shared/services/home.service';
import { IabService } from '../../shared/services/iab/iab.service';
import { ConstantsService } from '../../shared/shared.module';
import { AppSelectors } from '../../store/selectors/app-selectors';
import { SsoService } from '../sso/sso.service';

@Component({
  selector: 'app-careCost',
  templateUrl: 'care-cost.page.html',
  styleUrls: ['care-cost.page.scss']
})
export class CareCostPage {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;

  homeNavigationApiResponse: any;
  listItems: CareCostItemType[];
  isAuthenticatedUser: boolean;
  callNurseLine: CallNurseLine;

  constructor(
    private router: Router,
    private ssoService: SsoService,
    private iabService: IabService,
    private constants: ConstantsService,
    public homeService: HomeService
  ) {}

  ionViewWillEnter() {
    this.isAuthenticatedUser = this.scopeName.includes('AUTHENTICATED');
    this.initializeItemList();
  }

  initializeItemList() {
    this.homeService.setSessionLinks();

    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        const findADoctorUrl = this.homeNavigationApiResponse.APPTextUrl3 || '';
        const callNurseLinkUrl = this.homeNavigationApiResponse.APPTextUrl2 || '';
        this.callNurseLine = { labelText: 'Call the 24-Hour Nurse Line', phoneNumber: callNurseLinkUrl, icon: 'fal fa-phone fa-lg' };
        this.listItems = [
          {
            label: 'Find a Doctor & Estimate Costs',
            icon: 'fal fa-stethoscope fa-lg',
            url: findADoctorUrl,
            isSSO: true,
            ssoType: 'fad',
            isPhone: false
          },
          {
            label: 'Live Video Visits with Well Connection',
            icon: 'fal fa-comment-medical fa-lg',
            url: this.constants.wellConnectionUrl,
            isSSO: false,
            ssoType: '',
            isPhone: false
          }
        ];
      }
    });
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  navigate(item: CareCostItemType) {
    if (item.url.endsWith('fad')) {
      const isSmartShopperUser = this.checkSmartShopperUser(this.postLoginInfo);
      if (isSmartShopperUser) {
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['tabs/fad']);
      }
      return;
    }
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else {
      this.iabService.create(item.url);
    }
  }
}

interface CareCostItemType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
}

interface CallNurseLine {
  labelText: string;
  phoneNumber: string;
  icon: string;
}
