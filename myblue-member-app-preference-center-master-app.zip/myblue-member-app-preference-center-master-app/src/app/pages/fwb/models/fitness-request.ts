import { MemberModel } from './member-model';

export interface FitnessRequestModel {
  useridin: string;
  claim: {
    year: number;
    type: string;
    forMember: MemberModel;
    isEHB: boolean;
    category?: string;
    unitAmount?: number;
    annualFeeAmount?: number;
    totalAmount: number;
    planCancelDate?: string;
    collateralName: string;
    subscriberAlternateEmail?: string;
    memberAlternateEmail?: string;
  };
  programInformation: {
    programName: string;
    address: string;
    state: string;
    zip: string;
    phoneNumber: string;
  };
}
