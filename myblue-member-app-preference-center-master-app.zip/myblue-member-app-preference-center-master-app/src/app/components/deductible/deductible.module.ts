import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { DeductibleComponent } from './deductible.component';


@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [DeductibleComponent],
  declarations: [DeductibleComponent]
})
export class DeductibleModule {}
