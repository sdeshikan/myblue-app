import { FadFacilityInterface, GetSearchByFacilityResponseModelInterface } from './getSearchByFacility-models.interface';
import { GetSearchByProfessionalResponseModelInterface } from './getSearchByProfessional-models.interface';
import { GetSearchBySpecialtyResponseModelInterface } from './getSearchBySpeciality-models.interface';
// tslint:disable-next-line:no-empty-interface
export interface FadSearchListComponentOutputModelInterface {
    // selectedProfessionals: FadFacilityInterface[];
}

export interface FadSearchListComponentInputModelInterface {
    searchResults: GetSearchByProfessionalResponseModelInterface;
}

// tslint:disable-next-line:no-empty-interface
export interface FadFacilityListComponentOutputModelInterface {

}

export interface FadFacilityListComponentInputModelInterface {
    facilityResults: GetSearchByFacilityResponseModelInterface;
}

export interface FadSpecialtyListComponentOutputModelInterface {

}

export interface FadSpecialtyListComponentInputModelInterface {
    specialtyResults: GetSearchBySpecialtyResponseModelInterface;
}

export interface ClearSearchResultFlagInterface {
    clearFlag: boolean;
    type: string;
}
