import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { SwrveEventNames, SwrveService } from '../../../../services/swrve.service';
import { AlertType } from '../../../../shared/alerts/alertType.model';
import { AlertService } from '../../../../shared/services/alert.service';
import { Logout } from '../../../../store/actions/app.actions';
import { AppSelectors } from '../../../../store/selectors/app-selectors';
import { MigrationAppService } from '../../migration-app.service';

/* tslint:disable */
@Component({
  selector: 'app-migration-confirmation-app',
  templateUrl: './migration-confirmation-app.page.html',
  styleUrls: ['./migration-confirmation-app.page.scss']
})
export class MigrationConfirmationAppPage implements OnInit {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  public userid = '';

  constructor(
    private location: Location,
    private router: Router,
    private alertService: AlertService,
    private http: HttpClient,
    public migrationAppService: MigrationAppService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private store: Store
  ) {}

  ngOnInit() {
    this.userid = this.migrationAppService.getMemAcctMergeRequest().selectedUserId;
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MigrationConfirmation);
  }

  exploreNew(): void {
    if (this.authToken.migrationtype === 'SINGLE-APP') {
      this.migrateAndSendAccessCode();
    } else {
      this.router.navigate(['member-migration/updatePassword']);
      sessionStorage.setItem('migrationConfirmed', 'true');
    }
  }

  private migrateAndSendAccessCode(): any {
    const memacctmergerequest = this.migrationAppService.getMemAcctMergeRequest();
    this.migrationAppService
      .migrationCall(
        this.migrationAppService.migrationRequest(
          memacctmergerequest.selectedUserId,
          memacctmergerequest.selectedUserIdType,
          memacctmergerequest.selectedUserScope,
          memacctmergerequest.webUserID,
          memacctmergerequest.appUserIDs,
          memacctmergerequest.emailAddress,
          memacctmergerequest.hintQuestion,
          memacctmergerequest.hintAnswer,
          ''
        )
      )
      .subscribe(res => {
        let isValid = false;
        if (res['result'] === '0') {
          isValid = true;
          if (memacctmergerequest.selectedUserId) {
            localStorage.setItem('login-user', memacctmergerequest.selectedUserId);
          }
        } else {
          if (res['errormessage'] === 'Migration completed, but update notification could not be sent') {
            isValid = true;
            if (memacctmergerequest.selectedUserId) {
              localStorage.setItem('login-user', memacctmergerequest.selectedUserId);
            }
          }
        }
        if (isValid) {
          this.migrationAppService
            .savePageUrl('/myprofile', this.migrationAppService.getMemAcctMergeRequest().selectedUserId)
            .subscribe(migrationServiceResp => {
              if (migrationServiceResp['result'] === 0) {
                const memacctmergerequest_1 = this.migrationAppService.getMemAcctMergeRequest();
                if (memacctmergerequest_1.selectedUserScope === 'AUTHENTICATED-AND-VERIFIED') {
                  if (memacctmergerequest_1.isVerifiedEmail === 'true') {
                    //call send notifications and inform user that he has updated his hint QA
                    this.sendNotification();
                    this.store.dispatch(new Logout());
                    this.router.navigate(['login']);
                  } else {
                    this.sendAccessCode();
                    // this is a dead code since ther is no sceletion of user in SINGLE-APP
                  }
                } else {
                  this.sendAccessCode();
                }
              }
            });
        } else {
          if (res['result'] === '-2') {
            this.alertService.setAlert(
              "We're currently experiencing technical difficulties. Please try again later, or call <a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.",
              '',
              AlertType.Failure
            );
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      });
  }

  private sendAccessCode() {
    const currScope = this.authToken ? this.authToken.scopename : '';
    const memacctmergerequest = this.migrationAppService.getMemAcctMergeRequest();
    if (currScope === 'AUTHENTICATED-AND-VERIFIED') {
      this.sendCommChlAccessCode(memacctmergerequest.emailAddress, memacctmergerequest.selectedUserId);
    } else {
      this.sendaccesscode(memacctmergerequest.emailAddress, memacctmergerequest.selectedUserId);
    }
  }

  private sendaccesscode(emailAddress, selectedUserId): void {
    this.migrationAppService.sendAccessCode(emailAddress, selectedUserId).subscribe(
      res => {
        if (res['result'] === '0') {
          sessionStorage.setItem('sendCodeRes', res);
          this.router.navigate(['member-migration/verify']);
        } else {
          console.log('sendaccesscode error', res);
          if (res['result'] === '-1') {
            this.alertService.setAlert('We are unable to complete your request. Please try again.', '', AlertType.Failure);
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  private sendCommChlAccessCode(emailAddress, selectedUserId): void {
    this.migrationAppService.sendCommChlAccessCode(emailAddress, selectedUserId).subscribe(
      res => {
        if (res['result'] === '0') {
          this.router.navigate(['member-migration/verify']);
        } else {
          if (res['result'] === '-1') {
            this.alertService.setAlert(
              "We're currently experiencing technical difficulties. Please try again later, or call <a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.",
              '',
              AlertType.Failure
            );
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  back(): void {
    if ((window as any).history.length > 0) {
      // TODO: What??? Come on now
      (window as any).history.back();
    }
  }

  private sendNotification() {
    const getMemacctmergerequest = this.migrationAppService.getMemAcctMergeRequest();
    const notificationRequest = {
      useridin: this.useridin,
      commChannel: getMemacctmergerequest.emailAddress,
      commChannelType: 'EMAIL',
      templateKeyword: 'UPDATENOTIFICATION_EMAIL',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue: this.authToken && this.authToken.firstName ? this.authToken.firstName : ''
        },
        {
          keyName: 'myProfileURL',
          keyValue: window.location.origin + '/myprofile'
        },
        {
          keyName: 'updatedFields',
          keyValue: this.getUpdateFieldsBasedOnScenario()
        }
      ]
    };

    this.migrationAppService.sendUpdateNotification(notificationRequest).subscribe(res => {
      // in case if it fails - find it in adobe logs.
    });
  }

  private getUpdateFieldsBasedOnScenario(): string[] {
    const rtnVal = ['Email Address', 'Hint Question & Answer', 'Password'];
    if (this.authToken.migrationtype === 'SINGLE-WEB') {
      return rtnVal;
    }
    if (this.authToken.migrationtype === 'SINGLE-APP') {
      rtnVal.shift();
      rtnVal.pop();
      return rtnVal;
    }
    if (this.authToken.migrationtype === 'MULTIPLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
    if (this.authToken.migrationtype === 'SINGLE-WEB-SINGLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
    if (this.authToken.migrationtype === 'SINGLE-WEB-MULTIPLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
  }
}

//  selection -> update password (onsubmit) -> VAC -> success
// selection -> update passpword -> confirmation (onsubmit) -> VAC -> success
