export interface PhotoModel {
  src: string;
  size: string;
  bytes: number;
  error: boolean;
}
