import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ConstantsService } from '../../shared/shared.module';
import { MockClaim } from './claims.model';

@Injectable({ providedIn: 'root' })
export class ClaimsService {
  private claimRecord = new BehaviorSubject<MockClaim>(null);
  public claimRecord$ = this.claimRecord.asObservable();

  constructor(private http: HttpClient, private constants: ConstantsService) {}

  getClaimDetails(body): Observable<any> {
    const url = body.depid ? this.constants.claimsdepdetailsUrl : this.constants.claimdetailsUrl;
    return this.http.post(url, body);
  }

  getClaimProcessingStatus(requestParams) {
    const url = this.constants.claimProcessingStatusUrl;
    return this.http.post(url, requestParams);
  }

  getClaimsBenefitsLink(body): Observable<any> {
    const url = this.constants.benefitsLinkUrl;
    return this.http.post(url, body);
  }
}
