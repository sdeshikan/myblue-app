import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ConstantsService } from '../../shared/shared.module';
import { AppSelectors } from '../../store/selectors/app-selectors';

@Injectable()
export class MigrationAppService {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  private memAcctMergeRequest = null;

  public getMemAcctMergeRequest() {
    if (sessionStorage.getItem('migrationReq')) {
      return JSON.parse(sessionStorage.getItem('migrationReq'));
    } else {
      sessionStorage.setItem('migrationReq', JSON.stringify(this.memAcctMergeRequest));
    }
    return this.memAcctMergeRequest;
  }

  public setMemAcctMergeRequest(memAcctMergeRequest): void {
    sessionStorage.setItem('migrationReq', JSON.stringify(memAcctMergeRequest));
    this.memAcctMergeRequest = memAcctMergeRequest;
  }

  constructor(private http: HttpClient, private constants: ConstantsService) {}

  sendAccessCode(email, userIdToVerify, editAndResend?, requestObj?) {
    let request = {
      useridin: this.useridin,
      commChannel: email,
      commChannelType: 'EMAIL',
      userIDToVerify: userIdToVerify
    };
    if (editAndResend) {
      request = {
        ...requestObj,
        editCommChannel: 'true'
      };
    }
    return this.http.post<any>(this.constants.sendaccesscodeUrl, request);
  }

  sendCommChlAccessCode(email, userIdToVerify, editAndResend?) {
    const request = {
      useridin: this.useridin,
      email: email,
      mobile: '',
      userIDToVerify: JSON.parse(sessionStorage.getItem('migrationReq'))['selectedUserId']
        ? JSON.parse(sessionStorage.getItem('migrationReq'))['selectedUserId']
        : userIdToVerify
    };
    if (editAndResend) {
      request['editCommChannel'] = 'true';
    }
    return this.http.post(this.constants.sendCommChlAccesscode, request);
  }

  VerifyAccessCode(accessCode) {
    const userIDToVerify = this.memAcctMergeRequest.selectedUserId;
    const email = this.memAcctMergeRequest.emailAddress;
    const generatedRequest = {
      useridin: this.useridin,
      commChannel: email,
      commChannelType: 'EMAIL',
      userIDToVerify: userIDToVerify,
      accesscode: accessCode
    };

    return this.http.post(this.constants.verifyAccessCodeUrl, generatedRequest);
  }

  VerifyCommChlAccCode(accessCode) {
    if (!this.memAcctMergeRequest && sessionStorage.getItem('migrationReq')) {
      this.memAcctMergeRequest = JSON.parse(sessionStorage.getItem('migrationReq'));
    }
    const userIDToVerify = this.memAcctMergeRequest.selectedUserId;
    const email = this.memAcctMergeRequest.emailAddress;
    const generatedRequest = {
      useridin: this.useridin,
      email: email,
      mobile: '',
      userIDToVerify: userIDToVerify,
      accesscode: accessCode
    };

    return this.http.post(this.constants.verfiyCommChlAccesscode, generatedRequest);
  }

  memberMigration() {
    const request = { useridin: this.useridin };
    return this.http.post(this.constants.memlookupUrl, request);
  }

  savePageUrl(url: string, selectedId: string) {
    const requestPayload = {
      useridin: this.useridin,
      linkinfo: url,
      selecteduserid: selectedId
    };
    return this.http.post(this.constants.postdesinfoUrl, requestPayload);
  }

  migrationRequest(
    selectedUserId,
    selectedUserIdType,
    selectedUserScope,
    webUserID,
    appUserIDs,
    emailAddress,
    hintQuestion,
    hintAnswer,
    password
  ) {
    const migrationtype = this.authToken.migrationtype;
    const useridin = this.useridin;
    const migrationRequestMap = {
      'SINGLE-WEB': {
        useridin: useridin,
        selectedUserId: selectedUserId,
        selectedUserIdType: 'WEB', // always it will be WEB.
        selectedUserScope: selectedUserScope,
        webUserID: webUserID, // same as selected user id
        appUserIDs: [], // will be always empty
        emailAddress: emailAddress, // will be entered in 1st screen
        hintQuestion: hintQuestion, // will be selected in 1st screen
        hintAnswer: hintAnswer, // will be entered in 1st screen
        password: password // will be from the update password screen
      },
      'SINGLE-APP': {
        useridin: useridin,
        selectedUserId: selectedUserId,
        selectedUserIdType: 'APP', // will be always APP
        selectedUserScope: selectedUserScope,
        webUserID: '', // will be empty only
        appUserIDs: appUserIDs, // will be array with single value only
        emailAddress: emailAddress, // will be selected by user in 1st screen
        hintQuestion: hintQuestion, // will be selected by user in 1st screen
        hintAnswer: hintAnswer, // will be entered by user in 1st screen
        password: password // will be from login module.
      },
      'MULTIPLE-APP': {
        useridin: useridin,
        selectedUserId: selectedUserId,
        selectedUserIdType: 'APP', // will be always APP
        selectedUserScope: selectedUserScope,
        webUserID: '', // will be empty only
        appUserIDs: appUserIDs, // will be array with multiple values
        emailAddress: emailAddress, // will be selected by user in 1st screen
        hintQuestion: hintQuestion, // will be selected by user in 1st screen
        hintAnswer: hintAnswer, // will be entered by user in 1st screen
        password: password // will be from login module.
      },
      'SINGLE-WEB-SINGLE-APP': {
        useridin: useridin,
        selectedUserId: selectedUserId,
        selectedUserIdType: selectedUserIdType,
        selectedUserScope: selectedUserScope,
        webUserID: webUserID,
        appUserIDs: appUserIDs, // will be array with single value
        emailAddress: emailAddress, // will be selected by user in 1st screen
        hintQuestion: hintQuestion, // will be selected by user in 1st screen
        hintAnswer: hintAnswer, // will be entered by user in 1st screen
        password: password // will be from login module or new screen?
      },
      'SINGLE-WEB-MULTIPLE-APP': {
        useridin: useridin,
        selectedUserId: selectedUserId,
        selectedUserIdType: selectedUserIdType,
        selectedUserScope: selectedUserScope,
        webUserID: webUserID,
        appUserIDs: appUserIDs, // will be array with single value
        emailAddress: emailAddress, // will be selected by user in 1st screen
        hintQuestion: hintQuestion, // will be selected by user in 1st screen
        hintAnswer: hintAnswer, // will be entered by user in 1st screen
        password: password // will be from login module or new screen?
      },
      NONE: ''
    };
    return migrationRequestMap[migrationtype];
  }

  public migrationCall(request) {
    return this.http.post(this.constants.memacctmergeUrl, request);
  }

  sendUpdateNotification(request) {
    return this.http.post(this.constants.sendUpdateNotification, request);
  }
}
