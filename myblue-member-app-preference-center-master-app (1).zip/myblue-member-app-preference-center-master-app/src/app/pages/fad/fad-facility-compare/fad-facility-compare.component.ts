import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadFacilityCompareService } from './fad-facility-compare.service';

import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { AlertService } from '../../../shared/services/alert.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { BreadCrumb } from '../utils/fad.utils';

@Component({
  selector: 'app-fad-facility-compare',
  templateUrl: './fad-facility-compare.component.html',
  styleUrls: ['./fad-facility-compare.component.scss']
})
export class FadFacilityCompareComponent implements OnInit, OnDestroy {
  public fadConstants = FAD_CONSTANTS;
  public results;
  public selectedFacilityDetail = null;
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public costInfo;
  public awards;
  public showRemove = true;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public facilityCompareService: FadFacilityCompareService,
    private fadSearchListService: FadSearchListService,
    private fadBreadCrumbService: FadBreadCrumbsService,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    this.fadBreadCrumbService
      .addBreadCrumb(new BreadCrumb().setLabel('Search').setUrl('/fad/search-results'))
      .addBreadCrumb(new BreadCrumb().setLabel('Compare').setUrl('/fad/facility-compare'));
    try {
      this.costInfo = this.facilityCompareService.getCostInfo();

      if (
        this.route.snapshot.data.facilityCompareData &&
        this.route.snapshot.data.facilityCompareData.result &&
        this.route.snapshot.data.facilityCompareData.result < 0
      ) {
        this.alertService.setAlert(this.route.snapshot.data.facilityCompareData.displaymessage, '', AlertType.Failure);
      } else {
        this.selectedFacilityDetail =
          this.route.snapshot.data.facilityCompareData && this.route.snapshot.data.facilityCompareData.OutBodyFacility;
      }
      const original = this.facilityCompareService.getSearchResult();
      const result = [];

      Object.keys(original).map(key => {
        const firstLocation = original[key].locations[0];

        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });

          original[key].blueAwards = blueAwards;
        }

        result.push(original[key]);
        return result;
      });

      this.selectedFacilityDetail = original;

      this.doctorStarRating = new StarRatingComponentInputModel();
      // tslint:disable-next-line:no-magic-numbers
      this.doctorStarRating.ratingInPercentage = 80;
      this.doctorStarRating.numberOfStars = 5;
    } catch (exception) {}
  }

  // Remove from the compare table
  // In case only last one remains redirect to search results
  public removeFacility(idx: number) {
    this.selectedFacilityDetail.splice(idx, 1);
    // tslint:disable-next-line:prefer-conditional-expression
    if (this.selectedFacilityDetail.length <= 2) {
      this.showRemove = false;
    } else {
      this.showRemove = true;
    }
  }

  // Move to Doctor's Profile Page
  public goToFacilityProfilePage(facility) {
    sessionStorage.setItem('facilityProfileId', facility.facilityId);
    sessionStorage.setItem('locationId', facility.locations[0].id);
    this.router.navigate([`/fad/facility-profile`]);
  }

  getRating(ratings, totalReviews) {
    this.doctorStarRating = new StarRatingComponentInputModel();

    this.doctorStarRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.doctorStarRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.doctorStarRating;
  }

  ngOnDestroy(): void {
    this.alertService.clearError();
    this.facilityCompareService.setSearchResult(null);
  }
}
