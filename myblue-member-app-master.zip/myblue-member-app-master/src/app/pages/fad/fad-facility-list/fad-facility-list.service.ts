import { Injectable } from '@angular/core';
import { FadConstants } from '../constants/fad.constants';
import { interval, Observable } from "rxjs";
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';

// import { FadVitalsProfessionalsSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { switchMap } from "rxjs/operators";

@Injectable()
export class FadFacilityListService {
  private selectedId: any;
  public isFilterChangedFlag = false;

  constructor(private bcbsmaHttpService: BcbsmaHttpService, private searchResultsService: FadSearchResultsService) {}

  getProfessionalsInfo(): GetSearchByProfessionalResponseModelInterface {
    return this.searchResultsService.searchResultCache;
  }

  onMapContainerCreated(): Observable<Element> {
    return interval(500).pipe(switchMap(() => {
      return document.querySelectorAll('#' + FadConstants.elementRef.fadSearchListMapContent);
    }));
  }

  setSelectedId(selectedId) {
    this.selectedId = selectedId;
  }
  getSelectedId() {
    return this.selectedId;
  }
  isFilterChanged(value) {
    this.isFilterChangedFlag = value;
  }
}
