import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatCheckboxChange, MatRadioChange, MatSidenav } from '@angular/material';
import { Subscription } from 'rxjs/Subscription';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { GlobalService } from '../../../shared/services/global.service';
import { FadConstants } from '../constants/fad.constants';
import { FadFacilityListService } from '../fad-facility-list/fad-facility-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilitySearchFilterComponentOutputModel, FilterCheckboxItem, FilterRadioItem } from '../modals/fad-search-filter.modal';
import { FacilityFiltersMetadataModel } from '../modals/getSearchByFacility.model';
import { SortMetadata } from '../modals/getSearchByProfessional.model';
import {
  FadFacilitySearchFilterComponentOutputModelInterface,
  FilterCheckboxItemInterface,
  FilterListItemInterface
} from '../modals/interfaces/fad-search-filter.interface';
import { FadFacilityListComponentInputModelInterface } from '../modals/interfaces/fad-search-list.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import {
  FacetsFacilityListInterface,
  FacilityFiltersMetadataInterface,
  GetSearchByFacilityResponseModelInterface
} from './../modals/interfaces/getSearchByFacility-models.interface';
import { SortMetadataInterface } from './../modals/interfaces/getSearchByProfessional-models.interface';

@Component({
  selector: 'app-facility-search-filter',
  templateUrl: './fad-facility-search-filter.component.html',
  styleUrls: ['./fad-facility-search-filter.component.scss']
})
export class FadFacilitySearchFilterComponent implements OnInit, OnChanges {
  @Output('componentOutput') componentOutput = new EventEmitter<FadFacilitySearchFilterComponentOutputModelInterface>();
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;

  // being used both the html view and the component(this file)
  public isDisplayFilter = false;
  public fadConstants;
  public outputTransaction: FadFacilitySearchFilterComponentOutputModelInterface = new FadFacilitySearchFilterComponentOutputModel();

  // flag values used bound to the view alone (html tags)
  public collapsedSortHeight: string;
  public expandedSortHeight: string;
  public sortSelectedFilter: string;
  public collapsedHeight: string;
  public expandedHeight: string;

  @Input('componentFilterInput') componentFilterInput: FadFacilityListComponentInputModelInterface;
  public searchResponse: GetSearchByFacilityResponseModelInterface;
  public facetsList: FacetsFacilityListInterface;
  public locationGeoList: FilterListItemInterface[] = [];
  public ratingList: FilterListItemInterface[] = [];
  public specialtyList: FilterListItemInterface[] = [];
  public bdcTypeList: FilterListItemInterface[] = [];
  public awardTypeList: FilterListItemInterface[] = [];
  public cqmsTypeList: FilterListItemInterface[] = [];
  public inNetworkOnlyCheckbox: FilterCheckboxItemInterface;
  public tiersList: FilterListItemInterface[] = [];

  public enableClearfilterFlag = false;
  public filterMetaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
  public sortMetaData: SortMetadataInterface = new SortMetadata();
  public clearFilterFlagSubjectSubscription: Subscription;

  public sortCurrentValue: string;
  public isSortExpanded: boolean;
  public sortList: FilterRadioItem[] = [
    {
      name: 'Distance',
      value: 'distance+asc',
      checked: true
    },
    {
      name: 'Name A-Z',
      value: 'provider_name_sortable+asc',
      checked: false
    },
    {
      name: 'Name Z-A',
      value: 'provider_name_sortable+desc',
      checked: false
    },
    {
      name: 'Best Match',
      value: 'relevancy+desc',
      checked: false
    },
    {
      name: 'Quality',
      value: 'clinical_quality+desc',
      checked: false
    },
    {
      name: 'Ratings',
      value: 'prs_overall_rating+desc,+prs_experience_of_care+desc',
      checked: false
    }
  ];

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadFacilityListService,
    public globalService: GlobalService,
    private cdRef: ChangeDetectorRef
  ) {
    this.fadConstants = FadConstants;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '56px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isSortExpanded = false;
    this.sortSelectedFilter = 'Distance';
  }

  ngOnInit() {
    this.clearFilterFlagSubjectSubscription = this.fadSearchResultsService.clearFilterFlagSubject$.subscribe(message => {
      if (message && message.clearFlag == true && message.type == FadResouceTypeCodeConfig.facility) {
        this.clearFilter();
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      this.componentFilterInput = changes.componentFilterInput.currentValue;

      if (this.componentFilterInput) {
        this.searchResponse = this.componentFilterInput.facilityResults;
        if (this.searchResponse && this.searchResponse.facets) {
          this.facetsList = this.searchResponse.facets;
          this.manageFilter(this.facetsList);
        }

        if (this.searchResponse && this.searchResponse.sort) {
          this.sortCurrentValue = this.searchResponse.sort;
          this.manageSorting();
        }
        this.cdRef.detectChanges();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilitySearchFilterComponent,
        FadConstants.methods.ngOnChanges
      );
    }
  }

  ngOnDestroy(): void {
    this.clearFilterFlagSubjectSubscription.unsubscribe();
  }

  public manageSorting() {
    this.sortList = this.sortList.map(sortObj => {
      if (this.sortCurrentValue && sortObj.value == this.sortCurrentValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });
  }

  public manageFilter(facetsList: FacetsFacilityListInterface) {
    this.locationGeoList = facetsList.locationGeo ? facetsList.locationGeo : [];
    this.ratingList = facetsList.overallRating ? facetsList.overallRating : [];
    this.specialtyList = facetsList.fieldSpecialtyIds ? facetsList.fieldSpecialtyIds : [];
    this.bdcTypeList = facetsList.bdcTypeCodes ? facetsList.bdcTypeCodes : [];
    this.awardTypeList = facetsList.awardTypeCodes ? facetsList.awardTypeCodes : [];
    this.cqmsTypeList = facetsList.cqms ? facetsList.cqms : [];
    this.inNetworkOnlyCheckbox = facetsList.inNetwork ? facetsList.inNetwork : null;
    this.tiersList = facetsList.tiers ? facetsList.tiers : [];
  }

  private throwInvalidServiceResponseDataErrorInOnInit(): void {
    this.bcbsmaErrorHandler.logError(
      new Error(FadConstants.errorMessages.invalidServiceResponseData),
      BcbsmaConstants.modules.fadModule,
      FadConstants.components.fadFacilitySearchFilterComponent,
      FadConstants.methods.ngOnInit
    );
  }

  public isSortOpened() {
    this.isSortExpanded = true;
  }

  public isSortClosed() {
    this.isSortExpanded = false;
  }

  /**
   * @description helps hide the sections other than the filter section and vice versa when the "Filter" dropdown is clicked in
   *  mobile screen only. Does not have any effect on the desktop screens
   */
  public toggleFilter() {
    this.isDisplayFilter = !this.isDisplayFilter;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.outputTransaction.filterCriteriaData = null;
    this.outputTransaction.sortCriteriaData = null;
    this.componentOutput.emit(this.outputTransaction);
  }

  public applySortFilter() {
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.isDisplayFilter = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.enableClearfilterFlag = true;
    this.fadSearchListService.isFilterChanged(true);
    this.componentOutput.emit(this.outputTransaction);
  }

  public clearFilter() {
    this.isSortExpanded = false;
    this.isDisplayFilter = false;
    this.enableClearfilterFlag = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;

    this.filterMetaData = new FacilityFiltersMetadataModel();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.fadSearchListService.isFilterChanged(true);
    this.componentOutput.emit(this.outputTransaction);
  }

  /*
     To get the selected sorted criteria from the view/template while changing the options
  */
  public onSortItemChanged(selectedSortObject: MatRadioChange): void {
    const selectValue = selectedSortObject.value;
    this.sortList = this.sortList.map(sortObj => {
      if (selectValue.value && sortObj.value == selectValue.value) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });

    this.sortMetaData = selectedSortObject.value;
    this.applySortFilter();
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedFacilityFilter(selectionListRadioBoxChange: MatRadioChange) {
    const selectValue = selectionListRadioBoxChange.value;
    window.scroll(0, 0);
    //   const scrollToTop = window.setInterval(() => {
    //     const pos = window.pageYOffset;
    //     if (pos > 0) {
    //         window.scrollTo(0, pos - 10); // how far to scroll on each step
    //     } else {
    //         window.clearInterval(scrollToTop);
    //     }
    // }, 16);
    switch (selectionListRadioBoxChange.source.name) {
      case 'filterLocation':
        this.filterMetaData.filterLocation = selectValue;
        break;
      case 'filterRating':
        this.filterMetaData.filterRating = selectValue;
        break;
      case 'filterSpecialities':
        this.filterMetaData.filterSpecialities = selectValue;
        break;
      case 'filterBDC':
        this.filterMetaData.filterBDC = selectValue;
        break;
      case 'filterAward':
        this.filterMetaData.filterAward = selectValue;
        break;
      case 'filterCQMS':
        this.filterMetaData.filterCQMS = selectValue;
        break;
      case 'filterTiers':
        this.filterMetaData.filterTiers = selectValue;
        break;
    }

    this.applySortFilter();
  }

  /*
      To get the selected filter criteria from the view/template while changing the options
   */
  public manageCheckboxFacilityFilter(selectionChBoxChange) {
    const selectValue = selectionChBoxChange.checked ? selectionChBoxChange.source.value : null;
    switch (selectionChBoxChange.source.name) {
      case 'filterInNetwork':
        this.filterMetaData.filterInNetwork = selectValue;
        break;
    }

    this.applySortFilter();
  }

  /**
   * @description checks whether filters have key data
   */
  public expandAccordion(property): boolean {
    if (this.filterMetaData && this.filterMetaData.hasOwnProperty(property)) {
      return true;
    }

    return false;
  }
}
