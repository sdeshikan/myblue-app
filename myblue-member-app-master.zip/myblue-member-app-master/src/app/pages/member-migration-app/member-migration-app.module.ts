import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MigrationAppRouter } from './member-migration-app.routing';
import { ProfileInfoAppPage } from './profile-info-app/profile-info-app.page';
import { SharedModule } from '../../shared/shared.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdatePasswordAppPage } from './profile-info-update-app/update-password-app/update-password-app.page';
import { VerifyEmailMobileAppPage } from './profile-info-update-app/verify-email-mobile-app/verify-email-mobile-app.page';
import { MigrationSuccessAppPage } from './profile-info-update-app/migration-success-app/migration-success-app.page';
import { TextMaskModule } from 'angular2-text-mask';
import { MigrationAppService } from './migration-app.service';
import { MigrationConfirmationAppPage } from './profile-info-update-app/migration-confirmation-app/migration-confirmation-app.page';
import { MigrationAppGuard } from './migration-app.guard';
import { IonicModule } from '@ionic/angular';
@NgModule({
  imports: [
    IonicModule,
    MatSelectModule,
    CommonModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MigrationAppRouter,
    TextMaskModule
  ],
  declarations: [
    ProfileInfoAppPage,
    UpdatePasswordAppPage,
    VerifyEmailMobileAppPage,
    MigrationSuccessAppPage,
    MigrationConfirmationAppPage
  ],
  providers: [MigrationAppService, MigrationAppGuard]
})
export class MemberMigrationAppModule {}
