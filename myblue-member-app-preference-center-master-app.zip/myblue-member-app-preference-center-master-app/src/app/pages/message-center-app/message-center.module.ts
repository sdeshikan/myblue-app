import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { InboxComponent } from './inbox/inbox.component';
import { MessageCenterRouter } from './message-center.routing';
import { MessageCenterService } from './message-center.service';
import { MessageDetailComponent } from './message-detail/message-detail.component';
import { NoDocumentsFoundComponent } from './no-documents-found/no-documents-found.component';

import { SharedModule } from '../../shared/shared.module';
import { DocumentsComponent } from './documents/documents.component';
import { UploadDetailComponent } from './upload-detail/upload-detail.component';
import { UploadsComponent } from './uploads/uploads.component';

import { MaterialModule } from '../../material.module';
import { DocumentDetailComponent } from './document-detail/document-detail.component';
import { DocumentsListViewComponent } from './documents-list-view/documents-list-view.component';
import { DocumentsService } from './documents/documents.service';
import { MsgListingComponent } from './msg-listing/msg-listing.component';
import { MsgListingService } from './msg-listing/msg-listing.service';
import { NotificationsAlertsComponent } from './notifications-alerts/notifications-alerts.component';
import { NotificationsAlertsService } from './notifications-alerts/notifications-alerts.service';
import { UploadDetailsService } from './upload-detail/upload-details.service';
import { UploadsService } from './uploads/uploads.service';

import { DocumentDetailResolverService } from './document-detail/document-detail.resolver';
import { DocumentDetailService } from './document-detail/document-detail.service';
import { DocumentsListViewResolverService } from './documents-list-view/document-list-view.resolver';
import { DocumentsOverallViewComponent } from './documents-overall-view/documents-overall-view.component';
import { BenefitCoverageListResolverService } from './documents/benefit-coverage-list.resolver';
import { DocumentsResolverService } from './documents/documents.resolver';
import { EOBResolverService } from './eob/eob-resolver.service';
import { EobComponent } from './eob/eob.component';
import { EOBService } from './eob/eob.service';
import { MessageCenterSearchComponent } from './message-center-search/message-center-search.component';
import { MessageCenterSearchService } from './message-center-search/message-center-search.service';
import { MessageDetailService } from './message-detail/message-detail.service';
import { NotificationsAlertsDetailsService } from './notifications-alerts-details/notifications-alerts-details.service';

import { IonicModule } from '@ionic/angular';
import { PromoImagesModule } from '../../shared/components/promo/promo-images/promo-images.module';
import { NotificationsAlertsDetailsComponent } from './notifications-alerts-details/notifications-alerts-details.component';

@NgModule({
  imports: [CommonModule, MessageCenterRouter, SharedModule, MaterialModule, IonicModule, PromoImagesModule],
  exports: [],
  declarations: [
    NoDocumentsFoundComponent,
    InboxComponent,
    MessageDetailComponent,
    UploadsComponent,
    UploadDetailComponent,
    DocumentsComponent,
    DocumentsOverallViewComponent,
    DocumentsListViewComponent,
    MsgListingComponent,
    NotificationsAlertsComponent,
    NotificationsAlertsDetailsComponent,
    DocumentDetailComponent,
    MessageCenterSearchComponent,
    EobComponent
  ],
  providers: [
    AuthGuard,
    MessageCenterService,
    DocumentsService,
    UploadsService,
    UploadDetailsService,
    MsgListingService,
    NotificationsAlertsService,
    NotificationsAlertsDetailsService,
    MessageCenterSearchService,
    MessageDetailService,
    DocumentsResolverService,
    BenefitCoverageListResolverService,
    DocumentsListViewResolverService,
    DocumentDetailService,
    DocumentDetailResolverService,
    EOBService,
    EOBResolverService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MessageCenterModule {}
