import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../../../shared/alerts/alertType.model';
import { AlertService } from '../../../../shared/services/alert.service';
import { AuthService } from '../../../../shared/services/auth.service';
import { AuthHttp } from '../../../../shared/services/auth-http.service';
import { MigrationService } from '../../migration.service';

declare let $: any;

@Component({
  selector: 'app-migration-confirmation',
  templateUrl: './migration-confirmation.component.html',
  styleUrls: ['./migration-confirmation.component.scss']
})
export class MigrationConfirmationComponent implements OnInit {
  public userid = '';

  constructor(
    private location: Location,
    private router: Router,
    private alertService: AlertService,
    private http: AuthHttp,
    private authService: AuthService,
    public migrationService: MigrationService
  ) {}

  ngOnInit() {
    this.userid = this.migrationService.getMemacctmergerequest().selectedUserId;
  }

  exploreNew(): void {
    if (this.authService.authToken.migrationtype === 'SINGLE-APP') {
      this.migrateAndSendAccessCode();
      // sessionStorage.setItem('migrationConfirmed', 'true'); No need to goto update password flow.
    } else {
      this.router.navigate(['member-migration/updatePassword']);
      sessionStorage.setItem('migrationConfirmed', 'true');
    }
  }

  private migrateAndSendAccessCode(): any {
    const memacctmergerequest = this.migrationService.getMemacctmergerequest();
    this.migrationService
      .migrationcall(
        this.migrationService.migrationrequest(
          memacctmergerequest.selectedUserId,
          memacctmergerequest.selectedUserIdType,
          memacctmergerequest.selectedUserScope,
          memacctmergerequest.webUserID,
          memacctmergerequest.appUserIDs,
          memacctmergerequest.emailAddress,
          memacctmergerequest.hintQuestion,
          memacctmergerequest.hintAnswer,
          ''
        )
      )
      .subscribe(res => {
        console.log('service response', res);
        let isValid = false;
        if (res['result'] === '0') {
          isValid = true;
          if (memacctmergerequest.selectedUserId) {
            localStorage.setItem('login-user', memacctmergerequest.selectedUserId);
          }
        } else {
          if (res['errormessage'] === 'Migration completed, but update notification could not be sent') {
            isValid = true;
            if (memacctmergerequest.selectedUserId) {
              localStorage.setItem('login-user', memacctmergerequest.selectedUserId);
            }
          }
        }
        if (isValid) {
          this.migrationService
            .savePageUrl('/myprofile', this.migrationService.getMemacctmergerequest().selectedUserId)
            .subscribe(migrationServiceResp => {
              if (migrationServiceResp['result'] === 0) {
                const memacctmergerequest_1 = this.migrationService.getMemacctmergerequest();
                if (memacctmergerequest_1.selectedUserScope === 'AUTHENTICATED-AND-VERIFIED') {
                  if (memacctmergerequest_1.isVerifiedEmail === 'true') {
                    //call send notifications and inform user that he has updated his hint QA
                    this.sendNotification();
                    this.authService.logout();
                    this.router.navigate(['login']);
                  } else {
                    this.sendAccessCode();
                    // this is a dead code since ther is no sceletion of user in SINGLE-APP
                  }
                } else {
                  this.sendAccessCode();
                }
              } else {
                console.log('error in postdestURL');
              }
            });
        } else {
          console.log('mig error', res);
          if (res['result'] === '-2') {
            this.alertService.setAlert(
              "We're currently experiencing technical difficulties. Please try again later, or call <a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.",
              '',
              AlertType.Failure
            );
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      });
  }

  private sendAccessCode() {
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    const memacctmergerequest = this.migrationService.getMemacctmergerequest();
    if (currScope === 'AUTHENTICATED-AND-VERIFIED') {
      this.sendcommchlaccesscode(memacctmergerequest.emailAddress, memacctmergerequest.selectedUserId);
    } else {
      this.sendaccesscode(memacctmergerequest.emailAddress, memacctmergerequest.selectedUserId);
    }
  }

  private sendaccesscode(emailAddress, selectedUserId): void {
    this.migrationService.sendaccesscode(emailAddress, selectedUserId).subscribe(
      res => {
        if (res['result'] === '0') {
          const communicationChannel = this.http.handleDecryptedResponse(res);
          sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
          this.router.navigate(['member-migration/verify']);
        } else {
          console.log('sendaccesscode error', res);
          if (res['result'] === '-1') {
            this.alertService.setAlert('We are unable to complete your request. Please try again.', '', AlertType.Failure);
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  private sendcommchlaccesscode(emailAddress, selectedUserId): void {
    this.migrationService.sendcommchlaccesscode(emailAddress, selectedUserId).subscribe(
      res => {
        if (res['result'] === '0') {
          this.router.navigate(['member-migration/verify']);
        } else {
          console.log('sendcommchlaccesscode error', res);
          if (res['result'] === '-1') {
            this.alertService.setAlert(
              "We're currently experiencing technical difficulties. Please try again later, or call <a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.",
              '',
              AlertType.Failure
            );
          }
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  back(): void {
    if ((window as any).history.length > 0) {
      (window as any).history.back();
    }
  }

  private sendNotification() {
    const getMemacctmergerequest = this.migrationService.getMemacctmergerequest();
    const notificationRequest = {
      useridin: this.authService.useridin,
      commChannel: getMemacctmergerequest.emailAddress,
      commChannelType: 'EMAIL',
      templateKeyword: 'UPDATENOTIFICATION_EMAIL',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue:
            this.authService && this.authService.authToken && this.authService.authToken.firstName
              ? this.authService.authToken.firstName
              : ''
        },
        {
          keyName: 'myProfileURL',
          keyValue: window.location.origin + '/myprofile'
        },
        {
          keyName: 'updatedFields',
          keyValue: this.getUpdateFieldsBasedOnScenario()
        }
      ]
    };
    console.log('notificationRequest=', notificationRequest);
    this.migrationService.sendUpdateNotification(notificationRequest).subscribe(res => {
      // in case if it fails - find it in adobe logs.
    });
  }

  private getUpdateFieldsBasedOnScenario(): string[] {
    const rtnVal = ['Email Address', 'Hint Question & Answer', 'Password'];
    if (this.authService.authToken.migrationtype === 'SINGLE-WEB') {
      return rtnVal;
    }
    if (this.authService.authToken.migrationtype === 'SINGLE-APP') {
      rtnVal.shift();
      rtnVal.pop();
      return rtnVal;
    }
    if (this.authService.authToken.migrationtype === 'MULTIPLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
    if (this.authService.authToken.migrationtype === 'SINGLE-WEB-SINGLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
    if (this.authService.authToken.migrationtype === 'SINGLE-WEB-MULTIPLE-APP') {
      rtnVal.shift();
      return rtnVal;
    }
  }
}

//  selection -> update password (onsubmit) -> VAC -> success
// selection -> update passpword -> confirmation (onsubmit) -> VAC -> success
