import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { AppSelectors } from '../../store/selectors/app-selectors';

@Injectable()
export class DeductiblesGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authToken && this.authToken.HasActivePlan === 'true') {
      return true;
    }
    this.router.navigate(['home']);
    return false;
  }
}
