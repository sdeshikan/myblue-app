import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthService } from '../../../shared/services/auth.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {
  currentStep: Number = 2;
  diplayEmailAddress: string;
  ACopyofEmailStr: string;
  WhatPillPackDoesNextStr = 'What does pillpack does next';
  ManageyourPrecStr = 'Manage your prescriptions directly with PillPack';
  WhatPillPackDoesNext: Array<{ text: string }> = [
    { text: 'Coordinates with your doctors and insurance to gather your prescriptions' },
    { text: 'Schedules your first shipment and orders your refills automatically every month' },
    { text: 'Packages your medication by time of day and sends them to you' }
  ];
  WhatToExpect: Array<{ text: string }> = [
    { text: 'PillPack coordinates with your doctors and insurance to gather your prescriptions' },
    { text: 'PillPack schedules your first shipment and orders your refills automatically every month' },
    { text: 'PillPack packages your medicaition by time of day and sends them to you' }
  ];

  SampleEmail: Array<{ text: string }> = [
    { text: 'PillPack will work with your doctor and pharmacist to transfer your prescriptions.' },
    { text: "PillPack will notify you of the date you'll receive your first shipment." },
    { text: 'Your medications will be delivered in easy-to-open, presorted packets.' },
    { text: 'Your prescriptions will be refilled automatically and shipped to your door every month.' }
  ];
  constructor(
    private location: Location,
    private router: Router,
    private alertService: AlertService,
    private http: AuthHttp,
    private authService: AuthService,
    private profileService: ProfileService,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.profileService.fetchProfileInfo().subscribe(profileInfo => {
      this.diplayEmailAddress = profileInfo.emailAddress;
      this.ACopyofEmailStr = 'A copy of your receipt as been emailed to ' + this.diplayEmailAddress;
      if (this.diplayEmailAddress) {
        //this.SampleEmail.unshift({ "text": "A enrollment confirmation has been emailed to " + this.diplayEmailAddress });
      } else {
        //this.SampleEmail.unshift({ "text": "A enrollment confirmation has been emailed to jsample@domain.com" });
      }
      this.alertService.setAlert("Success! We've emailed your sign up confirmation to " + this.diplayEmailAddress, '', AlertType.Success);
    });
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
