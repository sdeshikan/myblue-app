import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '../../../shared/services/alert.service';

import { IonicModule, ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { StorageServiceModule } from 'angular-webstorage-service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { AppState } from '../../../store/state/app.state';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadMedicalIndexComponent } from './fad-medical-index.component';
import { FadMedicalIndexService } from './fad-medical-index.service';
import { IonicStorageModule } from '@ionic/storage';

describe('FadMedicalIndexComponent', () => {
  let component: FadMedicalIndexComponent;
  let fixture: ComponentFixture<FadMedicalIndexComponent>;

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NgxsSelectSnapshotModule.forRoot(),
        NgxsStoragePluginModule.forRoot(),
        StorageServiceModule,
        IonicModule.forRoot(),
        IonicStorageModule.forRoot(),
        NgxsModule.forRoot([AppState])
      ],
      declarations: [FadMedicalIndexComponent],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        FadMedicalIndexService,
        BcbsmaHttpService,
        ConstantsService,
        FadLandingPageService,
        FadSearchResultsService,
        FadService,
        AlertService,
        FadBreadCrumbsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadMedicalIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
