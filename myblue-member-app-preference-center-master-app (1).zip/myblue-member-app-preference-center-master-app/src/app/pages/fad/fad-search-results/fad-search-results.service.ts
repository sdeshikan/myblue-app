import { Injectable } from '@angular/core';
import * as cloneDeep from 'lodash/cloneDeep';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadAutoCompleteComplexOption, FadLandingPageSearchControlValues } from '../modals/fad-landing-page.modal';
import { FadMembersInfoModel } from '../modals/fad-landing-page.modal';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import {
  FadAutoCompleteComplexOptionInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';
import { ClearSearchResultFlagInterface } from '../modals/interfaces/fad-search-list.interface';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import {
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  GetSearchBySpecialityRequestModelInterface,
  GetSearchBySpecialtyResponseModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';

import { HttpClient } from '@angular/common/http';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { map } from 'rxjs/operators';
import { AppSelectors } from '../../../store/selectors/app-selectors';

@Injectable()
export class FadSearchResultsService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;
  @SelectSnapshot(AppSelectors.getMLEEligibility) mleEligibility: string;

  private searchCriteria: FadLandingPageSearchControlValuesInterface;
  public searchResultCache: GetSearchByProfessionalResponseModelInterface = null;
  public facilityResultCache: GetSearchByFacilityResponseModelInterface = null;
  public specialtyResultCache: GetSearchBySpecialtyResponseModelInterface = null;
  private lastSelectedSearchTextOption: FadAutoCompleteComplexOption = null;
  private lastSelectedZipCodeOption: FZCSRCity = null;
  private lastSelectedPlanOption: FadAutoCompleteComplexOption = null;
  private lastSelectedDependentOptions: FadAutoCompleteComplexOption = null;
  private contextText = '';

  public clearFilterFlagSubject = new Subject<ClearSearchResultFlagInterface>();
  public clearFilterFlagSubject$ = this.clearFilterFlagSubject.asObservable();
  public dependantsList: FadMembersInfoModel[] = [];

  public selectedMember: FadMembersInfoModel;
  public filterChanged: boolean;

  constructor(private http: HttpClient) {}

  public getLastSelectedPlanOption(): FadAutoCompleteComplexOption {
    return this.lastSelectedPlanOption;
  }

  public setLastSelectedPlanOption(lastSelectedPlanOption: FadAutoCompleteComplexOption): FadSearchResultsService {
    const modelEnforcedPlanOption = lastSelectedPlanOption
      ? Object.assign(Object.create(new FadAutoCompleteComplexOption()), lastSelectedPlanOption)
      : lastSelectedPlanOption;
    this.lastSelectedPlanOption = modelEnforcedPlanOption;
    return this;
  }

  public getLastSelectedDependentOptions(): FadAutoCompleteComplexOption {
    return this.lastSelectedDependentOptions;
  }

  public getLastSelectedSearchTextOption(): FadAutoCompleteComplexOption {
    return this.lastSelectedSearchTextOption
      ? Object.assign(Object.create(new FadAutoCompleteComplexOption()), this.lastSelectedSearchTextOption)
      : this.lastSelectedSearchTextOption;
  }

  public setLastSelectedSearchTextOption(lastSelectedSearchTextOption: FadAutoCompleteComplexOption): FadSearchResultsService {
    const modelEnforcedSearchTextOption = lastSelectedSearchTextOption
      ? Object.assign(Object.create(new FadAutoCompleteComplexOption()), lastSelectedSearchTextOption)
      : lastSelectedSearchTextOption;
    this.lastSelectedSearchTextOption = modelEnforcedSearchTextOption;
    return this;
  }

  public getLastSelectedZipCodeOption(): FZCSRCity {
    let lastSelectedZipCodeOption: FZCSRCity = null;
    if (this.lastSelectedZipCodeOption) {
      lastSelectedZipCodeOption = Object.assign(Object.create(new FZCSRCity()), this.lastSelectedZipCodeOption);
    }

    if (!lastSelectedZipCodeOption) {
      if (sessionStorage.getItem('fad-Last-selected-zip-code')) {
        lastSelectedZipCodeOption = Object.assign(
          Object.create(new FZCSRCity()),
          JSON.parse(sessionStorage.getItem('fad-Last-selected-zip-code'))
        );
      }
    }

    return lastSelectedZipCodeOption;
  }

  public setLastSelectedZipCodeOption(lastSelectedZipCodeOption: FZCSRCity): FadSearchResultsService {
    const modelEnforcedZipCodeOption = lastSelectedZipCodeOption
      ? Object.assign(Object.create(new FZCSRCity()), lastSelectedZipCodeOption)
      : lastSelectedZipCodeOption;
    this.lastSelectedZipCodeOption = modelEnforcedZipCodeOption;
    sessionStorage.setItem('fad-Last-selected-zip-code', JSON.stringify(lastSelectedZipCodeOption));
    return this;
  }

  public getSearchCriteria(): FadLandingPageSearchControlValuesInterface {
    if (!this.searchCriteria) {
      const cachedSearchCriteria = JSON.parse(sessionStorage.getItem('FadLandingPageSearchCriteria')) as FadLandingPageSearchControlValues;
      this.searchCriteria = cachedSearchCriteria
        ? Object.assign(new FadLandingPageSearchControlValues(), cloneDeep(cachedSearchCriteria))
        : null;
    }
    return this.searchCriteria as FadLandingPageSearchControlValuesInterface;
  }
  public getContextText(): string {
    return this.contextText;
  }

  public setContextText(contextText: string): string {
    this.contextText = contextText;
    return this.contextText;
  }

  public setSearchCriteria(searchCriteria: FadLandingPageSearchControlValuesInterface): FadSearchResultsService {
    // check if the last selected option and the text value in the search text field are the same.
    // if yes use the object reference for last selected option in memory
    if (
      this.lastSelectedSearchTextOption &&
      searchCriteria.getSearchText() &&
      searchCriteria
        .getSearchText()
        .getSimpleText()
        .toUpperCase()
        .trim() ===
        this.lastSelectedSearchTextOption
          .getSimpleText()
          .toUpperCase()
          .trim()
    ) {
      searchCriteria.setSearchText(this.lastSelectedSearchTextOption);
    }

    this.searchCriteria = searchCriteria;
    sessionStorage.setItem('FadLandingPageSearchCriteria', JSON.stringify(searchCriteria));
    localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(searchCriteria.getZipCode()));
    return this;
  }

  public getFadProfileSearchResults(
    vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface
  ): Observable<GetSearchByProfessionalResponseModelInterface> {
    if (this.useridin) {
      vitalsSearchRequestbyProfessional.setUserIdIn(this.useridin);
      vitalsSearchRequestbyProfessional['useridin'] = this.useridin;
      vitalsSearchRequestbyProfessional['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }

    if (this.hccsFlag !== null) {
      vitalsSearchRequestbyProfessional['hccsFlag'] = this.hccsFlag;
    }
    if (sessionStorage.getItem('linkedAffiliationId')) {
      vitalsSearchRequestbyProfessional['linkedAffiliationId'] = sessionStorage.getItem('linkedAffiliationId');

      if (!vitalsSearchRequestbyProfessional['sort']) {
        vitalsSearchRequestbyProfessional['sort'] = 'distance+asc';
      }
      vitalsSearchRequestbyProfessional['facilityName'] = sessionStorage.getItem('facilityname');
      if (sessionStorage.getItem('locationId')) {
        vitalsSearchRequestbyProfessional['locationId'] = sessionStorage.getItem('locationId');
      }
    }

    return this.http.post(FAD_CONSTANTS.urls.fadLandingPageProfessionalsSearchListUrl, vitalsSearchRequestbyProfessional).pipe(
      map(response => {
        sessionStorage.setItem('fadLandingPageSearchResults', JSON.stringify(response));

        return response as GetSearchByProfessionalResponseModelInterface;
      })
    );
  }

  public getFadFacilitySearchResults(
    vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface
  ): Observable<GetSearchByFacilityResponseModelInterface> {
    if (this.useridin) {
      vitalsSearchRequestbyFacility.setUserIdIn(this.useridin);
      vitalsSearchRequestbyFacility['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const mleIndicator = this.mleEligibility;
    if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
    }
    if (this.hccsFlag !== null) {
      vitalsSearchRequestbyFacility['hccsFlag'] = this.hccsFlag;
    }

    return this.http.post(FAD_CONSTANTS.urls.fadLandingPageFacilitiesSearchListUrl, vitalsSearchRequestbyFacility).pipe(
      map(response => {
        sessionStorage.setItem('fadLandingPageSearchResults', JSON.stringify(response));
        return response as GetSearchByFacilityResponseModelInterface;
      })
    );
  }

  public getFadSpecialitySearchResults(
    vitalsSearchRequestbyspeciality: GetSearchBySpecialityRequestModelInterface
  ): Observable<GetSearchBySpecialtyResponseModelInterface> {
    if (this.useridin && this.useridin !== 'undefined') {
      vitalsSearchRequestbyspeciality['useridin'] = this.useridin;
      const memIdx = sessionStorage.getItem('selMemIdx');
      if (memIdx && memIdx !== '-1') {
        //TODO: use ngxs store value here.
        this.dependantsList = JSON.parse(sessionStorage.getItem('dependantsList')) as FadMembersInfoModel[];
        sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
      } else {
        //TODO: use ngxs store value here.
        this.dependantsList = JSON.parse(sessionStorage.getItem('dependantsList')) as FadMembersInfoModel[];
        if (this.dependantsList && this.dependantsList.length) {
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      }
      const fadVendorMemberNumber = sessionStorage.getItem('fadVendorMemberNumber');
      if (fadVendorMemberNumber) {
        vitalsSearchRequestbyspeciality['fadVendorMemberNumber'] = fadVendorMemberNumber;
      }
    }

    if (this.hccsFlag !== null) {
      vitalsSearchRequestbyspeciality['hccsFlag'] = this.hccsFlag;
    }

    return this.http.post(FAD_CONSTANTS.urls.fadVitalsSpecailtyUrl, vitalsSearchRequestbyspeciality).pipe(
      map(response => {
        sessionStorage.setItem('fadLandingPageSearchResults', JSON.stringify(response));

        return response as GetSearchBySpecialtyResponseModelInterface;
      })
    );
  }

  public getFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.searchResultCache && this.searchResultCache.facets) {
      if (this.searchResultCache.facets.isChoicePcp) {
        filterCategories.push('Primary Care Provider Only');
      }
      if (this.searchResultCache.facets.acceptingNewPatients) {
        filterCategories.push(FAD_CONSTANTS.text.acceptingNewPatients);
      }
      if (this.searchResultCache.facets.techSavvy) {
        filterCategories.push('Tech Savvy');
      }
      if (this.searchResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.searchResultCache.facets.professionalGender) {
        filterCategories.push('Gender');
      }
      if (this.searchResultCache.facets.professionalLanguages) {
        filterCategories.push('Languages');
      }
      if (this.searchResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.searchResultCache.facets.treatedTypeCodes) {
        filterCategories.push('Ages Treated');
      }

      if (this.searchResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }
      if (this.searchResultCache.facets.disordersTreatedTypeCodes) {
        filterCategories.push('Disorders Treated');
      }

      if (this.searchResultCache.facets.treatmentMethodsTypeCodes) {
        filterCategories.push('Treatment Method');
      }

      if (this.searchResultCache.facets.groupAffiliationIds) {
        filterCategories.push('Medical Groups');
      }
      if (this.searchResultCache.facets.hospitalAffiliationIds) {
        filterCategories.push('Hospitals');
      }
      if (this.searchResultCache.facets.awardTypeCodes) {
        filterCategories.push('Awards');
      }
      if (this.searchResultCache.facets.bdcTypeCodes) {
        filterCategories.push('Blue Distinction Recognition');
      }
      if (this.searchResultCache.facets.cqms) {
        filterCategories.push('Clinical Quality');
      }
      if (this.searchResultCache.facets.tiers) {
        filterCategories.push('Tiers');
      }
    }
    return filterCategories;
  }

  public getFacilityFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.facilityResultCache && this.facilityResultCache.facets) {
      if (this.facilityResultCache.facets.inNetwork) {
        filterCategories.push('In-Network Only');
      }
      if (this.facilityResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.facilityResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.facilityResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }

      if (this.facilityResultCache.facets.bdcTypeCodes) {
        filterCategories.push('Blue Distinction Recognition');
      }
      if (this.facilityResultCache.facets.awardTypeCodes) {
        filterCategories.push('Awards');
      }
      if (this.facilityResultCache.facets.cqms) {
        filterCategories.push('Clinical Quality');
      }
    }
    return filterCategories;
  }

  public getSpecialtyFilterCategories(): string[] {
    const filterCategories: string[] = [];
    if (this.specialtyResultCache && this.specialtyResultCache.facets) {
      if (this.specialtyResultCache.facets.isChoicePcp) {
        filterCategories.push('Primary Care Provider Only');
      }
      if (this.specialtyResultCache.facets.acceptingNewPatients) {
        filterCategories.push(FAD_CONSTANTS.text.acceptingNewPatients);
      }
      if (this.specialtyResultCache.facets.techSavvy) {
        filterCategories.push('Tech Savvy');
      }
      if (this.specialtyResultCache.facets.locationGeo) {
        filterCategories.push('Distance');
      }
      if (this.specialtyResultCache.facets.professionalGender) {
        filterCategories.push('Gender');
      }
      if (this.specialtyResultCache.facets.professionalLanguages) {
        filterCategories.push('Languages');
      }
      if (this.specialtyResultCache.facets.overallRating) {
        filterCategories.push('Rating');
      }
      if (this.specialtyResultCache.facets.treatedTypeCodes) {
        filterCategories.push('Ages Treated');
      }

      if (this.specialtyResultCache.facets.fieldSpecialtyIds) {
        filterCategories.push('Specialties');
      }
      if (this.specialtyResultCache.facets.disordersTreatedTypeCodes) {
        filterCategories.push('Disorders Treated');
      }

      if (this.specialtyResultCache.facets.treatmentMethodsTypeCodes) {
        filterCategories.push('Treatment Method');
      }

      if (this.specialtyResultCache.facets.groupAffiliationIds) {
        filterCategories.push('Medical Groups');
      }

      if (this.specialtyResultCache.facets.providerType) {
        filterCategories.push('Providers');
      }
      if (this.specialtyResultCache.facets.hospitalAffiliationIds) {
        filterCategories.push('Hospitals');
      }
      if (this.specialtyResultCache.facets.awardTypeCodes) {
        filterCategories.push('Awards');
      }
      if (this.specialtyResultCache.facets.bdcTypeCodes) {
        filterCategories.push('Blue Distinction Recognition');
      }
      if (this.specialtyResultCache.facets.cqms) {
        filterCategories.push('Clinical Quality');
      }
      if (this.specialtyResultCache.facets.tiers) {
        filterCategories.push('Tiers');
      }
    }
    return filterCategories;
  }

  public getFilteredSearchName(searchCriteria: FadLandingPageSearchControlValuesInterface): string {
    const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
    let searchName = searchTextOption.getSimpleText() || searchTextOption.getContextText();
    if (searchName && searchName.trim && searchName.trim().indexOf(FAD_CONSTANTS.text.allDoctorOptionText) >= 0) {
      searchName = this.replaceAll(searchName, FAD_CONSTANTS.text.allDoctorOptionText, '');
      searchName = searchName.replace(/["']/g, '');
    }

    if (searchName && searchName.trim && searchName.trim().indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) >= 0) {
      searchName = this.replaceAll(searchName, FAD_CONSTANTS.text.allHospitalsOrFacilitiesText, '');
      searchName = searchName.replace(/["']/g, '');
    }

    return searchName;
  }

  public sendEmailRequest(request, email, optionalmessage) {
    console.log(request);
    console.log(email);
    const requestSendEmail = request;
    requestSendEmail['useridin'] = this.useridin;
    requestSendEmail['email'] = email;
    requestSendEmail['optnlMsg'] = optionalmessage;

    console.log(requestSendEmail);
    console.log(FAD_CONSTANTS.urls.fadSendEmail);
    return this.http.post(FAD_CONSTANTS.urls.fadSendEmail, requestSendEmail).pipe(
      map(response => {
        return response;
      })
    );
  }

  public replaceAll(originalString, find, replace): string {
    return originalString.replace(new RegExp(find, 'g'), replace);
  }
}
