import { RouterModule, Routes } from '@angular/router';
import { MymedsResolverService } from '../../shared/routeresolvers/mymeds-resolver.service';
import { MyMedicationDetailsComponent } from './myMedicationDetails/myMedicationDetails.component';
import { MyMedicationsComponent } from './mymedications/mymedications.component';

const MEDICATIONS_ROUTER: Routes = [
  {
    path: '',
    data: {
      breadcrumb: 'My Medications'
    },
    component: MyMedicationsComponent,
    resolve: {
      medsInfo: MymedsResolverService
    }
  },
  {
    path: 'medicationdetails',
    data: {
      breadcrumb: 'Medication Details'
    },
    component: MyMedicationDetailsComponent
  }
];

export const MedicationsRouter = RouterModule.forChild(MEDICATIONS_ROUTER);
