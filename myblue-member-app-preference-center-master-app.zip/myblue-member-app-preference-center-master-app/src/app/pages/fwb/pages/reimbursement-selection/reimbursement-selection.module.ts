import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { RadioDirectiveModule } from '../../../../directives/radio-button.module';
import { ReimbursementNotEligibleComponent } from '../../components/reimbursement-not-eligible/reimbursement-not-eligible.component';
import { ReimbursementNotEligibleModule } from '../../components/reimbursement-not-eligible/reimbursement-not-eligible.module';
import { ReimbursementSelectionPage } from './reimbursement-selection.page';

@NgModule({
  declarations: [ReimbursementSelectionPage],
  imports: [CommonModule, FormsModule, IonicModule, RadioDirectiveModule, RouterModule, ReimbursementNotEligibleModule],
  entryComponents: [ReimbursementNotEligibleComponent]
})
export class ReimbursementSelectionModule {}
