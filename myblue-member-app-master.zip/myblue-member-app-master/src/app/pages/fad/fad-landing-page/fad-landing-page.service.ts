import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import {
  FadZipCodeSearchResponseModelInterface,
  DoctorProfileSearchRequestModelInterface,
  FadVitalsZipCodeSearchRequestModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import {
  FadLandingPageSearchControlsModelInterface,
  FadLandingPageSearchControlValuesInterface,
  LandingPageResponseCacheModelInterface,
  FadMembersInfoRequestModelInterface,
  FadMembersInfoResponseModelInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  FadAutoCompleteOptionForSearchText,
  FadMembersInfoRequestModel
} from '../modals/fad-landing-page.modal';
import { FadConstants } from '../constants/fad.constants';
import { ConstantsService, AuthService } from '../../../shared/shared.module';
import { LeafLetResponseModelInterface } from '../modals/interfaces/leaflet-model.interface';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { GetSearchByProviderRequestModelInterface } from '../modals/interfaces/getSearchByProvider-models.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import {
  GetSearchByFacilityResponseModelInterface,
  GetSearchByFacilityRequestModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { HashMapInterface } from '../../financials/models';
import { HashMap } from '../../financials/utils/all-transaction.utilities';

import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';

@Injectable()
export class FadLandingPageService {
  public vitalsZipCodeInfo: FadZipCodeSearchResponseModelInterface = null;
  public cachedResponse: LandingPageResponseCacheModelInterface = null;

  public plannetworkdata = null;
  private cachedSearchControlState: FadLandingPageSearchControlsModelInterface = null;
  private cachedSearchTextLookupOptions: HashMapInterface<FadAutoCompleteOptionForSearchText[]> = new HashMap<
    FadAutoCompleteOptionForSearchText[]
  >();
  private cachedZipCodeLookupOptions: HashMapInterface<FZCSRCity[]> = new HashMap<FZCSRCity[]>();

  public showAutoCompleteDropDownSpinner = false;

  constructor(
    private bcbsmaHttpService: BcbsmaHttpService,
    private http: AuthHttp,
    private authService: AuthService,
    private constants: ConstantsService,
    private fadSearchResultsService: FadSearchResultsService
  ) {}

  public getCachedZipCodeLookupOptions(searchText: string): FZCSRCity[] {
    return this.cachedZipCodeLookupOptions.get(searchText);
  }
  public setCachedZipCodeLookupOptions(searchText: string, zipCodeLookupOptions: FZCSRCity[]): FadLandingPageService {
    this.cachedZipCodeLookupOptions.put(searchText, zipCodeLookupOptions);
    return this;
  }

  public getCachedSearchTextLookupOptions(key: string): FadAutoCompleteOptionForSearchText[] {
    let options: FadAutoCompleteOptionForSearchText[] = this.cachedSearchTextLookupOptions.get(key);
    if (!options) {
      const keyEntities = key.split('~');
      options = this.cachedSearchTextLookupOptions.get(`${keyEntities[0]}~`);
    }
    return options;
  }

  public setCachedSearchTextLookupOptions(searchText: string, lookupOptions: FadAutoCompleteOptionForSearchText[]): FadLandingPageService {
    this.cachedSearchTextLookupOptions.put(searchText, lookupOptions);
    return this;
  }

  getVitalsAutoCompleteSearchResponse(request: GetSearchByProviderRequestModelInterface): Observable<any> {
    this.showAutoCompleteDropDownSpinner = true;

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    const url = FadConstants.urls.fadLandingPageSearchAutocompleteListUrl;

    return this.http.encryptPost(url, request);
  }

  getVitalsZipCodeInfo(
    vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface
  ): Observable<FadZipCodeSearchResponseModelInterface> {
    let url;

    if (vitalsZipCodeSearchRequest.city || vitalsZipCodeSearchRequest.zip || vitalsZipCodeSearchRequest.state) {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?city=${vitalsZipCodeSearchRequest.city}&state_code=${vitalsZipCodeSearchRequest.state}&zip=${vitalsZipCodeSearchRequest.zip}`;
    } else if (
      vitalsZipCodeSearchRequest.lat &&
      vitalsZipCodeSearchRequest.lng &&
      vitalsZipCodeSearchRequest.sort &&
      vitalsZipCodeSearchRequest.limit
    ) {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&lat=${vitalsZipCodeSearchRequest.lat}&lng=${vitalsZipCodeSearchRequest.lng}&sort=${vitalsZipCodeSearchRequest.sort}`;
    } else {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&place=${vitalsZipCodeSearchRequest.place}`;
    }
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + this.http.uuid()
      })
    };
    // this.loadingHelper.presentLoader();
    return this.http.get<FadZipCodeSearchResponseModelInterface>(url, httpOptions, false);
    // .pipe(
    //   finalize(() => this.loadingHelper.dismissLoader())
    // );
  }

  getVitalsDependantList(): Observable<FadMembersInfoResponseModelInterface> {
    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.authService.useridin;
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    // const url = FadConstants.jsonurls.fadLandingPageDependentsListUrl;
    const url = FadConstants.urls.fadLandingPageDependentsListUrl;

    // return this.bcbsmaHttpService.get(url);

    return this.http.encryptPost(url, request);
  }

  getProcedureSummary() {
    const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
    if (this.authService.getFadHccsFlag() !== null) {
      ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    if (sessionStorage.getItem('fadVendorMemberNumber')) {
      ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FadConstants.urls.fadVitalsProcedureUrl;
    return this.http.encryptPost(url, ProcedureSearchReq);
  }
  getCachedSearchControlState(): FadLandingPageSearchControlsModelInterface {
    // if (!this.cachedSearchControlState) {
    //   this.cachedSearchControlState = new FadLandingPageSearchControlsModel();

    //   this.cachedSearchControlState.setValues(
    //     <FadLandingPageSearchControlValues>this.fadSearchResultsService.getSearchCriteria());
    // }
    return this.cachedSearchControlState;
  }

  setCachedSearchControlState(
    searchControlState: FadLandingPageSearchControlsModelInterface | FadLandingPageSearchControlValuesInterface
  ): FadLandingPageService {
    this.cachedSearchControlState = new FadLandingPageSearchControlsModel();
    if (searchControlState instanceof FadLandingPageSearchControlsModel) {
      this.cachedSearchControlState.setControls(
        searchControlState as FadLandingPageSearchControlsModelInterface,
        this.fadSearchResultsService
      );
    } else {
      this.cachedSearchControlState.setValues(searchControlState as FadLandingPageSearchControlValues);
    }
    return this;
  }

  clearCachedSearchControlState(): FadLandingPageService {
    this.cachedSearchControlState = null;
    return this;
  }

  getLocationFromLatLong(position: Position): Observable<LeafLetResponseModelInterface> {
    let params = new HttpParams();
    params = params.append('access_token', FadConstants.text.leafLetAccessToken);
    params = params.append('types', FadConstants.text.leafLetGeoCodingQueryTypes.join(','));

    const url = this.constants.leafLetGecodingVersionUrl + '/' + position.coords.longitude + ',' + position.coords.latitude + '.json';
    return this.bcbsmaHttpService.get(url, { params: params });
  }

  getDoctorProfileDetails(request: DoctorProfileSearchRequestModelInterface): Observable<GetSearchByProfessionalResponseModelInterface> {
    request.userid = this.authService.useridin;

    const url = FadConstants.jsonurls.fadGetDoctorProfile;
    return this.bcbsmaHttpService.get(url);
  }

  getFacilityProfileDetails(request: GetSearchByFacilityRequestModelInterface): Observable<GetSearchByFacilityResponseModelInterface> {
    const url = FadConstants.urls.fadGetFacilityProfile;
    return this.bcbsmaHttpService.get(url);
  }
  getToolTipInfo() {
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if (this.authService.useridin && this.authService.useridin !== 'undefined') {
      ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType'] = 'All';
    const url = FadConstants.urls.fadVitalsToolTipsInfo;
    return this.http.encryptPost(url, ToolTipReq);
  }
}
