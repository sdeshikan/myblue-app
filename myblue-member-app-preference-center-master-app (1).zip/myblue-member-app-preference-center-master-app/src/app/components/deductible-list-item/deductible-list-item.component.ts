import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { DeductibleModel } from '../../models/deductible.model';

@Component({
  selector: 'app-deductible-list-item',
  templateUrl: './deductible-list-item.component.html',
  styleUrls: ['./deductible-list-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeductibleListItemComponent {
  @Input() deductible: DeductibleModel;
}
