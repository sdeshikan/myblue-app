export interface OverallDeductibleModel {
  networkIndicatorForOverallDeductible: string;
  isFirstCoverage: boolean;
  overallDeductible: string;
  deductibleContributed: string;
  deductibleRemainingToMeet: string;
  overallDeductibleExclusionExcep: string;
  overallDeductibleLimitationContent: string;
}
