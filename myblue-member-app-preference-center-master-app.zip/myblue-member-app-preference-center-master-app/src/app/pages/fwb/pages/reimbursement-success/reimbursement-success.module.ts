import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { ReimbursementSuccessPage } from './reimbursement-success.page';

import { RadioDirectiveModule } from '../../../../directives/radio-button.module';
import { AlertsModule } from '../../../../shared/alerts/alerts.module';
import { SharedModule } from '../../../../shared/shared.module';

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule, RadioDirectiveModule, SharedModule, AlertsModule],
  declarations: [ReimbursementSuccessPage]
})
export class ReimbursementSuccessModule {}
