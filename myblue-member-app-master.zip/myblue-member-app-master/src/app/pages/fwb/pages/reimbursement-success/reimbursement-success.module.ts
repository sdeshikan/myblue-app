import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IonicModule } from '@ionic/angular';
import { ReimbursementSuccessPage } from './reimbursement-success.page';
import { RouterModule } from '@angular/router';

import { RadioDirectiveModule } from '../../../../directives/radio-button.module';
import { SharedModule } from '../../../../shared/shared.module';
@NgModule({
  imports: [CommonModule, IonicModule, RouterModule, RadioDirectiveModule, SharedModule],
  declarations: [ReimbursementSuccessPage]
})
export class ReimbursementSuccessModule {}
