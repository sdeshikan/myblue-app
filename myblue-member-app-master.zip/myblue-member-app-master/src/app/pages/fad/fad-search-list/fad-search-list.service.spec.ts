import { TestBed, inject } from '@angular/core/testing';

import { FadSearchListService } from './fad-search-list.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';

describe('FadSearchListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FadSearchListService, FadSearchResultsService]
    });
  });

  it('should be created', inject([FadSearchListService], (service: FadSearchListService) => {
    expect(service).toBeTruthy();
  }));
});
