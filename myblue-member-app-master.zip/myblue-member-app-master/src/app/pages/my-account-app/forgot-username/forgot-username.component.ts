import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../shared/services/validation.service';
import { MyAccountService } from '../my-account.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthService } from '../../../shared/services/auth.service';
import { RegType } from '../../../shared/models/regType.enum';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { SwrveService, SwrveEventNames } from './../../../shared/services/swrve.service';

@Component({
  selector: 'app-forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.scss']
})
export class ForgotUsernameComponent implements OnInit {
  forgotUsernameForm: FormGroup;
  dobMask: Array<any>;
  phoneMask: Array<any>;

  constructor(
    private fb: FormBuilder,
    private myAccountService: MyAccountService,
    private globalService: GlobalService,
    private authService: AuthService,
    private authHttp: AuthHttp,
    private constants: ConstantsService,
    private alertService: AlertService,
    private router: Router,
    private validationService: ValidationService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    try {
      this.forgotUsernameForm = this.fb.group({
        email: ['', [Validators.required, this.validationService.emailValidator()]],
        mobile: ['', [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()]]

        // dob: ['', [this.validationService.dateValidator()]],
      });
      // this.dobMask = this.validationService.dobMask;
      this.phoneMask = this.validationService.phoneMask;
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  showErrorMessage(regType: RegType, res) {
    try {
      this.authService.useridin = regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email;
      this.globalService.handleError(res, this.constants.displayMessage);
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  handleVerificationResponse(regType: RegType, res, isVerifedUser: boolean) {
    try {
      if (isVerifedUser) {
        this.handleSuccessResponse(regType, res);
      } else {
        this.handleNonVerifiedResponse();
      }
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  handleNonVerifiedResponse() {
    try {
      this.router.navigate(['./login-app']).then(() => {
        setTimeout(() => {
          this.alertService.setAlert('Please check your email account or mobile number for your username.', '', AlertType.Success);
        }, 500);
      });
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  handleSuccessResponse(regType: RegType, res) {
    try {
      sessionStorage.setItem(
        'useridin',
        regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email
      );
      sessionStorage.setItem('isauthenticated', 'TRUE');
      this.router.navigate(['./account/confirmidentity']);
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  handleNonAuthenticatedUserResponse(regType: RegType, res) {
    try {
      sessionStorage.setItem(
        'useridin',
        regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email
      );
      sessionStorage.setItem('isauthenticated', 'FALSE');
      sessionStorage.setItem('otp', 'TRUE');
      this.router.navigate(['/account/verifyAccessCode', 'FUN']);
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  getToken() {
    try {
      // this.authService.cryptoToken = null; // Commenting because this causes calling gettoken all the time
      this.authService.getTokens().subscribe(
        token => {
          this.authService.cryptoToken = token;
          this.authService.persistSession();
          this.verifyIsUserValid();
          console.log('ATOKEN: Crypto token called! whats in UI session storage: ', sessionStorage['token']);
        },
        err => {
          console.log('Error in forgot username', err);
          this.authHttp.handleError(err);
        }
      );
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  verifyIsUserValid() {
    try {
      const request = this.forgotUsernameForm.value;
      request.mobile = request.mobile ? request.mobile.replace(/-/g, '') : request.mobile;
      request.email = request.email ? request.email.toLowerCase() : request.email;
      this.myAccountService.verifyUserValid(request).subscribe(
        res => {
          if (res) {
            const resultId = res['result'];
            const regType = res['commType'] === 'MOBILE' ? RegType.MOBILE : RegType.EMAIL;
            this.myAccountService.funverifyuserResponse = res;
            const isVerfiedUser = res['isAuthenticated'] === 'TRUE';
            if (resultId === null || resultId === undefined) {
              if (isVerfiedUser) {
                this.handleVerificationResponse(regType, res, isVerfiedUser);
              } else if (!isVerfiedUser) {
                this.handleNonAuthenticatedUserResponse(regType, res);
              }
            } else {
              sessionStorage.setItem('isauthenticated', 'FALSE');
              resultId === '-1' ? this.showErrorMessage(regType, res) : this.alertService.setError(res.displaymessage);
            }
          }
        },
        error => {
          console.error('ERROR ' + JSON.stringify(error, null, 2));
        }
      );
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  onSubmit() {
    try {
      this.alertService.clearError();
      this.getToken();
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  ionViewWillLeave() {
    this.alertService.clearError();
  }

  ngOnInit() {
    try {
      this.alertService.clearError();
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ForgotUsername);
  }
}
