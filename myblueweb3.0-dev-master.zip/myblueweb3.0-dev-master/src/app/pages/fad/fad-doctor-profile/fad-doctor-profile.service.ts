import { Injectable } from '@angular/core';
import { FadProfessionalInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  GetSearchByProviderRequestModelInterface,
  GetSearchByProviderResponseModelInterface
} from '../modals/interfaces/getSearchByProvider-models.interface';
import { Observable } from 'rxjs/Observable';
import { HttpParams, HttpClient } from '@angular/common/http';
import { FadConstants } from '../constants/fad.constants';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import {
  FadDoctorProfileRequestModelInterface,
  FadProfessionalResponseModelInterface,
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadDoctorRatingsResponseModel } from '../modals/fad-doctor-profile-details.model';
import {AuthService} from '../../../shared/services/auth.service';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';

@Injectable()
export class FadDoctorProfileService {

  public doctorProfile: any;
  constructor(private http: AuthHttp, private simphttp: HttpClient,
              private authService: AuthService) { }

  getFadGetprofessionalprofileDetails(request: FadDoctorProfileRequestModelInterface)
    : Observable<FadProfessionalResponseModelInterface> {

    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    // , this.authService.isFadAccessTokenRequired()
    return this.http.encryptPost(FadConstants.urls.professionalprofile,
      request, '', '', false).map(response => {
        return response;
      });
  }

  getProfessionalratings(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptPost(FadConstants.urls.fadGetDoctorRatings,
     request, '', '', false).map(response => {
       return response;
    });

    // temp files
    // return this.simphttp.get(FadConstants.jsonurls.fadGetprofessionalratings).map(res => {
    //  return <FadDoctorRatingsResponseModel>res;
    // });
  }
  getToolTipInfo(){
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if(this.authService.useridin && this.authService.useridin!='undefined'){
    ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType']='All';
    const url = FadConstants.urls.fadVitalsToolTipsInfo;
    return this.http.encryptPost(url,ToolTipReq,null,null,false);
  }
  getAcceptableReviewers(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();
    delete request.ratingIdentifier;
    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptPost(FadConstants.urls.fadGetAcceptableReviersUrl,
     request, '', '', true).map(response => {
       return response;
    });

    // temp files
    // return this.simphttp.get(FadConstants.jsonurls.fadGetprofessionalratings).map(res => {
    //  return <FadDoctorRatingsResponseModel>res;
    // });
  }
}
