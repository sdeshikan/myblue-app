import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AuthToken } from '../../../models/auth-token.model';
import { PostLoginModel } from '../../../models/post-login.model';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { IabService } from '../../../shared/services/iab/iab.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { SsoService } from '../../sso/sso.service';
import { ClaimsService } from '../claims.service';
import { ClaimBenefitsLinkRequestModel, ClaimBenefitsLinkResponseModel } from '../models/claim-benefits-link.model';
import { ClaimDetail, ClaimDetailsRequestModel } from '../models/claim-details.model';
import {
  ClaimBenefitsLinkRequestModelInterface,
  ClaimBenefitsLinkResponseModelInterface
} from '../models/interfaces/claim-benefits-link-model.interface';
import { ClaimDetailInterface, ClaimDetailsRequestModelInterface } from '../models/interfaces/claim-details-model.interface';

@Component({
  templateUrl: './claim-details.page.html',
  styleUrls: ['./claim-details.page.scss']
})
export class ClaimDetailsPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getUserState) userState: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getPreferences) preferences: any;

  isUserStateActive: boolean;
  expandedHeight: string;
  isMedexMember: boolean;
  isRateProvided: boolean;
  claimDetails: ClaimDetailInterface = new ClaimDetail();
  benefitsDocument: ClaimBenefitsLinkResponseModelInterface = new ClaimBenefitsLinkResponseModel();
  providerAddress;
  claimTotals;
  claimStatusLowerCaseDescription;
  allClaimServiceLines;

  claimRecord;
  isExpanded = false;

  title = 'Explanation of Benefits';
  fpoTargetUrl = '';
  showFinancialLink = false;
  showHEQALGFinancialLink = false;
  ssoFinancialLink = '';

  contactus = this.constants.contactus + this.authToken.scopename;
  allCliamsDetailsRetrieved = false;
  private hasHEQ = false;
  private hasALG = false;
  showPreference = false;

  constructor(
    private claimService: ClaimsService,
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private ssoService: SsoService,
    private datePipe: DatePipe,
    public constants: ConstantsService,
    private document: DocumentViewer,
    private file: File,
    private transfer: FileTransfer,
    private platform: Platform,
    private iabService: IabService,
    private location: Location,
    private fileOpener: FileOpener,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private profileService: ProfileService
  ) {
    this.expandedHeight = '48px';
    this.fpoTargetUrl = this.constants.drupalClaimsrUrl;
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
    const hasAltAdd = this.postLoginInfo && this.postLoginInfo.repPayeeFalg.toLowerCase() === 'false'
    const isMedicare = this.authToken.userType && this.authToken.userType.toLowerCase() === 'medicare'
    this.showPreference = !hasAltAdd ? false : (isMedicare ? false : true)
  }

  private handleFinanceLinksInSideBar() {
    this.hasALG = this.authToken ? this.authToken.isALG === 'true' : false;
    this.hasHEQ = this.authToken ? this.authToken.isHEQ === 'true' : false;

    this.showHEQALGFinancialLink = false;
    this.showFinancialLink = false;
    if (this.hasALG) {
      if (this.hasHEQ) {
        // both are true - show 2 links
        this.showHEQALGFinancialLink = true;
        this.showFinancialLink = false;
      } else {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      }
    } else {
      if (this.hasHEQ) {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      } else {
        // both are false - show no links
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = false;
      }
    }

    // this.showFinancialLink = (hasALG || hasHEQ) ? true : false;
    this.ssoFinancialLink = this.hasHEQ ? '/sso/heathequity' : '/sso/alegeus';
  }

  openSSO(module?) {
    if (module === 'algOrHeq') {
      this.ssoService.openSSO(this.hasHEQ ? 'heq' : 'alg');
    } else {
      this.ssoService.openSSO(module);
    }
  }

  ionViewWillEnter() {
    // this.profileService.setPreferencePromo(this.preferences);
    //Show paperless promo
    if(this.showPreference){
      this.profileService.swapPromo(this.useridin);
    } 
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyClaims_ClaimDetails);
    this.isUserStateActive = this.userState === 'Active';

    if (this.useridin) {
      this.isMedexMember = false;
      this.isRateProvided = false;
    }
    this.handleFinanceLinksInSideBar();

    this.getClaimDetails();
    this.claimService.claimRecord$.subscribe(message => {
      this.claimRecord = message;
      if (this.claimRecord !== null) {
        sessionStorage.setItem('claimRecord', JSON.stringify(this.claimRecord));
      }
    });

    if (this.claimRecord === null) {
      this.claimRecord = JSON.parse(sessionStorage.getItem('claimRecord'));
    }
    const t = this.authToken;
    if (t) {
      const authToken = this.authToken;
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (
        authToken.userType === 'MEMBER' &&
        authToken.planTypes &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  getClaimDetails() {
    const claimDetailsReqParams: ClaimDetailsRequestModelInterface = new ClaimDetailsRequestModel();
    claimDetailsReqParams.useridin = this.useridin;
    claimDetailsReqParams.claimId = sessionStorage.getItem('claimId') ? sessionStorage.getItem('claimId') : '';

    this.claimService.getClaimDetails(claimDetailsReqParams).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.result && apiData.result !== 0) {
          this.claimDetails = null;
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          this.claimDetails = apiData; // this.allClaimDetails.claimDetails;
          sessionStorage.setItem('memberName', this.claimDetails.memberName);
          this.claimStatusLowerCaseDescription = this.claimDetails.claimStatus.toString().toLowerCase();
          this.providerAddress = this.claimDetails.providerAddress;
          this.claimTotals = this.claimDetails.claimTotals;
          this.allClaimServiceLines = this.claimDetails.claimServiceLines;
        }
      }
      //console.log(`Get Claims Detail loaded (${this.allCliamsDetailsRetrieved}): `, new Date().getTime());
      this.allCliamsDetailsRetrieved = true;
    });
  }

  showContent() {
    return this.claimDetails && this.allCliamsDetailsRetrieved;
  }

  getDirections() {
    // e.g.:- 60 LEONARD ST, BELMONT MA 02478
    const location =
      this.providerAddress.address1 + ', ' + this.providerAddress.city + this.providerAddress.state + this.providerAddress.zipcode;
    console.log('location', location);
    const geoLocation = 'http://maps.google.com/?q=' + encodeURI(location);
    // window.location.href = 'http://maps.google.com/?q=' + geoLocation;
    window.open(geoLocation, '_self');
  }

  toggleExpansionPanel(isExpanded: boolean) {
    this.isExpanded = isExpanded;
  }

  navigateToDetails(claimId, claimDetails) {
    // this.claimService.setClaimDetails(claimDetails);
    this.router.navigate(['../', 'claimdetails', 'claimstatusdetails'], { relativeTo: this.route, replaceUrl: true });
  }

  openUrl(url) {
    if (url) {
      /* open pdf */
      const downloadUrl = url;
      const path = this.file.dataDirectory;
      const transfer = this.transfer.create();

      transfer.download(downloadUrl, path + 'myfile.pdf').then(entry => {
        const appUrl = entry.toURL();
        console.log('all url', url, downloadUrl, path, appUrl);
        if (this.platform.is('ios')) {
          this.document.viewDocument(appUrl, 'application/pdf', {});
        } else {
          this.fileOpener
            .open(appUrl, 'application/pdf')
            .then(() => console.log('File is opened'))
            .catch(e => console.log('Error opening file', e));
        }
      });
    }
  }

  openContactsUs() {
    this.router.navigateByUrl('/contact-us');
  }

  goBack() {
    this.location.back();
  }

  openUrlinNewWindow(url) {
    window.open(this.constants.directPayUrl, '_blank');
  }

  formattedDate(date: string): string {
    if (date) {
      return this.datePipe.transform(date, 'MM/dd/yyyy');
    }
  }

  loadBenefitsDocument() {
    const benefitsDocumentReqParams: ClaimBenefitsLinkRequestModelInterface = new ClaimBenefitsLinkRequestModel();
    benefitsDocumentReqParams.useridin = this.useridin;
    benefitsDocumentReqParams.eobClaimId = this.claimDetails.eobClaimId;
    benefitsDocumentReqParams.eobContractId = this.claimDetails.eobContractId;
    benefitsDocumentReqParams.claimProcessDate = this.claimDetails.claimProcessDate;
    benefitsDocumentReqParams.recordKey = sessionStorage.getItem('claimKey');

    this.claimService.getClaimsBenefitsLink(benefitsDocumentReqParams).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.result && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          this.benefitsDocument = apiData;
          this.openUrl(this.benefitsDocument.eobLink);
        }
      }
    });
  }

  public decimalFragment(sourceNumber): string {
    try {
      if (!sourceNumber) {
        return '00';
      }
      if (Number(sourceNumber)) {
        return Number(sourceNumber)
          .toFixed(2)
          .split('.')[1];
      } else {
        return '00';
      }
    } catch (error) {
      return '00';
    }
  }
}
