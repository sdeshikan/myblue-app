import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePageComponent } from './home-page.component';
import { YyyymmddTommddyyyyPipe } from '../../shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { CamelcasePipe } from '../../shared/pipes/camelcase/camelcase.pipe';
import { ClaimidPipe } from '../../shared/pipes/claimid/claimid.pipe';
import { HomedatePipe } from '../../shared/pipes/date/date.pipe';
import { PhonePipe } from '../../shared/pipes/phone/phone.pipe';
import { CasingForFilterPipe } from '../../shared/pipes/casingForFilter/casingForFilter.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '../../shared/services/auth.service';
import { AuthHttp } from '../../shared/services/authHttp.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { GlobalService } from '../../shared/services/global.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { AlertService } from '../../shared/services/alert.service';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { HomeService } from '../../shared/services/home.service';
import { MyDedCoService } from '../myded-co-app/myded-co.service';
import { MyMedicationDetailsService } from '../my-medication/my-medication-details/my-medication-details.service';
import { IonicStorageModule } from '@ionic/storage';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { SsoService } from '../sso/sso.service';
import { ModalController } from '@ionic/angular';
import { HeaderService } from '../../shared/layouts/header/header.service';
import { FooterService } from '../../shared/layouts/footer/footer.service';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { PharmacyLinksService } from '../../shared/services/mypharmacy/pharmacylinks.service';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { FeatureToggleService } from '../../services/feature.service';

describe('HomePage', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);

  const mockService = jasmine.createSpyObj('FeatureToggleService', ['isFeatureEnabled']);

  mockService.isFeatureEnabled.and.returnValue(true);

  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, IonicStorageModule.forRoot(), NgxsModule.forRoot([])],
      declarations: [HomePageComponent, YyyymmddTommddyyyyPipe, CamelcasePipe, ClaimidPipe, HomedatePipe, PhonePipe, CasingForFilterPipe],
      providers: [
        {
          provide: FeatureToggleService,
          useValue: mockService
        },
        AuthService,
        AuthHttp,
        ConstantsService,
        GlobalService,
        DependantsService,
        AlertService,
        TitleCasePipe,
        DatePipe,
        HomeService,
        MyDedCoService,
        MyMedicationDetailsService,
        InAppBrowser,
        SsoService,
        HeaderService,
        FooterService,
        AndroidPermissions,
        PharmacyLinksService,
        AppRate,
        AppVersion,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
