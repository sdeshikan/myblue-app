import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadProfileCardComponent } from './fad-profile-card.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PhoneNumberPipe } from '../../../shared/pipes/phone/phoneNumber.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { AuthService } from '../../../shared/services/auth.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';

describe('FadProfileCardComponent', () => {
  let component: FadProfileCardComponent;
  let fixture: ComponentFixture<FadProfileCardComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadProfileCardComponent, PhoneNumberPipe, PhonePipe],
      providers: [
        FadSearchResultsService,
        AuthService,
        FadDoctorProfileService,
        AuthHttp,
        ConstantsService,
        CallNumber,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadProfileCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
