import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tax-form-list',
  templateUrl: './tax-form-list.page.html',
  styleUrls: ['./tax-form-list.page.scss'],
})
export class TaxFormListPage implements OnInit {
  currentYear: number = new Date().getFullYear();
  taxYears: number[];
  constructor(private router: Router) {
   }

  ngOnInit() {
    this.taxYears =  [this.currentYear - 1, this.currentYear - 2];
  }

  getTaxDetails(year: number) {
    const url = '/tabs/tax-forms/view';
    this.router.navigate([url], { queryParams: { year } });
  }

}
