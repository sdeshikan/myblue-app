import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { environment } from '../../../../environments/environment.qa';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AlertService, ConstantsService } from '../../../shared/shared.module';
import { UpdateDemographicInfoRequestModel } from '../models/update-demographic-info.model';
import { GlobalService } from '../../../shared/services/global.service';

@Component({
  selector: 'app-about-me',
  templateUrl: './about-me.component.html',
  styleUrls: ['./about-me.component.scss']
})
export class AboutMeComponent implements OnInit, OnChanges, OnDestroy {
  profile: any;
  editRace: boolean = false;
  raceForm: FormGroup;
  isFormSubmitted: boolean = false;
  showRaceForm: boolean = false;
  fpoTargetUrl = environment.drupalTestUrl + '/page/myprofile';

  raceList: { code: string; description: string }[];
  ethnicityList: { code: string; description: string }[];
  latinoOriginList: { code: string; description: string }[];
  languageList: { code: string; description: string }[];
  showEthenicity2Flag: boolean = false;
  showRace2Flag: boolean = false;
  editCancelText: string = 'edit';

  // Health
  editHealth: boolean = false;
  editHealthText: string = 'edit';
  healthInfoEditForm: FormGroup;
  health: {
    allergies?: string[]; // allergies
    conditions?: string[]; // conditions
  };
  healthInfoOptions: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private fb: FormBuilder,
    private profileService: ProfileService,
    private globalService: GlobalService,
    private constants: ConstantsService
  ) {
    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    this.raceForm = this.fb.group({
      race1: ['', this.raceForm && this.raceForm.value.agree ? [] : []],
      race2: ['', []],
      ethnicity1: ['', this.raceForm && this.raceForm.value.agree ? [] : []],
      ethnicity2: ['', []],
      latinoOrigin: ['', this.raceForm && this.raceForm.value.agree ? [] : []],
      primaryLang: ['', this.raceForm && this.raceForm.value.agree ? [] : []],
      memberDOB: ['', []],
      agree: [false, []]
    });
    this.healthInfoEditForm = this.fb.group({
      useridin: '',
      healthInfo: this.fb.array([]),
      health: this.fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      })
    });
    // this.healthInfoEditForm = this.fb.group({
    //   healthInfo: this.fb.array([]),
    //   health: this.fb.group({
    //     allergies: new FormControl(),
    //     conditions: new FormControl()
    //   })
    // });
    this.profileService.getDemoGraphicInfo().subscribe(
      demoGraphicResponse => {
        const raceFormData: any = Object.create({
          race1: demoGraphicResponse.race1,
          race2: demoGraphicResponse.race2,
          ethnicity1: demoGraphicResponse.ethnicity1,
          ethnicity2: demoGraphicResponse.ethnicity2,
          latinoOrigin: demoGraphicResponse.latinoOrigin,
          primaryLang: demoGraphicResponse.primaryLang,
          memberDOB: demoGraphicResponse.memberDOB,
          agree: demoGraphicResponse.agree
        });

        this.showRaceForm = demoGraphicResponse.agree;
        this.raceList = demoGraphicResponse.raceList;
        this.ethnicityList = demoGraphicResponse.ethnicityList;
        this.latinoOriginList = demoGraphicResponse.latinoOriginList;
        this.languageList = demoGraphicResponse.languageList;
        console.log('raceFormData = ' + raceFormData.__proto__, JSON.stringify(raceFormData.__proto__));
        console.log(raceFormData.__proto__);
        this.raceForm.setValue(raceFormData.__proto__);
        if (this.raceForm.get('race2').value !== '') {
          this.showRace2Flag = true;
        }
        if (this.raceForm.get('ethnicity2').value !== '') {
          this.showEthenicity2Flag = true;
        }
      },
      error => {
        throw error;
      }
    );
    this.alertService.clearError();
    this.health = this.profile.health;
    this.healthInfoOptions = [
      {
        question: 'Does you have any allergies?',
        choices: ['Yes', 'No'],
        placeholder: 'Add your allergies separated by commas',
        hint: 'Allergy 1, Allergy 2'
      },
      {
        question: 'Does you have any health conditions?',
        choices: ['Yes', 'No'],
        placeholder: 'Add your health condition separated by commas',
        hint: 'Health Condition 1, Health Condition 2'
      }
    ];
    this.healthInfoOptions.map((healthOptions, i) => {
      (<FormArray>this.healthInfoEditForm.get('healthInfo')).push(this.addQuesFormGroup());
    });
    console.log('healthinfo', this.healthInfoOptions);

    // this.profileService.setProfile(this.profile);
  }

  ngOnChanges() {
    this.disableRELUpdateButton();
  }

  ngOnInit() {}

  disableRELUpdateButton() {
    if (
      this.raceForm.value.race1 === '' &&
      this.raceForm.value.race2 === '' &&
      this.raceForm.value.ethnicity1 === '' &&
      this.raceForm.value.ethnicity2 === '' &&
      this.raceForm.value.latinoOrigin === '' &&
      this.raceForm.value.primaryLang === ''
    ) {
      return true;
    } else {
      return false;
    }
  }

  provideInfo() {
    this.showRaceForm = !this.showRaceForm;
    this.showRace2Flag = false;
    this.showEthenicity2Flag = false;
    this.raceForm = this.fb.group({
      race1: ['', []],
      race2: ['', []],
      ethnicity1: ['', []],
      ethnicity2: ['', []],
      latinoOrigin: ['', []],
      primaryLang: ['', []],
      memberDOB: ['', []],
      agree: [this.showRaceForm, []]
    });
  }

  onSubmit() {
    const updateDemographicInfoReq: UpdateDemographicInfoRequestModel = new UpdateDemographicInfoRequestModel();
    updateDemographicInfoReq.useridin = this.profileService.getProfile().useridin;
    updateDemographicInfoReq.agree = this.raceForm.value.agree;
    updateDemographicInfoReq.race1 = this.raceForm.value.race1;
    updateDemographicInfoReq.race2 = this.raceForm.value.race2;
    updateDemographicInfoReq.ethnicity1 = this.raceForm.value.ethnicity1;
    updateDemographicInfoReq.ethnicity2 = this.raceForm.value.ethnicity2;
    updateDemographicInfoReq.latinoOrigin = this.raceForm.value.latinoOrigin;
    updateDemographicInfoReq.primaryLang = this.raceForm.value.primaryLang;
    updateDemographicInfoReq.memberDOB = this.raceForm.value.memberDOB;
    this.profileService.updateDemographicInfo(updateDemographicInfoReq).subscribe(
      updateDemographicInfoResp => {
        this.alertService.setAlert('Success!', '', AlertType.Success, 'component', 'aboutmesuccess');
        this.cancelRace();
        window.scrollTo(0, 0);
      },
      error => {
        throw error;
      }
    );
  }

  cancelRace() {
    this.resetAllEdits();
    this.editCancelText = 'edit';
  }

  showEthenicity2() {
    this.showEthenicity2Flag = true;
  }

  showRace2() {
    this.showRace2Flag = true;
  }

  navigateToUrl(url) {
    this.router.navigate([url]);
  }

  toggleRaceVisibility() {
    this.alertService.clearError();
    this.editRace = !this.editRace;
    if (this.editRace) {
      this.editCancelText = 'cancel';
      this.profileService.getDemoGraphicInfo().subscribe(
        demoGraphicResponse => {
          const raceFormData: any = Object.create({
            race1: demoGraphicResponse.race1,
            race2: demoGraphicResponse.race2,
            ethnicity1: demoGraphicResponse.ethnicity1,
            ethnicity2: demoGraphicResponse.ethnicity2,
            latinoOrigin: demoGraphicResponse.latinoOrigin,
            primaryLang: demoGraphicResponse.primaryLang,
            memberDOB: demoGraphicResponse.memberDOB,
            agree: demoGraphicResponse.agree
          });

          this.showRaceForm = demoGraphicResponse.agree;
          this.raceList = demoGraphicResponse.raceList;
          this.ethnicityList = demoGraphicResponse.ethnicityList;
          this.latinoOriginList = demoGraphicResponse.latinoOriginList;
          this.languageList = demoGraphicResponse.languageList;
          console.log('raceFormData = ' + raceFormData.__proto__, JSON.stringify(raceFormData.__proto__));
          this.raceForm.setValue(raceFormData.__proto__);
          if (this.raceForm.get('race2').value !== '') {
            this.showRace2Flag = true;
          }
          if (this.raceForm.get('ethnicity2').value !== '') {
            this.showEthenicity2Flag = true;
          }
        },
        error => {
          throw error;
        }
      );
    } else {
      this.editCancelText = 'edit';
    }
  }

  resetAllEdits() {
    this.editRace = false;
  }

  // Health Methods
  toggleHealthVisibility() {
    this.alertService.clearError();
    this.editHealth = !this.editHealth;
    if (this.editHealth) {
      this.editHealthText = 'cancel';
      this.getHealthFormDefinition();
    } else {
      this.editHealthText = 'edit';
    }
  }

  cancelHealth() {
    this.editHealth = false;
    this.editHealthText = 'edit';
  }

  onHealthSubmit() {
    // var prfEdtFrm = this.profileEditForm.value;
    // if (this.profileEditForm.value.phoneNumber) {
    //   this.profileEditForm.value.phoneNumber = (this.profileEditForm.value.phoneNumber + '').replace(/-/g, '');
    // }
    if (this.editHealth) {
      const prfEdtFrm = this.healthInfoEditForm.value;
      prfEdtFrm.health.allergies = prfEdtFrm.healthInfo[0].healthHintAns;
      prfEdtFrm.health.conditions = prfEdtFrm.healthInfo[1].healthHintAns;
    }
    let alertMessageFinal = '';
    let alertType = '';
    let resultCode = 0;
    this.profileService
      .updateProfile(this.healthInfoEditForm.value, false, false, false, false, this.editHealth)
      .flatMap(result => {
        resultCode = result.result;
        if (resultCode === -90129) {
          alertType = 'success';
          alertMessageFinal = result.displaymessage;
        } else if (resultCode === -90124 || resultCode === -90126) {
          alertType = 'error';
          alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
          alertMessageFinal = result.displaymessage;
        }
        return this.profileService.fetchProfileInfo();
      })
      .subscribe(
        profile => {
          // this.canEdit = this.profileService.authService.isSubscriber;
          this.profile = profile;
          this.healthInfoEditForm.patchValue(profile);
          this.profileService.setProfile(this.profile);

          let message = '';
          let addressSuccessMessage = '';
          if (resultCode === -90129) {
            addressSuccessMessage = alertMessageFinal;
            alertMessageFinal = '';
          }
          if (alertMessageFinal === '') {
            message = this.editHealth ? 'You have successfully updated your Health Information!' : message;
            this.alertService.setAlert(message, '', AlertType.Success, 'component', 'aboutmesuccess');
          } else {
            message = alertMessageFinal;
            this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'aboutmehealthfailure');
          }
          this.editHealth = false;
          this.editHealthText = 'edit';
        },
        err => {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      );
  }

  addQuesFormGroup(): FormGroup {
    return this.fb.group({
      healthHintAns: [''],
      healthquestion: ['', this.editHealth ? [Validators.required] : []]
    });
  }

  onQuestionClick(index: number) {
    let isValid: boolean = (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[index].get('healthquestion').value;
    const healthHintAns = (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[index].get('healthHintAns');
    if (isValid) {
      healthHintAns.setValidators([Validators.required]);
    } else {
      healthHintAns.setValidators([]);
      healthHintAns.setValue('');
      healthHintAns.updateValueAndValidity();
    }
  }

  getHealthFormDefinition() {
    this.healthInfoEditForm = this.fb.group({
      useridin: '',
      healthInfo: this.fb.array([]),
      health: this.fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      })
    });
    this.healthInfoOptions.map((healthOptions, i) => {
      (<FormArray>this.healthInfoEditForm.get('healthInfo')).push(this.addQuesFormGroup());
    });
    (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').setValue(this.profile.health.allergies);
    if (this.profile.health.allergies.length > 0) {
      (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[0]
        .get('healthquestion')
        .setValue(this.profile.health.allergies.length > 0);
    }
    (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').setValue(this.profile.health.conditions);
    if (this.profile.health.conditions.length > 0) {
      (this.healthInfoEditForm.get('healthInfo') as FormArray).controls[1]
        .get('healthquestion')
        .setValue(this.profile.health.conditions.length > 0);
    }
    this.healthInfoEditForm.patchValue(this.profile);
    console.log('health in get form definition', this.profile, this.healthInfoEditForm);
  }

  ngOnDestroy() {}
}
