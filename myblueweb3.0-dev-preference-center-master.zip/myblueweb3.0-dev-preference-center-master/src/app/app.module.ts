import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatTooltipModule } from '@angular/material';
import { MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StorageServiceModule } from 'angular-webstorage-service';
import { MaterializeModule } from 'angular2-materialize';
import { MomentModule } from 'angular2-moment';
import { TextMaskModule } from 'angular2-text-mask';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { DialogModule } from 'primeng/primeng';
import { AppComponent } from './app.component';
import { reducers } from './app.reducer';
import { appRouter } from './app.router';
import { MaterialModule } from './material.module';
import { FadFacilityCompareResolver } from './pages/fad/fad-facility-compare/fad-facility-compare-resolver';
import { FadFacilityCompareService } from './pages/fad/fad-facility-compare/fad-facility-compare.service';
import { FadProfessionalCompareService } from './pages/fad/fad-professional-compare/fad-professional-compare.service';
import { FadProviderCompareResolver } from './pages/fad/fad-provider-compare/fad-provider-compare-resolver';
import { FadProviderCompareService } from './pages/fad/fad-provider-compare/fad-provider-compare.service';
import { LandingService } from './pages/landing/landing.service';
import { LoginModule } from './pages/login/login.module';
import { MyMedicationDetailsService } from './pages/medications/myMedicationDetails/my-medication-details.service';
import { MyaccountResolver } from './pages/myaccount/myaccount.resolver';
import { MyAccountService } from './pages/myaccount/myaccount.service';
import { ClaimsService } from './pages/myclaims/claims.service';
import { MyDedCoResolver } from './pages/myded-co/myded-co.resolver';
import { MyDedCoService } from './pages/myded-co/myded-co.service';
import { EobsService } from './pages/myeobs/eobs.service';
import { MyplansService } from './pages/myplans/myplans.service';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { NotificationPreferencesResolver } from './pages/notification-preferences/notification-preferences.resolver';
import { NotificationPreferencesService } from './pages/notification-preferences/notification-preferences.service';
import { SsoResolver } from './pages/sso/sso.resolver';
import { SsoService } from './pages/sso/sso.service';
import { VdkComponent } from './pages/vdk/vdk.component';
import { YearEndSummaryService } from './pages/year-end-summary/year-end-summary.service';
import { AppInitService } from './services/app.service';
import { FeatureToggleService } from './services/feature-service';
import { AuthenticatedLayoutComponent } from './shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { HeaderService } from './shared/layouts/header/header.service';
import { LogoDialogComponent } from './shared/logo-dialog/logo-dialog.component';
import { MenuDialogComponent } from './shared/menu-dialog/menu-dialog.component';
import { AppModalsProfileService } from './shared/modals/appmodals-profile.service';
import { AppmodalsComponent } from './shared/modals/appmodals.component';
import { AppModalsService } from './shared/modals/appmodals.service';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { FadResolverService } from './shared/routeresolvers/FadResolverService';
import { HomepageResolver } from './shared/routeresolvers/homepage-resolver';
import { MyCardsResolverService } from './shared/routeresolvers/my-cards-resolver.service';
import { MyPlansResolverService } from './shared/routeresolvers/my-plans-resolver.service';
import { MyclaimsResolverService } from './shared/routeresolvers/myclaims-resolver.service';
import { MyEobsResolverService } from './shared/routeresolvers/myeobs-resolver.service';
import { MymedsResolverService } from './shared/routeresolvers/mymeds-resolver.service';
import { MyprofileResolverService } from './shared/routeresolvers/myprofile-resolver.service';
import { PreferenceResolverService } from './shared/routeresolvers/preference-resolver.service';
import { OrderreplacementResolverService } from './shared/routeresolvers/orderreplacement-resolver';
import { AuthService } from './shared/services/auth.service';
import { AuthHttp } from './shared/services/auth-http.service';
import { DependantsService } from './shared/services/dependant.service';
import { SelectionService } from './shared/services/downloadForm/selection.service';
import { FilterService } from './shared/services/filter.service';
import { GlobalService } from './shared/services/global.service';
import { LayoutService } from './shared/services/layout.service';
import { MedicationsService } from './shared/services/medications/medications.service';
import { MyCardsService } from './shared/services/mycards/mycards.service';
import { ProfileService } from './shared/services/myprofile/profile.service';
import { PreferenceModalService } from './shared/services/myprofile/preference-modal.service';
import { OrderreplacementService } from './shared/services/orderreplacement/orderreplacement.service';
import { SpinnerService } from './shared/services/spinner.service';
import { AlertService, ConstantsService, SharedModule } from './shared/shared.module';
import { SpinnertimeoutComponent } from './shared/spinnertimeout/spinnertimeout.component';
import { NoMenuResolver } from './shared/utils/nomenu.resolver';
import { PreferenceModalComponent } from './shared/components/preference-modal/preference-modal.component';


export function init_app(appLoadService: AppInitService) {
  return () => appLoadService.init();
}

@NgModule({
  declarations: [AppComponent, NotfoundComponent, AppmodalsComponent, SpinnertimeoutComponent, VdkComponent, NavbarComponent],
  exports: [AuthenticatedLayoutComponent],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    CommonModule,
    MaterializeModule,
    LoginModule,
    appRouter,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    TextMaskModule,
    MomentModule,
    DialogModule,
    MaterialModule,
    MatCardModule,
    MatTooltipModule,
    MatTooltipModule,
    Ng4LoadingSpinnerModule,
    StorageServiceModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot({ showMaskTyped: true }),
    NgIdleKeepaliveModule.forRoot(),
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot([])
  ],
  entryComponents: [
    MenuDialogComponent,
    LogoDialogComponent,
    PreferenceModalComponent
  ],
  providers: [
    SelectionService,
    AlertService,
    AuthService,
    NoMenuResolver,
    ConstantsService,
    DependantsService,
    LayoutService,
    GlobalService,
    FilterService,
    AuthHttp,
    DatePipe,
    TitleCasePipe,
    SpinnerService,
    OrderreplacementResolverService,
    OrderreplacementService,
    MyprofileResolverService,
    PreferenceResolverService,
    ProfileService,
    PreferenceModalService,
    MyCardsResolverService,
    MyCardsService,
    MymedsResolverService,
    MedicationsService,
    MyDedCoResolver,
    MyDedCoService,
    MyaccountResolver,
    MyAccountService,
    YearEndSummaryService,
    ClaimsService,
    MyclaimsResolverService,
    FadResolverService,
    SsoResolver,
    SsoService,
    LandingService,
    HomepageResolver,
    MyMedicationDetailsService,
    NotificationPreferencesService,
    NotificationPreferencesResolver,
    MyPlansResolverService,
    MyplansService,
    MyEobsResolverService,
    HeaderService,
    EobsService,
    FadProviderCompareService,
    FadFacilityCompareResolver,
    FadFacilityCompareService,
    FadProviderCompareResolver,
    FadProfessionalCompareService,
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    FeatureToggleService,
    AppInitService,
    {
      provide: APP_INITIALIZER,
      useFactory: init_app,
      deps: [AppInitService],
      multi: true
    },
    AppModalsService,
    AppModalsProfileService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
