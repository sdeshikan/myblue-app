import { OverallDeductibleModel } from './overall-deductible.model';
import { OutOfPocketDeductibleModel } from './out-of-pocket-deductible.model';
import { OverallBenefitModel } from './overall-benefit.model';
import { CoinsuranceDeductibleModel } from './coinsurance-deductible.model';

export interface AccumulatorModel {
  result?: number;
  displaymessage?: string;
  errormessage: string;
  coverageType: string;
  benefitName: string;
  planTypeFlag: string;
  planName: string;
  healthPlanTypeDescription: string;
  cobundledPlanFlag: string;
  blueChoiceFlag: string;
  planStartDate: string;
  planEndDate: string;
  outOfPocket: OutOfPocketDeductibleModel[];
  overallDeductibles: OverallDeductibleModel[];
  overallBenefit: OverallBenefitModel[];
  coinsurance: CoinsuranceDeductibleModel[];
}
