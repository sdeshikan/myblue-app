import { DatePipe, TitleCasePipe } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IonContent, IonSlides, MenuController, NavController, Platform } from '@ionic/angular';
import { Observable, Subject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Finanical } from '../../shared/models/finanical.model';
import { AlertService } from '../../shared/services/alert.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { GlobalService } from '../../shared/services/global.service';
import { RxDetailsRequestModelInterface } from '../my-medication/models/interfaces/rx-details-model.interface';
import { RxDetailsRequestModel } from '../my-medication/models/rx-details.model';
import { MyMedicationDetailsService } from '../my-medication/my-medication-details/my-medication-details.service';
import { HomePageAppInfoModel } from './home.model';

import { HttpClient } from '@angular/common/http';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { Storage } from '@ionic/storage';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import { environment } from '../../../environments/environment';
import { DeductibleModel } from '../../models/deductible.model';
import { PharmacyLinkType } from '../../models/pharmacy-link-type';
import { PostLoginModel } from '../../models/post-login.model';
import { DeductibleService } from '../../services/deductible.service';
import { FeatureToggleService } from '../../services/feature.service';
import { SwrveEventNames, SwrveService } from '../../services/swrve.service';
import { AlertType } from '../../shared/alerts/alertType.model';
import { FooterService } from '../../shared/layouts/footer/footer.service';
import { HeaderService } from '../../shared/layouts/header/header.service';
import { HomeService } from '../../shared/services/home.service';
import { IabService } from '../../shared/services/iab/iab.service';
import { SetUserState } from '../../store/actions/app.actions';
import { GetFamilyDeductibles } from '../../store/actions/deductible.actions';
import { AppSelectors } from '../../store/selectors/app-selectors';
import { DeductibleSelectors } from '../../store/selectors/deductible.selectors';
import { SsoService } from '../sso/sso.service';

@Component({
  selector: 'app-home',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit, OnDestroy {
  @Select(DeductibleSelectors.getDeductibles) deductibles$: Observable<DeductibleModel[]>;
  @Select(DeductibleSelectors.loadingDeductibles) isLoadingDeductibles$: Observable<boolean>;
  @Select(AppSelectors.getPostLoginInfo) postLoginInfo$: Observable<PostLoginModel>;
  @SelectSnapshot(AppSelectors.getPharmacyLinks) pharmacyLinks: PharmacyLinkType[];

  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getRefreshToken) refreshToken: string;

  @ViewChild(IonContent) content: IonContent;
  @ViewChild(IonSlides) slides: IonSlides;

  isFitnessEnabled = false;
  isRegisteredUser: boolean;
  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  carouselItemDetails: [] = [];
  memberFirstName: string;
  showDoctorDrupal = false;
  showMedicationDrupal = false;
  showClaimsDrupal = false;
  financialChartDetails: Finanical[] = [];
  isDisplayFinanceLoader: boolean;
  showNurseLine = false;
  hasBlueGreen = false;
  ahealthyme = false;

  memberInfo: HomePageAppInfoModel;
  isFinancialView = false;
  doctorData: any;
  medicationData: any;
  claimsData: any;
  isdependant = false;
  ismedicaremember = false;
  isSmartShopperUser = false;
  bannerImage: any = '';
  hasBqi = false;
  isFirstTime = true;
  authFitness = this.swrveEventNames.AppClick_HomeAuthenticated_Fitness;
  unAuthFitness = this.swrveEventNames.AppClick_HomeAnonymous_Fitness;
  authAHealthyMe = this.swrveEventNames.AppClick_HomeAuthenticated_AHealthyMe;
  unAuthAHealthyMe = this.swrveEventNames.AppClick_HomeAnonymous_AHealthyMe;
  homepageApiResponse: Observable<any>;
  homeNavigationApiResponse: any;
  homeHeroBannerResponse: Observable<any>;
  homeDiscountsResponse: Observable<any>;
  featureUrl = this.constantsService.featureUrl;
  anonymousFeedback = this.constantsService.anonymousFeedback;
  blue365Url = this.constantsService.blue365Url;
  footerGlobalLinks: any;
  drupalUrl = environment.drupalTestUrl;

  destroy$: Subject<boolean> = new Subject<boolean>();

  slideOpts = {
    initialSlide: 0,
    speed: 400,
    loop: false
  };

  constructor(
    private router: Router,
    private globalService: GlobalService,
    private store: Store,
    private constantsService: ConstantsService,
    private alertService: AlertService,
    private http: HttpClient,
    private myDedCoService: DeductibleService,
    private datePipe: DatePipe,
    private myMedicationDetailsService: MyMedicationDetailsService,
    private titleCase: TitleCasePipe,
    private activatedRoute: ActivatedRoute,
    private menu: MenuController,
    private storage: Storage,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    private headerService: HeaderService,
    private platform: Platform,
    private footerService: FooterService,
    private androidpermissions: AndroidPermissions,
    private appRate: AppRate,
    private appVersion: AppVersion,
    private featureToggleService: FeatureToggleService,
    private navCtrl: NavController,
    private homeService: HomeService
  ) {
    this.isFitnessEnabled = featureToggleService.isFeatureEnabled('fitness-benefits');
  }

  scrollToTop() {
    const SCROLL_DELAY = 200;
    this.content.scrollToTop(SCROLL_DELAY);
  }

  ionViewDidEnter() {
    this.scrollToTop();
    if (this.scopeName && this.scopeName.includes('AUTHENTICATED')) {
      this.loadHomePageInfo();
    }
  }

  toggleMenu() {
    this.menu.toggle();
  }

  ngOnInit() {
    this.homeService.getCarouselItemDetails().subscribe(response => {
      this.carouselItemDetails = this.transformCarouselResponse(response);
    });

    // Home Page -- Promo Block Code
    this.homeService.loadArticle(1);
    this.homeService.loadArticle(2);
    this.homeService.loadArticle(3);

    this.homeService.getHomePageApiResponse().subscribe(response => {
      this.homepageApiResponse = this.transformPageApiResponse(Array.isArray(response) ? response[0] : response);
    });
    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        sessionStorage.setItem('find_a_doctor_link', this.homeNavigationApiResponse.APPTextUrl3 || '');
        sessionStorage.setItem('call_nurse_link_link', this.homeNavigationApiResponse.APPTextUrl2 || '');
      }
    });
    this.homeService.getHomeHeroBannerResponse().subscribe(response => {
      this.homeHeroBannerResponse = Array.isArray(response) ? response[0] : response;
    });
    this.homeService.getHomeDiscountsResponse().subscribe(response => {
      this.homeDiscountsResponse = Array.isArray(response) ? response[0] : response;
    });

    this.alertService.clearError();
    this.clearSessionItems();
    this.getFooter();
    this.accessFineLocation();
  }

  async accessFineLocation() {
    const hasRequestedPermission = await this.storage.get('hasRequestedPermisson');
    if (!hasRequestedPermission) {
      this.storage.set('hasRequestedPermisson', true);
      if (this.platform.is('android')) {
        const hasPermission = await this.androidpermissions.checkPermission(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION);
        if (!hasPermission) {
          this.androidpermissions.requestPermissions(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION);
        }
      }
    }
  }

  getFooter() {
    if (!this.homeService.globalFooterData) {
      this.footerService
        .getGlobalFooter()
        .pipe(
          filter((response: any) => response && response.length),
          map(response => response[0])
        )
        .subscribe(data => {
          this.footerGlobalLinks = data;
          this.homeService.globalFooterData = data;
        });
    } else {
      this.footerGlobalLinks = this.homeService.globalFooterData;
    }
  }

  transformPageApiResponse(response: any) {
    return {
      ...response,
      MobileHeroBanner: this.constantsService.drupalTestUrl + response.MobileHeroBanner
    };
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  checkSmartShopperUser(postLoginInfo: PostLoginModel) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  ionViewWillEnter() {
    this.isFirstTime = false;
    const scopeName = this.scopeName;
    this.isRegisteredUser = scopeName ? scopeName.includes('REGISTERED') : false;
    this.isAuthenticatedUser = scopeName ? scopeName.includes('AUTHENTICATED') : false;
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    this.alertService.clearError();
    if (scopeName === 'AUTHENTICATED-NOT-VERIFIED' || scopeName === 'AUTHENTICATED-AND-VERIFIED') {
      this.memberFirstName = this.authToken && this.authToken.firstName ? this.authToken.firstName : '';
    } else {
      //Show the alert for RV and RNV users
      this.alertService.setAlert(
        this.constantsService.registerNewMembers,
        'Welcome New Members!',
        AlertType.Warning,
        'component',
        'registeredhomepage'
      );
      this.memberFirstName = '';
    }
  }

  loadHomePageInfo() {
    this.store.dispatch(new GetFamilyDeductibles(this.useridin, false));
    this.homeService.getHomepageinfo().subscribe((data: any) => {
      if (data) {
        if (data.ROWSET && !Array.isArray(data.ROWSET.ROW) && typeof data.ROWSET.ROW === 'object') {
          this.memberInfo = new HomePageAppInfoModel(this.titleCase).deserialize(data.ROWSET && data.ROWSET.ROW);
          this.isSmartShopperUser = this.postLoginInfo ? this.checkSmartShopperUser(this.postLoginInfo) : false;

          this.showNurseLine =
            this.memberInfo.cerner &&
            this.memberInfo.cerner.hasCerner !== 'true' &&
            this.memberInfo.cerner.hasCernerEE !== 'true' &&
            this.memberInfo.cerner.hasCernerMedicare !== 'true' &&
            this.memberInfo.hasBlueGreen !== 'true' &&
            this.memberInfo.hasBQi !== 'true';
          this.hasBqi = this.memberInfo.hasBQi === 'true';
          this.hasBlueGreen = this.memberInfo.hasBlueGreen === 'true';

          this.ahealthyme =
            this.memberInfo.cerner &&
            (this.memberInfo.cerner.hasCerner === 'true' ||
              this.memberInfo.cerner.hasCernerEE === 'true' ||
              this.memberInfo.cerner.hasCernerMedicare === 'true');

          this.globalService.landingPageMemberInfoApp = this.memberInfo;
          this.store.dispatch(new SetUserState(this.memberInfo.userState));

          if (this.memberInfo.myclaims && this.memberInfo.myclaims.clmICN) {
            sessionStorage.setItem('claimId', this.memberInfo.myclaims.clmICN);
          }
        }

        this.showUserBanner();
        this.getFinancialData();
        this.showUserDataBlocks();
      }
    });

    if (this.authToken && this.authToken.unreadMsgCount && !this.headerService.unReadMsgCount) {
      this.headerService.unReadMsgCount = this.authToken.unreadMsgCount.toString();
    }
  }

  showUserBanner(): void {
    if (this.isMedicare()) {
      this.bannerImage = 'Hero_Image_Medicare';
      this.ismedicaremember = true;
    } else if (this.memberInfo && this.memberInfo.hasDependents.toString() === 'false' && this.isMedicare()) {
      this.bannerImage = 'Hero_Image_No_Dependents';
      this.isdependant = true;
    } else {
      this.bannerImage = 'Hero_Image_Default';
    }
  }

  isMedicare() {
    return this.authToken.userType.toLowerCase() === 'medicare' || this.authToken.userType.toLowerCase() === 'medex';
  }

  openInAppBrowser(url) {
    this.iabService.create(url);
  }

  openInAppBrowserSso(url: string, ssoLink: string, unAuthSwrveEvent: string, authSwrveEvent: string) {
    if (url.endsWith('fad')) {
      if (this.isSmartShopperUser) {
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['tabs/fad']);
      }
      return;
    }
    if (this.isAuthenticatedUser) {
      this.sendSwrveEventsForIABClicks(authSwrveEvent);
      this.ssoService.openSSO(ssoLink);
    } else {
      this.sendSwrveEventsForIABClicks(unAuthSwrveEvent);
      this.iabService.create(url);
    }
  }

  sendSwrveEventsForIABClicks(desctiption: string) {
    if (desctiption === 'Find_a_doctor') {
      if (this.isAuthenticatedUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAuthenticated_FindaDoctor);
      } else if (this.isRegisteredUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeRegistered_FindaDoctor);
      } else if (this.isAnonymousUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAnonymous_FindaDoctor);
      }
    }
  }

  authRestartScreen() {
    this.globalService
      .redirectionRoute()
      .then(response => {
        console.log(response);
      })
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  transformCarouselResponse(response: any): [] {
    if (response && response.length) {
      return response.map(item => {
        const carouselItem = new Image() as any;
        carouselItem.src = this.constantsService.drupalTestUrl + item.RegularImages;
        carouselItem.mobilesrc = this.constantsService.drupalTestUrl + item.MobileImages;
        carouselItem.text = item.ArticleText;
        carouselItem.isVideo = item.VideoUrl.length;
        carouselItem.VIdeoUrl = item.VideoUrl;
        carouselItem.urlLink = item.ArticleUrl;
        carouselItem.Title = item.Title;
        carouselItem.Body = item.Body;
        return carouselItem;
      });
    }
    return [];
  }

  goToDeductibleDetails() {
    this.navCtrl.navigateForward('deductibles');
  }

  getFinancialData() {
    if (this.hasFinancialsData()) {
      this.isFinancialView = true;
      this.isDisplayFinanceLoader = true;
      this.homeService.getFinanceBalancChartData().subscribe(
        response => {
          this.financialChartDetails = response && response.length ? response : [];
          this.isDisplayFinanceLoader = false;
        },
        () => {
          this.isDisplayFinanceLoader = false;
        }
      );
    } else {
      this.financialChartDetails = [];
    }
  }

  nextDeductible() {
    this.slides.slideNext();
  }

  previousDeductible() {
    this.slides.slidePrev();
  }

  hasFinancialsData(): boolean {
    const hasALG = this.memberInfo.hasALG.toString().toLowerCase();
    const hasHEQ = this.memberInfo.hasHEQ.toString().toLowerCase();
    const result = this.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    sessionStorage.setItem('hasALG', hasALG);
    sessionStorage.setItem('hasHEQ', hasHEQ);
    this.isFinancialView = result;
    return result;
  }

  showUserDataBlocks(): void {
    this.showMedicationDrupal = false;
    this.showDoctorDrupal = false;
    this.showClaimsDrupal = false;

    if (this.memberInfo) {
      if (this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) {
        this.showDoctorDrupal = true;
        this.getDrupalContent(this.constantsService.drupalDoctorsUrl).subscribe(response => {
          this.doctorData = response[0];
        });
      }

      if (this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) {
        this.showMedicationDrupal = true;
        this.getDrupalContent(this.constantsService.drupalMedicationsUrl).subscribe(response => {
          this.medicationData = response[0];
        });
      }
      if (this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN) {
        this.showClaimsDrupal = true;
        this.getDrupalContent(this.constantsService.drupalClaimsUrl).subscribe(response => {
          this.claimsData = response[0];
        });
      }
    }
  }

  getDrupalContent(url): Observable<any> {
    return this.http.get(url).pipe(map(response => this.transformCarouselResponse(response)));
  }

  showMedicationDetails() {
    const medicationDetailReq: RxDetailsRequestModelInterface = new RxDetailsRequestModel();
    medicationDetailReq.useridin = this.useridin;
    medicationDetailReq.rxIncurredDate = this.globalService.getUTCDate(this.memberInfo.mymedications.rxIncurredDate);
    medicationDetailReq.ndcCd = this.memberInfo.mymedications.rxNDCCode; // ndcCd;
    if (this.memberInfo && this.memberInfo.mymedications && this.memberInfo.mymedications.rxDependentId) {
      medicationDetailReq.dependentId = this.memberInfo.mymedications.rxDependentId;
    }
    this.myMedicationDetailsService.setMyMedicationDetailsRequest(medicationDetailReq);
    this.router.navigate(['../my-medications/medicationdetails']);
  }

  stopEventPropagation(event) {
    event.stopPropagation();
  }

  showDoctorDetails() {
    sessionStorage.setItem('providerName', this.memberInfo.mydoctors.visitPrvName);
    sessionStorage.setItem('providerNumber', this.memberInfo.mydoctors.visitPrvNum);
    if (this.memberInfo && this.memberInfo.mydoctors && this.memberInfo.mydoctors.visitDependentId) {
      sessionStorage.setItem('docDependentId', this.memberInfo.mydoctors.visitDependentId);
    }
    this.router.navigate([`/my-doctor/details`]);
  }

  handleMyFinancialClick() {
    if (this.isRegisteredUser) {
      this.authRestartScreen();
    }
  }

  navigateToAlegeus(lineChart: Finanical): void {
    if (lineChart.isALGAccount) {
      this.ssoService.openSSO('alg');
    } else {
      this.ssoService.openSSO('heq');
    }
  }

  isHsaAccount(accountType) {
    return accountType === 'ABH' || accountType === 'HSA' || accountType === 'AB2';
  }

  rateTheAppClick() {
    this.appRate.preferences.storeAppURL = {
      ios: '937789998',
      android: `market://details?id=${this.appVersion.getPackageName() || 'com.bcbsma.myblueredesign'}&hl=en_US`
    };

    this.appRate.promptForRating(true);
  }

  openSmartShopper() {
    if (this.postLoginInfo.hasSS || this.postLoginInfo.hasCI) {
      this.ssoService.openSSO('fad');
    }
  }

  navigatePharmacyLink(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  openFitnessURL() {
    if (this.isFitnessEnabled) {
      this.navCtrl.navigateForward('/tabs/fitness-and-weightloss');
    } else {
      window.open('https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss', '_blank');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
