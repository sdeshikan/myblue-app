import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { ReimbursementDetailsPageModule } from './pages/reimbursement-details/reimbursement-details.module';
import { ReimbursementDetailsPage } from './pages/reimbursement-details/reimbursement-details.page';
import { ReimbursementErrorModule } from './pages/reimbursement-error/reimbursement-error.module';
import { ReimbursementErrorPage } from './pages/reimbursement-error/reimbursement-error.page';
import { ReimbursementSelectionModule } from './pages/reimbursement-selection/reimbursement-selection.module';
import { ReimbursementSelectionPage } from './pages/reimbursement-selection/reimbursement-selection.page';
import { ReimbursementSuccessModule } from './pages/reimbursement-success/reimbursement-success.module';
import { ReimbursementSuccessPage } from './pages/reimbursement-success/reimbursement-success.page';

const routes: Routes = [
  {
    path: '',
    component: ReimbursementSelectionPage
  },
  {
    path: 'reimbursement-details',
    component: ReimbursementDetailsPage
  },
  {
    path: 'reimbursement-error',
    component: ReimbursementErrorPage
  },
  {
    path: 'reimbursement-success',
    component: ReimbursementSuccessPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    RouterModule.forChild(routes),
    ReimbursementSelectionModule,
    ReimbursementDetailsPageModule,
    ReimbursementErrorModule,
    ReimbursementSuccessModule
  ]
})
export class FitnessBenefitsModule {}
