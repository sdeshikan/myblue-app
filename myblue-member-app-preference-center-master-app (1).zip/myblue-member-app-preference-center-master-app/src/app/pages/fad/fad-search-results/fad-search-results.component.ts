import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { IonInfiniteScroll, ModalController } from '@ionic/angular';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadLandingPageCompInput } from '../modals/fad-landing-page.modal';
import {
  FadLandingPageCompInputInterface,
  FadLandingPageCompOutputInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  FadFacilitySearchFilterComponentOutputModelInterface,
  FadSearchFilterComponentOutputModelInterface,
  FadSpecialtyFilterComponentOutputModelInterface
} from '../modals/interfaces/fad-search-filter.interface';
import { FadLandingPageConsumer, FadSearchFilterConsumer, FadSearchListConsumer } from '../modals/interfaces/fad.interface';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { PopoverController } from '@ionic/angular';
import * as _isEmpty from 'lodash/isEmpty';
import { filter, map, mergeMap } from 'rxjs/operators';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { FadSendEmailPopoverComponent } from '../../../shared/layouts/fad-send-email-popover/fad-send-email-popover.component';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadFacilityCompareService } from '../fad-facility-compare/fad-facility-compare.service';
import { FadFacilityListService } from '../fad-facility-list/fad-facility-list.service';
import { FadFacilitySearchFilterComponent } from '../fad-facility-search-filter/fad-facility-search-filter.component';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { FadProviderCompareService } from '../fad-provider-compare/fad-provider-compare.service';
import { FadProviderFacilityListService } from '../fad-provider-facility-list/fad-provider-facility-list.service';
import { FadSearchFilterComponent } from '../fad-search-filter/fad-search-filter.component';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSpecialtySearchFilterComponent } from '../fad-specialty-search-filter/fad-specialty-search-filter.component';

import { HttpClient } from '@angular/common/http';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import {
  FadFacilityListComponentInputModel,
  FadSearchListComponentInputModel,
  FadSearchListComponentOutputModel,
  FadSpecialtyListComponentInputModel
} from '../modals/fad-search-list.modal';
import { FacilityFiltersMetadataModel, GetSearchByFacilityRequestModel } from '../modals/getSearchByFacility.model';
import { FiltersMetadata, GetSearchByProfessionalRequestModel, SortMetadata } from '../modals/getSearchByProfessional.model';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import {
  FadFacilityListComponentInputModelInterface,
  FadSearchListComponentInputModelInterface,
  FadSearchListComponentOutputModelInterface,
  FadSpecialtyListComponentInputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import {
  FacilityFiltersMetadataInterface,
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import {
  CostDetails,
  Disclaimers,
  FiltersMetadataInterface,
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface,
  SortMetadataInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  GetSearchBySpecialityRequestModelInterface,
  GetSearchBySpecialtyResponseModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { FadResouceTypeCodeConfig, FadResourceTypeCode } from '../modals/types/fad.types';
import { BreadCrumb } from '../utils/fad.utils';
import { FadService } from './../fad.service';
import { FadSearchResultsService } from './fad-search-results.service';


@Component({
  selector: 'app-fad-search-results',
  templateUrl: './fad-search-results.component.html',
  styleUrls: ['./fad-search-results.component.scss']
})
export class FadSearchResultsComponent
  implements OnInit, OnDestroy, FadLandingPageConsumer, FadSearchFilterConsumer, FadSearchListConsumer {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  @Output() componentOutput: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<
    FadSearchListComponentOutputModel
  >();

  @Output() clearFilter: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<FadSearchListComponentOutputModel>();
  @Input() componentInput: FadSearchListComponentInputModelInterface;

  public fadConstants = FAD_CONSTANTS;
  public isNoSearchResults = false;
  emailEditForm: FormGroup;

  // fad-landing-page component consumption requirements
  public miniSearchBarData: FadLandingPageCompInputInterface = new FadLandingPageCompInput();

  // fad-search-filter component consumption requirement
  public mobileHideByFilterOverlay = false;

  // fad-search-list component consumption requirement
  public searchListComponentInput: FadSearchListComponentInputModelInterface;
  public facilityListComponentInput: FadFacilityListComponentInputModelInterface;
  public specialtyListComponentInput: FadSpecialtyListComponentInputModelInterface;
  public totalCount: number;
  public isLoadMoreEnabled = true;
  public costDetails: CostDetails;
  public disclaimers: Disclaimers[];
  public disclaimerToplist: Disclaimers[];
  public disclaimerBottomlist: Disclaimers[];
  public disclaimerTopResults: Disclaimers[];
  public resourceTypeCode: FadResourceTypeCode = null;
  public locationID = 0;
  public facilityName = null;
  private infiniteScrollIndexCache = 1;

  // Search type Content
  public isAllProcedures = false;
  public isAffiliatedDoctors = false;

  @ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;
  @ViewChild('optionalMessage') optionalMessage;
  public isDisplaySpinner = false;
  public isDisplaySpinnerProfessional = false;

  public facilityFilterCriteriaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
  public filterCriteriaData: FiltersMetadataInterface = new FiltersMetadata();
  public sortCriteriaData: SortMetadataInterface = new SortMetadata();

  showCompareResultsButton = false;
  selectedResultCount = 0;
  displayBannerInFixedPosition = false;
  procedureFlag = false;
  specialtyEmailFlag = false;
  professionalEmailFlag = false;
  facilityEmailFlag = false;

  public networkChanged: string;
  public isFormSubmitted = false;
  public showRequestEstimateLink: boolean;
  public isFilterChanged = false;
  private scrollEvent: any;
  private sortMode = '';
  private filterMetaData = {};
  isSearchFocused = false;
  isProcedureFlag = false;
  submenu: any = {};

  constructor(
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadSearchListService,
    private fadFacilityListService: FadFacilityListService,
    private fadProviderFacilityListService: FadProviderFacilityListService,
    private cdRef: ChangeDetectorRef,
    private fadProviderCompareService: FadProviderCompareService,
    private fadFacilityCompareService: FadFacilityCompareService,
    private fadProfessionalCompareService: FadProfessionalCompareService,
    private activatedRoute: ActivatedRoute,
    private fadService: FadService,
    private router: Router,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private globalService: GlobalService,
    public elementRef: ElementRef,
    private httpClient: HttpClient,
    private validationService: ValidationService,
    private fb: FormBuilder,
    private popoverController: PopoverController,
    public modalController: ModalController,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.emailEditForm = this.fb.group({
      emailAddress: ['', [Validators.required, this.validationService.emailValidator()]]
    });

    this.router.events
      .filter(e => e instanceof NavigationEnd)
      .pipe(
        map(() => this.activatedRoute),
        // tslint:disable-next-line:no-shadowed-variable
        map(activatedRoute => {
          if (activatedRoute.firstChild) {
            activatedRoute = activatedRoute.firstChild;
          }

          return activatedRoute;
        }),
        // tslint:disable-next-line:no-shadowed-variable
        filter(activatedRoute => activatedRoute.outlet === 'primary'),
        // tslint:disable-next-line:no-shadowed-variable
        mergeMap(activatedRoute => activatedRoute.data)
      )
      .subscribe(data => {
        this.ngOnInit();
        this.fadProviderCompareService.setSearchResult(null);
      });
  }

  private has(object: any = {}, path: string = '') {
    const pathArray = path.split('.');
    for (let i = 0; i < pathArray.length; i++) {
      if (!object || !object[pathArray[i]]) {
        return false;
      }
      object = object[pathArray[i]];
    }
    return true;
  }

  onSearchFocus($event) {
    this.isSearchFocused = $event;
  }

  @HostListener('window:scroll', ['$event'])
  showBannerFixedOnWindowScroll($event) {
    const msgListingPos = this.elementRef.nativeElement.offsetTop;
    const windowScrollPos = window.pageYOffset;
    // tslint:disable-next-line:prefer-conditional-expression no-magic-numbers
    if (windowScrollPos > msgListingPos && windowScrollPos > 300 && window.screen.width > 992) {
      this.displayBannerInFixedPosition = this.showCompareResultsButton;
    } else {
      this.displayBannerInFixedPosition = false;
    }
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_FAD_SearchResult_Screen);

    let resolvedData = {};
    // tslint:disable-next-line:prefer-conditional-expression
    if (sessionStorage.getItem('fadLandingPageSearchResults')) {
      resolvedData = Object.assign({}, JSON.parse(sessionStorage.getItem('fadLandingPageSearchResults')));
    } else {
      resolvedData = Object.assign({}, this.activatedRoute.snapshot.data.fadLandingPageSearchResults);
    }

    this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Search').setUrl('/fad/search-results'));

    this.miniSearchBarData.componentMode = FAD_CONSTANTS.flags.fadLandingPageComponentMode_Abstract;
    this.miniSearchBarData.fadBaseSearchModel = this.fadSearchResultsService.getSearchCriteria();

    if (
      this.fadFacilityCompareService.getSearchResult() == null ||
      this.fadProviderCompareService.getSearchResult() == null ||
      this.fadProfessionalCompareService.getSearchResult() == null
    ) {
      this.showCompareResultsButton = false;
    }

    this.isAllProcedures = this.miniSearchBarData.fadBaseSearchModel.getSearchText().isProcedure();

    if (this.router.url === FAD_CONSTANTS.urls.fadAffiliatedDoctorsSearch) {
      this.isAffiliatedDoctors = true;
      this.facilityName = sessionStorage.getItem('facilityname');
    } else {
      sessionStorage.removeItem('linkedAffiliationId');
      this.isAffiliatedDoctors = false;
    }

    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

    if (searchCriteria) {
      // ensure that the a valid request is present before querying for a response
      this.resourceTypeCode = searchCriteria.getSearchText().getResourceTypeCode();
      this.locationID = searchCriteria.getSearchText().getLocationId();

      this.procedureFlag = searchCriteria.getSearchText().isProcedure();
      this.searchListComponentInput = new FadSearchListComponentInputModel();

      if (this.isAffiliatedDoctors) {
        this.resourceTypeCode = 'P';
        this.procedureFlag = false;

        this.getFadProfileSearchResults(searchCriteria, false, resolvedData as GetSearchByProfessionalResponseModelInterface);

      } else if (this.resourceTypeCode === FadResouceTypeCodeConfig.professional && !searchCriteria.getSearchText().isProcedure()) {

        this.getFadProfileSearchResults(searchCriteria, false, resolvedData as GetSearchByProfessionalResponseModelInterface);
      } else if (this.resourceTypeCode === FadResouceTypeCodeConfig.facility && !searchCriteria.getSearchText().isProcedure()) {

        this.getFadFacilitySearchResults(searchCriteria, false, resolvedData as GetSearchByFacilityResponseModelInterface);
      } else {

        this.getFadSpecialtySearchResults(
          searchCriteria,
          false,
          resolvedData as GetSearchBySpecialtyResponseModelInterface,
          null,
          null,
          true
        );
      }
    } else {
      this.isNoSearchResults = true;
    }
    this.fadSearchResultsService.setContextText('');
    this.networkChanged = sessionStorage.getItem('networkChange');
    const networkcheck = this.fadConstants.networks;
    const networkid = this.fadSearchResultsService
      .getSearchCriteria()
      .getPlanName()
      .getNetworkId();
    // console.log(this.fadConstants.networks.indexOf(networkid));
    // networkcheck.includes(networkid);
    this.showRequestEstimateLink = this.findnetworkid(networkid);
    console.log('find network id', this.showRequestEstimateLink, this.isAnonymousUser());

    // resetting the infinite scroll and scroll page flag to 1.
    if (this.has(this.scrollEvent, 'target')) {
      this.scrollEvent.target.disabled = false;
      this.infiniteScrollIndexCache = 1;
    }
  }

  findnetworkid(networkid) {
    let returnvalue = false;
    this.fadConstants.networks.find(network => {
      return (returnvalue = network === networkid);
    });
    return returnvalue;
  }

  async openEmailSendWindow() {
    const modal = await this.modalController.create({
      component: FadSendEmailPopoverComponent,
      cssClass: 'select-modal',
      componentProps: {
        specialtyEmailFlag: this.specialtyEmailFlag,
        procedureFlag: this.procedureFlag,
        professionalEmailFlag: this.professionalEmailFlag,
        facilityEmailFlag: this.facilityEmailFlag
      }
    });
    return await modal.present();
  }

  ngOnDestroy(): void {
    this.infiniteScrollIndexCache = 1;
    this.fadService.resetServiceError();
    sessionStorage.removeItem('searchAffiliatedDoctors');
  }


  private getFadProfileSearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchByProfessionalResponseModelInterface,
    filtersData?: FiltersMetadataInterface,
    sortData?: SortMetadataInterface
  ): void {
    sessionStorage.setItem('radius', null);
    // $('ng4-loading-spinner .spinner').addClass('visible');
    // PLEASE NOTE
    // THIS METHOD DOES NOT USE THE INPUT REQUEST YET
    // BUT THE SAME WILL BE USED ONCE ALL THE GET REQUESTS ARE CONVERTED INTO POST REQUESTS
    // PLEASE DONOT DELETE THE INPUT PARAMETER request: FadLandingPageSearchControlValuesInterface
    try {
      if (resolvedData) {
        this.updateProfessionalsDataToView(resolvedData, false, scroll);
        return;
      }

      this.isDisplaySpinnerProfessional = scroll;
      const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
      if (!scroll) {
        this.infiniteScrollIndexCache = 0;
      }
      if (this.isAffiliatedDoctors) {
        this.isDisplaySpinnerProfessional = true;
        vitalsSearchRequestbyProfessional
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(++this.infiniteScrollIndexCache)
          .setNetworkId(
            request.getPlanName && request.getPlanName().getNetworkId()
              ? request.getPlanName().getNetworkId()
              : FAD_CONSTANTS.defaults.networkId
          );
        // .setNetworkId(311005002);
      } else {
        vitalsSearchRequestbyProfessional
          .setGeoLocation(request.getZipCode().geo)
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(++this.infiniteScrollIndexCache)
          // tslint:disable-next-line:no-magic-numbers
          .setRadius(25)
          .setNetworkId(
            request.getPlanName && request.getPlanName().getNetworkId()
              ? request.getPlanName().getNetworkId()
              : FAD_CONSTANTS.defaults.networkId
          );

        if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
          vitalsSearchRequestbyProfessional.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
        } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
          vitalsSearchRequestbyProfessional.setSearchProcedureId(request.getSearchText().getProcedureId());
        } else {
          vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(request));
        }
      }

      // Start applying Sorting & filters //
      if (filtersData) {
        if (Object.keys(filtersData).length > 0) {
          this.isFilterChanged = true;

          if (filtersData.filterPCP) {
            vitalsSearchRequestbyProfessional.setisPcp(filtersData.filterPCP.toString());
          }

          if (filtersData.filterTechSavvy) {
            vitalsSearchRequestbyProfessional.setTechSavvy(filtersData.filterTechSavvy.toString());
          }

          if (filtersData.filterAcceptingNewPatients) {
            vitalsSearchRequestbyProfessional.setAcceptingNewPatients(filtersData.filterAcceptingNewPatients.toString());
          }

          if (filtersData.filterInNetwork) {
            vitalsSearchRequestbyProfessional.setInNetwork(filtersData.filterInNetwork.toString());
          }

          if (filtersData.filterGender) {
            vitalsSearchRequestbyProfessional.setProfessionalGender(filtersData.filterGender.toString());
          }

          if (filtersData.filterLanguage) {
            vitalsSearchRequestbyProfessional.setProfessionalLanguages(filtersData.filterLanguage.toString());
          }

          if (filtersData.filterRating) {
            vitalsSearchRequestbyProfessional.setAggregateOverallRating(filtersData.filterRating.toString());
          }

          if (filtersData.filterAges) {
            vitalsSearchRequestbyProfessional.setAgestreatedTypeCode(filtersData.filterAges.toString());
          }

          if (filtersData.filterDisorders) {
            vitalsSearchRequestbyProfessional.setDisorderTreatedTypeCode(filtersData.filterDisorders.toString());
          }

          if (filtersData.filterTreatment) {
            vitalsSearchRequestbyProfessional.setTreatmentMethodsTypeCode(filtersData.filterTreatment.toString());
          }

          if (filtersData.filterSpecialities) {
            vitalsSearchRequestbyProfessional.setSearchSpecialtyId(filtersData.filterSpecialities.toString());
          }

          if (filtersData.filterLocation) {
            vitalsSearchRequestbyProfessional.setRadius(Number(filtersData.filterLocation.toString()));
            //   if(Number(filtersData.filterLocation.toString()))
            //   sessionStorage.setItem('radius',filtersData.filterLocation.value);
            //   else
            //   sessionStorage.setItem('radius',null);
          }
          if (filtersData.filterBcd) {
            vitalsSearchRequestbyProfessional.setBcdTypeCodes(filtersData.filterBcd.toString());
          }
          if (filtersData.filterCqms) {
            vitalsSearchRequestbyProfessional.setCqms(filtersData.filterCqms.toString());
          }
          if (filtersData.filterisChoicePcp) {
            vitalsSearchRequestbyProfessional.setIsChoicePcp(filtersData.filterisChoicePcp.toString());
          }
          if (filtersData.filterTiers) {
            vitalsSearchRequestbyProfessional.setTiers(filtersData.filterTiers.toString());
          }
          if (filtersData.filterAwards) {
            vitalsSearchRequestbyProfessional.setAwardsTypeCodes(filtersData.filterAwards.toString());
          }
          if (filtersData.filterHospitalAffilation) {
            vitalsSearchRequestbyProfessional.setHospitalAffiliationId(filtersData.filterHospitalAffilation.toString());
          }
          if (filtersData.filterGroupAffilation) {
            vitalsSearchRequestbyProfessional.setGroupAffiliationId(filtersData.filterGroupAffilation.toString());
          }
        }

        if (Object.keys(sortData).length > 0) {
          this.isFilterChanged = true;
          vitalsSearchRequestbyProfessional.setSort(sortData.toString());
        }
        if (Object.keys(filtersData).length === 0 && Object.keys(sortData).length === 0) {
          this.isFilterChanged = false;
        }
      }
      // End applying Sorting & filters //
      const skipNoResultsValidationFlag = true;
      this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).subscribe(
        data => {
          this.isDisplaySpinnerProfessional = false;
          if (data.totalCount >= 0) {
            this.updateProfessionalsDataToView(data, skipNoResultsValidationFlag, scroll);
            this.cdRef.detectChanges();
          }
        },
        error => {
          this.isDisplaySpinnerProfessional = false;

          this.isNoSearchResults = !skipNoResultsValidationFlag && true;
          this.cdRef.detectChanges();
        }
      );
    } catch (exception) {}
  }

  private updateProfessionalsDataToView(
    data: GetSearchByProfessionalResponseModelInterface,
    skipNoResultsValidationFlag?: boolean,
    scroll?: boolean
  ) {
    this.fadService.clearServiceAlert(FAD_CONSTANTS.components.fadSearchResultsComponent);

    if ((data && data.professionals && data.professionals.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
        console.log('disclaimer top list ', this.disclaimerToplist);
      }
      // this.isNoSearchResults = false;

      if (!scroll) {
        this.fadSearchResultsService.searchResultCache = data;
        this.fadSearchResultsService.filterChanged = this.isFilterChanged;
        this.specialtyEmailFlag = false;
        this.professionalEmailFlag = true;
        this.facilityEmailFlag = false;
        let hasData = false;
        if (
          this.searchListComponentInput &&
          this.searchListComponentInput.searchResults &&
          this.searchListComponentInput.searchResults.professionals
        ) {
          for (let i = 0; i <= this.searchListComponentInput.searchResults.professionals.length - 1; i++) {
            if (this.searchListComponentInput.searchResults.professionals[i].isChecked) {
              hasData = true;
              break;
            }
          }
        }
        if (hasData) {
          this.searchListComponentInput = this.searchListComponentInput;
        } else {
          this.searchListComponentInput = new FadSearchListComponentInputModel();
          this.searchListComponentInput.searchResults = data;
        }
      } else {
        this.searchListComponentInput = {
          ...this.searchListComponentInput,
          searchResults: {
            ...this.searchListComponentInput.searchResults,
            professionals: this.searchListComponentInput.searchResults.professionals.concat(data.professionals)
          }
        };
      }
      this.isLoadMoreEnabled = !(this.totalCount === this.searchListComponentInput.searchResults.professionals.length);
      this.fadProviderCompareService.setSearchResult(this.searchListComponentInput.searchResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
      }
      this.searchListComponentInput = new FadSearchListComponentInputModel();
      this.searchListComponentInput.searchResults = data;
      this.fadProviderCompareService.setSearchResult(this.searchListComponentInput.searchResults);

      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FAD_CONSTANTS.components.fadSearchResultsComponent);
      }
    }

    // *** Need this call to set the infinite scroll event to complete and then invoke it again.
    if (this.has(this.scrollEvent, 'target.complete')) {
      this.scrollEvent.target.complete();
    }
  }

  /**
   * @description helps obtain search results based on input parameters
   *  The method gets from ngOnInit event or through search button click on landing page component in abstract mode
   * @param request : FadLandingPageSearchControlValuesInterface - search parameters
   */
  private getFadFacilitySearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchByFacilityResponseModelInterface,
    filtersData?: FacilityFiltersMetadataInterface,
    sortData?: SortMetadataInterface
  ): void {
    sessionStorage.setItem('radius', null);
    // PLEASE NOTE
    // THIS METHOD DOES NOT USE THE INPUT REQUEST YET
    // BUT THE SAME WILL BE USED ONCE ALL THE GET REQUESTS ARE CONVERTED INTO POST REQUESTS
    // PLEASE DONOT DELETE THE INPUT PARAMETER request: FadLandingPageSearchControlValuesInterface
    try {
      if (resolvedData) {
        // this.updateFacilityDataToView(Object.assign(
        //   Object.create(new GetSearchByFacilityResponseModel()), resolvedData,scroll));
        this.updateFacilityDataToView(resolvedData, false, scroll);
        return;
      }

      this.isDisplaySpinner = scroll;
      if (!scroll) {
        this.infiniteScrollIndexCache = 0;
      }

      const vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface = new GetSearchByFacilityRequestModel();
      vitalsSearchRequestbyFacility
        .setGeoLocation(request.getZipCode().geo)
        .setLimit(FAD_CONSTANTS.defaults.limit)
        .setPage(++this.infiniteScrollIndexCache)
        // tslint:disable-next-line:no-magic-numbers
        .setRadius(25)
        .setNetworkId(
          request.getPlanName && request.getPlanName().getNetworkId()
            ? request.getPlanName().getNetworkId()
            : FAD_CONSTANTS.defaults.networkId
        );

      if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
        vitalsSearchRequestbyFacility.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
      } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
        vitalsSearchRequestbyFacility.setProcedureId(request.getSearchText().getProcedureId());
      } else {
        vitalsSearchRequestbyFacility.setName(this.fadSearchResultsService.getFilteredSearchName(request));
      }

      // Start applying Sorting & filters //
      if (filtersData) {
        if (Object.keys(filtersData).length > 0) {
          this.isFilterChanged = true;
          // if(this.fadFacilityListService.isFilterChangedFlag == true)
          // this.clearSelectedResults();
          // this.clearSelectedResults();
          // this.isFilter = true;
          if (filtersData.filterInNetwork) {
            // vitalsSearchRequestbyFacility.setInNetwork(filtersData.filterInNetwork.value);
          }

          if (filtersData.filterLocation) {
            vitalsSearchRequestbyFacility.setRadius(Number(filtersData.filterLocation.toString()));
            // if(Number(filtersData.filterLocation.value))
            // sessionStorage.setItem('radius',filtersData.filterLocation.value);
            // else
            // sessionStorage.setItem('radius',null);
          }

          if (filtersData.filterRating) {
            vitalsSearchRequestbyFacility.setAggregateOverallRating(filtersData.filterRating.toString());
          }

          if (filtersData.filterSpecialities) {
            vitalsSearchRequestbyFacility.setSearchSpecialtyId(filtersData.filterSpecialities.toString());
          }

          if (filtersData.filterBDC) {
            vitalsSearchRequestbyFacility.setBdcId(filtersData.filterBDC.toString());
          }

          if (filtersData.filterAward) {
            vitalsSearchRequestbyFacility.setAwardId(filtersData.filterAward.toString());
          }

          if (filtersData.filterCQMS) {
            vitalsSearchRequestbyFacility.setCqmId(filtersData.filterCQMS.toString());
          }
          if (filtersData.filterTiers) {
            vitalsSearchRequestbyFacility.setTiers(filtersData.filterTiers.toString());
          }
        }

        if (Object.keys(sortData).length > 0) {
          this.isFilterChanged = true;
          vitalsSearchRequestbyFacility.setSort(sortData.toString());
        }

        if (Object.keys(filtersData).length === 0 && Object.keys(sortData).length === 0) {
          this.isFilterChanged = false;
        }
      }

      const skipNoResultsValidationFlag = true;
      this.fadSearchResultsService.getFadFacilitySearchResults(vitalsSearchRequestbyFacility).subscribe(
        data => {
          this.isDisplaySpinner = false;
          this.updateFacilityDataToView(data as GetSearchByFacilityResponseModelInterface, scroll, skipNoResultsValidationFlag);

          this.cdRef.detectChanges();
        },
        error => {
          this.isDisplaySpinner = false;

          this.isNoSearchResults = !skipNoResultsValidationFlag && true;
          this.cdRef.detectChanges();
        }
      );
    } catch (exception) {}
  }

  private updateFacilityDataToView(
    data: GetSearchByFacilityResponseModelInterface,
    scroll?: boolean,
    skipNoResultsValidationFlag?: boolean
  ) {
    this.fadService.clearServiceAlert(FAD_CONSTANTS.components.fadSearchResultsComponent);

    if ((data && data.facilities && data.facilities.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      this.isNoSearchResults = !skipNoResultsValidationFlag && false;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
      }
      if (!scroll) {
        this.fadSearchResultsService.facilityResultCache = data;
        this.fadSearchResultsService.filterChanged = this.isFilterChanged;
        this.specialtyEmailFlag = false;
        this.professionalEmailFlag = false;
        this.facilityEmailFlag = true;
        let hasData = false;
        if (
          this.facilityListComponentInput &&
          this.facilityListComponentInput.facilityResults &&
          this.facilityListComponentInput.facilityResults.facilities
        ) {
          for (let i = 0; i <= this.facilityListComponentInput.facilityResults.facilities.length - 1; i++) {
            if (this.facilityListComponentInput.facilityResults.facilities[i].isChecked) {
              hasData = true;
              break;
            }
          }
        }
        if (hasData) {
          this.facilityListComponentInput = this.facilityListComponentInput;
        } else {
          this.facilityListComponentInput = new FadFacilityListComponentInputModel();
          this.facilityListComponentInput.facilityResults = data;
        }
      } else {
        // data.facilities.map(facilityRecord => {
        //   this.facilityListComponentInput.facilityResults.facilities.push(facilityRecord);
        // });
        this.facilityListComponentInput = {
          ...this.facilityListComponentInput,
          facilityResults: {
            ...this.facilityListComponentInput.facilityResults,
            facilities: this.facilityListComponentInput.facilityResults.facilities.concat(data.facilities)
          }
        };
      }
      this.isLoadMoreEnabled = !(this.totalCount === this.facilityListComponentInput.facilityResults.facilities.length);
      // this.fadProviderCompareService.setSearchResult(this.facilityListComponentInput.facilityResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;

      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
      }
      this.facilityListComponentInput = new FadFacilityListComponentInputModel();
      this.facilityListComponentInput.facilityResults = data;
      // this.fadProviderCompareService.setSearchResult(this.facilityListComponentInput.facilityResults);

      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FAD_CONSTANTS.components.fadSearchResultsComponent);
      }
    }

    // *** Need this call to set the infinite scroll event to complete and then invoke it again.
    if (this.has(this.scrollEvent, 'target.complete')) {
      this.scrollEvent.target.complete();
    }
  }

  private getFadSpecialtySearchResults(
    request: FadLandingPageSearchControlValuesInterface,
    scroll: boolean = false,
    resolvedData?: GetSearchBySpecialtyResponseModelInterface,
    filtersData?: FiltersMetadataInterface,
    sortData?: SortMetadataInterface,
    fromOnInit = false
  ): void {
    sessionStorage.setItem('radius', null);

    if (resolvedData) {
      // tslint:disable-next-line:prefer-conditional-expression
      if (resolvedData.sort === 'distance+asc') {
        this.isProcedureFlag = false;
      } else {
        this.isProcedureFlag = true;
      }
      this.updateSpecialtyDataToView(resolvedData, false, scroll, fromOnInit);
      return;
    }

    this.isDisplaySpinnerProfessional = scroll;
    const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
    if (!scroll) {
      this.infiniteScrollIndexCache = 0;
    }

    vitalsSearchRequestbySpeciality
      .setGeoLocation(request.getZipCode().geo)
      .setLimit(FAD_CONSTANTS.defaults.limit)
      .setPage(++this.infiniteScrollIndexCache)
      // tslint:disable-next-line:no-magic-numbers
      .setRadius(25)
      .setNetworkId(
        request.getPlanName && request.getPlanName().getNetworkId()
          ? request.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId
      );

    if (!request.getSearchText().isProcedure() && request.getSearchText().getSpecialityId()) {
      vitalsSearchRequestbySpeciality.setSearchSpecialtyId(request.getSearchText().getSpecialityId());
    } else if (request.getSearchText().isProcedure() && request.getSearchText().getProcedureId()) {
      vitalsSearchRequestbySpeciality.setProcedureId(request.getSearchText().getProcedureId());
      this.isProcedureFlag = true;
      vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
    } else {
      vitalsSearchRequestbySpeciality.setName(this.fadSearchResultsService.getFilteredSearchName(request));
      this.isProcedureFlag = false;
    }

    // Start applying Sorting & filters //
    if (filtersData) {
      if (Object.keys(filtersData).length > 0) {
        this.isFilterChanged = true;
        if (filtersData.filterPCP) {
          vitalsSearchRequestbySpeciality.setisPcp(filtersData.filterPCP.toString());
        }

        if (filtersData.filterTechSavvy) {
          vitalsSearchRequestbySpeciality.setTechSavvy(filtersData.filterTechSavvy.toString());
        }
        if (filtersData.filterisChoicePcp) {
          vitalsSearchRequestbySpeciality.setIsChoicePcp(filtersData.filterisChoicePcp.toString());
        }
        if (filtersData.filterAcceptingNewPatients) {
          vitalsSearchRequestbySpeciality.setAcceptingNewPatients(filtersData.filterAcceptingNewPatients.toString());
        }

        if (filtersData.filterInNetwork) {
          vitalsSearchRequestbySpeciality.setInNetwork(filtersData.filterInNetwork.toString());
        }

        if (filtersData.filterGender) {
          vitalsSearchRequestbySpeciality.setProfessionalGender(filtersData.filterGender.toString());
        }

        if (filtersData.filterProviderType) {
          vitalsSearchRequestbySpeciality.setproviderType(filtersData.filterProviderType.toString());
        }

        if (filtersData.filterLanguage) {
          vitalsSearchRequestbySpeciality.setProfessionalLanguages(filtersData.filterLanguage.toString());
        }

        if (filtersData.filterRating) {
          vitalsSearchRequestbySpeciality.setAggregateOverallRating(filtersData.filterRating.toString());
        }

        if (filtersData.filterAges) {
          vitalsSearchRequestbySpeciality.setAgestreatedTypeCode(filtersData.filterAges.toString());
        }

        if (filtersData.filterDisorders) {
          vitalsSearchRequestbySpeciality.setDisorderTreatedTypeCode(filtersData.filterDisorders.toString());
        }

        if (filtersData.filterTreatment) {
          vitalsSearchRequestbySpeciality.setTreatmentMethodsTypeCode(filtersData.filterTreatment.toString());
        }

        if (filtersData.filterSpecialities) {
          vitalsSearchRequestbySpeciality.setSearchSpecialtyId(filtersData.filterSpecialities.toString());
        }

        if (filtersData.filterLocation) {
          vitalsSearchRequestbySpeciality.setRadius(Number(filtersData.filterLocation.toString()));
        }
        if (filtersData.filterBcd) {
          vitalsSearchRequestbySpeciality.setBcdTypeCodes(filtersData.filterBcd.toString());
        }
        if (filtersData.filterCqms) {
          vitalsSearchRequestbySpeciality.setCqms(filtersData.filterCqms.toString());
        }

        if (filtersData.filterTiers) {
          vitalsSearchRequestbySpeciality.setTiers(filtersData.filterTiers.toString());
        }
        if (filtersData.filterAwards) {
          vitalsSearchRequestbySpeciality.setAwardsTypeCodes(filtersData.filterAwards.toString());
        }
        if (filtersData.filterHospitalAffilation) {
          vitalsSearchRequestbySpeciality.setHospitalAffiliationId(filtersData.filterHospitalAffilation.toString());
        }
        if (filtersData.filterGroupAffilation) {
          vitalsSearchRequestbySpeciality.setGroupAffiliationId(filtersData.filterGroupAffilation.toString());
        }
      }
      if (sortData) {
        if (Object.keys(sortData).length > 0) {
          this.isFilterChanged = true;
          vitalsSearchRequestbySpeciality.setSort(sortData.toString());
        }

        if (Object.keys(filtersData).length === 0 && Object.keys(sortData).length === 0) {
          this.isFilterChanged = false;
        }
      }
    }

    const skipNoResultsValidationFlag = true;

    this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).subscribe(
      data => {
        this.isDisplaySpinnerProfessional = false;
        this.updateSpecialtyDataToView(data, skipNoResultsValidationFlag, scroll);
        this.cdRef.detectChanges();
      },
      error => {
        this.isDisplaySpinnerProfessional = false;
        this.isNoSearchResults = !skipNoResultsValidationFlag && true;
        this.cdRef.detectChanges();
      }
    );
  }

  private updateSpecialtyDataToView(
    data: GetSearchBySpecialtyResponseModelInterface,
    skipNoResultsValidationFlag?: boolean,
    scroll?: boolean,
    fromOnInit: boolean = false
  ) {
    this.fadService.clearServiceAlert(FAD_CONSTANTS.components.fadSearchResultsComponent);

    if ((data && data.providers && data.providers.length > 0) || (data.facets && !_isEmpty(data.facets))) {
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerTopResults = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBcbsTopResults;
          });

          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
      }

      if (!scroll) {
        this.fadSearchResultsService.specialtyResultCache = data;
        this.fadSearchResultsService.filterChanged = this.isFilterChanged;
        this.specialtyEmailFlag = true;
        this.professionalEmailFlag = false;
        this.facilityEmailFlag = false;
        let hasData = false;
        if (
          this.specialtyListComponentInput &&
          this.specialtyListComponentInput.specialtyResults &&
          this.specialtyListComponentInput.specialtyResults.providers
        ) {
          for (let i = 0; i <= this.specialtyListComponentInput.specialtyResults.providers.length - 1; i++) {
            if (this.specialtyListComponentInput.specialtyResults.providers[i].isChecked) {
              hasData = true;
              break;
            }
          }
        }
        if (hasData && !fromOnInit) {
          this.specialtyListComponentInput = Object.assign({}, this.specialtyListComponentInput);
        } else {
          this.specialtyListComponentInput = new FadSpecialtyListComponentInputModel();
          this.specialtyListComponentInput.specialtyResults = data;
        }
        if (!this.sortMode) {
          this.sortMode = data.sort;
        }
      } else {
        // data.providers.map(profRecord => {
        //   this.specialtyListComponentInput.specialtyResults.providers.push(profRecord);
        // });
        this.specialtyListComponentInput = {
          ...this.specialtyListComponentInput,
          specialtyResults: {
            ...this.specialtyListComponentInput.specialtyResults,
            providers: this.specialtyListComponentInput.specialtyResults.providers.concat(data.providers)
          }
        };
      }
      this.isLoadMoreEnabled = !(this.totalCount === this.specialtyListComponentInput.specialtyResults.providers.length);

      this.fadProviderCompareService.setSearchResult(this.specialtyListComponentInput.specialtyResults);
    } else {
      this.isNoSearchResults = !skipNoResultsValidationFlag && true;
      this.totalCount = data.totalCount;
      if (data) {
        if (data.costDetails) {
          this.costDetails = data.costDetails;
        }
        if (data.disclaimers && data.disclaimers.length > 0) {
          this.disclaimers = data.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(disclaimers => {
            return disclaimers.category === FAD_CONSTANTS.text.disclaimerBottomList;
          });
          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        } else {
          this.disclaimerTopResults = null;
          this.disclaimerBottomlist = null;
          this.disclaimerToplist = null;
        }
      }
      this.specialtyListComponentInput = new FadSpecialtyListComponentInputModel();
      this.specialtyListComponentInput.specialtyResults = data;
      this.fadProviderCompareService.setSearchResult(this.specialtyListComponentInput.specialtyResults);
      // $('ng4-loading-spinner .spinner').removeClass('visible');
      if (data.result && data.result < 0) {
        this.fadService.setServiceAlert(data['displaymessage'], AlertType.Failure, FAD_CONSTANTS.components.fadSearchResultsComponent);
      }
    }

    // *** Need this call to set the infinite scroll event to complete and then invoke it again.
    if (this.has(this.scrollEvent, 'target.complete')) {
      this.scrollEvent.target.complete();
    }
  }

  /**
   * @description fad-search-list component consumption requirement.
   *  The method gets triggered when filter component produces an output
   * @param fadSeachListComponentOutput : FadSearchListComponentOutputModelInterface
   */
  public onSearchListComponentInteraction(value: any): void {
    try {
      const { fadSeachListComponentOutput, index, isChecked } = value;
      console.log(fadSeachListComponentOutput);
      if (
        fadSeachListComponentOutput &&
        fadSeachListComponentOutput.selectedProfessionals &&
        fadSeachListComponentOutput.selectedProfessionals.length >= 2
      ) {
        this.showCompareResultsButton = true;
        this.selectedResultCount = fadSeachListComponentOutput.selectedProfessionals.length;
        // this.selectedProfessionalResult = fadSeachListComponentOutput;
        // this.compareResults = "Professionals";
        // this.searchListComponentInput.searchResults.professionals[index].isChecked = true;
      } else {
        this.showCompareResultsButton = false;
        this.selectedResultCount = 0;
      }
      if (fadSeachListComponentOutput.selectedProfessionals[fadSeachListComponentOutput.selectedProfessionals.length - 1].doctorName) {
        this.searchListComponentInput.searchResults.professionals[index].isChecked = isChecked;
      } else if (
        fadSeachListComponentOutput.selectedProfessionals[fadSeachListComponentOutput.selectedProfessionals.length - 1].providerName
      ) {
        this.specialtyListComponentInput.specialtyResults.providers[index].isChecked = isChecked;
      } else if (
        fadSeachListComponentOutput.selectedProfessionals[fadSeachListComponentOutput.selectedProfessionals.length - 1].facilityName
      ) {
        this.facilityListComponentInput.facilityResults.facilities[index].isChecked = isChecked;
      }
      // this.searchListComponentInput.searchResults.professionals[index].isChecked = isChecked;
    } catch (exception) {}
  }

  /**
   * @description action associated with search button in landing page in abstract mode
   * @param fadLandingPageCompOutputInterface : FadLandingPageCompOutputInterface
   */
  public onLandingPageSearchComponentInteraction(fadLandingPageCompOutputInterface: FadLandingPageCompOutputInterface): void {
    try {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      this.resourceTypeCode = searchCriteria.getSearchText().getResourceTypeCode();

      if (searchCriteria.getSearchText().getResourceTypeCode() === FadResouceTypeCodeConfig.professional) {
        this.getFadProfileSearchResults(fadLandingPageCompOutputInterface.searchCriteria, false);
      } else if (searchCriteria.getSearchText().getResourceTypeCode() === FadResouceTypeCodeConfig.facility) {
        this.getFadFacilitySearchResults(fadLandingPageCompOutputInterface.searchCriteria, false);
      } else {
        this.getFadSpecialtySearchResults(fadLandingPageCompOutputInterface.searchCriteria, false, null);
      }
    } catch (exception) {}
  }

  public onClearFilterInteraction(event) {
    console.log(event);
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (event.resourcetype === 'P') {
      if (event.filterCriteriaData || event.sortCriteriaData) {
        this.filterCriteriaData = event.filterCriteriaData;
        this.sortCriteriaData = event.sortCriteriaData;
        this.getFadProfileSearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
      }
    } else if (event.resourcetype === 'F') {
      if (event.filterCriteriaData || event.sortCriteriaData) {
        this.facilityFilterCriteriaData = event.filterCriteriaData;
        this.sortCriteriaData = event.sortCriteriaData;
        this.getFadFacilitySearchResults(searchCriteria, false, null, this.facilityFilterCriteriaData, this.sortCriteriaData);
      }
    } else {
      if (event.filterCriteriaData || event.sortCriteriaData) {
        this.filterCriteriaData = event.filterCriteriaData;
        this.sortCriteriaData = event.sortCriteriaData;
        this.getFadSpecialtySearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
      }
    }
  }

  public onSearchFilterComponentInteraction(fadSearchFilterComponentOutput: FadSearchFilterComponentOutputModelInterface): void {
    // toggle filter section display as necessary
    this.mobileHideByFilterOverlay = fadSearchFilterComponentOutput.filterOverlayFlag;
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadSearchFilterComponentOutput.filterCriteriaData || fadSearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.filterCriteriaData = fadSearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadSearchFilterComponentOutput.sortCriteriaData;
      this.getFadProfileSearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  public onFacilitySearchFilterComponentInteraction(
    fadFacilitySearchFilterComponentOutput: FadFacilitySearchFilterComponentOutputModelInterface
  ): void {
    this.mobileHideByFilterOverlay = fadFacilitySearchFilterComponentOutput.filterOverlayFlag;

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadFacilitySearchFilterComponentOutput.filterCriteriaData || fadFacilitySearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.facilityFilterCriteriaData = fadFacilitySearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadFacilitySearchFilterComponentOutput.sortCriteriaData;
      this.getFadFacilitySearchResults(searchCriteria, false, null, this.facilityFilterCriteriaData, this.sortCriteriaData);
    }
  }

  public onSpecialtySearchFilterComponentInteraction(
    fadSpecialtySearchFilterComponentOutput: FadSpecialtyFilterComponentOutputModelInterface
  ): void {
    console.log(fadSpecialtySearchFilterComponentOutput, 'check here');
    // toggle filter section display as necessary
    this.mobileHideByFilterOverlay = fadSpecialtySearchFilterComponentOutput.filterOverlayFlag;

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      !this.mobileHideByFilterOverlay &&
      (fadSpecialtySearchFilterComponentOutput.filterCriteriaData || fadSpecialtySearchFilterComponentOutput.sortCriteriaData)
    ) {
      this.filterCriteriaData = fadSpecialtySearchFilterComponentOutput.filterCriteriaData;
      this.sortCriteriaData = fadSpecialtySearchFilterComponentOutput.sortCriteriaData;
      this.getFadSpecialtySearchResults(searchCriteria, false, null, this.filterCriteriaData, this.sortCriteriaData);
    }
  }

  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  public isAnonymousUser() {
    return !(this.useridin && this.useridin !== 'undefined' && this.useridin !== 'null');
  }

  public isAuthenticatedUser() {
    const scopeName = this.scopeName;
    return scopeName === 'AUTHENTICATED-AND-VERIFIED';
  }

  public gotoAuthenticate() {
    this.globalService
      .redirectionRoute()
      .then(response => {})
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  public onFacilityScrollDown(event) {
    this.scrollEvent = event;
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      !this.isDisplaySpinner &&
      this.totalCount > this.facilityListComponentInput.facilityResults.facilities.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadFacilitySearchResults(searchCriteria, true, null, this.facilityFilterCriteriaData, this.sortCriteriaData);
    } else {
      console.log('done loading facilities');
      event.target.complete();
      event.target.disabled = true;
    }
  }

  public onProviderScrollDown(event) {
    this.scrollEvent = event;
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    console.log(searchCriteria);
    if (
      searchCriteria &&
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      !this.isDisplaySpinnerProfessional &&
      this.totalCount > this.specialtyListComponentInput.specialtyResults.providers.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadSpecialtySearchResults(searchCriteria, true, null, this.filterCriteriaData, this.sortCriteriaData);
    } else {
      event.target.complete();
      event.target.disabled = true;
    }
  }

  public onProfessionalScrollDown(event) {
    this.scrollEvent = event;
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    if (
      searchCriteria &&
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      !this.isDisplaySpinnerProfessional &&
      this.totalCount > this.searchListComponentInput.searchResults.professionals.length &&
      !this.mobileHideByFilterOverlay
    ) {
      this.getFadProfileSearchResults(searchCriteria, true, null, this.filterCriteriaData, this.sortCriteriaData);
    } else {
      console.log('done loading professionals');
      event.target.complete();
      event.target.disabled = true;
    }
  }

  clearSelectedResults() {
    this.showCompareResultsButton = false;
    this.selectedResultCount = 0;
    if (
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      this.facilityListComponentInput.facilityResults.facilities.length > 0
    ) {
      this.facilityListComponentInput = {
        ...this.facilityListComponentInput,
        facilityResults: {
          ...this.facilityListComponentInput.facilityResults,
          facilities: [
            ...this.facilityListComponentInput.facilityResults.facilities.map(item => ({
              ...item,
              isChecked: false,
              isDisabled: false
            }))
          ]
        }
      };
      this.fadFacilityCompareService.setSearchResult(null);
    }

    if (
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      this.searchListComponentInput.searchResults.professionals.length > 0
    ) {
      this.searchListComponentInput = {
        ...this.searchListComponentInput,
        searchResults: {
          ...this.searchListComponentInput.searchResults,
          professionals: [
            ...this.searchListComponentInput.searchResults.professionals.map(item => ({
              ...item,
              isChecked: false,
              isDisabled: false
            }))
          ]
        }
      };
      this.fadProfessionalCompareService.setSearchResult(null);
    }

    if (
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      this.specialtyListComponentInput.specialtyResults.providers.length > 0
    ) {
      this.specialtyListComponentInput = {
        ...this.specialtyListComponentInput,
        specialtyResults: {
          ...this.specialtyListComponentInput.specialtyResults,
          providers: [
            ...this.specialtyListComponentInput.specialtyResults.providers.map(item => ({
              ...item,
              isChecked: false,
              isDisabled: false
            }))
          ]
        }
      };
      this.fadProviderCompareService.setSearchResult(null);
    }
  }

  compareSelectedResults() {
    // TODO Redirect to the compare results page
    if (
      this.facilityListComponentInput &&
      this.facilityListComponentInput.facilityResults &&
      this.facilityListComponentInput.facilityResults.facilities &&
      this.facilityListComponentInput.facilityResults.facilities.length > 0
    ) {
      const selectedItems = this.facilityListComponentInput.facilityResults.facilities.filter(item => item.isChecked);
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.facilityId : item.facilityId;
        if (item.locations && item.locations[0] && item.locations[0].facilityCost && item.locations[0].facilityCost.memberCost) {
          costInfo[item.facilityId] = item.locations[0].facilityCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadFacilityCompareService.setCostInfo(costInfo);
        this.fadFacilityCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/facility-compare`]);
      }
    }

    if (
      this.searchListComponentInput &&
      this.searchListComponentInput.searchResults &&
      this.searchListComponentInput.searchResults.professionals &&
      this.searchListComponentInput.searchResults.professionals.length > 0
    ) {
      const selectedItems = Object.create(this.searchListComponentInput.searchResults.professionals.filter(item => item.isChecked));
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.providerId : item.providerId;
        if (item.locations && item.locations[0] && item.locations[0].memberCost && item.locations[0].memberCost.memberCost) {
          costInfo[item.providerId] = item.locations[0].memberCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadProviderCompareService.setCostInfo(costInfo);
        this.fadProviderCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/professional-compare`]);
      }
    }

    if (
      this.specialtyListComponentInput &&
      this.specialtyListComponentInput.specialtyResults &&
      this.specialtyListComponentInput.specialtyResults.providers &&
      this.specialtyListComponentInput.specialtyResults.providers.length > 0
    ) {
      const selectedItems = this.specialtyListComponentInput.specialtyResults.providers.filter(item => item.isChecked);
      let selectedIds = '';
      const costInfo = {};
      for (const item of selectedItems) {
        selectedIds = selectedIds ? selectedIds + ',' + item.providerId : item.providerId;
        if (item.locations && item.locations[0] && item.locations[0].providerCost && item.locations[0].providerCost.memberCost) {
          costInfo[item.providerId] = item.locations[0].providerCost.memberCost;
        }
      }
      if (selectedIds) {
        this.fadFacilityCompareService.setCostInfo(costInfo);
        this.fadFacilityCompareService.setCompareStirng(selectedIds);
        this.router.navigate([`/fad/provider-compare`]);
      }
    }
  }

  gotoMedicalGroup() {
    this.router.navigate([this.fadConstants.urls.fadFacilityProfilePage]);
  }

  async handleProfessionalFilter(ev) {
    let popover: HTMLIonPopoverElement;
    popover = await this.popoverController.create({
      component: FadSearchFilterComponent,
      event: ev,
      cssClass: 'my-claims-filter',
      translucent: true,
      mode: 'ios',
      componentProps: {
        searchListComponentInput: this.searchListComponentInput,
        filterMetaData: this.filterMetaData,
        isFilterChanged: this.isFilterChanged
      }
    });
    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        this.filterMetaData = dataReturned.data.filterCriteriaData;
        this.onSearchFilterComponentInteraction(dataReturned.data);
      }
    });

    return await popover.present();
  }
  async handleFacilityFilter(ev) {
    let popover: HTMLIonPopoverElement;
    popover = await this.popoverController.create({
      component: FadFacilitySearchFilterComponent,
      event: ev,
      cssClass: 'my-claims-filter',
      translucent: true,
      mode: 'ios',
      componentProps: {
        facilityListComponentInput: this.facilityListComponentInput,
        filterMetaData: this.filterMetaData,
        isFilterChanged: this.isFilterChanged
      }
    });
    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        this.filterMetaData = dataReturned.data.filterCriteriaData;
        this.onFacilitySearchFilterComponentInteraction(dataReturned.data);
      }
    });

    return await popover.present();
  }
  async handleSpecialtyFilter(ev) {
    let popover: HTMLIonPopoverElement;
    popover = await this.popoverController.create({
      component: FadSpecialtySearchFilterComponent,
      event: ev,
      cssClass: 'my-claims-filter',
      translucent: true,
      mode: 'ios',
      componentProps: {
        specialtyListComponentInput: this.specialtyListComponentInput,
        sortMode: this.sortMode,
        filterMetaData: this.filterMetaData,
        isFilterChanged: this.isFilterChanged,
        isProcedureFlag: this.isProcedureFlag
      }
    });
    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        console.log('Filter settings 1: ', dataReturned);
        this.filterMetaData = dataReturned.data.filterCriteriaData;
        this.onSpecialtySearchFilterComponentInteraction(dataReturned.data);
      }
    });

    return await popover.present();
  }

  expandContent(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
  }
  // tslint:disable-next-line:max-file-line-count
}
