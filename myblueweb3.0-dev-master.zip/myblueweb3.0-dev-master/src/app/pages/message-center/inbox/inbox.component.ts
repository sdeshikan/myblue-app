import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { ConstantsService } from '../../../shared/shared.module';
import { AuthService } from '../../registration/registration.module';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  public unreadMsgCount: number;
  public breadCrumbs: BreadCrumb[];
  fpoTargetUrl: string = this.constants.drupalTestUrl + '/page/myinbox-landingscreen';
  fpoPreferenceUrl: string;
  preferenceObject: any;
  // showPreferenceModal: boolean = false;
  isMedicare: boolean = false;
  selectedFilterId: string;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public headerService: HeaderService,
    private router: Router,
    private profileService: ProfileService,
    private constants: ConstantsService,
    public authService: AuthService
  ) {
    this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/promo-block/preference-center';
    this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
    this.isMedicare = this.authService.authToken.userType
      ? this.authService.authToken.userType.toLowerCase() === 'medicare'
        ? true
        : false
      : false;
  }

  ngOnInit() {
    //Show paperless promo
    setTimeout(() => {
      this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
      if (this.preferenceObject.Preferences) {
        this.preferenceObject.Preferences.map(item => {
          if (item.PreferenceType == '1') {
            this.selectedFilterId = item.FilterID;
          }
        });
        if (this.selectedFilterId === 'DOCS_PLAN_MAIL') {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
        } else {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/home-promoblock2';
        }
      } else {
        this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
      }
      this.profileService.preferencePromo(this.fpoPreferenceUrl);
    }, 200);

    this.initBreadcrumbs();
  }

  initBreadcrumbs() {
    this.breadCrumbs = [
      {
        label: 'Home',
        url: ['/home']
      },
      {
        label: 'My Inbox',
        url: ['/message-center']
      }
    ];
  }

  goToDocumentsHome() {
    this.router.navigate(['/message-center/documents/home']);
  }

  public openComponent(targetComponent: string): void {
    try {
      switch (targetComponent) {
        case 'messages':
          this.router.navigate([`/message-center/messages`]);
          break;
        case 'chats':
          break;
        default:
          break;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.messageCenterModule,
        MessageCenterConstants.components.inboxComponent,
        MessageCenterConstants.methods.openComponent
      );
    }
  }
}
