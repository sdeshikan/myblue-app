import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AuthToken } from '../../../models/auth-token.model';
import { PostLoginModel } from '../../../models/post-login.model';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getUserID) useridin: AuthToken;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  // @SelectSnapshot(AppSelectors.getPreferences) preferences: any;

  public unreadMsgCount: number;
  fpoTargetUrl = `${this.constants.drupalTestUrl}/page/myinbox-landingscreen`;
  showPreference = false;

  constructor(
    public headerService: HeaderService,
    private router: Router,
    private constants: ConstantsService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private profileService: ProfileService
  ) {
    const hasAltAdd = this.postLoginInfo && this.postLoginInfo.repPayeeFalg.toLowerCase() === 'false'
    const isMedicare = this.authToken.userType && this.authToken.userType.toLowerCase() === 'medicare'
    this.showPreference = !hasAltAdd ? false : (isMedicare ? false : true)
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox);    
  }

  ionViewWillEnter() {
    // this.profileService.setPreferencePromo(this.preferences);
    //Show paperless promo
    if(this.showPreference){
      this.profileService.swapPromo(this.useridin);
    } 
  }

  goToDocumentsHome() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments);
    this.router.navigate(['/tabs/myInbox/documents/home']);
  }

  goToNotificationsAlerts() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewNotificationsAlerts);
    this.router.navigate(['/tabs/myInbox/notifications-alerts']);
  }

  public openComponent(targetComponent: string): void {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewMessage);

      switch (targetComponent) {
        case 'messages':
          this.router.navigate([`/tabs/myInbox/messages`]);
          break;
        case 'chats':
          break;
        default:
          break;
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }
}
