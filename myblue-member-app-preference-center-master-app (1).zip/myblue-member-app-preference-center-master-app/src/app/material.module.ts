import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatCalendar,
  MatDatepickerModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatInputModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule
} from '@angular/material';

@NgModule({
  imports: [
    MatButtonModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatRadioModule,
    MatListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule
  ],
  exports: [
    MatButtonModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatRadioModule,
    MatListModule,
    MatDatepickerModule,
    MatCalendar,
    MatNativeDateModule,
    MatInputModule
  ]
})
export class MaterialModule {}
