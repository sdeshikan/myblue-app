import { TestBed } from '@angular/core/testing';

import { FitnessService } from './fitness.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';

describe('FitnessService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [AuthHttp, AuthService, ConstantsService]
    })
  );

  it('should be created', () => {
    const service: FitnessService = TestBed.get(FitnessService);
    expect(service).toBeTruthy();
  });
});
