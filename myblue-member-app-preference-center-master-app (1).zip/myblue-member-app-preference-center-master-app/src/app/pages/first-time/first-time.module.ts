import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { AlertsModule } from '../../shared/alerts/alerts.module';
import { FirstTimePage } from './first-time.page.component';

const routes: Routes = [
  {
    path: '',
    component: FirstTimePage
  }
];

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule.forChild(routes), AlertsModule],
  exports: [FirstTimePage],
  declarations: [FirstTimePage]
})
export class FirstTimeModule {}
