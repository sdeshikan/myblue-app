import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { TaxFormService } from './tax-forms-view.service';
import { TaxFileModel } from './tax-forms.model';

@Component({
  selector: 'app-tax-forms-view',
  templateUrl: './tax-forms-view.component.html',
  styleUrls: ['./tax-forms-view.component.scss']
})
export class TaxFormsviewComponent implements OnInit {

  public parentFolderName: string;
  public breadCrumbs: BreadCrumb[] = [];
  fileData: TaxFileModel;
  year: string;

  constructor(private router: Router,
    private taxFormService: TaxFormService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.queryParams
      .filter(params => params.year)
      .subscribe(params => {
        this.year = params.year;
      });
    this.taxFormService.getTaxForms(this.year).subscribe((taxFileModel: TaxFileModel) => {
      this.fileData = taxFileModel;
    });
    this.prepareChildBreadCrumbs(this.router.url.split('/')[this.router.url.split('/').length - 1]);
  }

  openFile(index: number) {
    const file = this.fileData.formData[index].file;
    const byteCharacters = atob(this.hexToBase64(file));
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob1 = new Blob([byteArray], { type: 'application/pdf' });
    const fileName1 = 'certificate.pdf';
    this.saveAs(blob1, fileName1);
  }

  hexToBase64(hexstring) {
    return btoa(hexstring.match(/\w{2}/g).map(function (a) {
      return String.fromCharCode(parseInt(a, 16));
    }).join(''));
  }

  saveAs(blob, fileName) {
    const url = window.URL.createObjectURL(blob)
    const anchorElem = document.createElement('a');
    this.setAttributes(anchorElem, { 'href': url, 'download': fileName });
    anchorElem.click();
    URL.revokeObjectURL(anchorElem.href);
    setTimeout(function () {
      window.URL.revokeObjectURL(url);
    }, 1000);
  }

  setAttributes(el, attrs) {
    Object.keys(attrs).forEach(key => el.setAttribute(key, attrs[key]));
  }

  prepareChildBreadCrumbs(folderId) {
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
    });
    this.breadCrumbs.push({
      label: 'My Inbox',
      url: ['/message-center']
    });
    this.breadCrumbs.push({
      label: 'My Documents',
      url: ['/message-center/documents/home']
    });
    this.breadCrumbs.push({
      label: 'Tax Forms',
      url: ['/message-center/documents/tax-forms']
    });
    this.breadCrumbs.push({
      label: 'Details',
      url: ['/message-center/documents/tax-forms/details']
    });
  }

}


