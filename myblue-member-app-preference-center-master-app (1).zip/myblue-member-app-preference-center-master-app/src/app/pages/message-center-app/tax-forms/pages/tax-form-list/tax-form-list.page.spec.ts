import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { TaxFormListPage } from './tax-form-list.page';

describe('TaxFormListPage', () => {
  let component: TaxFormListPage;
  let fixture: ComponentFixture<TaxFormListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TaxFormListPage],
      imports: [RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxFormListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  describe('Check Template element items count based on yeas', () => {
    it('ion item child element count', () => {
      const element = document.querySelector('ion-item');
      expect(element.childElementCount).toEqual(1);
    });

    it('ion list child element count', () => {
      const element = document.querySelector('ion-list');
      expect(element.childElementCount).toEqual(2);
    });
  });

  describe('Check last two years from current year', () => {
    it('Check current year minus 1', () => {
      const element = document.querySelectorAll('.m-r-5')[0];
      const year = (new Date().getFullYear() - 1).toString();
      expect(element.innerHTML).toEqual(year);
    });
    it('Check current year minus 2', () => {
      const element = document.querySelectorAll('.m-r-5')[1];
      const year = (new Date().getFullYear() - 2).toString();
      expect(element.innerHTML).toEqual(year);
    });
  });

  describe('Check years and default values', () =>{
    it('Identify the title Text', () => {
      const element = document.querySelector('ion-title');
      expect(element.innerHTML).toEqual('Tax Forms');
    });
  
    it('get Default Years', () => {
      const taxYears = component.taxYears;
      const years = [new Date().getFullYear() - 1, new Date().getFullYear() - 2];
      expect(taxYears).toEqual(years);
    });
  
    it('get Years count', () => {
      component.ngOnInit();
      const taxYears = component.taxYears;
      expect(taxYears.length).toEqual(2);
    });
  
    it('get Current Year', () => {
      component.ngOnInit();
      const currentYear = component.currentYear;
      expect(currentYear).toEqual(new Date().getFullYear());
    });
  });
});
