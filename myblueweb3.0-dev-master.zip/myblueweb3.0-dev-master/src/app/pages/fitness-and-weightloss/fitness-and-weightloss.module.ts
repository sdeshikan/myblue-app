import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FitnessFormComponent } from './fitness-form/fitness-form.component';
import { WeightlossFormComponent } from './weightloss-form/weightloss-form.component';
import { DownloadReimbursementComponent } from './download-reimbursement/download-reimbursement.component';
import { FitnessAndWeightlossRouter } from './fitness-and-weightloss.routing';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { ReimbursementOopsComponent } from './reimbursement-oops/reimbursement-oops.component';
import { NgxMaskModule } from 'ngx-mask';
import { NgxCurrencyModule } from 'ngx-currency';
import { MatProgressBarModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FitnessAndWeightlossRouter,
    ReactiveFormsModule,
    SharedModule,
    NgxMaskModule,
    NgxCurrencyModule,
    MatProgressBarModule
  ],
  declarations: [
    FitnessFormComponent,
    WeightlossFormComponent,
    DownloadReimbursementComponent,
    SuccessMessageComponent,
    ReimbursementOopsComponent
  ]
})
export class FitnessAndWeightlossModule {}
