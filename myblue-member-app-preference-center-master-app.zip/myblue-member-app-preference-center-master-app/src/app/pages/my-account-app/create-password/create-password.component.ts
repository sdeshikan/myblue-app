import { Component, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { MyAccountService } from '../my-account.service';

@Component({
  selector: 'app-create-password',
  templateUrl: './create-password.component.html',
  styleUrls: ['./create-password.component.scss']
})
export class CreatePasswordComponent implements OnDestroy {
  createPasswordForm: FormGroup;
  type: string;
  typePlaceholder: string;
  showPasswordErrors = false;
  typeReEnterNew: string;
  typePlaceholderReEnterNew: string;

  passwordcustomMessages = {
    required: 'You must enter a valid password.',
    invalidPassword: 'Your password does not match the minimum requirement. Please try again.',
    confirmPassword: "Password doesn't match "
  };

  constructor(
    private fb: FormBuilder,
    private accountService: MyAccountService,
    private router: Router,
    private alertService: AlertService,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private validationService: ValidationService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.type = 'password';
    this.typePlaceholder = 'Show';

    this.typeReEnterNew = 'password';
    this.typePlaceholderReEnterNew = 'Show';

    this.createPasswordForm = this.fb.group({
      passwordin: '',
      reEnterNewPassword: ''
    });

    this.createPasswordForm.controls['passwordin'].setValidators([
      Validators.required,
      // tslint:disable-next-line:no-magic-numbers
      Validators.minLength(8),
      this.validationService.invalidPasswordValidatorWrapper(),
      this.validationService.checkConfirmPasswordValidator(this.createPasswordForm.controls['reEnterNewPassword'])
    ]);

    this.createPasswordForm.controls['reEnterNewPassword'].setValidators([
      Validators.required,
      // tslint:disable-next-line:no-magic-numbers
      Validators.minLength(8),
      this.validationService.invalidPasswordValidatorWrapper(),
      this.validationService.checkConfirmPasswordValidator(this.createPasswordForm.controls['passwordin'], true)
    ]);

    this.alertService.clearError();
  }

  ngOnDestroy() {
    console.log(
      '-- sendSwrveEventsForIABClicks -- AppScreen_ForgotPassword_CreateNewPassword',
      this.swrveEventNames.AppScreen_ForgotPassword_CreateNewPassword
    );
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ForgotPassword_CreateNewPassword);

    this.alertService.clearError();
  }

  onSubmit() {
    this.accountService.resetPassword(this.createPasswordForm.value).subscribe(res => {
      if (res['result'] !== '0' && res['result'] !== 0) {
        this.createPasswordForm.controls.passwordin.setValue('');
        this.globalService.handleError(res, this.constants.displayMessage);
      } else {
        this.accountService.clearStorage();
        this.router.navigate(['../login']);
      }
    });
  }

  togglePasswordVisibility(confirmPassword?: boolean) {
    if (confirmPassword) {
      if (this.typeReEnterNew === 'text') {
        this.typeReEnterNew = 'password';
        this.typePlaceholderReEnterNew = 'Show';
      } else {
        this.typeReEnterNew = 'text';
        this.typePlaceholderReEnterNew = 'Hide';
      }
    } else {
      if (this.type === 'text') {
        this.type = 'password';
        this.typePlaceholder = 'Show';
      } else {
        this.type = 'text';
        this.typePlaceholder = 'Hide';
      }
    }
  }

  showErrorOnBlur() {
    this.showPasswordErrors = true;
  }
}
