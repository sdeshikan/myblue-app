import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FadFacilityListComponent } from './fad-facility-list.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FadFacilityListService } from './fad-facility-list.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadFacilityCompareService } from '../fad-facility-compare/fad-facility-compare.service';

describe('FadFacilityListComponent', () => {
  let component: FadFacilityListComponent;
  let fixture: ComponentFixture<FadFacilityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadFacilityListComponent],
      providers: [
        FadFacilityListService,
        BcbsmaHttpService,
        FadSearchResultsService,
        AuthService,
        AuthHttp,
        ConstantsService,
        FadFacilityProfileService,
        FadLandingPageService,
        FadFacilityCompareService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
