import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from '../../../shared/services/auth.service';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { DocumentsService } from './documents.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { ActivatedRoute, Router } from '@angular/router';

import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import {
  GetPlansBenefitsListResponseModelInterface,
  GetPlansBenefitsListPlanItemInterface
} from '../modals/interfaces/get-plans-benefits-list-models.interface';
import { GetBenefitCoverageResponseModelInterface, EocPolicyInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { ConstantsService, AlertService } from '../../../shared/shared.module';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { Location } from '@angular/common';

import { HomePageInfoModel } from '../../landing/landing.model';
import { Platform } from '@ionic/angular';
import { SwrveService, SwrveEventNames } from './../../../shared/services/swrve.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit, OnDestroy {
  public memberInfo: HomePageInfoModel;
  public planBenefitsList: GetPlansBenefitsListResponseModelInterface = null;
  public benefitCoverageDocs: GetBenefitCoverageResponseModelInterface = null;
  public policiesInBenefitCoverage: EocPolicyInterface = null;
  public hasContents: boolean;
  private clearAlertOnDestroy = true;
  title = 'Explanation of Benefits';
  isMedicare = false;

  public no_doc_found_component_mode: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public selectedPlan: GetPlansBenefitsListPlanItemInterface;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public documentsService: DocumentsService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private authService: AuthService,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private profileService: ProfileService
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
    this.no_doc_found_component_mode.mode = MessageCenterConstants.flags.documentsMode;
    this.isMedicare = this.authService.authToken.userType
      ? this.authService.authToken.userType.toLowerCase() === 'medicare'
        ? true
        : false
      : true;
  }

  ngOnInit() {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewDocuments);
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewDocuments_PlanDetailsLists);
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_PlanDetailsLists_BenefitLists);

      const oMemberData = this.route.snapshot.data.memberData;
      console.log(oMemberData);
      if (oMemberData) {
        if (Object.keys(oMemberData).length && 'ROWSET' in oMemberData && 'ROW' in oMemberData.ROWSET) {
          this.memberInfo = oMemberData.ROWSET.ROW;
        }
      }
      const t = sessionStorage.getItem('authToken');
      if (t) {
        const authToken = JSON.parse(t);
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Explanation of Your Dental Benefits';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Your Dental Benefits';
        }
      }

      // console.log('router', this.router.url.split('/')[this.router.url.split('/').length - 1]);

      this.policiesInBenefitCoverage = this.route.snapshot.data.policiesInBenefitCoverage;
      this.planBenefitsList = this.route.snapshot.data.planDocuments;
      this.benefitCoverageDocs = this.route.snapshot.data.benefitCoverageDocs;

      if (this.planBenefitsList && this.planBenefitsList.result && this.planBenefitsList.result < 0) {
        this.alertService.setAlert(this.planBenefitsList.displaymessage, ' ', AlertType.Failure);
      } else {
        if (this.documentsService.getSelectedPlan()) {
          this.selectedPlan = this.documentsService.getSelectedPlan();
        }
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  ionViewWillEnter() {
    this.profileService.setPreferencePromo();
  }

  ngOnDestroy(): void {
    this.planBenefitsList = null;
    this.benefitCoverageDocs = null;
    if (this.clearAlertOnDestroy) {
      this.alertService.clearError();
    }
  }

  public goBack(): void {
    this.location.back();
    // this.router.navigate(['../tabs/myInbox'], {replaceUrl: true});
  }

  planDetailsList() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments_PlanDetailsLists);
    this.router.navigate(['/tabs/myInbox/documents/planDocuments']);
  }

  openBenefitCoverageDocsList(plan: GetPlansBenefitsListPlanItemInterface) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_PlanDetailsLists_BenefitLists);
    this.documentsService.setSelectedPlan(plan);
    this.router.navigate(['/tabs/myInbox/documents/planDocuments/benefitCoverageList']);
  }

  openOverAllPlanInformation(): void {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_BenefitLists_OverallPlanLists);
    this.router.navigate(['/tabs/myInbox/documents/document-overall-view']);
  }

  openBenefitCoverage(policy: EocPolicyInterface) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_BenefitLists_DocumentsLists);
    this.documentsService.setSelectedPolicy(policy);
    this.router.navigate(['/tabs/myInbox/documents/documents-list-view']);
  }

  eobListing() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments_EobLists);

    // this.router.navigate(['../myeobs']);
    this.router.navigate(['/tabs/myInbox/documents/eob']);
  }
}
