import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AuthService } from '../../registration/registration.module';
import { MessageCenterConstants } from '../constants/messageCenter.constants';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  public unreadMsgCount: number;
  public breadCrumbs: BreadCrumb[];
  fpoTargetUrl: string = this.constants.drupalTestUrl + '/page/myinbox-landingscreen';
  fpoPreferenceUrl: string;
  preferenceObject: any;
  // showPreferenceModal: boolean = false;
  isMedicare = false;
  selectedFilterId: string;
  repPayeeFalg;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public headerService: HeaderService,
    private router: Router,
    private profileService: ProfileService,
    private constants: ConstantsService,
    public authService: AuthService) {
    this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
    this.isMedicare = this.authService.authToken.userType ? (this.authService.authToken.userType.toLowerCase() === "medicare" ? true : false) : false;
    this.repPayeeFalg = JSON.parse(sessionStorage.getItem('postLoginInfo')).repPayeeFalg;
    this.repPayeeFalg = (this.repPayeeFalg === 'true' || this.repPayeeFalg === 'unknown');
  }

  ngOnInit() {
    //Show paperless promo
    this.profileService.swapPromo();

    this.initBreadcrumbs();
  }

  initBreadcrumbs() {
    this.breadCrumbs = [
      {
        label: 'Home',
        url: ['/home']
      },
      {
        label: 'My Inbox',
        url: ['/message-center']
      }
    ];
  }

  goToDocumentsHome() {
    this.router.navigate(['/message-center/documents/home']);
  }

  public openComponent(targetComponent: string): void {
    try {
      switch (targetComponent) {
        case 'messages':
          this.router.navigate([`/message-center/messages`]);
          break;
        case 'chats':
          break;
        default:
          break;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.messageCenterModule,
        MessageCenterConstants.components.inboxComponent,
        MessageCenterConstants.methods.openComponent
      );
    }
  }
}
