import { Injectable } from '@angular/core';

import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadProviderCompareService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public compareString = '';

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem('compareDoctor', compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem('doctorCostInfo', JSON.stringify(costInfo));
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('doctorCostInfo');
    if (costInfo) {
      return JSON.parse(costInfo);
    }
    return null;
  }
}
