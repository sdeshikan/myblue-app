import {} from 'jasmine';

import { TestBed, inject } from '@angular/core/testing';

import { FadFacilityProfileService } from './fad-facility-profile.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';

describe('FadFacilityProfileComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadFacilityProfileService, AuthHttp, AuthService, ConstantsService]
    });
  });

  it('should be created', inject([FadFacilityProfileService], (service: FadFacilityProfileService) => {
    expect(service).toBeTruthy();
  }));
});
