import { Component, Input, OnInit } from '@angular/core';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { MessageCenterNoDocsFoundPageModelInterface } from '../modals/interfaces/message-center.interface';
import {
  MessageCenterNoDocumentsFoundPageModel,
  MessageCenterNoMessagesFoundPageModel,
  MessageCenterNoSearchResultsFoundPageModel,
  MessageCenterNoUploadsFoundPageModel,
  NoDocumentsFoundComponentModel
} from '../modals/message-center.modal';

@Component({
  selector: 'app-no-documents-found',
  templateUrl: './no-documents-found.component.html',
  styleUrls: ['./no-documents-found.component.scss']
})
export class NoDocumentsFoundComponent implements OnInit {
  @Input() componentMode: NoDocumentsFoundComponentModel;
  @Input() fpoUrl: string;

  public messageCenterNoDocsFoundPageModel: MessageCenterNoDocsFoundPageModelInterface;
  public noSearchResultsMode = false;

  ngOnInit() {
    if (this.componentMode) {
      if (this.componentMode.mode === MessageCenterConstants.flags.messagesMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoMessagesFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.documentsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoDocumentsFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.uploadsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoUploadsFoundPageModel();
      } else if (this.componentMode.mode === MessageCenterConstants.flags.noSearchResultsMode) {
        this.messageCenterNoDocsFoundPageModel = new MessageCenterNoSearchResultsFoundPageModel();
        this.noSearchResultsMode = true;
      } else {
        throw new Error(MessageCenterConstants.errorMessages.noDocsFound_InvalidComponentModeError);
      }
    }
  }
}
