import {} from 'jasmine';

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadFacilityCompareComponent } from './fad-facility-compare.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { FadFacilityCompareService } from './fad-facility-compare.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { NgxsModule } from '@ngxs/store';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { AlertService } from '../../../shared/services/alert.service';

describe('FadFacilityCompareComponent', () => {
  let component: FadFacilityCompareComponent;
  let fixture: ComponentFixture<FadFacilityCompareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadFacilityCompareComponent, PhonePipe],
      providers: [
        FadFacilityCompareService,
        BcbsmaHttpService,
        AuthHttp,
        AuthService,
        ConstantsService,
        FadSearchListService,
        FadBreadCrumbsService,
        AlertService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCompareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
