import { Component, ViewChild } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { GetBenefitsInfo, GetReimbursementForm, SetReimbursement, SetSelectedBenefit } from '../../../../store/actions/fitness.actions';
import { Observable } from 'rxjs';
import { FitnessSelectors } from '../../../../store/selectors/fitness.selectors';
import { BenefitModel } from '../../models/benefit-model';
import { ReimbursementModel } from '../../models/reimbursement-model';
import { animate, group, state, style, transition, trigger } from '@angular/animations';
import { IonContent } from '@ionic/angular';
import { IabService } from '../../../../shared/services/iab/iab.service';

@Component({
  selector: 'app-fwb',
  templateUrl: './reimbursement-selection.page.html',
  styleUrls: ['./reimbursement-selection.page.scss'],
  animations: [
    trigger('slideInOut', [
      state('in', style({ height: '*', opacity: 0 })),
      transition(':leave', [
        style({ height: '*', opacity: 1 }),
        group([animate(400, style({ height: 0 })), animate('400ms ease-in-out', style({ opacity: '0' }))])
      ]),
      transition(':enter', [
        style({ height: '0', opacity: 0 }),
        group([animate(400, style({ height: '*' })), animate('1000ms ease-in-out', style({ opacity: '1' }))])
      ])
    ])
  ]
})
export class ReimbursementSelectionPage {
  @ViewChild(IonContent) content: IonContent;

  @Select(FitnessSelectors.getBenefits) benefits$: Observable<BenefitModel[]>;
  @Select(FitnessSelectors.getSelectedBenefit) selectedBenefit$: Observable<BenefitModel>;
  @Select(FitnessSelectors.getSelectedReimbursement) selectedReimbursement$: Observable<ReimbursementModel>;
  @Select(FitnessSelectors.getEligibility) notEligible$: Observable<boolean>;
  @Select(FitnessSelectors.getEligibilityStatement) eligibilityText$: Observable<string>;

  toggle = false;

  constructor(private store: Store, private iabService: IabService) {}

  ionViewDidEnter() {
    this.content.scrollToTop(500);
    // TODO: Create this toggle in the ngxs state so we can reset this to use onPush
    this.toggle = false;
    this.store.dispatch(new GetBenefitsInfo());
  }

  yearChange(e) {
    this.store.dispatch(new SetSelectedBenefit(e.detail.value));
  }

  benefitTypeChange(e) {
    this.store.dispatch(new SetReimbursement(e.detail.value));
  }

  submit() {
    this.store.dispatch(new GetReimbursementForm());
  }

  toggleEligibility() {
    this.toggle = !this.toggle;

    if (this.toggle) {
      setTimeout(() => {
        this.content.scrollToBottom(0);
      }, 500);
    }
  }
}
