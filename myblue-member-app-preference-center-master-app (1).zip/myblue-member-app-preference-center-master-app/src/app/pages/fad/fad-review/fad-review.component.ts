import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadDoctorRatingsRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadReviewQuestion } from '../modals/fad-review-questions.modal';
import {
  FadDoctorRatingsRequestModelInterface,
  FadDoctorRatingsResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { FadReviewService } from './fad-review.service';

@Component({
  selector: 'app-fad-review',
  templateUrl: './fad-review.component.html',
  styleUrls: ['./fad-review.component.scss']
})
export class FadReviewComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  reviewForm: FormGroup;
  reviewquestions: FadReviewQuestion[] = [];
  reviewSubmitSuccess = false;

  reviewAlreadyDone = false;
  forModeration = false;
  canReview = false;

  public doctorInfo: any;
  reviewSubmitSuccessMessage: any;

  constructor(
    private fadReviewService: FadReviewService,
    private location: Location,
    private alertService: AlertService,
    private fadDoctorProfileService: FadDoctorProfileService
  ) {}

  ngOnInit() {
    this.doctorInfo = sessionStorage.getItem('doctorreviewer');
    const fadDoctorProfileRequestParams: FadDoctorRatingsRequestModelInterface = new FadDoctorRatingsRequestModel();
    fadDoctorProfileRequestParams.setReviewIdentifier(sessionStorage.getItem('reviewIdentifier'));
    const authUserId = this.useridin;
    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      fadDoctorProfileRequestParams.useridin = this.useridin;
    }
    this.fadDoctorProfileService.getAcceptableReviewers(fadDoctorProfileRequestParams).subscribe((responseData) => {
      this.canReview = responseData.canReview;
      if (this.canReview === true) {
        this.fadReviewService.getReviewQuestions().subscribe(response => {
          if (response && response.questionsList && response.questionsList.length > 0) {
            this.generateQuestionsForm(response.questionsList);
          }
        });
      } else {
        this.doctorInfo = sessionStorage.getItem('doctorreviewer');
        this.reviewAlreadyDone = true;
        this.reviewSubmitSuccessMessage = responseData.displaymessage;
        this.alertService.setAlert('', "Oops! You can't review yet.", AlertType.Failure);
      }
    });
    // fetch the quetions details
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  generateQuestionsForm(questions) {
    const group = {};
    for (const question of questions) {
      this.reviewquestions.push({ ...question, value: '' });
      group[question.id] = question.required ? new FormControl('', Validators.required) : new FormControl('');
    }
    this.reviewForm = new FormGroup(group);
  }

  onSubmit() {
    const questions = [];
    this.doctorInfo = sessionStorage.getItem('doctorreviewer');

    for (const [key, value] of Object.entries(this.reviewForm.value)) {
      questions.push({ questionNumber: key, questionValue: value });
    }

    this.fadReviewService.postReviewSubmitQuestions(questions).subscribe(response => {
      if (response && response.hasOwnProperty('result') && response.result === 0) {
        this.reviewSubmitSuccess = true;
        this.reviewSubmitSuccessMessage = response.displaymessage;
        this.alertService.setAlert('', 'Thank you for your review!', AlertType.Success);
      } else {
        this.reviewAlreadyDone = true;
        this.reviewSubmitSuccessMessage = response.displaymessage;
        this.alertService.setAlert('', "Oops! You can't review yet.", AlertType.Failure);
      }
    });
  }

  onCancel() {}

  closeScreen(): void {
    this.location.back();
  }
  gotoDoctorProfile() {
    this.location.back();
  }
}
