import { NgModule } from '@angular/core';
//import { LoginComponent } from './login.component';
//import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
//import { LoginRouter } from './login.routing';
//import { LoginService } from './login.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ImpersonationComponent } from './impersonation.component';
import { ImpersonationService } from './impersonation.service';
import { ImpersonationErrorComponent } from './impersonation-error/impersonation-error.component';
import { ImpersonationRouter } from './impersonation.routing';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [ImpersonationComponent, ImpersonationErrorComponent],
  exports: [],
  imports: [
    CommonModule,
    ImpersonationRouter,
    //HttpClientModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [
    //LoginService
    ImpersonationService
  ]
})
export class ImpersonationModule {}
