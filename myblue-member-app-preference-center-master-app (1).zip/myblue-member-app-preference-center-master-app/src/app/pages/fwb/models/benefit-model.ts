import { MemberModel } from './member-model';
import { ReimbursementModel } from './reimbursement-model';

export interface BenefitModel {
  year: number;
  planName: string;
  cancelDate: string;
  coveragePackageCode: string;
  effectiveDate: string;
  members: MemberModel[];
  fitness: ReimbursementModel;
  weightloss: ReimbursementModel;
  groupName: string;
  groupNumber: string;
}
