import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { TitleCasePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSidenavModule
} from '@angular/material';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { FilterPipe } from 'ngx-filter-pipe';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { OrderModule } from 'ngx-order-pipe';
import { SharedModule } from '../../shared/shared.module';
import { ClaimsRouter } from './claims.routing';
import { ClaimdetailsComponent } from './myclaimdetails/claimdetails.component';
import { ClaimsComponent } from './myclaims/claims.component';
import { ClaimStatusDetailsComponent } from './myClaimStatusDetails/claimStatusDetails.component';

@NgModule({
  declarations: [ClaimsComponent, ClaimdetailsComponent, ClaimStatusDetailsComponent],
  imports: [
    CommonModule,
    ClaimsRouter,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MatSidenavModule,
    MatExpansionModule,
    MatListModule,
    MatRadioModule,
    MatDatepickerModule,
    MatButtonModule,
    MatNativeDateModule,
    FilterPipeModule,
    OrderModule,
    InfiniteScrollModule
  ],
  providers: [DatePipe, FilterPipe, TitleCasePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ClaimsModule {}
