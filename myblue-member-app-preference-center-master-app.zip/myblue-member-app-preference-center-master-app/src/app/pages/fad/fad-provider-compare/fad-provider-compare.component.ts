import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadDoctorProfileRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { BreadCrumb } from '../utils/fad.utils';
import { FadProviderCompareService } from './fad-provider-compare.service';


@Component({
  selector: 'app-fad-provider-compare',
  templateUrl: './fad-provider-compare.component.html',
  styleUrls: ['./fad-provider-compare.component.scss']
})
export class FadProviderCompareComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getMLEEligibility) mleEligibility: any;

  public fadConstants = FAD_CONSTANTS;
  public results;
  public selectedFacilityDetail = null;
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public costInfo;
  public awards;
  public showRemove = true;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public providerCompareService: FadProviderCompareService,
    private fadSearchListService: FadSearchListService,
    private fadBreadCrumbService: FadBreadCrumbsService,
    private alertService: AlertService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadDoctorProfileService: FadDoctorProfileService
  ) {}

  ngOnInit() {
    this.fadBreadCrumbService
      .addBreadCrumb(new BreadCrumb().setLabel('Search').setUrl('/fad/search-results'))
      .addBreadCrumb(new BreadCrumb().setLabel('Compare').setUrl('/fad/provider-compare'));

    this.costInfo = this.providerCompareService.getCostInfo();

    if (
      this.route.snapshot.data.facilityCompareData &&
      this.route.snapshot.data.facilityCompareData.result &&
      this.route.snapshot.data.facilityCompareData.result < 0
    ) {
      this.alertService.setAlert(this.route.snapshot.data.facilityCompareData.displaymessage, '', AlertType.Failure);
    } else {
      this.selectedFacilityDetail =
        this.route.snapshot.data.facilityCompareData && this.route.snapshot.data.facilityCompareData.OutBodyFacility;
    }
    const original = this.providerCompareService.getSearchResult();

    const result = [];
    Object.keys(original).map(key => {
      const firstLocation = original[key].locations[0];

      if (firstLocation.awards && firstLocation.awards.length) {
        const blueAwards = firstLocation.awards.filter(award => {
          return award.name.indexOf('BLUE DISTINCTION') >= 0;
        });

        original[key].blueAwards = blueAwards;
      }

      result.push(original[key]);
      return result;
    });
    this.selectedFacilityDetail = original;
    setTimeout(() => {
      for (let i = 0; i < this.selectedFacilityDetail.length; i++) {
        this.getFacilityData(this.selectedFacilityDetail[i]);

      }
      // tslint:disable-next-line:no-magic-numbers
    }, 500);

    this.doctorStarRating = new StarRatingComponentInputModel();
    // tslint:disable-next-line:no-magic-numbers
    this.doctorStarRating.ratingInPercentage = 80;
    this.doctorStarRating.numberOfStars = 5;
  }

  getFacilityData(facilityoutput) {
    if (facilityoutput.providerType === 'P') {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const facilityProfileId = parseInt(facilityoutput.providerId.toString());
      // this.fadFacilityProfileService.facilityProfile;
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FAD_CONSTANTS.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FAD_CONSTANTS.defaults.geo;
      const locationId = facilityoutput.locations[0].id;
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setProfessional(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));

      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FAD_CONSTANTS.defaults.radius);
      }

      const authUserId = this.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.useridin;
      }
      const mleIndicator = this.mleEligibility;
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {
        if (data.locations) {
          for (let i = 0; i < this.selectedFacilityDetail.length; i++) {
            if (this.selectedFacilityDetail[i].providerId === facilityoutput.providerId) {
              this.selectedFacilityDetail[i].acceptingNewPatients = data.locations[0].acceptingNewPatients;
            }
          }
        }
      });
    }
  }

  // Remove from the compare table
  // In case only last one remains redirect to search results
  public removeFacility(idx: number) {
    this.selectedFacilityDetail.splice(idx, 1);
    this.showRemove = this.selectedFacilityDetail.length <= 2;
  }

  // Move to Doctor's Profile Page
  public goToFacilityProfilePage(provider) {
    sessionStorage.setItem('locationId', provider.locations[0].id);
    if (provider.providerType === 'F') {
      sessionStorage.setItem('facilityProfileId', provider.providerId);
      this.router.navigate([`/fad/facility-profile`]);
    } else if (provider.providerType === 'P') {
      sessionStorage.setItem('professionalId', provider.providerId);
      this.router.navigate(['/fad/doctor-profile']);
    }
  }

  getRating(ratings, totalReviews) {
    this.doctorStarRating = new StarRatingComponentInputModel();

    this.doctorStarRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.doctorStarRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.doctorStarRating;
  }

  ngOnDestroy(): void {
    this.alertService.clearError();
  }
}
