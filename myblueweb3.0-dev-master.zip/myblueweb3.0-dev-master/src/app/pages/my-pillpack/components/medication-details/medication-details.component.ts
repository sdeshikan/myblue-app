import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-medication-details',
  templateUrl: './medication-details.component.html',
  styleUrls: ['./medication-details.component.scss']
})
export class MedicationDetailsComponent implements OnInit {

  @Input() medication: any;
  @Input() medicationAddedtoCart :boolean;
  doseType = {'T':'Tablet','C':'Capsule','S':'Spray','O':'Tube'};
  pluralDoseType = {'T':'Tablets','C':'Capsules','S':'Sprays','O':'Tubes'};
  constructor() { }

  ngOnInit() {
  }

  getBasePrice(price: number) {
     if (price != undefined)
    return ('' + price).split('.')[0];
    else return '';
  }

  getFloatPrice(price: number) {
    if (price != undefined)
    return price.toFixed(2).split('.')[1];
    else return '';
  }


  getType(medication : any)
   {
     if(medication.orderDetails[0].orderCount==1){
      return this.doseType[medication.doseType];
     }else{
      return this.pluralDoseType[medication.doseType];
     }
   }

   getBaseCostSum(medication: any) {
    return  this.getCost(medication).toString().split('.')[0];
   }
 
   getCost(medication: any){
     var cost = 0.00;
     var unitCost = medication.price/medication.count;
     medication.orderDetails.map(item =>{
       if(medication.inPackets){
         cost = cost + (unitCost * item.orderCount * 30);
       } else {
         cost = cost + (item.orderCount  * medication.price);
       }
    });
    return cost;
 }
 
   getFloatCostSum(medication: any) {
     return  this.getCost(medication).toFixed(2).toString().split('.')[1];
   }
}
