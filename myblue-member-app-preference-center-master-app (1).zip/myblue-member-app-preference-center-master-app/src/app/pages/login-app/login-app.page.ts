import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { Keychain } from '@ionic-native/keychain/ngx';
import { LoadingController, Platform } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { from } from 'rxjs';
import { LoginRequest } from '../../models/login-request.model';
import { SwrveEventNames, SwrveService } from '../../services/swrve.service';
import { LoadingHelperClass } from '../../shared/classes/loadingHelper.class';
import { AnalyticsService } from '../../shared/services/analytics.service';
import { GlobalService } from '../../shared/services/global.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { AlertService, ConstantsService } from '../../shared/shared.module';
import { GetTokens } from '../../store/actions/app.actions';
import { AppSelectors } from '../../store/selectors/app-selectors';

@Component({
  selector: 'app-login-app',
  templateUrl: './login-app.page.html',
  styleUrls: ['./login-app.page.scss']
})
export class LoginAppPage {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  loginForm = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    rememberMe: new FormControl(''),
    bioMetrics: new FormControl('')
  });
  showPassword: string;
  message: string;
  idAvailable = true;
  faceIdAvailable: boolean;
  fingerPrintAvailable: boolean;
  isAuthenticatedUser: boolean;
  userName: any;
  private loadingHelper: LoadingHelperClass;

  constructor(
    private storage: Storage,
    private store: Store,
    private router: Router,
    private faio: FingerprintAIO,
    private alertService: AlertService,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private analyticsService: AnalyticsService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    public loadingController: LoadingController,
    private keyboard: Keyboard,
    private keychain: Keychain,
    private platform: Platform,
    private profileService: ProfileService,
    private modalController: ModalController
  ) {
    this.loadingHelper = new LoadingHelperClass(loadingController);
    this.showPassword = 'password';
    this.checkIdTech();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_SignIn);
  }

  checkIdTech() {
    this.faio
      .isAvailable()
      .then(result => {
        result === 'finger' ? (this.fingerPrintAvailable = true) : (this.faceIdAvailable = true);
      })
      .catch(err => {
        this.idAvailable = false;
      });
  }

  ionViewWillEnter() {
    this.checkRememberMe();
    this.checkIsBioSetup();
  }

  ionViewWillLeave() {
    this.clearForm();
  }

  checkRememberMe() {
    from(this.storage.get('userid')).subscribe(data => {
      if (data) {
        this.loginForm.patchValue({ rememberMe: true });
        this.getSavedUserName();
      } else {
        this.loginForm.patchValue({ rememberMe: true });
        this.checkLocalStorageForUserId();
      }
    });
  }

  checkLocalStorageForUserId() {
    if (window.localStorage && localStorage.getItem('userid')) {
      this.loginForm.patchValue({
        userName: localStorage.getItem('userid'),
        rememberMe: true
      });
    }
  }

  checkIsBioSetup() {
    from(this.storage.get('pBioData')).subscribe(pBioData => {
      if (pBioData) {
        this.launchBioMetrics();
      } else {
        this.loginForm.patchValue({ bioMetrics: false });
      }
    });
  }

  getSavedUserName() {
    from(this.storage.get('userid')).subscribe(data => {
      this.userName = data;
      this.loginForm.patchValue({
        userName: data,
        rememberMe: true
      });
    });
  }

  showHidePassword(type: string) {
    type === 'text' ? (this.showPassword = 'text') : (this.showPassword = 'password');
  }

  onSubmit() {
    this.loadingHelper.fetch(() => this.handleSubmit());
  }

  handleSubmit() {
    this.loginForm.get('rememberMe').value ? this.saveUserName(this.loginForm.get('userName').value) : this.eraseUserNameFromStorage();
    this.loginForm.get('bioMetrics').value ? this.setBioUp() : this.eraseBiometricsFromStorage();
    this.showHidePassword('password');
    this.login(this.createRequest());
  }

  closeKeyboard() {
    this.keyboard.hide();
  }

  createRequest(): LoginRequest {
    return {
      useridin: this.loginForm.get('userName').value,
      passwordin: this.loginForm.get('password').value
    };
  }

  launchBioMetrics() {
    this.faio
      .show({
        title: 'Use Pin',
        disableBackup: true // Only for Android(optional)
      })
      .then((result: any) => {
        console.log(result);
        return this.bioMetricSuccess();
      })
      .catch((error: any) => console.log(error));
  }

  bioMetricSuccess() {
    this.storage
      .get('pBioData')
      .then(pBioData => {
        this.loadingHelper.fetch(() => this.login({ useridin: this.userName, passwordin: pBioData.password }));
      })
      .catch((error: any) => {
        console.log(error);
      });
  }

  setBioUp() {
    const pBioData = {
      password: this.loginForm.get('password').value,
      userid: this.loginForm.get('userName').value
    };
    this.storage
      .set('pBioData', pBioData)
      .then(() => {})
      .catch((error: any) => console.log(error));
  }

  clearForm() {
    this.loginForm.patchValue({ password: '' });
  }

  login(request: LoginRequest) {
    this.store.dispatch(new GetTokens(request));
  }

  saveUserName(userName: string) {
    from(this.storage.set('userid', userName)).subscribe(() => {});
  }

  eraseBiometricsFromStorage() {
    from(this.storage.set('pBioData', '')).subscribe(() => {});
  }

  eraseUserNameFromStorage() {
    from(this.storage.set('userid', '')).subscribe(() => {});
  }

  bioMetricChange() {
    this.loginForm.get('bioMetrics').value ? this.loginForm.patchValue({ rememberMe: true }) : this.eraseBiometricsFromStorage();
  }

  rememberMeChange() {
    if (!this.loginForm.get('rememberMe').value) {
      this.eraseUserNameFromStorage();
    }
  }

  navigateToForgotPassword() {
    const userName =
      this.loginForm && this.loginForm.controls && this.loginForm.controls.useridin ? this.loginForm.controls.useridin.value : '';

    if (userName) {
      this.router.navigate(['/account/forgotPassword', userName]);
    } else {
      this.router.navigate(['/account/forgotPassword']);
    }
  }
}
