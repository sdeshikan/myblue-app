import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DeductibleModel } from '../../models/deductible.model';

@Component({
  selector: 'app-deductible',
  templateUrl: './deductible.component.html',
  styleUrls: ['./deductible.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeductibleComponent {
  @Input() deductibleInfo: DeductibleModel;
  @Output() goToDeductibleDetails = new EventEmitter();

  goToDetails() {
    this.goToDeductibleDetails.emit();
  }
}
