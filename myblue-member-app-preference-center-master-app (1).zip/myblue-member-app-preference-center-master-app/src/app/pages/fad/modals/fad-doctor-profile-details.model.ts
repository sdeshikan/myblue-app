import { FadAwardDetailModel } from './fad-facility-profile-details.model';
import {
    CostBenefitDetailsInterface, DisclaimersInterface, FacilityCostDetailInterface,
    FadAmenitiesInterface, FadAwardsInterface,
    FadContractsInterface, FadDoctorProfileRequestModelInterface, FadDoctorRatingsRequestModelInterface,
    FadDoctorRatingsResponseModelInterface,
    FadEducationInterface,
    FadGroupAffiliationsInterface,
    FadHospitalAffiliationsInterface,
    FadIdentifiersInterface,
    FadLocationDetailsInterface,
    FadProfessionalResponseModelInterface,
    FadReviewsListInterface,
    FadTiersInterface,
    ReviewsListInterface
} from './interfaces/fad-doctor-profile-details.interface';

export class FadDoctorProfileRequestModel implements FadDoctorProfileRequestModelInterface {
    geoLocation: string;
    locationId: number;
    professionalId: number;
    networkId: number;
    useridin: string;
    procedureId: string;
    radius: number;

    getGeoLocation(): string {
        return this.geoLocation;
    }
    setGeoLocation(geoLocation: string): FadDoctorProfileRequestModelInterface {
        this.geoLocation = geoLocation;
        return this;
    }

    getLocationId(): number {
        return this.locationId;
    }

    setLocationId(locationId: number): FadDoctorProfileRequestModelInterface {
        this.locationId = locationId;
        return this;
    }

    getProfessional(): number {
        return this.professionalId;
    }
    setProfessional(professionalId: number): FadDoctorProfileRequestModelInterface {
        this.professionalId = professionalId;
        return this;
    }

    getRadius(): number {
        return this.radius;
    }
    setRadius(radius: number): FadDoctorProfileRequestModelInterface {
        this.radius = radius;
        return this;
    }

    getNetworkId(): number {
        return this.networkId;
    }
    setNetworkId(networkId: number): FadDoctorProfileRequestModelInterface {
        this.networkId = networkId;
        return this;
    }
    getProcedureId(): string {
        return this.procedureId;
    }
    setProcedureId(procedureId: string): FadDoctorProfileRequestModelInterface {
        this.procedureId = procedureId;
        return this;
    }
}

export class FadProfessionalResponseModel implements FadProfessionalResponseModelInterface {
    result: number;
    errormessage: string;
    displaymessage: string;
    doctorName: string;
    disclaimers: DisclaimersModel[];
    specialty: string;
    languages: string;
    education: FadEducationModel[];
    locations: FadLocationDetailsModel[];
    reviews: FadReviewsListModel;
    matchedLocation: FadLocationDetailsModel;
    onRecordDiclaimers?: DisclaimersModel;
}

export class FadEducationModel implements FadEducationInterface {
    name: string;
    type: string;
}

export class DisclaimersModel implements DisclaimersInterface {
    text: string;
    category: string;
    priority: 0;
    id?: number;
}

export class FadContractsModel implements FadContractsInterface {
    hospitalAffiliations: FadHospitalAffiliationsModel[];
    groupAffiliations: FadGroupAffiliationsModel[];
    identifiers: FadIdentifiersModel[];
    awards: FadAwardsModel[];
    pcpId: string;
    acceptingNewPatients: string;
}

export class FadLocationDetailsModel extends FadContractsModel implements FadLocationDetailsInterface {
    id: number; //    This is the location
    name: string; //     This is the location name
    address: string; //     This is the address info
    phone: string; //     This is the phone info
    amenities: FadAmenitiesModel[];
    awards: FadAwardsInterface[];
    facilityCost: FacilityCostDetailModel;
    costBenefit: CostBenefitDetailsModel;
    tiers: FadTiersModel;
    // contracts: FadContractsModel[];
}

export class FadAmenitiesModel implements FadAmenitiesInterface {
    type: string;
}


export class FadHospitalAffiliationsModel implements FadHospitalAffiliationsInterface {
    name: string;
    facilityId: number;
    facilityLocationId: number;
    address: string;
}

export class FadGroupAffiliationsModel implements FadGroupAffiliationsInterface {
    name: string;
    facilityId: number;
    facilityLocationId: number;
}

export class FadIdentifiersModel implements FadIdentifiersInterface {
    typeCode: string;
    value: string;
}

export class FadAwardsModel implements FadAwardsInterface {
    name: string;
    awardDetails: FadAwardDetailModel[];
    typeCode: string;
}

export class FadReviewsListModel implements FadReviewsListInterface {
    overallRating: number; //     This is the city/state of the location
    percentRecommended: number; //     This is the percentRecommended
    totalRatings: number; //     This is the totalRatings
}

export class FadDoctorRatingsRequestModel implements FadDoctorRatingsRequestModelInterface {
    ratingIdentifier: string;
    useridin: string;
    reviewIdentifier: string;

    getRatingIdentifier(): string {
        return this.ratingIdentifier;
    }
    setRatingIdentifier(ratingIdentifier: string): FadDoctorRatingsRequestModelInterface {
        this.ratingIdentifier = ratingIdentifier;
        return this;
    }
    getReviewIdentifier(): string {
        return this.reviewIdentifier;
    }
    setReviewIdentifier(reviewIdentifier: string): FadDoctorRatingsRequestModelInterface {
        this.reviewIdentifier = reviewIdentifier;
        return this;
    }
}

export class FadDoctorRatingsResponseModel implements FadDoctorRatingsResponseModelInterface {
    overallRating: string;
    percentRecommended: string;
    totalReviews: string;
    environmentRating: string;
    communicationRating: string;
    availabilityRating: string;
    reviews: ReviewsListModel[];
    result: number;
    errormessage: string;
    displaymessage: string;

}

export class ReviewsListModel implements ReviewsListInterface {
    reviewDate: string;
    screenName: string;
    recommended: string;
    overallExperience: string;
    communication: string;
    availability: string;
    environment: string;
    headline: string;
    comments: string;
}

export class FacilityCostDetailModel implements FacilityCostDetailInterface {
    copay: number;
    coinsuranceAmount: number;
    deductibleAmount: number;
    employerCost: number;
    procedureCost: number;
    memberCost: number;
}

export class CostBenefitDetailsModel implements CostBenefitDetailsInterface {
    individualDeductibleLimit: number;
    individualDeductibleAccumulated: number;
    overallDeductibleLimit: number;
    overallDeductibleAccumulated: number;
    individualOutofPocketLimit: number;
    individualOutofPocketAccumulated: number;
    familyOutofPocketLimit: number;
    familyOutofPocketAccumulated: number;
}

export class FadTiersModel implements FadTiersInterface {
    description: string;
}
