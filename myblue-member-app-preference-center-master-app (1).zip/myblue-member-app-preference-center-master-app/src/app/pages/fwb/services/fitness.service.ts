import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { encryptPayload } from '../../../utils/app.utils';
import { GET_REIMBURSEMENT_BENEFITS_ENDPOINT, SUBMIT_REIMBURSEMENT_BENEFITS_ENDPOINT } from '../constants/fitness.constants';

@Injectable({
  providedIn: 'root'
})
export class FitnessService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  constructor(private http: HttpClient) {}

  getBenefitsInfo(): Observable<any> {
    const request = {
      useridin: this.useridin,
      isCommercial: 'true'
    };
    return this.http.post(GET_REIMBURSEMENT_BENEFITS_ENDPOINT, request);
  }

  submitBenefitsInfo(claims, images): Observable<any> {
    const formData = new FormData();
    const message = encryptPayload(claims, this.cryptoToken, false);
    for (let i = 0; images && i < images.length; i++) {
      formData.append('imageFiles', images[i], 'image.jpg');
    }
    formData.append('FWLBenefitClaim', JSON.stringify(message));

    return this.http.post(SUBMIT_REIMBURSEMENT_BENEFITS_ENDPOINT, formData);
  }
}
