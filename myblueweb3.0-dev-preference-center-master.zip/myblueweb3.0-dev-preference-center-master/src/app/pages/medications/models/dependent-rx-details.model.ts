import { GeneralError } from '../../../shared/models/generic-app.model';
import {
  DependentRxDetailsRequestModelInterface,
  DependentRxDetailsResponseModelInterface
} from './interfaces/dependent-rx-details-model.interface';
import { BaseRxDetailsRequestModel, RxDetails } from './my-medications-generic.models';

export class DependentRxDetailsRequestModel extends BaseRxDetailsRequestModel implements DependentRxDetailsRequestModelInterface {
  dependentId: number; // *dependentIdnumber - example: 123456786 - Dependent ID
}

export class DependentRxDetailsResponseModel extends GeneralError implements DependentRxDetailsResponseModelInterface {
  rxDetails: RxDetails;
}
