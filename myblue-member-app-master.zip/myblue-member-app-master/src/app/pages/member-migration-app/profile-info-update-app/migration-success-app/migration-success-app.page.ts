import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../../shared/services/auth.service';
import { Platform } from '@ionic/angular';
import { SwrveService, SwrveEventNames } from './../../../../shared/services/swrve.service';

@Component({
    selector: 'app-migration-success-app',
    templateUrl: './migration-success-app.page.html',
    styleUrls: ['./migration-success-app.page.scss']
})

export class MigrationSuccessAppPage implements OnInit {

    public userid: string = localStorage['login-user'];

    constructor(private location: Location,
        private router: Router,
        private authService: AuthService,
        private platform: Platform,
        private swrveService: SwrveService,
        private swrveEventNames: SwrveEventNames) { }

    ngOnInit() {
        this.authService.logout();
        this.platform.backButton.subscribe(() => {
            this.exploreNew();
        });
        this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MigrationComplete);
    }

    exploreNew(): void {
        this.router.navigateByUrl('login-app');
    }
}

