import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ModalController } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../shared/services/constants.service';
import { HomeService } from '../../shared/services/home.service';
import { SsoService } from '../sso/sso.service';
import { CareCostPage } from './care-cost.page';

describe('Tab2Page', () => {
  let component: CareCostPage;
  let fixture: ComponentFixture<CareCostPage>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [
        SsoService,
        ConstantsService,
        InAppBrowser,
        HomeService,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      declarations: [CareCostPage],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareCostPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
