import { Component, OnDestroy, ViewChild } from '@angular/core';
import { Actions, ofActionSuccessful, Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { DeductibleSelectors } from '../../../store/selectors/deductible.selectors';
import { DeductibleStateModel } from '../../../store/state/deductible.state';
import { IonContent, NavController, PopoverController } from '@ionic/angular';
import { DeductibleFilterPopover } from '../popovers/deductible-filter.popover';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { MemberDeductibleModel } from '../models/member-deductible.model';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { GetIndividualDeductibles, SetFamilyDeductibles } from '../../../store/actions/deductible.actions';
import { SsoService } from '../../sso/sso.service';
import { AuthToken } from '../../../models/auth-token.model';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-deductible-details',
  templateUrl: './deductible-details.page.html',
  styleUrls: ['./deductible-details.page.scss']
})
export class DeductibleDetailsPage implements OnDestroy {
  @Select(DeductibleSelectors.getDeductibleState) deductibleState$: Observable<DeductibleStateModel>;

  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(DeductibleSelectors.getCurrentMember) currentMember: MemberDeductibleModel;
  @SelectSnapshot(DeductibleSelectors.getMembers) members: MemberDeductibleModel[];
  @SelectSnapshot(DeductibleSelectors.hasFamily) hasFamily: boolean;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  @ViewChild(IonContent) content: IonContent;

  destroy$: Subject<boolean> = new Subject<boolean>();

  public hasHEQ = false;

  constructor(
    public popoverController: PopoverController,
    private actions$: Actions,
    private navCtrl: NavController,
    private ssoService: SsoService
  ) {
    this.hasHEQ = this.authToken ? this.authToken.isHEQ === 'true' : false;

    this.actions$.pipe(ofActionSuccessful(GetIndividualDeductibles), takeUntil(this.destroy$)).subscribe(() => {
      this.content.scrollToTop(100);
    });
    this.actions$.pipe(ofActionSuccessful(SetFamilyDeductibles), takeUntil(this.destroy$)).subscribe(() => {
      this.content.scrollToTop(100);
    });
  }

  ionViewDidEnter() {
    this.content.scrollToTop(100);
  }

  async presentPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: DeductibleFilterPopover,
      event: ev,
      cssClass: 'deductible-popover',
      componentProps: { members: this.members, current: this.currentMember, hasFamily: this.hasFamily, useridin: this.useridin }
    });
    return await popover.present();
  }

  openSSO() {
    this.ssoService.openSSO(this.hasHEQ ? 'heq' : 'alg');
  }

  goBack() {
   // this.navCtrl.navigateBack()
    this.navCtrl.back();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
