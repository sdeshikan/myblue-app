import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReimbursementSelectionPage } from './reimbursement-selection.page';
import { NgxsModule } from '@ngxs/store';
import { IabService } from '../../../../shared/services/iab/iab.service';

class MockIabService {}

describe('FwbPage', () => {
  let component: ReimbursementSelectionPage;
  let fixture: ComponentFixture<ReimbursementSelectionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxsModule.forRoot([])],
      declarations: [ReimbursementSelectionPage],
      providers: [{ provide: IabService, useClass: MockIabService }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReimbursementSelectionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
