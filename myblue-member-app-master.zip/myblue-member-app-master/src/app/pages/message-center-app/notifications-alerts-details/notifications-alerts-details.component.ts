import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { MsgListingService } from '../msg-listing/msg-listing.service';
import { NotificationsAlertsDetailsService } from './notifications-alerts-details.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';

import { MessageDetailRequestDataModelInterface, MessageDetailModelInterface } from '../modals/interfaces/message-detail.interface';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { MessageDetailRequestDataModel, MessageDetailModel } from '../modals/message-detail.model';
import { MessageCenterService } from '../message-center.service';
import { MessageCenterSearchService } from '../message-center-search/message-center-search.service';
import { UpdateMsgListingAndMemberAlertsRequestInterface } from '../modals/interfaces/message.interface';
import { UpdateMsgListingAndMemberAlertsRequestModel } from '../modals/messages.model';
import { Location } from '@angular/common';
import { Platform } from '@ionic/angular';
import { SwrveService, SwrveEventNames } from '../../../shared/services/swrve.service';

@Component({
  selector: 'app-notifications-alerts-details',
  templateUrl: './notifications-alerts-details.component.html',
  styleUrls: ['./notifications-alerts-details.component.scss']
})
export class NotificationsAlertsDetailsComponent implements OnInit {
  public msgDetail: MessageDetailModelInterface = new MessageDetailModel();
  public category: string;
  public timeStamp: string;
  public test;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private headerService: HeaderService,
    private msgListingService: MsgListingService,
    private messageCenterService: MessageCenterService,
    private messageDetailService: NotificationsAlertsDetailsService,
    private messageCenterSearchService: MessageCenterSearchService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.onBackPressed();
    });
  }

  ngOnInit() {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewNotificationsAlerts_ViewNotificationsAlertsDetails);

      this.setMessageDetail();
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public onBackPressed(): void {
    this.router.navigate(['../tabs/myInbox/notifications-alerts'], { replaceUrl: true });
  }

  private setMessageDetail() {
    this.messageDetailService.getMessageDetail(this.setMsgDetailAndMemberAlertsReqParams()).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        // this.timeStamp = this.messageCenterService.msgListingResponse.messageUpdatedDateTime;
        if (apiData.hasOwnProperty('messageDetailResponse') && Object.keys(apiData.messageDetailResponse).length) {
          this.msgDetail = apiData.messageDetailResponse;
          if (this.msgDetail.body) {
            this.setCtaLink();
          }
          this.category = sessionStorage.getItem('category') ? sessionStorage.getItem('category') : '';
          if (this.messageCenterService.msgListingResponse.isRead === 'false') {
            // if it's already read, this call is not required
            this.markAsRead();
          }
        } else if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        }
      }
    });
  }

  /*
    Method to replace the text url with the links in the multiple places from the message body
 */
  private setCtaLink() {
    const urlRegex = /(\b((https?|ftp|file):\/\/|(www))[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|]*)/gi,
      msgBody = this.msgDetail.body.toLowerCase();
    if (msgBody.indexOf('cta:') !== -1) {
      if (msgBody.split('cta:')[1].indexOf('opens') !== -1) {
        this.msgDetail.body = this.msgDetail.body.replace(urlRegex, url => `<a href=${url}>${url}</a>`);
        if (this.msgDetail.body.indexOf('CTA: Opens') >= 0) {
          this.msgDetail.body = this.msgDetail.body.replace('CTA: Opens ', '');
        } else if (this.msgDetail.body.indexOf('CTA:Opens') >= 0) {
          this.msgDetail.body = this.msgDetail.body.toLowerCase().replace('CTA:Opens ', '');
        }
      }
    }
  }

  public backToMsgListing() {
    try {
      this.messageCenterSearchService.isPersistSearchCriteria = true;
      this.router.navigate(['/tabs/myInbox/notifications-alerts']);
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public deleteMessage() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MessageCenter_DeleteMessage);
    this.backToMsgListing();
    this.messageCenterService.msgListingResponse.type = 'delete';
  }

  public markAsRead() {
    this.msgListingService.getUpdateMsgListingAndMemberAlerts(this.setMsgDetailAndMemberAlertsReqParams(true)).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          console.log(apiData);
          this.headerService.unReadMsgCount = apiData.successresponse.unreadMessageCount.toString();
        }
      }
    });
  }

  public formattedDate(date: string, format: string): string {
    if (date) {
      return this.datePipe.transform(date, format);
    }
  }

  private setMsgDetailAndMemberAlertsReqParams(isMsgRead?: boolean): any {
    const memberId = sessionStorage.getItem('memberId') ? sessionStorage.getItem('memberId') : '',
      messageId = sessionStorage.getItem('messageId') ? sessionStorage.getItem('messageId') : '',
      useridin = this.authService.useridin;

    if (typeof isMsgRead === 'boolean') {
      const updateMsgListingAndMemberAlertsReqParams: UpdateMsgListingAndMemberAlertsRequestInterface = new UpdateMsgListingAndMemberAlertsRequestModel();

      if (isMsgRead === true) {
        updateMsgListingAndMemberAlertsReqParams.readalertids = messageId;
      } else {
        updateMsgListingAndMemberAlertsReqParams.unreadalertids = messageId;
      }
      updateMsgListingAndMemberAlertsReqParams.useridin = useridin;
      updateMsgListingAndMemberAlertsReqParams.memberId = memberId;
      return updateMsgListingAndMemberAlertsReqParams;
    } else {
      const msgDetailReqParams: MessageDetailRequestDataModelInterface = new MessageDetailRequestDataModel();
      msgDetailReqParams.memberId = memberId;
      msgDetailReqParams.messageId = messageId;
      msgDetailReqParams.useridin = useridin;

      return msgDetailReqParams;
    }
    // return;
  }
}
