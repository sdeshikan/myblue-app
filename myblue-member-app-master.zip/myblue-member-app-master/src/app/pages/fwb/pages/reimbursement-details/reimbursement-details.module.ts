import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ReimbursementDetailsPage } from './reimbursement-details.page';
import { InfoModalComponent } from '../../../../modals/info-modal/info-modal.component';
import { InfoModalModule } from '../../../../modals/info-modal/info-modal.module';
import { InfoPopoverComponent } from '../../../../popovers/info-popover/info-popover.component';
import { InfoPopoverModule } from '../../../../popovers/info-popover/info-popover.module';
import { RouterModule } from '@angular/router';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InfoModalModule,
    InfoPopoverModule,
    ReactiveFormsModule,
    RouterModule,
    NgxCurrencyModule,
    NgxMaskModule
  ],
  providers: [CurrencyPipe],
  declarations: [ReimbursementDetailsPage],
  entryComponents: [InfoModalComponent, InfoPopoverComponent]
})
export class ReimbursementDetailsPageModule {}
