import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService, AuthService, ConstantsService } from '../../../shared/shared.module';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { CommunicationPreferenceService } from './communication-preference.service';

@Component({
  selector: 'app-communication-preferences',
  templateUrl: './communication-preference.component.html',
  styleUrls: ['./communication-preference.component.scss']
})
export class CommunicationPreferenceComponent implements OnInit, OnDestroy {
  programGroupObject: any;
  preferenceObject: any;
  filterListReverse: any;
  pageTitle: string;
  pageDesc: string;
  emailDesc: string;
  submitBtnTxt: string;
  successText: string;
  errorText: string;
  disclosureText: string;
  programList: any;
  preferenceList = [];
  radioChecked: boolean;
  changedItem: any;
  toolTipVisible: boolean = false;
  prefCID: string;
  displayEmailAddress: string;
  profile: any;
  lblEmailNotVerified: string;
  isUserVerified: boolean = false;
  getConsent: any;
  getConsentDrupal: any;
  impersonate: boolean = true;

  constructor(
    private date: DatePipe,
    private globalService: GlobalService,
    private alertService: AlertService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private profileService: ProfileService,
    private http: AuthHttp,
    private constants: ConstantsService,
    private preferenceService: CommunicationPreferenceService,
    private authService: AuthService
  ) {
    this.programGroupObject = JSON.parse(sessionStorage.getItem('programGroups'));
    this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
    this.getConsent = JSON.parse(sessionStorage.getItem('consentData'));
    this.getConsentDrupal = JSON.parse(sessionStorage.getItem('getConsentDrupal'));
    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    this.preferenceService.preferenceDataChange$.subscribe(data => {
      if (data == new Date()) {
        this.fetchUpdatedProfileInfo();
      }
    });
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }

  ngOnInit() {
    this.programGroupObject.ProgramGroup.map(group => {
      //config data
      if (group.ID === 'MyB_PC_Pg_Config') {
        group.Locales.map(item => {
          item.DisplayTags.map(tag => {
            if (tag.Key === 'lblPCPageTitle') {
              this.pageTitle = tag.Value;
            }
            if (tag.Key === 'lblPCPageDescription') {
              this.pageDesc = tag.Value;
            }
            if (tag.Key === 'lblEmailDesc') {
              this.emailDesc = tag.Value;
            }
            if (tag.Key === 'lblSubmitButton') {
              this.submitBtnTxt = tag.Value;
            }
            if (tag.Key === 'lblSaveConfirmation') {
              this.successText = tag.Value;
            }
            if (tag.Key === 'lblSaveError') {
              this.errorText = tag.Value;
            }
            if (tag.Key === 'DisclosureText') {
              this.disclosureText = tag.Value;
            }
            if (tag.Key === 'lblEmailUnverified') {
              this.lblEmailNotVerified = tag.Value;
            }
          });
        });
      }
      // preference and filters iterate
      if (group.ID === 'Docs_Reqd') {
        this.programList = group.Programs;
        for (const values of this.programList) {
          this.filterListReverse = values.Filters.reverse();
        }
      }
    });
    if (this.preferenceObject) {
      if (this.preferenceObject.errormessage) {
        //if user has no prefernce get CID from error msg
        this.prefCID = this.preferenceObject.errormessage.slice(this.preferenceObject.errormessage.length - 40);
      } else {
        //user already has preference
        this.preferenceObject.Preferences.map(x => {
          if (!(x.FilterID === 'CONSENT_PAPERLESS_SOLICIT')) {
            this.preferenceList.push(x);
          }
        });
        // reversing inorder to get email value first as per wireframe
        this.preferenceList = this.preferenceList.reverse();
      }
    }
    this.displayEmailAddress = this.profile.emailAddress;
    if (!this.profile.isVerifiedEmail) {
      this.alertService.setAlert(this.lblEmailNotVerified, '', AlertType.Failure, 'component', 'communication');
    }
  }

  showToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }

  fetchUpdatedProfileInfo() {
    this.profileService.fetchProfileInfo().subscribe(profile => {
      this.profile = Object.assign({}, profile);
      profile && this.submitPrefernce();
    });
  }

  onChange(event) {
    this.changedItem = [];
    let sessionId = this.http.sessionid();
    if (event.value) {
      // User already has preference
      if (this.preferenceList.length > 0) {
        let consent: any = {};
        let consentAvailable = true;
        this.changedItem = this.preferenceList.map(item => {
          this.prefCID = item.CID;
          if (item.FilterID == event.value) {
            item.PreferenceType = '1';
            item.PreferenceAttributes = [
              {
                Key: 'PS_Update_Type',
                Value: new Date(item.LastModifiedDate).getDate() === new Date().getDate() ? 'A' : 'U'
              },
              {
                Key: 'PS_EventID',
                Value: sessionId
              },
              {
                Key: 'PS_SystemName',
                Value: 'MyBlue_PC_Web'
              },
              {
                Key: 'ConsentVerNo',
                Value: this.getConsent.consentLanguageId
              }
            ];
            item.CustomerDate = this.date.transform(new Date(), 'M/d/yyyy h:m:s aa');
          } else {
            item.PreferenceType = '2';
            item.PreferenceAttributes = [
              {
                Key: 'PS_Update_Type',
                Value: new Date(item.LastModifiedDate).getDate() === new Date().getDate() ? 'A' : 'U'
              },
              {
                Key: 'PS_EventID',
                Value: sessionId
              },
              {
                Key: 'PS_SystemName',
                Value: 'MyBlue_PC_Web'
              },
              {
                Key: 'ConsentVerNo',
                Value: this.getConsent.consentLanguageId
              }
            ];
            item.CustomerDate = this.date.transform(new Date(), 'M/d/yyyy h:m:s aa');
          }
          return item;
        });
        this.changedItem.map(changedItems => {
          if (changedItems.FilterID !== 'CONSENT_PAPERLESS_SOLICIT') {
            consentAvailable = false;
            consent.PreferenceType = event.value === 'DOCS_PLAN_ONLINE' ? '1' : '2';
            consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
            consent.PreferenceAttributes = [
              {
                Key: 'PS_Update_Type',
                Value: 'A'
              },
              {
                Key: 'PS_EventID',
                Value: sessionId
              },
              {
                Key: 'PS_SystemName',
                Value: 'MyBlue_PC_Web'
              },
              {
                Key: 'ConsentVerNo',
                Value: this.getConsent.consentLanguageId
              }
            ];
            consent.CustomerDate = this.getConsent.consentTS;
            consent.CID = this.prefCID;
          }
        });
        if (!consentAvailable) {
          this.changedItem = [...this.changedItem, consent];
        }
      } else {
        // If user has no preference
        let tempItem: any = {};
        let consent: any = {};
        //consent object creation
        consent.PreferenceType = event.value === 'DOCS_PLAN_ONLINE' ? '1' : '2';
        consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
        consent.PreferenceAttributes = [
          {
            Key: 'PS_Update_Type',
            Value: 'A'
          },
          {
            Key: 'PS_EventID',
            Value: sessionId
          },
          {
            Key: 'PS_SystemName',
            Value: 'MyBlue_PC_Web'
          },
          {
            Key: 'ConsentVerNo',
            Value: this.getConsent.consentLanguageId
          }
        ];
        consent.CustomerDate = this.getConsent.consentTS;
        consent.CID = this.prefCID;
        // email and mail object creation
        this.filterListReverse.map(item => {
          tempItem = {};
          tempItem.PreferenceType = item.ID == event.value ? '1' : '2';
          tempItem.FilterID = item.ID;
          tempItem.CustomerDate = this.date.transform(new Date(), 'M/d/yyyy h:m:s aa');
          tempItem.PreferenceAttributes = [
            {
              Key: 'PS_Update_Type',
              Value: 'A'
            },
            {
              Key: 'PS_EventID',
              Value: sessionId
            },
            {
              Key: 'PS_SystemName',
              Value: 'MyBlue_PC_Web'
            },
            {
              Key: 'ConsentVerNo',
              Value: this.getConsent.consentLanguageId
            }
          ];
          tempItem.CID = this.prefCID;
          this.changedItem.push(tempItem);
        });
        this.changedItem = [...this.changedItem, consent];
        console.log('tempitem', this.changedItem);
      }
    }
  }

  submitPrefernce() {
    if (!this.profile.isVerifiedEmail) {
      sessionStorage.setItem('communicationPreferencePath', 'communication-preferences');
      this.verifyEmail();
    } else {
      this.globalService.updatePreferences(this.changedItem).subscribe(res => {
        console.log('res', res);
        if (res.errormessage) {
          this.router.navigate(['/myprofile']).then(() => {
            this.alertService.setAlert(this.errorText, '', AlertType.Failure);
          });
        } else {
          sessionStorage.removeItem('preferences');
          let submitObject = this;
          this.globalService.getPreferences().subscribe(updatedpref => {
            sessionStorage.setItem('preferences', JSON.stringify(updatedpref.message));
            let selectedFilterId = '';
            let fpoPreferenceUrl = '';
            submitObject.preferenceObject = updatedpref.message;
            if (submitObject.preferenceObject.Preferences) {
              submitObject.preferenceObject.Preferences.map(item => {
                if (item.PreferenceType == '1') {
                  selectedFilterId = item.FilterID;
                }
              });
              if (selectedFilterId === 'DOCS_PLAN_MAIL') {
                fpoPreferenceUrl = submitObject.constants.drupalTestUrl + '/page/preference-center';
              } else {
                fpoPreferenceUrl = submitObject.constants.drupalTestUrl + '/page/home-promoblock2';
              }
            } else {
              fpoPreferenceUrl = submitObject.constants.drupalTestUrl + '/page/preference-center';
            }
            submitObject.profileService.preferencePromo(fpoPreferenceUrl);
            submitObject.router.navigate(['/myprofile']).then(() => {
              submitObject.alertService.setAlert(submitObject.successText, '', AlertType.Success);
            });
          });
        }
      });
    }
  }

  verifyEmail(emailId?: string) {
    this.alertService.clearError();
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
      this.sendcommchlaccesscode(emailId ? emailId : this.displayEmailAddress, '').subscribe(
        res => {
          if (res['result'] === '0') {
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.displayEmailAddress);
            sessionStorage.setItem('maskedVerifyPhone', 'N');
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    } else {
      this.sendaccesscode('EMAIL', emailId ? emailId : this.displayEmailAddress).subscribe(
        res => {
          if (res['result'] === '0') {
            const communicationChannel = this.http.handleDecryptedResponse(res);
            sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
            const userId = sentMailId && sentMailId['commChannel'];
            this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
            sessionStorage.setItem('maskedVerifyPhone', 'N');
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    }
  }

  private sendaccesscode(commChannelType, commChannel) {
    return this.profileService.sendaccesscode(commChannelType, commChannel);
  }

  private sendcommchlaccesscode(email, mobile) {
    return this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, ''));
  }

  navigateToVerifyScreen() {
    this.router.navigate(['/myprofile/verify']).then(() => {
      this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
    });
  }

  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }

  ngOnDestroy() {}
}
