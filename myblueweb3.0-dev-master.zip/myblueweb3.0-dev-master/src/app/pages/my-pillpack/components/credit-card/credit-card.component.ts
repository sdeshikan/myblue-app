import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  Output,
  EventEmitter,
  Input
} from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, FormArray, FormControl, Validators, ValidatorFn, NgForm } from '@angular/forms';
import { AuthService } from '../../../../shared/shared.module';

declare var stripe: any;
declare var elements: any;
declare let $: any;
@Component({
  selector: 'app-credit-card',
  templateUrl: './credit-card.component.html',
  styleUrls: ['./credit-card.component.scss']
})
export class CreditCardComponent implements AfterViewInit, OnInit, OnDestroy {
  [x: string]: any;
  public isCSV: boolean = false;
  public isPSV: boolean = false;
  @ViewChild('cardInfo') cardInfo: ElementRef;
  @ViewChild('cardNumber') cardNumber: ElementRef;
  @ViewChild('cardCVC') cardCvc: ElementRef;
  @ViewChild('cardExpiry') cardExpiry: ElementRef;
  @Input('otcSummaryTotal') otcSummaryTotal: number;
  @Input('ShowCreditCard') ShowCreditCard: string;
  @Input('estimatedOrderTotal') estimatedOrderTotal: number;
  @Input('maintenanceMedicationsSummaryTotal') maintenanceMedicationsSummaryTotal: number;
  @Input('hasMaintenanceMeds') hasMaintenanceMeds: boolean;
  @Input('isAddingOTC') isAddingOTC: boolean;
  @Input('ismobile') ismobile: boolean;
  @Output() moveNextEvent = new EventEmitter<any>();
  @Input('selectedMedications') selectedMedications: any[];
  @Input('selectedOTCs') selectedOTCs: any[];
  card: any;
  cardNumberHandler = this.onChangeCardNumberError.bind(this);
  cardExpiryHandler = this.onChangeCardExpiryError.bind(this);
  cardCvcHandler = this.onChangeCardCvcError.bind(this);
  error: any;
  cardNumberError: any;
  cardExpiryError: any;
  cardCvcError: any;
  myToken: any;
  paymentHeaderText = 'PillPack Payment Information';
  checkout: FormGroup;
  isFSAorHSA: true;
  paymentDisclamier: string =
    "You're almost done signing up for PillPack! Enter your credit card, or health financial account debit card information below. PillPack is responsible for managing all transactions and payments. Your credit card/debit card will not be charged until your first order is shipped. Blue Cross Blue Shield of Massachusetts will not store or maintain your credit card or debit card information.";
  impersonate: boolean = true;
  constructor(private cd: ChangeDetectorRef, private authservice: AuthService) {
    //this.card.clear();
  }

  ngOnInit() {
    $('#AgreeWindow').modal({ dismissible: true });
    $('#openOtherPartnerSite').modal({ dismissible: true });
    this.impersonate = this.authservice.impersonation();
  }
  openPillPackSite(link) {
    sessionStorage.setItem('consentLink', link);
    $('#openPillPackSite').modal('open');
  }
  closeOtherPartnerSite() {
    $('#openOtherPartnerSite').modal('close');
  }
  TCPV() {
    $('#AgreeWindow').modal('open');
  }
  ChildAgreeModal() {
    $('#AgreeWindow').modal('open');
  }
  PharmacAagreeModal() {
    $('#AgreeWindow').modal('open');
  }
  closeEmailModals() {
    this.isCSV = false;
    this.isPSV = false;
    $('#AgreeWindow').modal('close');
  }

  ngAfterViewInit() {
    // Floating labels
    var inputs = document.querySelectorAll('.credit-card-container .input');
    Array.prototype.forEach.call(inputs, function(input) {
      input.addEventListener('focus', function() {
        input.classList.add('focused');
      });
      input.addEventListener('blur', function() {
        input.classList.remove('focused');
      });
      input.addEventListener('keyup', function() {
        if (input.value.length === 0) {
          input.classList.add('empty');
        } else {
          input.classList.remove('empty');
        }
      });
    });

    var elementStyles = {
      base: {
        color: '#32325D',
        fontWeight: 500,
        fontFamily: 'Roboto',
        fontSize: '16px',

        fontSmoothing: 'antialiased',
        '::placeholder': {
          color: '#CFD7DF'
        },
        ':-webkit-autofill': {
          color: '#e39f48'
        }
      },
      invalid: {
        color: '#E25950',

        '::placeholder': {
          color: '#FFCCA5'
        }
      }
    };

    var elementClasses = {
      focus: 'focused',
      empty: 'empty',
      invalid: 'invalid'
    };

    this.card = elements.create('cardNumber', {
      style: elementStyles,
      classes: elementClasses
    });
    this.card.mount(this.cardNumber.nativeElement);
    this.card.addEventListener('change', this.cardNumberHandler);

    this.card = elements.create('cardExpiry', {
      style: elementStyles,
      classes: elementClasses
    });
    this.card.mount(this.cardExpiry.nativeElement);
    this.card.addEventListener('change', this.cardExpiryHandler);

    this.card = elements.create('cardCvc', {
      style: elementStyles,
      classes: elementClasses
    });
    this.card.mount(this.cardCvc.nativeElement);

    this.card.addEventListener('change', this.cardCvcHandler);
  }

  onChangeCardNumberError({ error }) {
    if (error) {
      this.cardNumberError = error.message;
    } else {
      this.cardNumberError = null;
    }
    this.cd.detectChanges();
  }

  onChangeCardExpiryError({ error }) {
    if (error) {
      this.cardExpiryError = error.message;
    } else {
      this.cardExpiryError = null;
    }
    this.cd.detectChanges();
  }

  onChangeCardCvcError({ error }) {
    if (error) {
      this.cardCvcError = error.message;
    } else {
      this.cardCvcError = null;
    }
    this.cd.detectChanges();
  }

  parentSumbit({ stepNumber: number, tokenId: tokenId }) {
    this.moveNextEvent.emit({ number, tokenId });
  }

  async onSubmit(form: NgForm) {
    await stripe.createToken(this.card).then(res => {
      if (res.error) {
        console.log('Something is wrong:', res.error);
        //this.parentSumbit({stepNumber:3, tokenId:''});
      } else {
        console.log('Success!', res.token);

        this.parentSumbit({ stepNumber: 5, tokenId: res.token.id });
        // ...send the token to the your backend to process the charge
      }
    });
  }

  ngOnDestroy() {
    this.card.removeEventListener('change', this.cardNumberHandler);
    this.card.removeEventListener('change', this.cardExpiryHandler);
    this.card.removeEventListener('change', this.cardCvcHandler);
    this.card.destroy();
  }
}
