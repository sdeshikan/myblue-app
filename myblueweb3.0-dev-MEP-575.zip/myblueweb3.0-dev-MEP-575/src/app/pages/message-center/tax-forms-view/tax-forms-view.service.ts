import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { AuthHttp } from '../../../shared/services/auth-http.service';

@Injectable()
export class TaxFormService {

    constructor(private http: AuthHttp) { }

    getTaxForms(year: string) {
        if (year) {
            return this.http.get('../../../../assets/tax-forms-' + year + '.json').pipe(data => data);
        }
    }
}

