import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ReimbursementErrorPage } from './reimbursement-error.page';
import { RouterModule } from "@angular/router";

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule],
  declarations: [ReimbursementErrorPage]
})
export class ReimbursementErrorModule {}
