
import { Component, OnInit, Input, EventEmitter, Output, SimpleChanges } from '@angular/core';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import { ClearSearchResultFlagInterface } from '../modals/interfaces/fad-search-list.interface';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import { ClearSearchResultFlagModel } from './../modals/fad-search-list.modal';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import { FiltersMetadata, SortMetadata } from '../modals/getSearchByProfessional.model';
import { FadSearchFilterComponentOutputModelInterface } from '../modals/interfaces/fad-search-filter.interface';
import { FadSpecialtyFilterComponentOutputModel } from '../modals/fad-search-filter.modal';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';

@Component({
  selector: 'app-fad-no-docs-page',
  templateUrl: './fad-no-docs-page.component.html',
  styleUrls: ['./fad-no-docs-page.component.scss']
})
export class FadNoDocsPageComponent implements OnInit {
  @Output('componentOutput') componentOutput = new EventEmitter<FadSearchFilterComponentOutputModelInterface>();
  @Input('componentInput') componentInput: FadNoDocsPageInputDataModelInterface;
  @Input('isFilterChanged') isFilterChanged: boolean;

  public searchText: string = '';
  public withFilterFlag: boolean = false;
  public filterCategories: string[]=[];
  filterChanged: boolean;
  filterMetaData: FiltersMetadata;
  sortMetaData: SortMetadata;
  public outputTransaction: FadSearchFilterComponentOutputModelInterface = new FadSpecialtyFilterComponentOutputModel();
  constructor(private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadSearchListService) { }

  ngOnInit() {
    try {
      if (this.fadSearchResultsService.getSearchCriteria()) {
        this.searchText = this.fadSearchResultsService.getSearchCriteria().getSearchText().getSimpleText();
          this.searchText = this.searchText.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
          this.searchText = this.searchText.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
        if (this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.professional) {
          this.filterCategories = this.fadSearchResultsService.getFilterCategories();
        } else if(this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.facility) {
          this.filterCategories = this.fadSearchResultsService.getFacilityFilterCategories();
        }
        else{
          this.filterCategories = this.fadSearchResultsService.getSpecialtyFilterCategories();
        }
      }

      this.withFilterFlag = (this.componentInput && this.componentInput.type && this.componentInput.type != "") ? true : false;
      // this.filterChanged = this.fadSearchResultsService.filterChanged;

    } catch (exception) {
      
    }
  }

  // ngDoCheck() {
  //   try {
  //     console.log(true);
  //   }
  //   catch (exception) {
  //     this.bcbsmaErrorHandler.logError(exception, BcbsmaConstants.modules.fadModule,
  //       FadConstants.components.fadNoDocsPageComponent,
  //       FadConstants.methods.ngOnInit);
  //   }
  // }
  public clearFilter() {
    // const searchResultFlagObj: ClearSearchResultFlagInterface = new ClearSearchResultFlagModel();
    // searchResultFlagObj.clearFlag = true;
    // searchResultFlagObj.type = (this.componentInput && this.componentInput.type != "") ? this.componentInput.type : null;
    // this.fadSearchResultsService.clearFilterFlagSubject.next(searchResultFlagObj);
    this.filterMetaData = new FiltersMetadata();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = new FiltersMetadata();
    this.outputTransaction.sortCriteriaData = new SortMetadata();
    this.outputTransaction.resourcetype = this.componentInput.type;
    this.componentOutput.emit(this.outputTransaction);
  }
}
