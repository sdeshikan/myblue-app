import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
import { Component, ElementRef, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import moment from 'moment';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { HeaderService } from '../../../shared/layouts/header/header.service';
import { AlertService } from '../../../shared/services/alert.service';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { ConstantsService } from '../../../shared/shared.module';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import { MessageCenterService } from '../message-center.service';
import {
  MessageCenterSearchCompOutputModelInterface,
  MessageCenterSearchFilterDateRanges,
  MessageDetailsSearchResponseModelInterface
} from '../modals/interfaces/message-center-search.interface';
import { NoDocumentsFoundComponentConsumer, NoSearchResultsFoundComponentConsumer } from '../modals/interfaces/message-center.interface';
import { UpdateMsgListingAndMemberAlertsRequestInterface } from '../modals/interfaces/message.interface';
import { MessageDetailsSearchResponseModel, SearchCriteriaItem } from '../modals/message-center-search.model';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import { InboxMessageModel, UpdateMsgListingAndMemberAlertsRequestModel } from '../modals/messages.model';
import { MessageCenterUtilities } from '../utils/message-center.utilities';
import { NotificationsAlertsService } from './notifications-alerts.service';

@Component({
  selector: 'app-notifications-alerts',
  templateUrl: './notifications-alerts.component.html',
  styleUrls: ['./notifications-alerts.component.scss']
})
export class NotificationsAlertsComponent implements OnInit, NoDocumentsFoundComponentConsumer, NoSearchResultsFoundComponentConsumer {

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;


  public noDocsFound: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public noSearchResultsFound: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();

  public searchCriteriaData: MessageDetailsSearchResponseModelInterface = new MessageDetailsSearchResponseModel();
  public msgCount = 0;
  public isDeleteListing = false;
  public isUndoListing = false;
  public isDisplayBanner = false;
  public isHideBanner = false;
  public isDisplayUndo = false;
  public msgListing: InboxMessageModel[] = [];
  public isMsgNotAvailable = false;
  public isNoSearchResults = false;
  public mobileHideByFilterOverlay: boolean;
  public applyFilterFlag: boolean;
  public showClearLink = false;
  public filterMsgCount: any[];

  private utils: MessageCenterUtilities = new MessageCenterUtilities();
  private deletedMsgListing: any = [];
  private deletedMessageIds: string;
  private undoTimeout: any;
  private memberId: string;
  public fpoTargetUrl = this.constants.drupalTestUrl + '/page/myinbox-nomessages';

  constructor(
    public el: ElementRef,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationsAlertsService,
    private messageCenterService: MessageCenterService,
    private headerService: HeaderService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private constants: ConstantsService,
    private location: Location,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.noDocsFound.mode = MessageCenterConstants.flags.messagesMode;
    this.noSearchResultsFound.mode = MessageCenterConstants.flags.noSearchResultsMode;
  }

  public clearFilter() {
    const clearButtonInFilterSection: HTMLButtonElement = document.getElementsByClassName('clear-filter-button')[0] as HTMLButtonElement;
    clearButtonInFilterSection.click();
  }

  ngOnInit() {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewNotificationsAlerts);
      this.setMsgListing();
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  ionViewWillEnter() {
    try {
      this.setMsgListing();
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  goBack() {
    // this.location.back();
    this.router.navigate(['../tabs/myInbox'], { replaceUrl: true });
  }
  // Show banner section on window scroll to clear and delete message listing
  @HostListener('window:scroll', ['$event'])
  showBannerOnWindowScroll($event) {
    const msgListingPos = this.el.nativeElement.offsetTop;
    const windowScrollPos = window.pageYOffset;

    if (windowScrollPos > msgListingPos) {
      if (this.msgCount > 0) {
        this.isDisplayBanner = true;
        this.isHideBanner = true;
      }
    } else {
      this.isDisplayBanner = false;
      this.isHideBanner = false;
    }
  }

  public createSearchCriteria(): MessageDetailsSearchResponseModelInterface {
    const searchCriteriaData: MessageDetailsSearchResponseModelInterface = new MessageDetailsSearchResponseModel();
    const keywordList: string[] = [];
    try {
      const now = moment(new Date());
      let dateRangeInfo: MessageCenterSearchFilterDateRanges = {
        all_dates: 0,
        last_30_days: 0,
        last_60_days: 0,
        last_90_days: 0,
        year_to_date: 0
      };
      const uniqueCategoryMap: string[] = [];
      this.msgListing.map(msgListItem => {
        keywordList.push(msgListItem.ShortText);
        keywordList.push(msgListItem.LongText);

        const categoryName: string = msgListItem.category;
        dateRangeInfo = this.utils.trackAgeOfEntity(now, msgListItem.messageUpdatedDateTime, dateRangeInfo);

        if (uniqueCategoryMap.indexOf(categoryName) === -1) {
          uniqueCategoryMap.push(categoryName);
          searchCriteriaData.addCategoryFilter(new SearchCriteriaItem().setCriteriaName(categoryName).setMatchingResultsCount(1));
        } else {
          searchCriteriaData.categoryFilterMap.get(categoryName).matchingResultsCount++;
        }
        return;
      });

      searchCriteriaData.keywordList = keywordList;

      searchCriteriaData
        .addSortByFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.sortByFilters.mostRecent))
        .addSortByFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.sortByFilters.oldestFirst))
        .addSortByFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.sortByFilters.unreadFirst))

        .addDateFilter(
          new SearchCriteriaItem()
            .setCriteriaName(MessageCenterConstants.filters.dateFilters.last30Days)
            .setMatchingResultsCount(dateRangeInfo.last_30_days)
        )
        .addDateFilter(
          new SearchCriteriaItem()
            .setCriteriaName(MessageCenterConstants.filters.dateFilters.last60Days)
            .setMatchingResultsCount(dateRangeInfo.last_60_days)
        )
        .addDateFilter(
          new SearchCriteriaItem()
            .setCriteriaName(MessageCenterConstants.filters.dateFilters.last90Days)
            .setMatchingResultsCount(dateRangeInfo.last_90_days)
        )
        .addDateFilter(
          new SearchCriteriaItem()
            .setCriteriaName(MessageCenterConstants.filters.dateFilters.yearToDate)
            .setMatchingResultsCount(dateRangeInfo.year_to_date)
        )
        .addDateFilter(
          new SearchCriteriaItem()
            .setCriteriaName(MessageCenterConstants.filters.dateFilters.allDates)
            .setMatchingResultsCount(dateRangeInfo.all_dates)
        )
        .addDateFilter(new SearchCriteriaItem().setCriteriaName(MessageCenterConstants.filters.dateFilters.customDateRange));

      this.searchCriteriaData = searchCriteriaData;
      this.noSearchResultsFound.searchCriteria = searchCriteriaData;
    } catch (exception) {
      console.error(exception, null, 2);
    }

    return searchCriteriaData;
  }

  public onSearch(searchFilterOptions: MessageCenterSearchCompOutputModelInterface): void {
    const searchCriteriaData: MessageDetailsSearchResponseModelInterface = searchFilterOptions.searchCriteriaData;
    this.mobileHideByFilterOverlay = searchFilterOptions.filterOverlayFlag;
    // if the emit event has not been triggered by apply or clear filters then do nothing
    if (searchCriteriaData === null) {
      return;
    }

    let messageList: InboxMessageModel[];
    this.applyFilterFlag = searchFilterOptions.applyFilter;
    try {
      this.showClearLink = false;

      // clear previous search results from view
      this.msgListing = this.utils.clearPreviousSearchFlags(this.msgListing) as InboxMessageModel[];

      // clone the existing msg list to avoid performance issues due to intermitten model changes in view
      messageList = Object.assign([], this.msgListing);

      // sort the message list as necessary based on the user selection
      const sortFilterKeys: string[] = searchCriteriaData.sortByFilterMap.getKeys();
      for (const sortKey of sortFilterKeys) {
        const sortCriteria = searchCriteriaData.sortByFilterMap.get(sortKey);
        if (sortCriteria.criteriaName === MessageCenterConstants.filters.sortByFilters.mostRecent && sortCriteria.criteriaSelected) {
          // tslint:disable-next-line:variable-name
          messageList.sort((msgItem_a, msgItem_b) => {
            const date1 = moment(new Date(msgItem_a.messageUpdatedDateTime));
            const date2 = moment(new Date(msgItem_b.messageUpdatedDateTime));
            return moment.duration(date2.diff(date1)).asDays() || this.compareStringField(msgItem_b.ShortText, msgItem_a.ShortText);
          });
          break;
        } else if (
          sortCriteria.criteriaName === MessageCenterConstants.filters.sortByFilters.oldestFirst &&
          sortCriteria.criteriaSelected
        ) {
          this.showClearLink = true;
          // tslint:disable-next-line:variable-name
          messageList.sort((msgItem_a, msgItem_b) => {
            const date1 = moment(new Date(msgItem_a.messageUpdatedDateTime));
            const date2 = moment(new Date(msgItem_b.messageUpdatedDateTime));
            return moment.duration(date1.diff(date2)).asDays();
          });
          break;
        } else if (
          sortCriteria.criteriaName === MessageCenterConstants.filters.sortByFilters.unreadFirst &&
          sortCriteria.criteriaSelected
        ) {
          this.showClearLink = true;
          messageList
            // tslint:disable-next-line:variable-name
            .sort((msgItem_a, msgItem_b) => {
              const date1 = moment(new Date(msgItem_a.messageUpdatedDateTime));
              const date2 = moment(new Date(msgItem_b.messageUpdatedDateTime));
              return moment.duration(date2.diff(date1)).asDays();
            })
            // tslint:disable-next-line:variable-name
            .sort((msgItem_a, msgItem_b) => {
              const refA = msgItem_a.isRead === 'true' ? 1 : 0;
              const refB = msgItem_b.isRead === 'true' ? 1 : 0;
              return refA - refB;
            });
          break;
        }
      }

      const categoryFilterKeys: string[] = searchCriteriaData.categoryFilterMap.getKeys();
      const selectedCategoryNames: string[] = [];
      for (const categoryKey of categoryFilterKeys) {
        if (searchCriteriaData.categoryFilterMap.get(categoryKey).criteriaSelected) {
          selectedCategoryNames.push(categoryKey);
        }
      }

      // do nothing if no category is selected and skip to next step
      // if atleast one is selected hide message items in categories that are not selected
      if (selectedCategoryNames.length > 0) {
        this.showClearLink = true;
        messageList = messageList.map(msgListItem => {
          const categoryName: string = msgListItem.category;
          // tslint:disable-next-line:prefer-conditional-expression
          if (selectedCategoryNames.indexOf(categoryName) !== -1) {
            msgListItem.hideEntityFromDisplay = false;
          } else {
            msgListItem.hideEntityFromDisplay = true;
          }
          return msgListItem;
        });
      } else {
        messageList = messageList.map(msgListItem => {
          msgListItem.hideEntityFromDisplay = false;
          return msgListItem;
        });
      }

      // apply date filters to the result obtained from the previous step
      const refMessageList = Object.assign([], messageList);
      let refMessageEntityDisplayCount = 0;
      refMessageList.map(refMsgEntity => {
        if (refMsgEntity.hideEntityFromDisplay) {
          refMessageEntityDisplayCount++;
        }
      });

      messageList = this.utils.doDateFilter(
        refMessageList,
        searchCriteriaData,
        MessageCenterConstants.attributes.messageUpdatedDateTime
      ) as InboxMessageModel[];
      let messageEntityDisplayCount = 0;
      messageList.map(msgList => {
        if (msgList.hideEntityFromDisplay) {
          messageEntityDisplayCount++;
        }
      });

      if (refMessageEntityDisplayCount !== messageEntityDisplayCount) {
        this.showClearLink = true;
      }

      messageList = this.utils.doKeywordFilter(messageList, searchCriteriaData) as InboxMessageModel[];
      // check if atleast one file item matches the search results. if not display the 'no-documents-found-component'
      // tslint:disable-next-line:prefer-conditional-expression
      if (
        !messageList.some(msgListItem => {
          return !msgListItem.hideEntityFromDisplay;
          // return !this.msgListingResponse.hideEntityFromDisplay;
        })
      ) {
        this.isNoSearchResults = true;
      } else {
        this.isNoSearchResults = false;
      }

      // return the result to enable view-model binding
      this.msgListing = messageList;
      this.filterMsgCount = messageList.filter(oMessageList => oMessageList.hideEntityFromDisplay === false);
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public setMsgListing() {
    this.notificationService.getMsgListing().subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
          if (apiData.hasOwnProperty('inboxmessageresponse') && apiData.inboxmessageresponse.length) {
            const msgListing = apiData.inboxmessageresponse.filter(oMsgListing => oMsgListing.isDeleted === 'false');
            if (msgListing.length) {
              this.msgListing = msgListing;
              this.createSearchCriteria();
              setTimeout(() => {
                if (
                  Object.keys(this.messageCenterService.msgListingResponse).length &&
                  this.messageCenterService.msgListingResponse.type === 'delete'
                ) {
                  this.deleteMsgListing(this.messageCenterService.msgListingResponse);
                }
                // tslint:disable-next-line:no-magic-numbers
              }, 100);
            } else {
              this.isMsgNotAvailable = true;
            }
          }
        } else {
          // tslint:disable-next-line:no-magic-numbers
          if (apiData.result === -90704) {
            this.isMsgNotAvailable = true;
          } else {
            this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
          }
        }
      } else {
        this.isMsgNotAvailable = true;
      }
    });
  }

  public getSelectedMsgListing(oMsgListing, oMsgCheckBox) {
    console.log('selected msg', oMsgListing, oMsgCheckBox);
    try {
      if (!this.isDeleteListing && this.isUndoListing) {
        this.msgCount = 0;
      }

      if (oMsgCheckBox.detail.checked) {
        this.msgCount++;
        oMsgListing.selected = true;
        this.isDeleteListing = true;
      } else {
        this.msgCount--;
        oMsgListing.selected = false;
      }

      if (this.msgCount <= 0) {
        this.isDeleteListing = false;
      }

      this.isUndoListing = false;
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public deleteMsgListing(oMsgListingResp?: InboxMessageModel) {
    try {
      this.isDeleteListing = false;
      this.isUndoListing = true;
      this.deletedMsgListing = [];
      this.deletedMessageIds = '';

      if (oMsgListingResp) {
        this.msgCount = 1;
        this.deletedMessageIds = oMsgListingResp.messageId;
        this.memberId = oMsgListingResp.memberId;
        this.deletedMsgListing.push({
          deletedMsgs: this.msgListing[oMsgListingResp.rowNum],
          deletedMsgIndex: oMsgListingResp.rowNum
        });
        this.msgListing.splice(oMsgListingResp.rowNum, 1);
      } else {
        const msgListingLen: number = this.msgListing.length;
        for (let index = msgListingLen - 1; index >= 0; index -= 1) {
          if (this.msgListing[index].selected) {
            this.memberId = this.msgListing[index].memberId;
            if (!this.deletedMessageIds) {
              this.deletedMessageIds = this.msgListing[index].messageId;
            } else {
              this.deletedMessageIds += '|' + this.msgListing[index].messageId;
            }
            this.deletedMsgListing.push({ deletedMsgs: this.msgListing[index], deletedMsgIndex: index });
            this.msgListing.splice(index, 1);
          }
        }
      }

      this.removeUndoOption();
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public undoMsgListing() {
    try {
      this.isDeleteListing = false;
      this.isUndoListing = false;
      this.msgCount = 0;

      if (this.undoTimeout) {
        clearTimeout(this.undoTimeout); // Reset the undo timeout
        this.isDisplayUndo = false;
      }

      const deletedMsgListingLen: number = this.deletedMsgListing.length;

      for (let index = deletedMsgListingLen - 1; index >= 0; index -= 1) {
        this.deletedMsgListing[index].deletedMsgs.selected = false;
        this.msgListing.splice(this.deletedMsgListing[index].deletedMsgIndex, 0, this.deletedMsgListing[index].deletedMsgs);
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public removeUndoOption() {
    try {
      // let self=this;
      if (this.undoTimeout) {
        clearTimeout(this.undoTimeout); // Reset the undo timeout
        this.isDisplayUndo = false;
      }

      // To remove the undo option after 3 secs
      this.undoTimeout = setTimeout(() => {
        this.updateMsgListingAndMemberAlerts();
        // tslint:disable-next-line:no-magic-numbers
      }, 30000);
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public clearMsgListing() {
    try {
      this.msgCount = 0;
      this.isDeleteListing = false;
      this.msgListing.forEach(msg => {
        msg.selected = false;
      });
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public showMsgDetails(oMsg, index) {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewNotificationsAlerts_ViewNotificationsAlertsDetails);

      this.messageCenterService.msgListingResponse = oMsg;
      this.messageCenterService.msgListingResponse.rowNum = index;
      sessionStorage.setItem('messageId', oMsg.messageId);
      sessionStorage.setItem('memberId', oMsg.memberId);
      sessionStorage.setItem('category', oMsg.category);
      this.router.navigate(['/tabs/myInbox/notifications-alerts-details']);
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  public updateMsgListingAndMemberAlerts() {
    // tslint:disable-next-line:max-line-length
    const updateMsgListingAndMemberAlertsReqParams: UpdateMsgListingAndMemberAlertsRequestInterface = new UpdateMsgListingAndMemberAlertsRequestModel();

    if (this.deletedMessageIds) {
      updateMsgListingAndMemberAlertsReqParams.deletealertids = this.deletedMessageIds;
    }

    updateMsgListingAndMemberAlertsReqParams.memberId = this.memberId;
    updateMsgListingAndMemberAlertsReqParams.useridin = this.useridin;

    this.notificationService.getUpdateMsgListingAndMemberAlerts(updateMsgListingAndMemberAlertsReqParams).subscribe(apiData => {
      if (apiData && Object.keys(apiData).length) {
        if (apiData.hasOwnProperty('result') && apiData.result !== 0) {
          this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
        } else {
          this.isDisplayUndo = true;
          this.msgCount = 0;
          this.messageCenterService.msgListingResponse.type = '';
          this.applyFilterFlag = false;
          this.setMsgListing();
          this.headerService.unReadMsgCount = apiData.successresponse.unreadMessageCount.toString();
        }
      }
    });
  }

  compareStringField(value1: string, value2: string) {
    if (value1 === value2) {
      return 0;
    }
    return value1 > value2 ? -1 : 1;
  }

  public formattedDate(date: string): string {
    if (moment(date).isValid()) {
      let format = 'MMM dd, y'; // Default Format
      const currentDate = moment().format('YYYY-MM-DD');
      const msgDate = moment(date).format('YYYY-MM-DD');

      if (moment(msgDate).isSame(currentDate, 'day')) {
        // For Checking same day or not
        format = 'hh:mm a';
      } else if (moment(msgDate).isSame(currentDate, 'year')) {
        // For Checking same year or not
        format = 'MMM dd';
      }

      return this.datePipe.transform(date, format);
    }

    return '';
  }
}
