import { FacilityFiltersMetadataModel } from './getSearchByFacility.model';
import { FiltersMetadata, SortMetadata } from './getSearchByProfessional.model';
import {
  FadFacilitySearchFilterComponentOutputModelInterface,
  FadSearchFilterComponentOutputModelInterface,
  FadSpecialtyFilterComponentOutputModelInterface,
  FilterCheckboxItemInterface,
  FilterListItemInterface,
  FilterRadioItemInterface,
  GrpHospitalAffiliationFilterListItemInterface
} from './interfaces/fad-search-filter.interface';
import { FacilityFiltersMetadataInterface } from './interfaces/getSearchByFacility-models.interface';

export class FadSearchFilterComponentOutputModel implements FadSearchFilterComponentOutputModelInterface {
  filterOverlayFlag = false;
  filterCriteriaData: FiltersMetadata = new FiltersMetadata();
  sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FadFacilitySearchFilterComponentOutputModel implements FadFacilitySearchFilterComponentOutputModelInterface {
  filterOverlayFlag = false;
  filterCriteriaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
  sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FadSpecialtyFilterComponentOutputModel implements FadSpecialtyFilterComponentOutputModelInterface {
  filterOverlayFlag = false;
  filterCriteriaData: FiltersMetadata = new FiltersMetadata();
  sortCriteriaData: SortMetadata = new SortMetadata();
}

export class FilterListItem implements FilterListItemInterface {
  name: string;
  value: string;
  count: string;
  default: string;
  selected: string;
}

export class FilterRadioItem implements FilterRadioItemInterface {
  name: string;
  value: string;
  checked: boolean;
}

export class FilterCheckboxItem implements FilterCheckboxItemInterface {
  value: string;
  count: string;
  default: string;
  selected: string;
}

export class GrpHospitalAffiliationFilterListItem implements GrpHospitalAffiliationFilterListItemInterface {
  name: string;
  value: string;
  count: string;
  category: string;
  default: string;
  selected: string;
}
