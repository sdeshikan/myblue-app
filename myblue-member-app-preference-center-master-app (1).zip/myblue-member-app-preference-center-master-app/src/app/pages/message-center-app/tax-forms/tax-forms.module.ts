import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { TaxFormsState } from '../../../store/state/taxforms.state';
import { TaxFormsService } from '../services/tax-forms.service';
import { TaxFormListPageModule } from './pages/tax-form-list/tax-form-list.module';
import { TaxFormListPage } from './pages/tax-form-list/tax-form-list.page';
import { TaxFormViewPageModule } from './pages/tax-form-view/tax-form-view.module';
import { TaxFormViewPage } from './pages/tax-form-view/tax-form-view.page';



const routes: Routes = [
  {
    path: '',
    component: TaxFormListPage
  },
  {
    path: 'view',
    component: TaxFormViewPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    RouterModule.forChild(routes),
    TaxFormListPageModule,
    TaxFormViewPageModule
  ],
  providers: [
    TaxFormsService
  ]
})
export class TaxFormsModule {}
