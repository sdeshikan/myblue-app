import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reimbursement-not-eligible',
  templateUrl: './reimbursement-not-eligible.component.html',
  styleUrls: ['./reimbursement-not-eligible.component.scss']
})
export class ReimbursementNotEligibleComponent {
  constructor(private router: Router) {}

  openLink() {
    this.router.navigate(['/tabs/home']);
  }
}
