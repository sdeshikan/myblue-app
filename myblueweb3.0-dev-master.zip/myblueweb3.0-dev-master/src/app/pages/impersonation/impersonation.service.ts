import { Injectable } from '@angular/core';
import { AuthService } from '../../shared/services/auth.service';
import { AuthHttp } from '../../shared/services/authHttp.service';
import * as CryptoJS from 'crypto-js';

@Injectable()
export class ImpersonationService {
  private _encryptSecretKey: string = '123456$#@$^@1ERF';

  constructor(private authService: AuthService, private authHttp: AuthHttp) {}

  impersonation(request) {
    this.authService.cryptoToken = null;
    return this.authHttp.impersonation(request);
  }

  decryptData(data: string): string {
    try {
      var key = CryptoJS.enc.Utf16.parse(this._encryptSecretKey);
      var iv = CryptoJS.enc.Utf16.parse(this._encryptSecretKey);
      var decrypted = CryptoJS.AES.decrypt(data, key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });

      return decrypted.toString(CryptoJS.enc.Utf16);
      //const bytes = CryptoJS.AES.decrypt(data.trim(), this._encryptSecretKey.trim()).toString(CryptoJS.enc.Utf8);
      //return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      // return bytes;
    } catch (e) {
      console.log('Impersonation Error on Decryption' + e);
    }
  }
}
