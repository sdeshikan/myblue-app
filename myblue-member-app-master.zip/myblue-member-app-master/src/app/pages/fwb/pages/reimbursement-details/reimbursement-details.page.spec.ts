import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReimbursementDetailsPage } from './reimbursement-details.page';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxCurrencyModule } from 'ngx-currency';
import { MaskApplierService, MaskDirective, MaskPipe, NgxMaskModule } from 'ngx-mask';
import { NgxsModule } from '@ngxs/store';
import { IonicModule, ModalController, PopoverController } from '@ionic/angular';
import { RouterTestingModule } from '@angular/router/testing';
import { Camera } from '@ionic-native/camera/ngx';
import { AuthService } from '../../../../shared/services/auth.service';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ReimbursementDetailsPage', () => {
  let component: ReimbursementDetailsPage;
  let fixture: ComponentFixture<ReimbursementDetailsPage>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        NgxCurrencyModule,
        IonicModule,
        NgxMaskModule.forRoot({}),
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([])
      ],
      declarations: [ReimbursementDetailsPage],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        },
        Camera,
        AuthService,
        ConstantsService,
        MaskApplierService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReimbursementDetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
