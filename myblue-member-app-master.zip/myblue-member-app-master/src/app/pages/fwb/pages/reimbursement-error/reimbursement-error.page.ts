import { ChangeDetectionStrategy, Component } from "@angular/core";
import { NavController } from "@ionic/angular";

@Component({
  selector: 'app-reimbursement-error',
  templateUrl: './reimbursement-error.page.html',
  styleUrls: ['./reimbursement-error.page.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReimbursementErrorPage {
  constructor(private navCtrl: NavController) {}
  tryAgain() {
    this.navCtrl.navigateForward('/tabs/fitness-and-weightloss');
  }
}
