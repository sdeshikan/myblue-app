import { Component } from '@angular/core';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { NavController, Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { environment } from '../../../environments/environment';
import { IabService } from '../../shared/services/iab/iab.service';
import { SwrveEventNames, SwrveService } from '../../services/swrve.service';
import { AppSelectors } from '../../store/selectors/app-selectors';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.page.html',
  styleUrls: ['./contact-us.page.scss']
})
export class ContactUsPage {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  isRegisteredUser: boolean;
  chatMember =
    'https://chat.bluecrossma.com/system/templates/chat/bcbs/chat.html?subActivity=Chat&entryPointId=1001&templateName=sunburst' +
    '&languageCode=en&countryCode=US&ver=v11&postChatAttributes=false&eglvrefname=&null&referer=https%3A%2F%2Fmyblue.bluecrossma.com%2F';
  anonymousFeedback = 'https://engage.bluecrossma.com/forms/submit-feedback';
  authenticatedSecureMessage = environment.secureMessageInquiryUrl;
  talkToDoctor = 'https://myblue.bluecrossma.com/health-plan/well-connection';

  constructor(
    public swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private swrveService: SwrveService,
    private callNumber: CallNumber,
    private navCtrl: NavController,
    private platform: Platform
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
  }

  openInAppBrowser(url) {
    this.iabService.create(url);
  }

  ionViewWillEnter() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ContactUs);
    this.isRegisteredUser = this.scopeName.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    if (this.isAuthenticatedUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAuthenticated_ContactUs);
    } else if (this.isRegisteredUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeRegistered_ContactUs);
    } else if (this.isAnonymousUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAnonymous_ContactUs);
    }
  }

  sendSwerve(event) {
    this.swrveService.sendAppMessage(event);
  }

  callHelpLine(number: string, swrveEventName: string) {
    from(this.callNumber.callNumber(number, true)).subscribe(response => console.log('Launched dialer'));
    this.sendSwerve(swrveEventName);
  }

  goBack() {
    this.navCtrl.back();
  }
}
