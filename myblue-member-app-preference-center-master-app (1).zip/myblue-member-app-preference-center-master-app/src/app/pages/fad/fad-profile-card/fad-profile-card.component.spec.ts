import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadProfileCardComponent } from './fad-profile-card.component';
import { NgxMaskModule } from 'ngx-mask';

describe('FadProfileCardComponent', () => {
  let component: FadProfileCardComponent;
  let fixture: ComponentFixture<FadProfileCardComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgxMaskModule.forRoot(), HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadProfileCardComponent],
      providers: [
        FadSearchResultsService,
        FadDoctorProfileService,
        ConstantsService,
        CallNumber,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadProfileCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
