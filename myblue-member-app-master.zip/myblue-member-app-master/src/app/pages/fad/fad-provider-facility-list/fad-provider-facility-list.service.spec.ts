import { TestBed, inject } from '@angular/core/testing';

import { FadProviderFacilityListService } from './fad-provider-facility-list.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('FadProviderFacilityListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([])],
      providers: [FadProviderFacilityListService, BcbsmaHttpService, AuthHttp, FadSearchResultsService, AuthService, ConstantsService]
    });
  });

  it('should be created', inject([FadProviderFacilityListService], (service: FadProviderFacilityListService) => {
    expect(service).toBeTruthy();
  }));
});
