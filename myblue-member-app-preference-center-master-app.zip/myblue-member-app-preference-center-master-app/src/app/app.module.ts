import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { NgxsRouterPluginModule } from '@ngxs/router-plugin';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { NGXS_PLUGINS, NgxsModule } from '@ngxs/store';
import { StorageServiceModule } from 'angular-webstorage-service';

import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { MomentModule } from 'angular2-moment';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { environment } from '../environments/environment';
import { AppRoutingModule, rootRoutes } from './app-routing.module';
import { AppComponent } from './app.component';
import { TokenInterceptorService } from './interceptors/http-request-interceptor';
import { HttpResponseInterceptor } from './interceptors/http-response.interceptor';
import { ProgressModalComponent } from './modals/progress-modal/progress-modal.component';
import { ProgressModalModule } from './modals/progress-modal/progress-modal.module';
import { ProfileModalComponent } from './pages/my-pillpack-app/profile-modal/profile-modal.component';
import { MyaccountResolver } from './pages/myaccount/myaccount.resolver';
import { MyAccountService } from './pages/myaccount/myaccount.service';
import { NotificationPreferencesResolver } from './pages/notification-preferences-app/notification-preferences.resolver';
import { NotificationPreferencesService } from './pages/notification-preferences-app/notification-preferences.service';
import { JumpScreenComponent } from './pages/sso/jump-screen/jump-screen.component';
import { SsoResolver } from './pages/sso/sso.resolver';
import { SsoService } from './pages/sso/sso.service';
import { InitService } from './services/init.service';
import { SwrveEventNames, SwrveService } from './services/swrve.service';
import { LoadingHelperClass } from './shared/classes/loadingHelper.class';
import { ConsentMeansComponent } from './shared/modals/consent-means/consent-means.component';
import { MyclaimsResolverService } from './shared/routeresolvers/myclaims-resolver.service';
import { MymedsResolverService } from './shared/routeresolvers/mymeds-resolver.service';
import { MyprofileResolverService } from './shared/routeresolvers/myprofile-resolver.service';
import { FilterService } from './shared/services/filter.service';
import { OrderreplacementService } from './shared/services/orderreplacement/orderreplacement.service';
import { SharedModule } from './shared/shared.module';
import { NoMenuResolver } from './shared/utils/nomenu.resolver';
import { logoutPlugin } from './store/ngxs-plugins/app.plugins';
import { AppState } from './store/state/app.state';
import { DeductibleState } from './store/state/deductible.state';
import { FitnessState } from './store/state/fitness.state';
import { TaxFormsState } from './store/state/taxforms.state';
import { PreferenceState } from './store/state/preference.state';
import { NgxStripeModule } from 'ngx-stripe';

export function init_app(appLoadService: InitService) {
  return () => appLoadService.initFeatureFlags();
}

@NgModule({
  declarations: [AppComponent, JumpScreenComponent, ProfileModalComponent, ConsentMeansComponent],
  exports: [RouterModule],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    IonicModule.forRoot(),
    CommonModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot(rootRoutes, { onSameUrlNavigation: 'reload' }),
    CommonModule,
    NgIdleKeepaliveModule.forRoot(),
    IonicStorageModule.forRoot(),
    NgxsModule.forRoot([AppState, FitnessState, TaxFormsState, DeductibleState, PreferenceState], { developmentMode: !environment.production }),
    NgxsRouterPluginModule.forRoot(),
    NgxsSelectSnapshotModule.forRoot(),
    NgxsStoragePluginModule.forRoot(),
    NgxsReduxDevtoolsPluginModule.forRoot({ disabled: environment.production }),
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    TextMaskModule,
    MomentModule,
    StorageServiceModule,
    ProgressModalModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot({ showMaskTyped: true })
  ],
  entryComponents: [ProgressModalComponent, JumpScreenComponent, ProfileModalComponent, ConsentMeansComponent],
  providers: [
    NoMenuResolver,
    FilterService,
    Camera,
    DatePipe,
    TitleCasePipe,
    OrderreplacementService,
    MyprofileResolverService,
    MymedsResolverService,
    MyaccountResolver,
    MyAccountService,
    MyclaimsResolverService,
    SsoResolver,
    SsoService,
    NotificationPreferencesService,
    NotificationPreferencesResolver,
    SplashScreen,
    StatusBar,
    SmsRetriever,
    CallNumber,
    InAppBrowser,
    InitService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpResponseInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptorService, multi: true },
    { provide: NGXS_PLUGINS, useValue: logoutPlugin, multi: true },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    {
      provide: APP_INITIALIZER,
      useFactory: init_app,
      deps: [InitService],
      multi: true
    },
    DocumentViewer,
    FileTransfer,
    File,
    FileOpener,
    EmailComposer,
    AppVersion,
    SwrveService,
    SwrveEventNames,
    Deeplinks,
    LocalNotifications,
    AndroidPermissions,
    Geolocation,
    LocationAccuracy,
    Keyboard,
    LoadingHelperClass
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
