import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BenefitData } from '../benefits.model';
import { SelectionService } from './../../../shared/services/downloadForm/selection.service';

@Component({
  selector: 'app-download-reimbursement',
  templateUrl: './download-reimbursement.component.html',
  styleUrls: ['./download-reimbursement.component.scss']
})
export class DownloadReimbursementComponent implements OnInit {
  reimbursementForm: FormGroup;
  isFormSubmitted = false;
  showForm = false;
  buttonCopy: string = 'Continue';
  yearData: any;
  typeofBenefit = [];
  overallBenefits = [];
  onlineSubmission: boolean = false;
  planTitle: string = '';
  showSelectionForm: boolean = false;
  showNoFormPage: boolean = true;
  memberList: any;
  benefitsData: BenefitData = {};
  errorCode: any;
  showIneligibleForm: boolean = false;
  selectionErrorCodes = [-94000, -94001, -94002, -94003, -94004, -94005, -94006, -94007, -94011, -94012, -94013];
  submissionErrorCodes = [-94026, -94027, -94028, -94029, -94030, -94031, -94032, -94033, -94034, -94035];
  ineligibleErrorCodes = [-94008, -94010, -94014, -94015];
  learnMoreLink: string = 'https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss';
  constructor(private fb: FormBuilder, private router: Router, private downloadData: SelectionService) {}

  ngOnInit() {
    this.initializeReimbursementsForm();
  }

  initializeReimbursementsForm() {
    this.downloadData.getYear().subscribe(response => {
      if (response) {
        this.yearData = response.benefits;
        this.showSelectionForm = !!this.yearData;
        this.errorCode = response.result;
        if (this.errorCode) {
          this.checkErrorCodes(this.errorCode);
        }

        let typeSet = false;
        let yearSet = false;

        for (let i = 0; i < this.yearData.length; i++) {
          if (!yearSet) {
            this.reimbursementForm.controls.year.setValue(this.yearData[0].year);
            this.onChange();
            yearSet = true;
          }

          if (this.yearData[i].fitness) {
            if (!typeSet) {
              this.typeofBenefit.push('Fitness');
              this.reimbursementForm.controls.typeOfReimbursement.setValue('Fitness');
              this.updateCTA();
              typeSet = true;
            }
            this.overallBenefits.push(this.yearData[i].year + ' ' + 'Fitness');
          }

          if (this.yearData[i].weightloss) {
            if (!typeSet) {
              this.typeofBenefit.push('Weight Loss');
              this.reimbursementForm.controls.typeOfReimbursement.setValue('Weight Loss');
              this.updateCTA();
              typeSet = true;
            }
            this.overallBenefits.push(this.yearData[i].year + ' ' + 'Weight Loss');
          }
        }
        this.typeofBenefit = this.typeofBenefit.filter((item, index) => this.typeofBenefit.indexOf(item) === index);
        this.saveEmail(response);
      }
    });

    const formGroup = {
      year: ['', Validators.required],
      typeOfReimbursement: ['', [Validators.required]]
    };
    this.reimbursementForm = this.fb.group(formGroup);

    this.showForm = true;
  }

  openMyBlue() {
    this.router.navigate(['/home']);
  }

  onSubmit($event) {
    $event.preventDefault();
    this.isFormSubmitted = true;
    this.checkSelectedForm();
    this.checkErrorCodes(this.errorCode);
    this.downloadData.setBenefitModelData(this.benefitsData);
  }

  checkErrorCodes(errorCode: any) {
    this.benefitsData.selectionErrorCodes = this.selectionErrorCodes;
    this.benefitsData.submissionErrorCodes = this.submissionErrorCodes;
    this.benefitsData.ineligibleErrorCodes = this.ineligibleErrorCodes;

    this.ineligibleErrorCodes.forEach(codeVal => {
      if (codeVal === errorCode) {
        this.showIneligibleForm = true;
      }
    });

    this.selectionErrorCodes.forEach(codeVal => {
      if (codeVal === errorCode) {
        this.router.navigate(['fitness-and-weightloss/reimbursement-oops']);
      }
    });
  }

  checkSelectedForm() {
    this.downloadData.setSelectedBenefitData(this.reimbursementForm.value);
    this.downloadData.setOverallBenefits(this.overallBenefits);
    const typeOfReimbursement: string = this.reimbursementForm.get('typeOfReimbursement').value;
    this.buttonCopy === 'Download' ? this.downLoadForm(typeOfReimbursement) : this.routeToForm(typeOfReimbursement);
  }

  routeToForm(typeOfReimbursement: string) {
    if (typeOfReimbursement === 'Fitness') {
      this.navigateToFitness();
    } else {
      this.navigateToWeightloss();
    }
  }

  saveEmail(data) {
    this.downloadData.setBenefitData(data);
    this.benefitsData.subscriberMaskedEmail = data.subscriberMaskedEmail;
    this.benefitsData.memberEmail = data.memberEmail;
  }

  navigateToFitness() {
    this.router.navigate(['fitness-and-weightloss/fitness-form']);
  }

  navigateToWeightloss() {
    this.router.navigate(['fitness-and-weightloss/weightloss-form']);
  }

  downLoadForm(typeOfReimbursement: string) {
    typeOfReimbursement.toLowerCase() === 'fitness' ? this.downloadFitness() : this.downloadWeightloss();
  }

  downloadFitness() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0763_Fitness_Reimbursement_Form.pdf');
  }

  downloadWeightloss() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0764_Weight_Loss_Reimbursement_Form.pdf');
  }

  onChange() {
    const selectionYear = this.reimbursementForm.get('year').value;
    this.benefitsData.selectionYear = selectionYear;
    this.typeofBenefit = [];
    for (let i = 0; i < this.yearData.length; i++) {
      if (this.yearData[i].year === selectionYear) {
        this.benefitsData.memberList = this.yearData[i].members;
        if (this.yearData[i].fitness) {
          this.typeofBenefit.push('Fitness');
          this.benefitsData.fitnessCollateralText = this.yearData[i].fitness.collateralText;
        }
        if (this.yearData[i].weightloss) {
          this.typeofBenefit.push('Weight Loss');
          this.benefitsData.weightlossCollateralText = this.yearData[i].weightloss.collateralText;
        }
      }
    }
  }

  updateCTA() {
    const selectionYear: string = this.reimbursementForm.get('year').value;
    const selectionBenefit: string = this.reimbursementForm.get('typeOfReimbursement').value;
    this.planTitle = selectionBenefit === 'Fitness' ? 'Fitness' : 'Weightloss';
    if (selectionYear && selectionBenefit) {
      for (let i = 0; i < this.yearData.length; i++) {
        if (this.yearData[i].weightloss && this.yearData[i].weightloss.receiptRequired) {
          this.benefitsData.weightlossReceiptRequired = this.yearData[i].weightloss.receiptRequired;
        }
        if (this.yearData[i].fitness && this.yearData[i].fitness.receiptRequired) {
          this.benefitsData.fitnessReceiptRequired = this.yearData[i].fitness.receiptRequired;
        }
        if (this.yearData[i].year === selectionYear) {
          if (this.yearData[i].fitness) {
            if (this.yearData[i].fitness.collateralName === this.planTitle) {
              this.onlineSubmission = this.yearData[i].fitness.onlineSubmissionEligible;
              this.benefitsData.isEHB = this.yearData[i].fitness.isEHB;
              this.benefitsData.benefitAmount = this.yearData[i].fitness.benefitAmount;
              this.benefitsData.collateralText = this.yearData[i].fitness.collateralText;
              this.benefitsData.fitnessReceiptRequired = this.yearData[i].fitness.receiptRequired;
              this.benefitsData.selectionYear = selectionYear;
              this.benefitsData.selectionType = selectionBenefit;
              break;
            }
          }
          if (this.yearData[i].weightloss) {
            if (this.yearData[i].weightloss.collateralName === this.planTitle) {
              this.onlineSubmission = this.yearData[i].weightloss.onlineSubmissionEligible;
              this.benefitsData.isEHB = this.yearData[i].weightloss.isEHB;
              this.benefitsData.benefitAmount = this.yearData[i].weightloss.benefitAmount;
              this.benefitsData.selectionYear = selectionYear;
              this.benefitsData.selectionType = selectionBenefit;
              this.benefitsData.collateralText = this.yearData[i].weightloss.collateralText;
              this.benefitsData.weightlossReceiptRequired = this.yearData[i].weightloss.receiptRequired;
              break;
            }
          }
        }
      }
      this.buttonCopy = this.onlineSubmission ? 'Continue' : 'Download';
    }
  }
}
