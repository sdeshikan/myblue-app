import { RouterModule, Routes } from '@angular/router';
import { AuthenticatedLayoutComponent } from '../../shared/layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { HomepageResolver } from '../../shared/routeresolvers/homepage-resolver';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { FeatureGuard } from '../../shared/utils/feature-guard';
import { DocumentDetailComponent } from './document-detail/document-detail.component';
import { DocumentDetailResolverService } from './document-detail/document-detail.resolver';
import { DocumentsListViewResolverService } from './documents-list-view/document-list-view.resolver';
import { DocumentsListViewComponent } from './documents-list-view/documents-list-view.component';
import { DocumentsOverallViewComponent } from './documents-overall-view/documents-overall-view.component';
import { BenefitCoverageListResolverService } from './documents/benefit-coverage-list.resolver';
import { DocumentsComponent } from './documents/documents.component';
import { DocumentsResolverService } from './documents/documents.resolver';
import { InboxComponent } from './inbox/inbox.component';
import { MessageDetailComponent } from './message-detail/message-detail.component';
import { MsgListingComponent } from './msg-listing/msg-listing.component';
import { TaxFormsviewComponent } from './tax-forms-view/tax-forms-view.component';
import { UploadDetailComponent } from './upload-detail/upload-detail.component';
import { UploadsComponent } from './uploads/uploads.component';
import { TaxFormsOverallViewComponent } from './tax-forms-overall-view/tax-forms-overall-view.component';



// import { EOBResolverService } from './eob/eob-resolver.service';

const MESSAGE_CENTER_ROUTER: Routes = [
  {
    path: '',
    component: AuthenticatedLayoutComponent,
    children: [
      {
        path: '',
        component: InboxComponent
      },
      {
        path: 'messages',
        component: MsgListingComponent,
        data: {
          breadcrumb: 'Messages'
        },
        canActivate: [AuthGuard]
      },
      {
        path: 'message-detail',
        component: MessageDetailComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'documents/tax-forms',
        component: TaxFormsOverallViewComponent,
        canActivate: [AuthGuard, FeatureGuard],
        data: {
          featureName: 'tax-forms',
          // any other relevant data to make your checks
        }
      },
      {
        path: 'documents/tax-forms/details',
        component: TaxFormsviewComponent,
        canActivate: [AuthGuard, FeatureGuard],
        data: {
          featureName: 'tax-forms',
          // any other relevant data to make your checks
        }
      },
      {
        path: 'documents/home',
        component: DocumentsComponent,
        canActivate: [AuthGuard],
        resolve: {
          memberData: HomepageResolver
        }
      },
      {
        path: 'documents/planDocuments',
        component: DocumentsComponent,
        canActivate: [AuthGuard],
        resolve: {
          planDocuments: DocumentsResolverService
        }
      },
      {
        path: 'documents/planDocuments/benefitCoverageList',
        component: DocumentsComponent,
        canActivate: [AuthGuard],
        resolve: {
          benefitCoverageDocs: BenefitCoverageListResolverService
        }
      },
      {
        path: 'documents/document-view',
        component: DocumentDetailComponent,
        canActivate: [AuthGuard],
        resolve: {
          benefitText: DocumentDetailResolverService
        }
      },
      {
        path: 'documents/document-overall-view',
        component: DocumentsOverallViewComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'uploads',
        component: UploadsComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'upload-detail/:fileId',
        component: UploadDetailComponent,
        canActivate: [AuthGuard]
      }
      //,
      // {
      //     path: 'documents/eob',
      //     component: EobComponent,
      //     canActivate: [AuthGuard],
      //     // data: {
      //     //     breadcrumb: 'EOB'
      //     // },
      //     resolve: {
      //         eobInfo: EOBResolverService
      //     }
      // }
    ]
  },
  {
    path: 'documents/documents-list-view',
    // component: AuthCentralLayoutComponent,
    component: AuthenticatedLayoutComponent,
    children: [
      {
        path: '',
        canActivate: [AuthGuard],
        component: DocumentsListViewComponent,
        resolve: {
          policy: DocumentsListViewResolverService
        }
      }
    ]
  }
];

export const MessageCenterRouter = RouterModule.forChild(MESSAGE_CENTER_ROUTER);
