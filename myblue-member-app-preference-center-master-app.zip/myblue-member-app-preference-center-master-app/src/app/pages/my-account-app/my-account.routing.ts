import { RouterModule, Routes } from '@angular/router';
import { ConfirmidentityComponent } from './confirm-identity/confirmidentity.component';
import { CreatePasswordComponent } from './create-password/create-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { FpConfirmidentityComponent } from './fp-confirm-identity/fpconfirmidentity.component';
import { ForgetPasswordFlowGuard } from './utils/forget-password-flow.guard';
import { ForgetUserNameFlowGuard } from './utils/forget-username-flow.guard';
import { VerifyAccessGuard } from './utils/verify-access.guard';
import { VerifyOTPaccesscodeComponent } from './verifyOTPaccesscode/verifyaccesscode.component';

const ACCOUNT_ROUTER: Routes = [
  {
    path: '',
    children: [
      {
        path: 'forgotPassword/:user',
        component: ForgotPasswordComponent
      },
      {
        path: 'forgotPassword',
        component: ForgotPasswordComponent
      },
      {
        path: 'forgotusername',
        component: ForgotUsernameComponent
      },
      {
        path: 'createPassword',
        component: CreatePasswordComponent
      },
      {
        path: 'verifyAccessCode/:caller',
        canActivate: [VerifyAccessGuard],
        component: VerifyOTPaccesscodeComponent
      },
      {
        path: 'confirmidentity',
        canActivate: [ForgetUserNameFlowGuard],
        component: ConfirmidentityComponent
      },
      {
        path: 'fpconfirmidentity',
        canActivate: [ForgetPasswordFlowGuard],
        component: FpConfirmidentityComponent
      }
    ]
  }
];

export const MyAccountRouter = RouterModule.forChild(ACCOUNT_ROUTER);
