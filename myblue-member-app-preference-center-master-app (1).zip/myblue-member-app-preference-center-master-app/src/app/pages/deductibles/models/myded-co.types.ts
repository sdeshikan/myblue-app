export enum AccumChartType {
  Coinsurance,
  overallDeductables,
  outOfPocket,
  overallBenefit
}
