import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { RegType } from '../../../shared/models/regType.enum';
import { AlertService } from '../../../shared/services/alert.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { GetTokens, SetUserID } from '../../../store/actions/app.actions';
import { MyAccountService } from '../my-account.service';

// TODO: THIS WILL NEED TO BE TESTED
@Component({
  selector: 'app-forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.scss']
})
export class ForgotUsernameComponent implements OnInit {
  forgotUsernameForm: FormGroup;
  dobMask: Array<any>;
  phoneMask: Array<any>;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private myAccountService: MyAccountService,
    private globalService: GlobalService,
    private http: HttpClient,
    private constants: ConstantsService,
    private alertService: AlertService,
    private router: Router,
    private validationService: ValidationService,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    try {
      this.forgotUsernameForm = this.fb.group({
        email: ['', [Validators.required, this.validationService.emailValidator()]],
        mobile: ['', [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()]]
      });

      this.phoneMask = this.validationService.phoneMask;
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  showErrorMessage(regType: RegType, res) {
    // TODO: IF THERE IS AN ERROR WE SET THE USERID TO ONE OF THESE VALUES? THAT SEEMS OFF...
    const userId = regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email;
    this.store.dispatch(new SetUserID(userId));
    this.globalService.handleError(res, this.constants.displayMessage);
  }

  handleVerificationResponse(regType: RegType, res, isVerifedUser: boolean) {
    try {
      if (isVerifedUser) {
        this.handleSuccessResponse(regType, res);
      } else {
        this.handleNonVerifiedResponse();
      }
    } catch (exception) {
      console.error('ERROR ' + JSON.stringify(exception, null, 2));
    }
  }

  handleNonVerifiedResponse() {
    this.router.navigate(['./login-app']).then(() => {
      setTimeout(() => {
        this.alertService.setAlert('Please check your email account or mobile number for your username.', '', AlertType.Success);
        // tslint:disable-next-line:no-magic-numbers
      }, 500);
    });
  }

  handleSuccessResponse(regType: RegType, res) {
    sessionStorage.setItem(
      'useridin',
      regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email
    );
    sessionStorage.setItem('isauthenticated', 'TRUE');
    this.router.navigate(['./account/confirmidentity']);
  }

  handleNonAuthenticatedUserResponse(regType: RegType, res) {
    sessionStorage.setItem(
      'useridin',
      regType === RegType.MOBILE ? this.forgotUsernameForm.value.mobile : this.forgotUsernameForm.value.email
    );
    sessionStorage.setItem('isauthenticated', 'FALSE');
    sessionStorage.setItem('otp', 'TRUE');
    this.router.navigate(['/account/verifyAccessCode', 'FUN']);
  }

  getToken() {
    // TODO: NGXS REFACTOR - call verifyIsUserValid after this - TEST
    this.store.dispatch(new GetTokens());
    this.verifyIsUserValid();
  }

  verifyIsUserValid() {
    const request = this.forgotUsernameForm.value;
    request.mobile = request.mobile ? request.mobile.replace(/-/g, '') : request.mobile;
    request.email = request.email ? request.email.toLowerCase() : request.email;
    this.myAccountService.verifyUserValid(request).subscribe(
      (res: any) => {
        if (res) {
          const resultId = res['result'];
          const regType = res['commType'] === 'MOBILE' ? RegType.MOBILE : RegType.EMAIL;
          this.myAccountService.funverifyuserResponse = res;
          const isVerfiedUser = res['isAuthenticated'] === 'TRUE';
          if (resultId === null || resultId === undefined) {
            if (isVerfiedUser) {
              this.handleVerificationResponse(regType, res, isVerfiedUser);
            } else if (!isVerfiedUser) {
              this.handleNonAuthenticatedUserResponse(regType, res);
            }
          } else {
            sessionStorage.setItem('isauthenticated', 'FALSE');
            resultId === '-1' ? this.showErrorMessage(regType, res) : this.alertService.setError(res.displaymessage);
          }
        }
      },
      error => {
        console.error('ERROR ' + JSON.stringify(error, null, 2));
      }
    );
  }

  onSubmit() {
    this.alertService.clearError();
    this.getToken();
  }

  ionViewWillLeave() {
    this.alertService.clearError();
  }

  ngOnInit() {
    this.alertService.clearError();
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ForgotUsername);
  }
}
