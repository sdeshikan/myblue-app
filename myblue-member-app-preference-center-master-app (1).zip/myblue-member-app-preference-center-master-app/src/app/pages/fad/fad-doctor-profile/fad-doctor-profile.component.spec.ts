import { NgxMaskModule } from 'ngx-mask';
import { AlertService } from '../../../shared/services/alert.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { AppState } from '../../../store/state/app.state';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadDoctorProfileComponent } from './fad-doctor-profile.component';
import { FadDoctorProfileService } from './fad-doctor-profile.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ModalController, PopoverController } from '@ionic/angular';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicStorageModule } from '@ionic/storage';
import { NgxsModule } from '@ngxs/store';
import { StorageServiceModule } from 'angular-webstorage-service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';

describe('FadDoctorProfileComponent', () => {
  let component: FadDoctorProfileComponent;
  let fixture: ComponentFixture<FadDoctorProfileComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StorageServiceModule,
        RouterTestingModule,
        NgxMaskModule.forRoot(),
        IonicStorageModule.forRoot(),
        NgxsSelectSnapshotModule.forRoot(),
        NgxsModule.forRoot([AppState]),
        NgxMaskModule.forRoot()
      ],
      declarations: [FadDoctorProfileComponent],
      providers: [
        FadDoctorProfileService,
        ConstantsService,
        AlertService,
        FadSearchResultsService,
        FadBreadCrumbsService,
        FadService,
        FadCostBreakdownService,
        BcbsmaHttpService,
        FadFacilityProfileService,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadDoctorProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
