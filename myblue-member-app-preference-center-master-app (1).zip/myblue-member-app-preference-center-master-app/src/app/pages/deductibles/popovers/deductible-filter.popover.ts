import { Component, OnInit } from '@angular/core';
import { NavParams, PopoverController } from '@ionic/angular';
import { MemberDeductibleModel } from '../models/member-deductible.model';
import { Store } from '@ngxs/store';
import { GetFamilyDeductibles, GetIndividualDeductibles } from '../../../store/actions/deductible.actions';

@Component({
  selector: 'app-deductible-filter-popover',
  templateUrl: './deductible-filter.popover.html'
})
export class DeductibleFilterPopover implements OnInit {
  members: MemberDeductibleModel[];
  selectedFilter: string;
  toggleMedical = true;
  toggleDental = false;
  useridin: string;

  constructor(private params: NavParams, private store: Store, private popoverController: PopoverController) {}

  ngOnInit() {}

  ionViewDidEnter() {
    this.members = this.params.data.members;
    this.useridin = this.params.data.useridin;
    this.selectedFilter = this.params.data.current;
  }

  onToggleMedical() {
    this.toggleMedical = !this.toggleMedical;
    this.toggleDental = false;
  }

  onToggleDental() {
    this.toggleDental = !this.toggleDental;
    this.toggleMedical = false;
  }

  applyFilter() {
    if (this.selectedFilter) {
      if (this.selectedFilter !== 'family') {
        let type = null;
        if (this.toggleDental) {
          type = 'DENTAL';
        } else if (this.toggleMedical) {
          type = 'MEDICAL';
        }
        this.store.dispatch(new GetIndividualDeductibles(this.selectedFilter, type));
        this.selectedFilter = this.params.data.current;
      } else {
        this.store.dispatch(new GetFamilyDeductibles(this.useridin, true));
      }
    }

    this.popoverController.dismiss();
  }
}
