import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadDoctorProfileService } from './fad-doctor-profile.service';

describe('FadDoctorProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadDoctorProfileService, ConstantsService]
    });
  });

  it('should be created', inject([FadDoctorProfileService], (service: FadDoctorProfileService) => {
    expect(service).toBeTruthy();
  }));
});
