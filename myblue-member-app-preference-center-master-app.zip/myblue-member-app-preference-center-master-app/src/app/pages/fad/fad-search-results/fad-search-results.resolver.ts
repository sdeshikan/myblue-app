import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { GetSearchByFacilityRequestModel } from '../modals/getSearchByFacility.model';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import {
  FadAutoCompleteComplexOptionInterface,
  FadLandingPageSearchControlValuesInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import {
  GetSearchByProfessionalRequestModelInterface,
  GetSearchByProfessionalResponseModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import { FadSearchResultsService } from './fad-search-results.service';

import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import {
  GetSearchBySpecialityRequestModelInterface,
  GetSearchBySpecialtyResponseModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';

@Injectable()
export class FadSearchResultsResolver<T>
  implements
    Resolve<
      Promise<
        | GetSearchBySpecialtyResponseModelInterface
        | GetSearchByProfessionalResponseModelInterface
        | GetSearchByFacilityResponseModelInterface
      >
    > {

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private fadSearchResultsService: FadSearchResultsService, private router: Router) {}

  async resolve(): Promise<
    GetSearchBySpecialtyResponseModelInterface | GetSearchByProfessionalResponseModelInterface | GetSearchByFacilityResponseModelInterface
  > {


    const authUserId = this.useridin;
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    console.log('router url', this.fadSearchResultsService.getContextText());
    console.log('routes url', this.router.url);
    if (searchCriteria && searchCriteria.getSearchText()) {
      const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
      console.log('searchtextoption', searchTextOption);

      if (
        searchTextOption.getInfoText() === 'Specialty' ||
        searchTextOption.getInfoText() === 'procedures' ||
        searchTextOption.getInfoText() === 'specialities'
      ) {
        if (
          searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.speciality &&
          this.fadSearchResultsService.getContextText() !== 'affiliated'
        ) {
          const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();

          vitalsSearchRequestbySpeciality
            .setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FAD_CONSTANTS.defaults.limit)
            .setPage(FAD_CONSTANTS.defaults.page)
            // tslint:disable-next-line:no-magic-numbers
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());

          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
          } else {
          }

          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbySpeciality.setUserId(this.useridin);
          }
          return this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
        } else if (
          searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility &&
          this.fadSearchResultsService.getContextText() !== 'affiliated'
        ) {
          const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();

          vitalsSearchRequestbySpeciality
            .setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FAD_CONSTANTS.defaults.limit)
            .setPage(FAD_CONSTANTS.defaults.page)
            // tslint:disable-next-line:no-magic-numbers
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());

          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
          } else {
          }

          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbySpeciality.setUserId(this.useridin);
          }
          return this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
        } else if (
          searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional &&
          this.fadSearchResultsService.getContextText() !== 'affiliated'
        ) {
          const vitalsSearchRequestbySpeciality: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();

          vitalsSearchRequestbySpeciality
            .setGeoLocation(searchCriteria.getZipCode().geo)
            .setLimit(FAD_CONSTANTS.defaults.limit)
            .setPage(FAD_CONSTANTS.defaults.page)
            // tslint:disable-next-line:no-magic-numbers
            .setRadius(25)
            .setNetworkId(searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId());

          if (!searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getSpecialityId()) {
            vitalsSearchRequestbySpeciality.setSearchSpecialtyId(searchCriteria.getSearchText().getSpecialityId());
          } else if (searchCriteria.getSearchText().isProcedure() && searchCriteria.getSearchText().getProcedureId()) {
            vitalsSearchRequestbySpeciality.setProcedureId(searchCriteria.getSearchText().getProcedureId());
            vitalsSearchRequestbySpeciality['sort'] = 'cost+asc';
          } else {
          }

          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbySpeciality.setUserId(this.useridin);
          }

          return this.fadSearchResultsService.getFadSpecialitySearchResults(vitalsSearchRequestbySpeciality).toPromise();
        } else if (this.fadSearchResultsService.getContextText() === 'affiliated') {
          // tslint:disable-next-line:max-line-length
          const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
          vitalsSearchRequestbyProfessional
            .setLimit(FAD_CONSTANTS.defaults.limit)
            .setPage(FAD_CONSTANTS.defaults.page)
            .setNetworkId(
              searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
                ? searchCriteria.getPlanName().getNetworkId()
                : FAD_CONSTANTS.defaults.networkId
            );
          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsSearchRequestbyProfessional.setUserIdIn(this.useridin);
          }

          return this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
        }
      } else if (this.fadSearchResultsService.getContextText() === 'affiliated') {
        const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
        vitalsSearchRequestbyProfessional
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(FAD_CONSTANTS.defaults.page)
          .setNetworkId(
            searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
              ? searchCriteria.getPlanName().getNetworkId()
              : FAD_CONSTANTS.defaults.networkId
          );

        if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
          vitalsSearchRequestbyProfessional.setUserIdIn(this.useridin);
        }

        return this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
      } else if (
        searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.professional &&
        !searchCriteria.getSearchText().isProcedure() &&
        this.fadSearchResultsService.getContextText() !== 'affiliated'
      ) {
        const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
        vitalsSearchRequestbyProfessional
          .setGeoLocation(searchCriteria.getZipCode().geo) // '42.402311000000026,-71.12037000000004')
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(FAD_CONSTANTS.defaults.page)
          .setRadius(FAD_CONSTANTS.defaults.radius)
          .setNetworkId(
            searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
              ? searchCriteria.getPlanName().getNetworkId()
              : FAD_CONSTANTS.defaults.networkId
          );

        if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
          vitalsSearchRequestbyProfessional.setSearchSpecialtyId(searchTextOption.getSpecialityId());
        } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
          vitalsSearchRequestbyProfessional.setSearchProcedureId(searchTextOption.getProcedureId());
        } else {
          vitalsSearchRequestbyProfessional.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
        }

        if (authUserId) {
          vitalsSearchRequestbyProfessional.setUserIdIn(this.useridin);
        }

        return this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional).toPromise();
      } else if (
        searchTextOption.getResourceTypeCode() === FadResouceTypeCodeConfig.facility &&
        !searchCriteria.getSearchText().isProcedure() &&
        this.fadSearchResultsService.getContextText() !== 'affiliated'
      ) {
        const vitalsSearchRequestbyFacility: GetSearchByFacilityRequestModelInterface = new GetSearchByFacilityRequestModel();
        // alternate geolocation value format that is allowed '42.402311000000026,-71.12037000000004')
        // searchCriteria.zipCode ||
        vitalsSearchRequestbyFacility
          .setGeoLocation(searchCriteria.getZipCode().geo)
          .setLimit(FAD_CONSTANTS.defaults.limit)
          .setPage(FAD_CONSTANTS.defaults.page)
          .setRadius(FAD_CONSTANTS.defaults.radius)
          .setNetworkId(
            searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
              ? searchCriteria.getPlanName().getNetworkId()
              : FAD_CONSTANTS.defaults.networkId
          );

        if (!searchTextOption.isProcedure() && searchTextOption.getSpecialityId()) {
          vitalsSearchRequestbyFacility.setSearchSpecialtyId(searchTextOption.getSpecialityId());
        } else if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
          vitalsSearchRequestbyFacility.setProcedureId(searchTextOption.getProcedureId());
        } else {
          vitalsSearchRequestbyFacility.setName(this.fadSearchResultsService.getFilteredSearchName(searchCriteria));
        }

        if (authUserId) {
          vitalsSearchRequestbyFacility.setUserIdIn(this.useridin);
        }

        return this.fadSearchResultsService.getFadFacilitySearchResults(vitalsSearchRequestbyFacility).toPromise();
      }
    } else {
      this.router.navigate([FAD_CONSTANTS.urls.fadLandingPage]);
    }
  }

}
