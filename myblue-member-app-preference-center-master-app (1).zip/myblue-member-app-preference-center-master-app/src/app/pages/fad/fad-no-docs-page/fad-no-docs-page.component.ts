import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSpecialtyFilterComponentOutputModel } from '../modals/fad-search-filter.modal';
import { FiltersMetadata, SortMetadata } from '../modals/getSearchByProfessional.model';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import { FadSearchFilterComponentOutputModelInterface } from '../modals/interfaces/fad-search-filter.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

@Component({
  selector: 'app-fad-no-docs-page',
  templateUrl: './fad-no-docs-page.component.html',
  styleUrls: ['./fad-no-docs-page.component.scss']
})
export class FadNoDocsPageComponent implements OnInit {
  @Output() componentOutput = new EventEmitter<FadSearchFilterComponentOutputModelInterface>();
  @Input() componentInput: FadNoDocsPageInputDataModelInterface;
  @Input() isFilterChanged: boolean;

  public searchText = '';
  public withFilterFlag = false;
  public filterCategories: string[] = [];
  filterMetaData: FiltersMetadata;
  sortMetaData: SortMetadata;
  public outputTransaction: FadSearchFilterComponentOutputModelInterface = new FadSpecialtyFilterComponentOutputModel();
  constructor(private fadSearchResultsService: FadSearchResultsService) {}

  ngOnInit() {
    try {
      if (this.fadSearchResultsService.getSearchCriteria()) {
        this.searchText = this.fadSearchResultsService
          .getSearchCriteria()
          .getSearchText()
          .getSimpleText();
        this.searchText = this.searchText.replace(FAD_CONSTANTS.text.allDoctorOptionText, '').replace(/["']/g, '');
        this.searchText = this.searchText.replace(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
        if (this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.professional) {
          this.filterCategories = this.fadSearchResultsService.getFilterCategories();
        } else if (this.componentInput && this.componentInput.type && this.componentInput.type === FadResouceTypeCodeConfig.facility) {
          this.filterCategories = this.fadSearchResultsService.getFacilityFilterCategories();
        } else {
          this.filterCategories = this.fadSearchResultsService.getSpecialtyFilterCategories();
        }
      }

      this.withFilterFlag = this.componentInput && this.componentInput.type && this.componentInput.type !== '';
    } catch (exception) {}
  }

  public clearFilter() {
    this.filterMetaData = new FiltersMetadata();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = new FiltersMetadata();
    this.outputTransaction.sortCriteriaData = new SortMetadata();
    this.outputTransaction.resourcetype = this.componentInput.type;
    this.componentOutput.emit(this.outputTransaction);
  }
}
