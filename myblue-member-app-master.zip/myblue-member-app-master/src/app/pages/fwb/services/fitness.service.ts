import { Injectable } from '@angular/core';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { AuthService } from '../../../shared/services/auth.service';
import { Observable } from 'rxjs';
import { GET_REIMBURSEMENT_BENEFITS_ENDPOINT, SUBMIT_REIMBURSEMENT_BENEFITS_ENDPOINT } from '../constants/fitness.constants';
import fitness from '../../../../assets/data/fitness.json';

@Injectable({
  providedIn: 'root'
})
export class FitnessService {
  constructor(private http: AuthHttp, private constants: ConstantsService, private authService: AuthService) {}

  getBenefitsInfo(): Observable<any> {
    const request = {
      useridin: this.authService.useridin,
      isCommercial: 'true'
    };
    return this.http.encryptPost(this.constants.getFitnessBenefits, request);
  }

  submitBenefitsInfo(claims, images): Observable<any> {
    return this.http.encryptPost(SUBMIT_REIMBURSEMENT_BENEFITS_ENDPOINT, { claims: claims, images: images }, true, true);
  }
}
