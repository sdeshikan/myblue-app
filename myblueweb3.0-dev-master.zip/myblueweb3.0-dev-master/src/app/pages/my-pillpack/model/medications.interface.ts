
export interface MedicationsModelInterface{
    ndcCd:string;
    rxcui:string;
    description:string;
    isSelfPrescribed:boolean;
    shouldChase:boolean;
    doseTimes:string;
    genericName:string;
    form:string;
    daysSupply:number;
    lastFill:string;
    strength:string;
    directions:string;
    pharmacy:PharmacyInterface;
    prescriber:PrescriberModelInterface;
    isSelected?:boolean;
    copay:number;
}
export interface PharmacyAddressModelInterface{
    address1:string;
    address2:string;
    city:string;
    state:string;
    zipcode:string;
}

export interface Member {
    firstName: string;
    lastName: string;
    relationship: string;
    depId?: number;
    medications?: MedicationsModelInterface;
}
export interface PharmacyInterface{
    id:string;
    name:string;
    phoneNumber:string;
    address:PharmacyAddressModelInterface;
}
export interface PrescriberModelInterface{
    firstName:string;
    lastName:string;
    middleInitial:string;
    id:string;
    deaNumber:string;
    phoneNumber:string;
    address:PharmacyAddressModelInterface;     
}