import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {

  @Input() maxRating = 5;
  @Output() ratingChanged = new EventEmitter();
  currentRating = 0;
  @Input() id: any = null;
  selectedRatings: number[] = [];
  unSelectedRatings: number[] = []; // TODO refactor  using single array
  ngOnInit() {
    this.updateRatingArray();
  }

  updateRatingArray() {
    this.selectedRatings = [];
    this.unSelectedRatings = [];
    for (let index = 1; index <= this.maxRating; index++) {
      if (index <= this.currentRating) {
        this.selectedRatings.push(index);
      } else {
        this.unSelectedRatings.push(index);
      }
    }
  }

  onRatingChanged(rating) {
    this.currentRating = rating;
    this.updateRatingArray();
    this.ratingChanged.emit({currentRating: this.currentRating, id: this.id});
  }

}
