import {
  Component,
  OnInit,
  Output,
  Input,
  EventEmitter,
  ComponentFactoryResolver,
  Injector,
  ApplicationRef,
  ChangeDetectorRef,
  SimpleChanges,
  OnChanges,
  ViewChild,
  ElementRef,
  HostListener,
  OnDestroy
} from '@angular/core';
import {
  FadFacilityListComponentOutputModelInterface,
  FadSearchListComponentOutputModelInterface,
  FadSpecialtyListComponentInputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import { FadFacilityListComponentOutputModel, FadSearchListComponentOutputModel } from '../modals/fad-search-list.modal';

import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';

import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { FadConstants } from '../constants/fad.constants';
import * as leafLet from 'leaflet';
import { Subscription } from 'rxjs/Subscription';
import { FadProviderFacilityListService } from './fad-provider-facility-list.service';

import { FadZipCodeSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';

import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';
import { FadProviderCardComponentOutputModelInterface } from '../modals/interfaces/fad-profile-card.interface';

import { Router } from '@angular/router';

import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import {
  GetSearchBySpecialtyResponseModelInterface,
  FadSpecialtyInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';

import { AuthHttp } from '../../../shared/services/authHttp.service';
import { FadProviderCompareService } from '../fad-provider-compare/fad-provider-compare.service';
import { AuthService } from '../../../shared/shared.module';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadNoSearchResultsPageConsumer, FadProviderCardConsumer } from '../modals/interfaces/fad.interface';
import { FadProviderProfileCardComponentInputModel } from '../modals/fad-profile-card.modal';

@Component({
  selector: 'app-provider-fad-facility-list',
  templateUrl: './fad-provider-facility-list.component.html',
  styleUrls: ['./fad-provider-facility-list.component.scss']
})
export class FadProviderFacilityListComponent
  implements OnInit, OnChanges, OnDestroy, FadNoSearchResultsPageConsumer, FadProviderCardConsumer {
  @Output('componentOutput') componentOutput: EventEmitter<FadFacilityListComponentOutputModelInterface> = new EventEmitter<
    FadFacilityListComponentOutputModel
  >();

  @Output('clearFilter') clearFilter: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<
    FadSearchListComponentOutputModel
  >();

  @Input('componentInput') componentInput: FadSpecialtyListComponentInputModelInterface;

  @ViewChild('profileCardList') profileCardList: ElementRef;

  public isDisplayBanner = false;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public filteredSearchResponse: GetSearchBySpecialtyResponseModelInterface;
  public searchResponse: GetSearchBySpecialtyResponseModelInterface;
  public facilityList: FadSpecialtyInterface[] = null;
  public selectedProfessionals: FadSpecialtyInterface[] = [];

  private mapInstance: leafLet.Map;
  private cachedAllZipCodeInfo: FadZipCodeSearchResponseModelInterface;
  public idValues: number[];
  public list: number[] = [];
  private maxSelectionAllowed = 5;
  public comparefacilityData = [];

  disableSelection = false;
  isFilterChanged: boolean;

  constructor(
    private router: Router,
    private fadSearchListService: FadProviderFacilityListService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private resolver: ComponentFactoryResolver,
    public authService: AuthService,
    private injector: Injector,
    private appRef: ApplicationRef,
    private fadSearchResultsService: FadSearchResultsService,
    private landingPageService: FadLandingPageService,
    public FadProviderCompareService: FadProviderCompareService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef,
    private authHttp: AuthHttp
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.speciality;
  }

  // Show banner section on window scroll to clear and delete message listing
  @HostListener('window:scroll', ['$event'])
  showBannerOnWindowScroll($event) {
    const fadSearchListPos = this.el.nativeElement.offsetTop,
      windowScrollPos = window.pageYOffset;

    if (windowScrollPos > fadSearchListPos) {
      this.isDisplayBanner = true;
    } else {
      this.isDisplayBanner = false;
    }
  }
  ngOnInit() {
    try {
      this.cachedAllZipCodeInfo = this.landingPageService.vitalsZipCodeInfo;
    } catch (exception) {}
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      // this.authHttp.showSpinnerLoading();
      this.componentInput = changes.componentInput.currentValue;
      this.isFilterChanged = this.fadSearchResultsService.filterChanged;
      if (this.componentInput) {
        this.searchResponse = this.componentInput.specialtyResults;
        if (this.searchResponse) {
          if (this.fadSearchListService.isFilterChangedFlag == true) {
            this.fadSearchListService.isFilterChangedFlag = false;
            // this.selectedProfessionals = [];
            this.clearProfileSelections();
          }
          this.facilityList = this.searchResponse.providers;
          if (this.FadProviderCompareService.getSearchResult() == null) {
            this.clearProfileSelections();
          }
          const disableFurtherSelection =
            this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed ? true : false;
          this.facilityList = this.facilityList.map(item => ({
            ...item,
            isDisabled: item.isChecked ? false : disableFurtherSelection
          }));
          this.isNoSearchResults = false;
        } else {
          this.isNoSearchResults = true;
        }
        // alert("hide spinner loading");
        // this.authHttp.hideSpinnerLoading();
        this.cdRef.detectChanges();
      }
    } catch (exception) {
      // this.authHttp.hideSpinnerLoading();
    }
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(facility: FadSpecialtyInterface): FadProviderProfileCardComponentInputModel {
    return new FadProviderProfileCardComponentInputModel(facility);
  }

  public onSearchListComponentInteraction(event) {
    console.log(event);
    this.clearFilter.emit(event);
  }

  public onProfileCardComponentInteraction(facilityCardCompOutput: FadProviderCardComponentOutputModelInterface) {
    const index = this.facilityList.findIndex(item => item.providerId === facilityCardCompOutput.provider.providerId);
    const selectedItem = this.facilityList[index];
    // const selectedItem = this.facilityList.find((item) => item.providerId === facilityCardCompOutput.provider.providerId);
    selectedItem.isChecked = facilityCardCompOutput.isSelected;
    this.selectedProfessionals = this.facilityList.filter(item => item.isChecked);

    const fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection =
      this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed ? true : false;
    this.facilityList = this.facilityList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });

    this.FadProviderCompareService.setSearchResult(this.selectedProfessionals);
    // this.getFacilityData(facilityCardCompOutput);
    this.componentOutput.emit({ fadSeachListComponentOutput, index, isChecked: facilityCardCompOutput.isSelected });
  }

  // end: FadProfileCardConsumer consumption requirement

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList != undefined) {
      this.facilityList.forEach(item => (item.isChecked = false));
    }
  }
  ngOnDestroy(): void {
    // this.authHttp.hideSpinnerLoading();
  }

  public onTabSelectionChange(selectedIndex) {
    let selectedLatitude: number;
    let selectedLongitude: number;

    try {
      if (selectedIndex === 1) {
        if (!this.fadSearchResultsService.getSearchCriteria()) {
          if (this.mapInstance && this.mapInstance.remove) {
            this.mapInstance.off();
            this.mapInstance.remove();
          }
          return;
        }

        const zipCodeInSearch: FZCSRCity = this.fadSearchResultsService.getSearchCriteria().getZipCode();
        let targetIndex = -1;
        this.cachedAllZipCodeInfo.cities.some((city, index) => {
          if (zipCodeInSearch && zipCodeInSearch.zip.indexOf(city.zip) >= 0) {
            targetIndex = index;
            return true;
          }
        });

        if (targetIndex < 0) {
          const fadLastSelectedCityZip = JSON.parse(localStorage.getItem('fadLastSelectedCityZip')) as FZCSRCity;
          if (fadLastSelectedCityZip && zipCodeInSearch.zip === fadLastSelectedCityZip.zip) {
            selectedLatitude = Number(fadLastSelectedCityZip.lat);
            selectedLongitude = Number(fadLastSelectedCityZip.lng);
          } else {
            throw new Error('Invalid zipcode');
          }
        } else {
          selectedLatitude = Number(this.cachedAllZipCodeInfo.cities[targetIndex].lat);
          selectedLongitude = Number(this.cachedAllZipCodeInfo.cities[targetIndex].lng);
        }

        const onMapCreatedEventWatcher: Subscription = this.fadSearchListService.onMapContainerCreated().subscribe(data => {
          this.createInteractiveMap(FadConstants.elementRef.fadSearchListMapContent, [selectedLatitude, selectedLongitude], 13);
          onMapCreatedEventWatcher.unsubscribe();
        });
      }
    } catch (exception) {
      // this.authHttp.hideSpinnerLoading();
    }
  }

  private createInteractiveMap(mapContainerId: string, coords: leafLet.LatLngExpression, zoomLevel: number) {
    try {
      if (this.mapInstance && this.mapInstance.remove) {
        this.mapInstance.off();
        this.mapInstance.remove();
      }
      this.mapInstance = leafLet.map(mapContainerId).setView(coords, zoomLevel);

      this.addMarkers();
    } catch (exception) {}
  }

  private addMarkers() {
    try {
      this.facilityList.map(professional => {
        professional.locations.map(location => {
          // const lattitude: number = location.address.latitude;
          // const longitude: number = location.address.longitude;
          // const latLng: leafLet.LatLngExpression = [lattitude, longitude];
          // const marker: leafLet.Marker = leafLet.marker(latLng).addTo(this.mapInstance);
          // marker.bindPopup(this.fetchPopupContent(professional));
        });
      });
    } catch (exception) {
      // this.authHttp.hideSpinnerLoading();
    }
  }
}
