import { Component, HostListener, NgModule, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { MyPillpackService } from '../../../shared/services/mypillpack';
import { AuthService } from '../../../shared/shared.module';
import { MyPillPackConstants } from './../my-pillpack.constants';

declare let $: any;
@NgModule({ imports: [MatIconModule] })
@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
  ismobile: boolean;
  mobileViewPort = 992;
  currentStep: Number = 1;
  isPillPackEnrolledThisSession: boolean;
  public WelcomeMsg;
  panelOpenState = false;
  pillpackSiteUrl: string;
  public isCPDPPromotion = false;
  public isCPDPEnrolled = false;
  public isCPDPHandedoff = false;
  public isKentuckyMember = false;
  public getStartedButtonText = 'Get Started';
  public getKentuckyStartedButtonText = 'Get Started On PillPack.com';
  public isCreatePharmacyUser = false;
  headline = 'You’ll Never Have to Manage Your Maintenance Medications Again';
  intro =
    'Using our new medication delivery service, you’ll never have to worry about going to the pharmacy, organizing your medications, or missing a dose again. PillPack, an independent company that administers this service, presorts your medications and delivers them in individually wrapped packages with the day, date, and time written on them, so you’ll know exactly when to take them.';

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  impersonate = true;

  constructor(
    private router: Router,
    private _pillpackService: MyPillpackService,
    private alertService: AlertService,
    private authservice: AuthService
  ) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
  }
  openPillPackSite() {
    sessionStorage.setItem('consentLink', 'https://www.pillpack.com');
    $('#openPillPackSite').modal('open');
  }
  goToPillPack() {
    this.pillpackSiteUrl = 'https://www.pillpack.com';
    window.open(this.pillpackSiteUrl, '_self');
  }

  ngOnInit() {
    const cachedPostLoginInformation = sessionStorage.getItem('postLoginInfo');
    if (cachedPostLoginInformation) {
      const myPostLoginInfo = JSON.parse(cachedPostLoginInformation);
      console.log('myPostLoginInfo', myPostLoginInfo);
      this.isCPDPPromotion = myPostLoginInfo.isCPDPPromotion;
      this.isCPDPEnrolled = myPostLoginInfo.isCPDPEnrolled;
      this.isCPDPHandedoff = myPostLoginInfo.isCPDPHandedoff;
      this.isKentuckyMember = myPostLoginInfo.isKYMember;
    }

    if (!this.isCPDPPromotion) {
      this.router.navigate(['home']);
    }

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }
    this.WelcomeMsg = MyPillPackConstants.WelcomeMsg;

    sessionStorage.setItem('selectedOTCs', '');

    this.impersonate = this.authservice.impersonation();
  }

  async navigateToCPDP() {
    if (!this.isCPDPEnrolled && !this.isCPDPHandedoff && !this.isPillPackEnrolledThisSession) {
      const yesNo = await this.checkPharmacyUserCreated().then(res => {
        this.isCreatePharmacyUser = true;
        if (res) {
          this.router.navigateByUrl('/my-pillpack');
        }
      });
    } else {
      this.gotoStep(2);
      window.scrollTo(0, 0);
    }
  }

  async checkPharmacyUserCreated() {
    if (!this.isCPDPEnrolled && !this.isCPDPHandedoff && !this.isPillPackEnrolledThisSession) {
      return await this._pillpackService.createPharmacyUser().then(res => {
        console.log('createPharmacyUser::' + res);
        if (!res.existingUser && res.errormessage) {
          sessionStorage.setItem('isCreatePharmacyUser', 'false');
          this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
          return false;
        } else if (res.existingUser) {
          sessionStorage.setItem('isCreatePharmacyUser', 'true');
          sessionStorage.setItem('partnerId', res.partner.id);
          return true;
        } else {
          sessionStorage.setItem('isCreatePharmacyUser', 'true');
          sessionStorage.setItem('partnerId', res.partner.id);
          return true;
        }
      });
    } else {
      this.gotoStep(2);
    }
  }

  openPhoneDialer() {
    document.location.href = 'tel:+18557455725 ';
  }

  gotoStep(step: number) {
    setTimeout(() => (this.currentStep = step), 0);
  }
}
