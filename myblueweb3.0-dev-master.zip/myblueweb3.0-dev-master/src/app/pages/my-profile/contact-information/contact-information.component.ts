import { Component, OnInit, OnDestroy } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { AlertService, ValidationService, AuthService, ConstantsService } from '../../../shared/shared.module';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
// import { NotificationPreferencesService } from '../../notification-preferences/notification-preferences.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ContactInformationService } from './contact-information.service';

declare let $: any;

@Component({
  selector: 'app-contact-information',
  templateUrl: './contact-information.component.html',
  styleUrls: ['./contact-information.component.scss']
})
export class ContactInformationComponent implements OnInit, OnDestroy {
  profile: any;
  registeredUserOnly: boolean = false;
  useridin: string = '';
  preferenceInfo: any;
  disableSave: boolean = true;
  fpoPreferenceUrl;
  preferenceObject: any;
  selectedFilterId: string;
  impersonate: boolean = true;

  //Mailing Address
  profileAddressEditForm: FormGroup;
  editAddress: boolean = false;
  address3: string = '';
  diplayEmailAdress: string = '';
  statesList = [
    { label: 'Alabama', value: 'AL' },
    { label: 'Alaska', value: 'AK' },
    { label: 'Arizona', value: 'AZ' },
    { label: 'Arkansas', value: 'AR' },
    { label: 'California', value: 'CA' },
    { label: 'Colorado', value: 'CO' },
    { label: 'Connecticut', value: 'CT' },
    { label: 'Delaware', value: 'DE' },
    { label: 'District of Columbia', value: 'DC' },
    { label: 'Florida', value: 'FL' },
    { label: 'Georgia', value: 'GA' },
    { label: 'Hawaii', value: 'HI' },
    { label: 'Idaho', value: 'ID' },
    { label: 'Illinois', value: 'IL' },
    { label: 'Indiana', value: 'IN' },
    { label: 'Iowa', value: 'IA' },
    { label: 'Kansas', value: 'KS' },
    { label: 'Kentucky', value: 'KY' },
    { label: 'Louisiana', value: 'LA' },
    { label: 'Maine', value: 'ME' },
    { label: 'Maryland', value: 'MD' },
    { label: 'Massachusetts', value: 'MA' },
    { label: 'Michigan', value: 'MI' },
    { label: 'Minnesota', value: 'MN' },
    { label: 'Mississippi', value: 'MS' },
    { label: 'Missouri', value: 'MO' },
    { label: 'Montana', value: 'MT' },
    { label: 'Nebraska', value: 'NE' },
    { label: 'Nevada', value: 'NV' },
    { label: 'New Hampshire', value: 'NH' },
    { label: 'New Jersey', value: 'NJ' },
    { label: 'New Mexico', value: 'NM' },
    { label: 'New York', value: 'NY' },
    { label: 'North Carolina', value: 'NC' },
    { label: 'North Dakota', value: 'ND' },
    { label: 'Ohio', value: 'OH' },
    { label: 'Oklahoma', value: 'OK' },
    { label: 'Oregon', value: 'OR' },
    { label: 'Pennsylvania', value: 'PA' },
    { label: 'Rhode Island', value: 'RI' },
    { label: 'South Carolina', value: 'SC' },
    { label: 'South Dakota', value: 'SD' },
    { label: 'Tennessee', value: 'TN' },
    { label: 'Texas', value: 'TX' },
    { label: 'Utah', value: 'UT' },
    { label: 'Vermont', value: 'VT' },
    { label: 'Virginia', value: 'VA' },
    { label: 'Washington', value: 'WA' },
    { label: 'West Virginia', value: 'WV' },
    { label: 'Wisconsin', value: 'WI' },
    { label: 'Wyoming', value: 'WY' }
  ];
  addressMessages = {
    required: 'You must enter a valid mailing address.',
    invalidCharacters: 'You must enter a valid mailing address.'
  };
  cityMessages = {
    required: 'You must enter the city.',
    invalidCharacters: 'You must enter a valid city.'
  };
  stateMessages = {
    required: 'State is required'
  };
  zipMessages = {
    required: 'You must enter your ZIP code.',
    minlength: 'You must enter a valid ZIP code.'
  };
  mailingAddressToolTipVisible: boolean = false;
  addressEditCancelText: string = 'edit';
  contactus = this.constants.contactus + this.authService.authToken.scopename;

  //Email
  profileEmailEditForm: FormGroup;
  editEmail: boolean = false;
  emailEditCancelText: string = 'edit';
  isUseridAEmail: boolean = false;
  optInEmail: boolean = false;
  preferenceEmailBackUp: boolean;
  mcIsVerifiedEmail: boolean = false;
  emailToolTipVisible: boolean = false;
  optInEmailChanged: boolean = false;
  emailMessages = {
    required: 'You must enter your email address.',
    invalidEmail: 'You must enter a valid email address.'
  };

  //Mobile
  profilePhoneEditForm: FormGroup;
  phoneEditCancelText: string = 'edit';
  isUseridAPhone: boolean = false;
  preferenceMobileBackUp: boolean;
  optInMobile: boolean = false;
  phoneToolTipVisible: boolean = false;
  editPhone: boolean = false;
  optInPhoneChanged: boolean = false;
  isMedicare: boolean = false;
  mask: Object = { mask: this.validationService.phoneMask, guide: false };
  phoneNumberTypeValues = [
    { label: 'Mobile', value: 'MOBILE' },
    { label: 'Home', value: 'HOME' },
    { label: 'Work', value: 'WORK' }
  ];
  mobileNumberMessages = {
    required: 'You must enter a valid phone number.',
    invalidNumber: 'You must enter a valid phone number.',
    invalidMobile: 'You must enter a valid phone number.'
  };

  constructor(
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router,
    private alertService: AlertService,
    private validationService: ValidationService,
    private profileService: ProfileService,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private http: AuthHttp,
    private contactInfoService: ContactInformationService,
    private authService: AuthService
  ) {
    this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
    this.profileAddressEditForm = this.fb.group({
      useridin: '',
      isEditableAddress: false,
      userState: '',
      isDirectPay: false,
      address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
      dob: ['', []],
      city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      state: ['', this.editAddress ? [Validators.required] : []],
      zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []]
    });
    this.profileEmailEditForm = this.fb.group({
      useridin: '',
      emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
      fullName: '',
      isVerifiedEmail: false
    });
    this.profilePhoneEditForm = this.fb.group({
      useridin: '',
      isVerifiedMobile: false,
      phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
      phoneNumber: [
        this.editPhone ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
      ]
    });
    this.useridin = sessionStorage.getItem('useridin');
    const numberRegEx = new RegExp('^[0-9]{10}');
    const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    this.isUseridAPhone = numberRegEx.test(this.useridin) ? true : false;
    this.isUseridAEmail = emailRegex.test(this.useridin) ? true : false;
    this.mask = { mask: this.validationService.phoneMask, guide: false };
    this.isMedicare = this.authService.authToken.userType
      ? this.authService.authToken.userType.toLowerCase() === 'medicare'
        ? true
        : false
      : false;
    this.contactInfoService.contactInfoDataChange$.subscribe(data => {
      if (data == new Date()) {
        this.disableSave = true;
        //   this.updateCommStatusEmail();
        //    this.updateCommStatusPhone();
        this.updateCommStatus();
      }
    });
  }

  ngOnInit() {
    //Show paperless promo
    setTimeout(() => {
      this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
      if (this.preferenceObject.Preferences) {
        this.preferenceObject.Preferences.map(item => {
          if (item.PreferenceType == '1') {
            this.selectedFilterId = item.FilterID;
          }
        });
        if (this.selectedFilterId === 'DOCS_PLAN_MAIL') {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
        } else {
          this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/home-promoblock2';
        }
      } else {
        this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
      }
      this.profileService.preferencePromo(this.fpoPreferenceUrl);
    }, 200);

    const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (this.profile) {
      if (!this.profile.phoneType) {
        this.profile.phoneType = 'MOBILE';
      }
      this.diplayEmailAdress = this.profile.emailAddress;
      const userRole = this.profileService.getUserRole();
      this.registeredUserOnly = userRole === 'REGISTERED-NOT-VERIFIED' || userRole === 'REGISTERED-AND-VERIFIED' ? true : false;
      this.address3 = '';
      this.address3 = this.profile.city ? this.address3 + this.profile.city + ', ' : this.address3;
      this.address3 = this.profile.state ? this.address3 + this.profile.state + ' ' : this.address3;
      this.address3 = this.profile.zip ? this.address3 + this.profile.zip : this.address3;
      this.profileAddressEditForm.patchValue(this.profile);
      this.profileEmailEditForm.patchValue(this.profile);
      this.profilePhoneEditForm.patchValue(this.profile);
      this.profileService.setProfile(this.profile);
      this.profile.phoneNumber = this.formatPhone(this.profile.phoneNumber);
    }
    this.preferenceInfo = this.activatedRoute.snapshot.data.commstatus.commstatus;
    this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
    this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
    this.preferenceEmailBackUp = this.optInEmail;
    this.preferenceMobileBackUp = this.optInMobile;
    this.mcIsVerifiedEmail = this.getPreferenceValue('IsVerifiedEmail') === 'true';
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }

  resetAllEdits() {
    this.editAddress = false;
    this.editEmail = false;
    this.editPhone = false;
  }
  private sendaccesscode(commChannelType, commChannel) {
    return this.profileService.sendaccesscode(commChannelType, commChannel);
  }
  private sendcommchlaccesscode(email, mobile) {
    return this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, ''));
  }
  navigateToVerifyScreen() {
    this.router.navigate(['/myprofile/verify']).then(() => {
      this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
    });
  }
  getPreferenceValue(keyName) {
    const preferenceItem = this.preferenceInfo.preferences.filter(item => {
      return item['memKeyName'] === keyName;
    });
    return preferenceItem && preferenceItem[0] ? preferenceItem[0]['memKeyValue'] : '';
  }
  openConsentToReceiveCommunicationModal(value: string) {
    $('#consentToReceiveCommunications').modal('open');
    this.showToolTip(value);
  }
  showToolTip(value: string) {
    switch (value) {
      case 'mailingAddress':
        this.mailingAddressToolTipVisible = !this.mailingAddressToolTipVisible;
        break;
      case 'email':
        this.emailToolTipVisible = !this.emailToolTipVisible;
        break;
      case 'phone':
        this.phoneToolTipVisible = !this.phoneToolTipVisible;
        break;
    }
  }
  updateCommStatus() {
    this.alertService.clearError();
    const preferences = [];
    this.optInEmail = sessionStorage.getItem('optInEmail') ? JSON.parse(sessionStorage.getItem('optInEmail')) : this.optInEmail;
    this.optInMobile = sessionStorage.getItem('optInMobile') ? JSON.parse(sessionStorage.getItem('optInMobile')) : this.optInMobile;
    console.log('opt in status', this.optInEmail, this.optInMobile);
    preferences.push({ memKeyName: 'EmailOptInStatus', memKeyValue: this.optInEmail.toString() }),
      preferences.push({ memKeyName: 'EmailOptInSource', memKeyValue: 'WEB' });
    preferences.push({ memKeyName: 'MobileOptInStatus', memKeyValue: this.optInMobile.toString() }),
      preferences.push({ memKeyName: 'MobileOptInSource', memKeyValue: 'WEB' });

    console.log('pref', preferences);
    this.contactInfoService.updateCommStatus({ preferences: preferences }).subscribe(res => {
      if (res) {
        this.preferenceEmailBackUp = this.optInEmail;
        this.preferenceMobileBackUp = this.optInMobile;
        console.log('Profile Update Response', res);

        // console.log(this.optInMobile, 'optin')
        // console.log('Profile Update Response', res);

        let message = '';
        message = this.disableSave ? 'Success! Notifications updated!' : message;

        // if (message) {
        //   this.alertService.setAlert(message, 'Success', AlertType.Success);
        // } else {
        //   this.alertService.setAlert(message, 'Success', AlertType.Success);
        // }
        if (res && (res['result'] === 0 || res['result'] === '0')) {
          if (this.registeredUserOnly) {
            this.router.navigate(['/register/register-detail']).then(() => {
              this.alertService.setAlert(message, '', AlertType.Success);
            });
          } else {
            this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfosuccess');
          }
          this.resetAllEdits();
          this.emailEditCancelText = 'edit';
          this.phoneEditCancelText = 'edit';
          sessionStorage.removeItem('optInEmail');
          sessionStorage.removeItem('optInMobile');
          setTimeout(() => {
            this.profileService.getcommStatus().subscribe(res => {
              console.log('res', res);
              this.preferenceInfo = res;
              this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
              this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
            });
          }, 0);
        }
      } else {
        this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', 'contactinfosuccess');
      }
    });
  }
  updateEmail() {
    let alertMessageFinal = '';
    let alertType = '';
    let resultCode = 0;
    this.profileService
      .updateProfile(this.profileEmailEditForm.value, false, this.editEmail, false, false)
      .flatMap(result => {
        resultCode = result.result;
        if (resultCode === -90129) {
          alertType = 'success';
          alertMessageFinal = result.displaymessage;
        } else if (resultCode === -90124 || resultCode === -90126) {
          alertType = 'error';
          alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
          alertMessageFinal = result.displaymessage;
          console.log('result.displaymessage=', result.displaymessage);
        }
        return this.profileService.fetchProfileInfo();
      })
      .subscribe(
        profile => {
          this.profile = profile;
          this.profileEmailEditForm.patchValue(profile);
          this.profileService.setProfile(this.profile);
          let message = '';
          if (alertMessageFinal === '') {
            message = this.editEmail ? 'Your Email Address has been updated!' : message;
            this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfosuccess');
            if (this.editEmail) {
              this.verifyEmail(this.profile.emailAddress);
            }
          } else {
            message = alertMessageFinal;
            this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'emailfailure');
          }
          this.resetAllEdits();
          this.emailEditCancelText = 'edit';
        },
        err => {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      );
  }
  updatePhone() {
    if (this.profilePhoneEditForm.value.phoneNumber) {
      this.profilePhoneEditForm.value.phoneNumber = (this.profilePhoneEditForm.value.phoneNumber + '').replace(/-/g, '');
    }
    let alertMessageFinal = '';
    let alertType = '';
    let resultCode = 0;
    this.profileService
      .updateProfile(this.profilePhoneEditForm.value, false, false, this.editPhone, false)
      .flatMap(result => {
        resultCode = result.result;
        if (resultCode === -90129) {
          alertType = 'success';
          alertMessageFinal = result.displaymessage;
        } else if (resultCode === -90124 || resultCode === -90126) {
          alertType = 'error';
          alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
          alertMessageFinal = result.displaymessage;
          console.log('result.displaymessage=', result.displaymessage);
        }
        return this.profileService.fetchProfileInfo();
      })
      .subscribe(
        profile => {
          // this.canEdit = this.profileService.authService.isSubscriber;
          this.profile = profile;
          this.profilePhoneEditForm.patchValue(profile);
          this.profileService.setProfile(this.profile);

          let message = '';
          let addressSuccessMessage = '';
          if (resultCode === -90129) {
            addressSuccessMessage = alertMessageFinal;
            alertMessageFinal = '';
          } else if (this.editAddress && resultCode === 0) {
            alertMessageFinal = 'Your Mailing Address has been updated!';
          }
          if (alertMessageFinal === '') {
            message = this.editPhone ? 'Your Phone number has been updated!' : message;
            if (
              this.editPhone &&
              this.profilePhoneEditForm.value.phoneType &&
              this.profilePhoneEditForm.value.phoneType.toUpperCase() === 'MOBILE'
            ) {
              this.verifyPhone(this.profile.phoneNumber);
            }
          } else {
            message = alertMessageFinal;
            this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'phonefailure');
          }
          this.resetAllEdits();
          this.phoneEditCancelText = 'edit';
        },
        err => {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      );
  }

  //Mailing address
  showEdit() {
    let rtnVal: boolean;
    rtnVal = this.profile.userState !== 'REGISTERED-NOT-VERIFIED';
    rtnVal = rtnVal && !this.profileService.authService.isSubscriber;
    rtnVal = rtnVal && this.profileAddressEditForm.value.isEditableAddress;
    return rtnVal;
  }
  toggleAddressVisibility() {
    this.editEmail = false;
    this.editPhone = false;
    this.phoneEditCancelText = 'edit';
    this.emailEditCancelText = 'edit';
    this.alertService.clearError();
    this.editAddress = !this.editAddress;
    if (this.editAddress) {
      this.addressEditCancelText = 'cancel';
      this.getAddressFormDefinition();
    } else {
      this.addressEditCancelText = 'edit';
    }
  }
  getAddressFormDefinition() {
    this.profile = this.profileService.getProfile();
    console.log(this.profileAddressEditForm);
    this.profileAddressEditForm = this.fb.group({
      useridin: '',
      isEditableAddress: false,
      userState: '',
      isDirectPay: false,
      address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
      dob: ['', []],
      city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      state: ['', this.editAddress ? [Validators.required, this.validationService.validateState()] : []],
      zip: ['', this.editAddress ? [Validators.required] : []]
    });
    this.profileAddressEditForm.patchValue(this.profile);
  }
  onSubmit() {
    let alertMessageFinal = '';
    let alertType = '';
    let resultCode = 0;
    this.profileService
      .updateProfile(this.profileAddressEditForm.value, this.editAddress, false, false, false)
      .flatMap(result => {
        resultCode = result.result;
        if (resultCode === -90129) {
          alertType = 'success';
          alertMessageFinal = result.displaymessage;
        } else if (resultCode === -90124 || resultCode === -90126) {
          alertType = 'error';
          alertMessageFinal = result.displaymessage;
        } else if (result.displaymessage !== '') {
          alertMessageFinal = result.displaymessage;
          console.log('result.displaymessage=', result.displaymessage);
        }
        return this.profileService.fetchProfileInfo();
      })
      .subscribe(
        profile => {
          // this.canEdit = this.profileService.authService.isSubscriber;
          this.profile = profile;
          this.profileAddressEditForm.patchValue(profile);
          this.profileService.setProfile(this.profile);
          let message = '';
          let addressSuccessMessage = '';
          if (resultCode === -90129) {
            addressSuccessMessage = alertMessageFinal;
            alertMessageFinal = '';
          } else if (this.editAddress && resultCode === 0) {
            alertMessageFinal = 'Your Mailing Address has been updated!';
          }
          if (alertMessageFinal === '') {
            message = this.editAddress ? addressSuccessMessage : message;
            this.alertService.setAlert(message, '', AlertType.Success, 'component', 'contactinfosuccess');
          } else {
            message = alertMessageFinal;
            this.alertService.setAlert(message, '', AlertType.Failure, 'component', 'addressfailure');
          }
          this.resetAllEdits();
          this.addressEditCancelText = 'edit';
        },
        err => {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
      );
  }
  cancelAddress() {
    this.editAddress = false;
    this.addressEditCancelText = 'edit';
  }

  //Email
  toggleEmailVisibility() {
    this.editAddress = false;
    this.editPhone = false;
    this.phoneEditCancelText = 'edit';
    this.addressEditCancelText = 'edit';
    this.alertService.clearError();
    this.http.showSpinnerLoading();
    this.profileService.getcommStatus().subscribe(res => {
      console.log('res', res);
      res.preferences.map(item => {
        this.preferenceInfo = res;
        this.optInEmail = this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true';
      });
      this.http.hideSpinnerLoading();
    });

    this.editEmail = !this.editEmail;
    if (this.editEmail) {
      this.emailEditCancelText = 'cancel';
      this.optInEmailChanged = false;
      // this.optInEmail = sessionStorage.getItem('optInEmail')?JSON.parse(sessionStorage.getItem('optInEmail')): false;

      this.getEmailFormDefinition();
    } else {
      this.emailEditCancelText = 'edit';
    }
  }
  getEmailFormDefinition() {
    this.profile = this.profileService.getProfile();
    console.log(this.profileEmailEditForm);
    this.profileEmailEditForm = this.fb.group({
      useridin: '',
      emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
      fullName: '',
      isVerifiedEmail: false
    });
    this.profileEmailEditForm.patchValue(this.profile);
  }
  onEmailSubmit() {
    if (!this.profile.isVerifiedEmail) {
      this.updateEmail();
    } else {
      if (this.profile.emailAddress !== this.profileEmailEditForm.value.emailAddress) {
        this.updateEmail();
      } else {
        if (!this.disableSave) {
          this.disableSave = true;
          this.updateCommStatus();
        }
      }
    }
  }
  cancelEmail() {
    this.editEmail = false;
    this.emailEditCancelText = 'edit';
    this.profileEmailEditForm.patchValue(this.profile);
    if (this.optInEmailChanged) {
      this.optInEmail = !this.optInEmail;
    }
  }
  verifyEmail(emailId?: string) {
    this.alertService.clearError();
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
      this.sendcommchlaccesscode(emailId ? emailId : this.diplayEmailAdress, '').subscribe(
        res => {
          if (res['result'] === '0') {
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.diplayEmailAdress);
            sessionStorage.setItem('maskedVerifyPhone', 'N');
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    } else {
      this.sendaccesscode('EMAIL', emailId ? emailId : this.diplayEmailAdress).subscribe(
        res => {
          if (res['result'] === '0') {
            const communicationChannel = this.http.handleDecryptedResponse(res);
            sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
            const userId = sentMailId && sentMailId['commChannel'];
            this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
            sessionStorage.setItem('maskedVerifyPhone', 'N');
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    }
  }
  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }
  onEmailChange() {
    this.optInEmailChanged = true;
    this.optInEmail = !this.optInEmail;
    sessionStorage.setItem('optInEmail', JSON.stringify(this.optInEmail));
    this.allowSaveOnChange();
  }
  allowSaveOnChange() {
    if (this.preferenceMobileBackUp !== this.optInMobile || this.preferenceEmailBackUp !== this.optInEmail) {
      this.disableSave = false;
    } else {
      this.disableSave = true;
    }
  }
  onEmailRegSubmit() {
    this.updateEmail();
  }

  //Mobile
  getPhoneFormDefinition() {
    this.profile = this.profileService.getProfile();
    const defaultPhoneNumber = this.formatPhone('');
    console.log(this.profilePhoneEditForm);
    this.profilePhoneEditForm = this.fb.group({
      useridin: '',
      phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
      phoneNumber: [
        defaultPhoneNumber,
        this.editPhone ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
      ],
      isVerifiedMobile: false
    });
    if (!this.profile.phoneType) {
      this.profile.phoneType = 'MOBILE';
    }
    this.profilePhoneEditForm.patchValue(this.profile);
  }
  formatPhone(inputPhoneNumber) {
    if (inputPhoneNumber !== undefined && inputPhoneNumber !== null && inputPhoneNumber !== '') {
      let phoneNumber: string = inputPhoneNumber;
      phoneNumber = phoneNumber.replace(/-/g, '');
      const areaCode = phoneNumber.slice(0, 3);
      const number = phoneNumber.slice(3);
      return areaCode + '-' + number.slice(0, 3) + '-' + number.slice(3);
    } else {
      return '';
    }
  }
  verifyPhone(phoneNumber?: string) {
    this.alertService.clearError();
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
      this.sendcommchlaccesscode('', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(
        res => {
          if (res['result'] === '0') {
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            this.profileService.maskedVerify = this.maskPhoneNumber(
              phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')
            );
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            sessionStorage.setItem('maskedVerifyPhone', 'Y');
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    } else {
      this.sendaccesscode('MOBILE', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(
        res => {
          if (res['result'] === '0') {
            const communicationChannel = this.http.handleDecryptedResponse(res);
            sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
            console.log('sendaccesscode success', res);
            this.alertService.clearError();
            // only if success
            const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
            const userId = sentMailId && sentMailId['commChannel'];
            this.profileService.maskedVerify = this.maskPhoneNumber(phoneNumber ? phoneNumber : userId);
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            sessionStorage.setItem('maskedVerifyPhone', 'Y');
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    }
  }
  getDefaultOptionForPhoneNumberType() {
    if (this.profile) {
      this.profile.phoneType = 'MOBILE';
      return this.profile.phoneType;
    }
  }
  maskPhoneNumber(userId: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    let maskedUserId = userId
      ? userId.replace(/^(.*)(.{4})$/, (_, digitsToMasked, lastFourDigits) => {
          return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
        })
      : userId;
    const str = maskedUserId;
    const subst = `$1-$2-$3`;
    maskedUserId = str.replace(regex, subst);
    return maskedUserId;
  }
  onPhoneChange() {
    console.log('phone changed optin');
    this.optInPhoneChanged = true;
    this.optInMobile = !this.optInMobile;
    sessionStorage.setItem('optInMobile', JSON.stringify(this.optInMobile));
    this.allowSaveOnChange();
  }
  cancelPhone() {
    this.editPhone = false;
    this.phoneEditCancelText = 'edit';
    this.profilePhoneEditForm.patchValue(this.profile);
    if (this.optInPhoneChanged) {
      this.optInMobile = !this.optInMobile;
    }
  }
  togglePhoneVisibility() {
    this.editAddress = false;
    this.editEmail = false;
    this.emailEditCancelText = 'edit';
    this.addressEditCancelText = 'edit';
    this.alertService.clearError();
    this.http.showSpinnerLoading();
    this.profileService.getcommStatus().subscribe(res => {
      console.log('res', res);
      res.preferences.map(item => {
        this.preferenceInfo = res;
        this.optInMobile = this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true';
      });
      this.http.hideSpinnerLoading();
    });
    this.editPhone = !this.editPhone;
    if (this.editPhone) {
      this.phoneEditCancelText = 'cancel';
      this.optInPhoneChanged = false;
      this.getPhoneFormDefinition();
    } else {
      this.phoneEditCancelText = 'edit';
    }
  }
  isWebMigrated(): boolean {
    return !this.isUseridAPhone && !this.isUseridAPhone && !this.profilePhoneEditForm.value.phoneNumber;
  }
  onPhoneSubmit() {
    if (!this.profile.isVerifiedMobile) {
      this.updatePhone();
    } else {
      if (this.profile.phoneNumber !== this.profilePhoneEditForm.value.phoneNumber) {
        this.updatePhone();
      } else {
        if (!this.disableSave) {
          this.disableSave = true;
          this.updateCommStatus();
        }
      }
    }
  }
  onPhoneRegSubmit() {
    this.updatePhone();
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}

// import { Component, OnInit, OnDestroy } from '@angular/core';
// import { Validators, FormBuilder, FormGroup } from '@angular/forms';
// import { AlertService, ValidationService, AuthService, ConstantsService } from '../../../shared/shared.module';
// import { ActivatedRoute, Router } from '@angular/router';
// import { ProfileService } from '../../../shared/services/myprofile/profile.service';
// import { NotificationPreferencesService } from '../../notification-preferences/notification-preferences.service';
// import { AlertType } from '../../../shared/alerts/alertType.model';
// import { AuthHttp } from '../../../shared/services/authHttp.service';
// import { GlobalService } from '../../../shared/services/global.service';

// declare let $: any;

// @Component({
//   selector: 'app-contact-information',
//   templateUrl: './contact-information.component.html',
//   styleUrls: ['./contact-information.component.scss']
// })
// export class ContactInformationComponent implements OnInit, OnDestroy {
//   profile: any;
//   useridin: string = '';
//   submenu: any = {};
//   memProfile: any;
//   dob: any;
//   preferenceInfo: any;
//   profileAddressEditForm: FormGroup;
//   profileEmailEditForm: FormGroup;
//   profilePhoneEditForm: FormGroup;
//   isUseridAPhone: boolean = false;
//   isUseridAEmail: boolean = false;
//   registeredUserOnly: boolean = false;
//   diplayUserID: string = '';
//   diplayEmailAdress: string = '';
//   canEdit: boolean = false;
//   optInEmail: boolean = false;
//   optInMobile: boolean = false;
//   preferenceEmailBackUp: boolean;
//   preferenceMobileBackUp: boolean;
//   isVerifiedEmail: boolean = false;
//   IsVerifiedMobile: boolean = false;
//   verifiedMobile: string;
//   verifiedEmail: string;
//   isMobileNumberAvail: string;
//   editAddress: boolean;
//   address3: string = '';
//   editEmail: boolean = this.commPreferenceService.editEmail ? this.commPreferenceService.editEmail : false;
//   editPhone: boolean = this.commPreferenceService.editPhone ? this.commPreferenceService.editPhone : false;
//   currentUserScope = '';
//   editHint: boolean;
//   emailOrMobileChanged: boolean = false;

//   mask: Object = { mask: this.validationService.phoneMaskRegister, guide: false };
//   zipMask: Object = { mask: this.validationService.zipMask, guide: false };
//   contactus = this.constants.contactus + this.authService.authToken.scopename;
//   statesList = [
//     { label: 'Alabama', value: 'AL' },
//     { label: 'Alaska', value: 'AK' },
//     { label: 'Arizona', value: 'AZ' },
//     { label: 'Arkansas', value: 'AR' },
//     { label: 'California', value: 'CA' },
//     { label: 'Colorado', value: 'CO' },
//     { label: 'Connecticut', value: 'CT' },
//     { label: 'Delaware', value: 'DE' },
//     { label: 'District of Columbia', value: 'DC' },
//     { label: 'Florida', value: 'FL' },
//     { label: 'Georgia', value: 'GA' },
//     { label: 'Hawaii', value: 'HI' },
//     { label: 'Idaho', value: 'ID' },
//     { label: 'Illinois', value: 'IL' },
//     { label: 'Indiana', value: 'IN' },
//     { label: 'Iowa', value: 'IA' },
//     { label: 'Kansas', value: 'KS' },
//     { label: 'Kentucky', value: 'KY' },
//     { label: 'Louisiana', value: 'LA' },
//     { label: 'Maine', value: 'ME' },
//     { label: 'Maryland', value: 'MD' },
//     { label: 'Massachusetts', value: 'MA' },
//     { label: 'Michigan', value: 'MI' },
//     { label: 'Minnesota', value: 'MN' },
//     { label: 'Mississippi', value: 'MS' },
//     { label: 'Missouri', value: 'MO' },
//     { label: 'Montana', value: 'MT' },
//     { label: 'Nebraska', value: 'NE' },
//     { label: 'Nevada', value: 'NV' },
//     { label: 'New Hampshire', value: 'NH' },
//     { label: 'New Jersey', value: 'NJ' },
//     { label: 'New Mexico', value: 'NM' },
//     { label: 'New York', value: 'NY' },
//     { label: 'North Carolina', value: 'NC' },
//     { label: 'North Dakota', value: 'ND' },
//     { label: 'Ohio', value: 'OH' },
//     { label: 'Oklahoma', value: 'OK' },
//     { label: 'Oregon', value: 'OR' },
//     { label: 'Pennsylvania', value: 'PA' },
//     { label: 'Rhode Island', value: 'RI' },
//     { label: 'South Carolina', value: 'SC' },
//     { label: 'South Dakota', value: 'SD' },
//     { label: 'Tennessee', value: 'TN' },
//     { label: 'Texas', value: 'TX' },
//     { label: 'Utah', value: 'UT' },
//     { label: 'Vermont', value: 'VT' },
//     { label: 'Virginia', value: 'VA' },
//     { label: 'Washington', value: 'WA' },
//     { label: 'West Virginia', value: 'WV' },
//     { label: 'Wisconsin', value: 'WI' },
//     { label: 'Wyoming', value: 'WY' }
//   ];

//   phoneNumberTypeValues = [
//     { label: 'Mobile', value: 'MOBILE' },
//     { label: 'Home', value: 'HOME' },
//     { label: 'Work', value: 'WORK' }
//   ];

//   addressMessages = {
//     'required': 'You must enter a valid mailing address.',
//     'invalidCharacters': 'You must enter a valid mailing address.'
//   };
//   cityMessages = {
//     'required': 'You must enter the city.',
//     'invalidCharacters': 'You must enter a valid city.'
//   };
//   stateMessages = {
//     'required': 'State is required'
//   };
//   zipMessages = {
//     'required': 'You must enter your ZIP code.',
//     'minlength': 'You must enter a valid ZIP code.'
//   };
//   emailMessages = {
//     'required': 'You must enter your email address.',
//     'invalidEmail': 'You must enter a valid email address.'
//   };
//   mobileNumberMessages = {
//     'required': 'You must enter a valid phone number.',
//     'invalidNumber': 'You must enter a valid phone number.',
//     'invalidMobile': 'You must enter a valid phone number.'
//   };

//   mailingAddressToolTipVisible: boolean = false;
//   emailToolTipVisible: boolean = false;
//   mobileToolTipVisible: boolean = false;
//   fpoPreferenceUrl: string;
//   preferenceObject: any;
//   // showPreferenceModal: boolean = false;
//   isMedicare: boolean = false;

//   constructor(
//     private activatedRoute: ActivatedRoute,
//     private router: Router,
//     private alertService: AlertService,
//     private http: AuthHttp,
//     private fb: FormBuilder,
//     private profileService: ProfileService,
//     private globalService: GlobalService,
//     private constants: ConstantsService,
//     private commPreferenceService: NotificationPreferencesService,
//     private validationService: ValidationService,
//     private authService: AuthService
//   ) {
//     this.profileAddressEditForm = this.fb.group({
//       isEditableAddress: false,
//       address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
//       address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
//       city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
//       state: ['', this.editAddress ? [Validators.required] : []],
//       zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []],
//     });
//     this.profileEmailEditForm = this.fb.group({
//       emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
//       isVerifiedEmail: false,
//       isEmailOptedIn: false,
//     });
//     this.profilePhoneEditForm = this.fb.group({
//       phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
//       phoneNumber: [this.editPhone ? [Validators.required, this.validationService.phoneValidator(),
//       this.validationService.phoneNumberValidator()] : []],
//       isVerifiedMobile: false,
//       isMobileOptedIn: false
//     });
//     this.memProfile = sessionStorage.getItem('memProfile') ? sessionStorage.getItem('memProfile') : '';
//     this.dob = this.memProfile ? JSON.parse(this.memProfile).dob : '';
//     this.dob = this.dob ? new Date(this.dob) : '';
//     this.useridin = sessionStorage.getItem('useridin');
//     const numberRegEx = new RegExp('^[0-9]{10}');
//     this.profile = Object.assign({}, this.activatedRoute.snapshot.data.profile);
//     const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     this.currentUserScope = this.authService.authToken ? this.authService.authToken.scopename : '';
//     this.isUseridAPhone = numberRegEx.test(this.useridin) ? true : false;
//     this.isUseridAEmail = emailRegex.test(this.useridin) ? true : false;
//     this.diplayUserID = this.isUseridAPhone ? this.maskPhoneNumberId(this.useridin) : this.useridin;
//     this.resetAllEdits();
//     this.canEdit = this.profileService.authService.isSubscriber;
//     this.mask = { mask: this.validationService.phoneMaskRegister, guide: false };
//     this.fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/promo-block/preference-center';
//     this.preferenceObject = JSON.parse(sessionStorage.getItem('preferences'));
//     this.isMedicare = this.authService.authToken.userType ? (this.authService.authToken.userType.toLowerCase()==="medicare"? true : false) : false;
//   }

//   emailChange(event) {
//     console.log(event.target.value);
//     if (this.profile.emailAddress === event.target.value) {
//       this.emailOrMobileChanged = false;
//     } else {
//       this.emailOrMobileChanged = true;
//     }
//   }

//   phoneChange(event) {
//     if (this.profile.phoneNumber === event.target.value) {
//       this.emailOrMobileChanged = false;
//     } else {
//       this.emailOrMobileChanged = true;
//     }
//   }

//   maskPhoneNumberId(userId: string): string {
//     const regex = /^(.{3})(.{3})(.{4})(.*)/;
//     const subst = `$1-$2-$3`;
//     const maskedUserId = userId ? userId.replace(regex, subst) : userId;
//     return maskedUserId;
//   }

//   ngOnInit() {
//     console.log('this.profile', this.profile);
//     this.preferenceInfo = this.activatedRoute.snapshot.data.commstatus.commstatus;
//     console.log("preferenceinfo",this.preferenceInfo);
//     this.isVerifiedEmail = this.getPreferenceValue('IsVerifiedEmail') === 'true';
//     this.IsVerifiedMobile = this.getPreferenceValue('IsVerifiedMobile') === 'true';
//     this.optInEmail = this.isVerifiedEmail ? this.getPreferenceValue('EmailOptInStatus').toLowerCase() === 'true' : false;
//     this.optInMobile = this.IsVerifiedMobile ? this.getPreferenceValue('MobileOptInStatus').toLowerCase() === 'true' : false;
//     this.updateCommStatus();
//     const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
//     if (this.profile) {
//       if (!this.profile.phoneType) {
//         this.profile.phoneType = 'MOBILE';
//       }
//       this.diplayEmailAdress = this.profile.emailAddress;
//       this.profile.phoneNumber = this.formatPhone(this.profile.phoneNumber);
//       const userRole = this.profileService.getUserRole();
//       this.registeredUserOnly = (userRole === 'REGISTERED-NOT-VERIFIED' || userRole === 'REGISTERED-AND-VERIFIED') ? true : false;
//       this.address3 = '';
//       this.address3 = this.profile.city ? this.address3 + this.profile.city + ', ' : this.address3;
//       this.address3 = this.profile.state ? this.address3 + this.profile.state + ' ' : this.address3;
//       this.address3 = this.profile.zip ? this.address3 + this.profile.zip : this.address3;
//       this.profileAddressEditForm.patchValue(this.profile);
//       this.profileEmailEditForm.patchValue(this.profile);
//       this.profilePhoneEditForm.patchValue(this.profile);
//       this.profileService.setProfile(this.profile);
//     }
//     // Show Paperless Promo content
//     // if(this.preferenceObject.Preferences){
//     //   this.preferenceObject.Preferences.map(item =>{
//     //     if(item.PreferenceType == '1'){
//     //       this.showPreferenceModal = (item.FilterID === 'DOCS_PLAN_MAIL')? true : false;
//     //     }
//     //   })
//     // }else if(this.preferenceObject.errormessage){
//     //   this.showPreferenceModal = true;
//     // }else{
//     //   this.showPreferenceModal = false;
//     // }
//   }

//   onMobileChange() {
//     this.optInMobile = !this.optInMobile;
//   }

//   onEmailChange() {
//     this.optInEmail = !this.optInEmail;
//   }

//   openConsentToReceiveCommunicationModal(value: string) {
//     $('#consentToReceiveCommunications').modal('open');
//     this.showToolTip(value);
//   }

//   updateCommStatus() {
//     this.alertService.clearError();
//     const preferences = [];
//     preferences.push({ 'memKeyName': 'EmailOptInStatus', 'memKeyValue': this.optInEmail.toString() }),
//       preferences.push({ 'memKeyName': 'EmailOptInSource', 'memKeyValue': 'WEB' });
//     preferences.push({ 'memKeyName': 'MobileOptInStatus', 'memKeyValue': this.optInMobile.toString() }),
//       preferences.push({ 'memKeyName': 'MobileOptInSource', 'memKeyValue': 'WEB' });

//     this.commPreferenceService.updateCommStatus({ 'preferences': preferences }).subscribe((res) => {
//       this.preferenceEmailBackUp = this.optInEmail;
//       this.preferenceMobileBackUp = this.optInMobile;
//       console.log('Profile Update Response', res);
//     });
//   }

//   getCommStatus() {
//     return this.commPreferenceService.getcommStatus();
//   }

//   emailEdit() {
//     this.resetAllEdits();
//     this.editPhone = false;
//     this.editEmail = true;
//     this.alertService.clearError();
//     this.getFormDefinition();
//   }

//   phoneEdit() {
//     this.resetAllEdits();
//     this.editEmail = false;
//     this.alertService.clearError();
//     this.editPhone = true;
//     this.getFormDefinition();
//   }

//   addressEdit() {
//     this.resetAllEdits();
//     this.editPhone = false;
//     this.editEmail = false;
//     this.editAddress = true;
//     this.alertService.clearError();
//     this.getFormDefinition();
//   }

//   resetAllEdits() {
//     this.editAddress = false;
//     this.editEmail = this.commPreferenceService.editEmail ? this.commPreferenceService.editEmail : false;
//     this.editPhone = this.commPreferenceService.editPhone ? this.commPreferenceService.editPhone : false;
//     this.editHint = false;
//   }

//   getFormDefinition() {
//     this.profile = this.profileService.getProfile();
//     const defaultPhoneNumber = this.formatPhone('');
//     this.profileAddressEditForm = this.fb.group({
//       isEditableAddress: false,
//       address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
//       address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
//       city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
//       state: ['', this.editAddress ? [Validators.required] : []],
//       zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []],
//     });
//     this.profileEmailEditForm = this.fb.group({
//       emailAddress: [this.diplayUserID, this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
//       isVerifiedEmail: false,
//       isEmailOptedIn: false,
//     });
//     this.profilePhoneEditForm = this.fb.group({
//       phoneType: [this.getDefaultOptionForPhoneNumberType(), this.editPhone ? [Validators.required] : []],
//       phoneNumber: [defaultPhoneNumber, this.editPhone ? [Validators.required, this.validationService.phoneValidator(),
//       this.validationService.phoneNumberValidator()] : []],
//       isVerifiedMobile: false,
//       isMobileOptedIn: false
//     });
//     if (!this.profile.phoneType) {
//       this.profile.phoneType = 'MOBILE';
//     }
//     this.profileAddressEditForm.patchValue(this.profile);
//     this.profileEmailEditForm.patchValue(this.profile);
//     this.profilePhoneEditForm.patchValue(this.profile);
//   }

//   formatPhone(inputPhoneNumber) {
//     if (inputPhoneNumber !== undefined && inputPhoneNumber !== null && inputPhoneNumber !== '') {
//       let phoneNumber: string = inputPhoneNumber;
//       phoneNumber = phoneNumber.replace(/-| |[\])}[{(]/g, '');
//       const areaCode = phoneNumber.slice(0, 3);
//       const number = phoneNumber.slice(3);
//       return areaCode + '' + number.slice(0, 3) + '' + number.slice(3);
//     } else {
//       return '';
//     }
//   }

//   verifyEmail(emailId?: string) {

//     this.alertService.clearError();
//     const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
//     if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
//       this.sendcommchlaccesscode(emailId ? emailId : this.diplayEmailAdress, '').subscribe(res => {
//         if (res['result'] === '0') {
//           console.log('sendaccesscode success', res);
//           this.alertService.clearError();
//           // only if success
//           this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.diplayEmailAdress);
//           sessionStorage.setItem('maskedVerifyPhone', 'N');
//           sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
//           this.navigateToVerifyScreen();
//         } else {
//           if (res['displaymessage']) {
//             this.alertService.setAlert(res['displaymessage'],
//               '', AlertType.Failure);
//           }
//         }
//       }, err => {
//         console.log('error', err);
//       });
//     } else {
//       this.sendaccesscode('EMAIL', emailId ? emailId : this.diplayEmailAdress).subscribe(res => {
//         if (res['result'] === '0') {
//           const communicationChannel = this.http.handleDecryptedResponse(res);
//           sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
//           console.log('sendaccesscode success', res);
//           this.alertService.clearError();
//           // only if success
//           const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
//           const userId = sentMailId && sentMailId['commChannel'];
//           this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
//           sessionStorage.setItem('maskedVerifyPhone', 'N');
//           sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
//           this.navigateToVerifyScreen();
//         } else {
//           if (res['displaymessage']) {
//             this.alertService.setAlert(res['displaymessage'],
//               '', AlertType.Failure);
//           }
//         }
//       }, err => {
//         console.log('error', err);
//       });
//     }
//   }

//   verifyPhone(phoneNumber?: string) {

//     this.alertService.clearError();
//     const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
//     if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
//       this.sendcommchlaccesscode('', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(res => {
//         if (res['result'] === '0') {
//           console.log('sendaccesscode success', res);
//           this.alertService.clearError();
//           // only if success
//           this.profileService.maskedVerify = this.maskPhoneNumber(phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, ''));
//           sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
//           sessionStorage.setItem('maskedVerifyPhone', 'Y');
//           this.navigateToVerifyScreen();
//         } else {
//           if (res['displaymessage']) {
//             this.alertService.setAlert(res['displaymessage'],
//               '', AlertType.Failure);
//           }
//         }
//       }, err => {
//         console.log('error', err);
//       });
//     } else {
//       this.sendaccesscode('MOBILE', phoneNumber ? phoneNumber : this.profile.phoneNumber.replace(/\D/g, '')).subscribe(res => {
//         if (res['result'] === '0') {
//           const communicationChannel = this.http.handleDecryptedResponse(res);
//           sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
//           console.log('sendaccesscode success', res);
//           this.alertService.clearError();
//           // only if success
//           const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
//           const userId = sentMailId && sentMailId['commChannel'];
//           this.profileService.maskedVerify =
//             this.maskPhoneNumber(phoneNumber ? phoneNumber : userId);
//           sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
//           sessionStorage.setItem('maskedVerifyPhone', 'Y');
//           this.navigateToVerifyScreen();
//         } else {
//           if (res['displaymessage']) {
//             this.alertService.setAlert(res['displaymessage'],
//               '', AlertType.Failure);
//           }
//         }
//       }, err => {
//         console.log('error', err);
//       });
//     }
//   }

//   getPreferenceValue(keyName) {
//     const preferenceItem = this.preferenceInfo.preferences.filter((item) => {
//       return item['memKeyName'] === keyName;
//     });
//     return preferenceItem && preferenceItem[0] ? preferenceItem[0]['memKeyValue'] : '';
//   }

//   showEdit() {
//     let rtnVal: boolean;
//     rtnVal = this.profile.userState !== 'REGISTERED-NOT-VERIFIED';
//     rtnVal = rtnVal && !this.profileService.authService.isSubscriber;
//     rtnVal = rtnVal && this.profileAddressEditForm.value.isEditableAddress;
//     return rtnVal;
//   }

//   isWebMigrated(): boolean {
//     return (!this.isUseridAPhone && !this.isUseridAPhone &&
//       !this.profilePhoneEditForm.value.phoneNumber);
//   }

//   onSubmit(submitType?: string) {
//     if (this.profilePhoneEditForm.value.phoneNumber) {
//       this.profilePhoneEditForm.value.phoneNumber = (this.profilePhoneEditForm.value.phoneNumber + '').replace(/-| |[\])}[{(]/g, '');
//     }
//     let alertMessageFinal = '';
//     let alertType = '';
//     let resultCode = 0;
//     console.log(
//       {
//         ...this.profileAddressEditForm.value,
//         ...this.profileEmailEditForm.value,
//         ...this.profilePhoneEditForm.value,
//         dependents: this.profile.dependents,
//         dob: this.profile.dob,
//         fullName: this.profile.fullName,
//         gender: this.profile.gender,
//         health: this.profile.health,
//         hintAnswer: this.profile.hintAnswer,
//         hintQuestion: this.profile.hintQuestion,
//         isDirectPay: this.profile.isDirectPay,
//         userState: this.profile.userState,
//         useridin: this.profile.useridin
//       });
//       console.log(this.editAddress, this.editEmail, this.editPhone, this.editHint);
//     this.profileService.updateProfile(
//       {
//         ...this.profileAddressEditForm.value,
//         ...this.profileEmailEditForm.value,
//         ...this.profilePhoneEditForm.value,
//         dependents: this.profile.dependents,
//         dob: this.profile.dob,
//         fullName: this.profile.fullName,
//         gender: this.profile.gender,
//         health: this.profile.health,
//         hintAnswer: this.profile.hintAnswer,
//         hintQuestion: this.profile.hintQuestion,
//         isDirectPay: this.profile.isDirectPay,
//         userState: this.profile.userState,
//         useridin: this.profile.useridin
//       },
//       this.editAddress, this.editEmail, this.editPhone, this.editHint)
//       .flatMap(result => {
//         resultCode = result.result;
//         if (resultCode === -90129) {
//           alertType = 'success';
//           alertMessageFinal = result.displaymessage;
//         } else if (resultCode === -90124 || resultCode === -90126) {
//           alertType = 'error';
//           alertMessageFinal = result.displaymessage;
//         } else if (result.displaymessage !== '') {
//           alertMessageFinal = result.displaymessage;
//           console.log('result.displaymessage=', result.displaymessage);
//         }
//         return this.profileService.fetchProfileInfo();
//       })
//       .subscribe(
//         profile => {

//           this.canEdit = this.profileService.authService.isSubscriber;
//           this.profile = profile;
//           console.log(this.profile);
//           this.profileAddressEditForm.patchValue(profile);
//           this.profileEmailEditForm.patchValue(profile);
//           this.profilePhoneEditForm.patchValue(profile);
//           this.profileService.setProfile(this.profile);

//           let message = '';
//           let addressSuccessMessage = '';
//           if (resultCode === -90129) {
//             addressSuccessMessage = alertMessageFinal;
//             alertMessageFinal = '';
//           } else if (this.editAddress && resultCode === 0) {
//             alertMessageFinal = 'Your Mailing Address has been updated!';
//           }
//           if (alertMessageFinal === '') {
//             message = this.editAddress ? addressSuccessMessage : message;
//             message = this.editEmail ? 'Your Email Address has been updated!' : message;
//             message = this.editPhone ? 'Your Phone number has been updated!' : message;
//             message = this.editHint ? 'You have successfully updated your hint question and answer!' : message;
//             if (this.editHint) {
//               this.alertService.setAlert(message, '', AlertType.Success);
//             } else {
//               this.alertService.setAlert(message, '', AlertType.Success);
//             }
//             if (this.editEmail && this.emailOrMobileChanged && !(this.profile.userState == 'AUTHENTICATED-AND-VERIFIED')) {
//               this.verifyEmail(this.profile.emailAddress);
//             }
//             if (this.editPhone && this.emailOrMobileChanged && this.profilePhoneEditForm.value.phoneType &&
//               this.profilePhoneEditForm.value.phoneType.toUpperCase() === 'MOBILE' && !(this.profile.userState == 'AUTHENTICATED-AND-VERIFIED')) {
//               this.verifyPhone(this.profile.phoneNumber);
//             }
//           } else {
//             message = alertMessageFinal;
//             this.alertService.setAlert(message, '', AlertType.Failure);
//           }

//           this.resetAllEdits();
//         },
//         err => {
//           this.globalService.handleError(err.error, this.constants.displayMessage);
//         }
//       );
//       this.updateCommStatus();
//   }

//   cancel() {
//     this.resetAllEdits();
//     this.editEmail = false;
//     this.editPhone = false;
//     this.profileService.fetchProfileInfo().subscribe(profile => {
//       const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
//       this.canEdit = this.profileService.authService.isSubscriber;
//       this.profile = Object.assign({}, profile);
//       this.getDefaultOptionForPhoneNumberType();
//       this.profileService.setProfile(this.profile);
//       this.profileAddressEditForm.patchValue(this.profile);
//       this.profileEmailEditForm.patchValue(this.profile);
//       this.profilePhoneEditForm.patchValue(this.profile);
//     });
//   }

//   navigateToVerifyScreen() {
//     this.router.navigate(['/myprofile/verify']).then(() => {
//       this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
//     });
//   }

//   getDefaultOptionForPhoneNumberType() {
//     if (this.profile) {
//       this.profile.phoneType = 'MOBILE';
//       return this.profile.phoneType;
//     }
//   }

//   maskEmailId(userId: string): string {
//     const maskedUserId = userId ? userId.replace(/^(.{3})(.*)(@.*)$/,
//       (_, firstCharacter, charToMasked, domain) => {
//         return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
//       }) : userId;
//     return maskedUserId;
//   }

//   maskPhoneNumber(userId: string): string {
//     const regex = /^(.{3})(.{3})(.{4})(.*)/;
//     let maskedUserId = userId ? userId.replace(/^(.*)(.{4})$/,
//       (_, digitsToMasked, lastFourDigits) => {
//         return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
//       }) : userId;
//     const str = maskedUserId;
//     const subst = `$1-$2-$3`;
//     maskedUserId = str.replace(regex, subst);
//     return maskedUserId;
//   }

//   ngOnDestroy() {
//     this.alertService.clearError();
//     this.commPreferenceService.editPhone = false;
//     this.commPreferenceService.editEmail = false;
//   }

//   showToolTip(value: string) {
//     switch (value) {
//       case 'mailingAddress':
//         this.mailingAddressToolTipVisible = !this.mailingAddressToolTipVisible;
//         break;
//       case 'email':
//         this.emailToolTipVisible = !this.emailToolTipVisible;
//         break;
//       case 'mobile':
//         this.mobileToolTipVisible = !this.mobileToolTipVisible;
//         break;
//     }
//   }

//   private sendaccesscode(
//     commChannelType,
//     commChannel) {
//     return this.profileService.sendaccesscode(commChannelType, commChannel);
//   }

//   private sendcommchlaccesscode(email, mobile) {
//     return this.profileService.sendcommchlaccesscode(
//       email, mobile.replace(/\D/g, ''));
//   }

// }
