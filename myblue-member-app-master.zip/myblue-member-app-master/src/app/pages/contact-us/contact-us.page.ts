import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/services/auth.service';
import { IabService } from '../../shared/services/iab/iab.service';
import { SwrveService, SwrveEventNames } from '../../shared/services/swrve.service';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { from } from 'rxjs';
import { environment } from '../../../environments/environment';
import { NavController, Platform } from '@ionic/angular';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.page.html',
  styleUrls: ['./contact-us.page.scss']
})
export class ContactUsPage implements OnInit {
  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  isRegisteredUser: boolean;
  chatMember =
    'https://chat.bluecrossma.com/system/templates/chat/bcbs/chat.html?subActivity=Chat&entryPointId=1001&templateName=sunburst&languageCode=en&countryCode=US&ver=v11&postChatAttributes=false&eglvrefname=&null&referer=https%3A%2F%2Fmyblue.bluecrossma.com%2F';
  anonymousFeedback = 'https://engage.bluecrossma.com/forms/submit-feedback';
  authenticatedSecureMessage = environment.secureMessageInquiryUrl;
  talkToDoctor = 'https://myblue.bluecrossma.com/health-plan/well-connection';

  constructor(
    public swrveEventNames: SwrveEventNames,
    private authService: AuthService,
    private iabService: IabService,
    private swrveService: SwrveService,
    private callNumber: CallNumber,
    private navCtrl: NavController,
    private platform: Platform
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
  }

  ngOnInit() {}

  openInAppBrowser(url) {
    this.iabService.create(url);
  }

  ionViewWillEnter() {
    console.log('-- sendSwrveEventsForClicks -- AppScreen_ContactUs', this.swrveEventNames.AppScreen_ContactUs);
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_ContactUs);
    const scopeName = this.authService.getScopeName();
    this.isRegisteredUser = scopeName.includes('REGISTERED');
    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    if (this.isAuthenticatedUser) {
      console.log(
        '-- sendSwrveEventsForClicks -- AppClick_HomeAuthenticated_ContactUs',
        this.swrveEventNames.AppClick_HomeAuthenticated_ContactUs
      );
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAuthenticated_ContactUs);
    } else if (this.isRegisteredUser) {
      console.log(
        '-- sendSwrveEventsForClicks -- AppClick_HomeRegistered_ContactUs',
        this.swrveEventNames.AppClick_HomeRegistered_ContactUs
      );
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeRegistered_ContactUs);
    } else if (this.isAnonymousUser) {
      console.log('-- sendSwrveEventsForClicks -- AppClick_HomeAnonymous_ContactUs', this.swrveEventNames.AppClick_HomeAnonymous_ContactUs);
      this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAnonymous_ContactUs);
    }
  }

  sendSwerve(event) {
    this.swrveService.sendAppMessage(event);
  }

  callHelpLine(number: string, swrveEventName: string) {
    from(this.callNumber.callNumber(number, true)).subscribe(response => console.log('Launched dialer'));
    this.sendSwerve(swrveEventName);
  }

  goBack() {
    this.navCtrl.back();
    // this.router.navigate(['../tabs/myInbox/notifications-alerts'], {replaceUrl: true});
  }
}
