import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { MedLookupToolPage } from './med-lookup-tool.page';

const routes: Routes = [
  {
    path: '',
    component: MedLookupToolPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [MedLookupToolPage]
})
export class MedLookupToolPageModule {}
