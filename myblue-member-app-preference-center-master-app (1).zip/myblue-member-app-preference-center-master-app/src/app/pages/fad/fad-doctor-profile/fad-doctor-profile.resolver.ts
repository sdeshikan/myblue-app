import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import {
  FadDoctorProfileRequestModelInterface,
  FadProfessionalResponseModelInterface
} from '../modals/interfaces/fad-doctor-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadDoctorProfileService } from './fad-doctor-profile.service';

@Injectable()
export class FadDoctorProfileResolver<T> implements Resolve<Promise<FadProfessionalResponseModelInterface>> {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private fadSearchResultsService: FadSearchResultsService, private fadDoctorProfileService: FadDoctorProfileService) {}

  async resolve(): Promise<FadProfessionalResponseModelInterface> {
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

    // tslint:disable-next-line:radix
    const professionalId = parseInt(sessionStorage.getItem('professionalId'));
    const networkId =
      searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
        ? searchCriteria.getPlanName().getNetworkId()
        : FAD_CONSTANTS.defaults.networkId;
    const geoLocation =
      searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
        ? searchCriteria.getZipCode().geo
        : FAD_CONSTANTS.defaults.geo;
    // const locationId = searchCriteria.getSearchText().getLocationId();
    const locationId = sessionStorage.getItem('locationId');

    const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
    fadDoctorProfileRequestParams
      .setGeoLocation(geoLocation)
      .setProfessional(professionalId)
      .setNetworkId(networkId)
      .setLocationId(Number(locationId));
    if (sessionStorage.getItem('linkedAffiliationId')) {
      fadDoctorProfileRequestParams['linkedAffiliationId'] = sessionStorage.getItem('linkedAffiliationId');
    } else if (searchCriteria && searchCriteria.getSearchText().isProcedure()) {
      const procedureID = searchCriteria.getSearchText().getProcedureId();
      fadDoctorProfileRequestParams.setProcedureId(procedureID);

      fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius') !== 'null' ? Number(sessionStorage.getItem('radius')) : 25);
    }

    const authUserId = this.useridin;

    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      fadDoctorProfileRequestParams.useridin = this.useridin;
    }

    fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');

    return await this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).toPromise();
  }
}
