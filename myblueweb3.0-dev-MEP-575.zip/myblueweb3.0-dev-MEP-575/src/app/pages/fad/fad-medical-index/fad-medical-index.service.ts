import { Injectable } from '@angular/core';
// import { FadVitalsSpecialitiesSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadMedicalIndexRequestModal } from '../modals/fad-medical-index.modal';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetSearchBySpecialityRequestModel } from '../modals/getSearchBySpeciality.model';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import {
  GetSearchBySpecialityRequestModelInterface,
  GetSearchBySpecialityResponseModelInterface
} from '../modals/interfaces/getSearchBySpeciality-models.interface';
import { FadMedicalIndexParamType } from '../modals/types/fad.types';
@Injectable()
export class FadMedicalIndexService {
  constructor(private bcbsmaHttpService: BcbsmaHttpService, private http: AuthHttp, private authService: AuthService) {}

  public fetchMedicalIndex(request: FadMedicalIndexRequestModal): Observable<GetSearchBySpecialityResponseModelInterface> {
    if (request.type === FadMedicalIndexParamType.procedures) {
      // const url = FadConstants.jsonurls.fadVitalsSpecialitiesUrl;
      // return this.bcbsmaHttpService.get(url);

      // Once We received URL have to update in (FadConstants.urls.fadVitalsProcedureUrl)
      const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
      ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
      if (this.authService.getFadHccsFlag() !== null) {
        ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (this.authService.useridin) {
        ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }
      // if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
      //   ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      // }
      return this.http.encryptPost(FadConstants.urls.fadVitalsProcedureUrl, ProcedureSearchReq).map(response => {
        return response;
      });
    } else if (request.type === FadMedicalIndexParamType.specialities) {
      const specialitySearchReq: GetSearchBySpecialityRequestModelInterface = new GetSearchBySpecialityRequestModel();
      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        specialitySearchReq.setUserId(this.authService.useridin);
      }
      if (this.authService.getFadHccsFlag() !== null) {
        specialitySearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
      }
      specialitySearchReq.setNetworkId(FadConstants.defaults.networkId);

      return this.http.encryptPost(FadConstants.urls.fadVitalsSpecialitiesUrl, specialitySearchReq).map(response => {
        return response;
      });
    }
  }
}
