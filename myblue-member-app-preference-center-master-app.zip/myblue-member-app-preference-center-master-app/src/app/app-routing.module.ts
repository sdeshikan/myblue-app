import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

export const rootRoutes: Routes = [
  {
    path: '',
    loadChildren: './pages/tabs/tabs.module#TabsPageModule'
  },
  {
    path: 'home',
    loadChildren: './pages/home/home.module#HomePageModule'
  },
  {
    path: 'first-time',
    loadChildren: './pages/first-time/first-time.module#FirstTimeModule'
  },
  {
    path: 'register',
    redirectTo: 'tabs/register'
  },
  {
    path: 'member-migration',
    redirectTo: 'tabs/member-migration'
  },
  {
    path: 'pages',
    redirectTo: 'tabs/pages'
  },
  {
    path: 'login-app',
    redirectTo: 'tabs/login-app'
  },
  {
    path: 'login',
    redirectTo: 'tabs/login-app'
  },
  {
    path: 'whatsnew',
    redirectTo: 'tabs/whatsnew'
  },
  {
    path: 'terms-of-use',
    redirectTo: 'tabs/terms-of-use'
  },
  {
    path: 'confidentiality',
    redirectTo: 'tabs/confidentiality'
  },
  {
    path: 'care-cost',
    redirectTo: 'tabs/care-cost'
  },
  {
    path: 'myPlan',
    redirectTo: 'tabs/myPlan'
  },
  {
    path: 'my-doctor',
    redirectTo: 'tabs/my-doctor'
  },
  {
    path: 'myClaims',
    redirectTo: 'tabs/myClaims'
  },
  {
    path: 'my-financial',
    redirectTo: 'tabs/my-financial'
  },
  {
    path: 'myprofile',
    redirectTo: 'tabs/myprofile'
  },
  {
    path: 'myPharmacy',
    redirectTo: 'tabs/myPharmacy'
  },
  {
    path: 'contact-us',
    redirectTo: 'tabs/contact-us'
  },
  {
    path: 'my-medications',
    redirectTo: 'tabs/my-medications'
  },
  {
    path: 'orderreplacement',
    redirectTo: 'tabs/orderreplacement'
  },
  {
    path: 'request-estimate',
    redirectTo: 'tabs/request-estimate'
  },
  {
    path: 'deductibles',
    redirectTo: 'tabs/deductibles'
  },
  {
    path: 'sso/cerner',
    redirectTo: 'tabs/sso/cerner'
  },
  {
    path: 'sso/alegeus',
    redirectTo: 'tabs/sso/alegeus'
  },
  {
    path: 'sso/heathequity',
    redirectTo: 'tabs/sso/heathequity'
  },
  {
    path: 'sso/connecture',
    redirectTo: 'tabs/sso/connecture'
  },
  {
    path: 'account',
    redirectTo: 'tabs/account'
  },
  {
    path: 'med-lookup-tool',
    redirectTo: 'tabs/med-lookup-tool'
  },
  {
    path: 'mycards',
    redirectTo: 'tabs/mycards'
  },
  {
    path: 'myInbox',
    redirectTo: 'tabs/myInbox'
  },
  {
    path: 'notification-preferences',
    redirectTo: 'tabs/notification-preferences'
  },
  {
    path: 'myInbox',
    redirectTo: 'tabs/myInbox'
  },
  {
    path: 'changeMyPcp',
    redirectTo: 'tabs/my-doctor/update-pcp'
  },
  {
    path: 'fad',
    redirectTo: 'tabs/fad'
  },
  {
    path: 'fitness-and-weightloss',
    redirectTo: 'tabs/fitness-and-weightloss'
  },
  {
    path: 'reimbursement-details',
    redirectTo: 'tabs/fitness-and-weightloss/reimbursement-details'
  },
  {
    path: 'my-pillpack',
    redirectTo: 'tabs/my-pillpack'
  },
  {
    path: 'yes',
    redirectTo: 'tabs/yes'
  }
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(rootRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
