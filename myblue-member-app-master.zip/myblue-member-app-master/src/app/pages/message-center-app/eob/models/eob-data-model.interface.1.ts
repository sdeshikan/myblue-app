import { MyBlueGeneralAPIRequestModelInterface
} from '../../../../shared/models/interfaces/generic-app-models.interface';

export interface EOBListRequestModelInterface extends MyBlueGeneralAPIRequestModelInterface {
    statementDateRange?: CustomDateRangeMetaInterface;
    serviceDateRange?: CustomDateRangeMetaInterface;
}
export interface EOBLinkRequestModelInterface extends MyBlueGeneralAPIRequestModelInterface {
    claimID? : string;
    nascoSubscriberNumber? :string;
    serviceDate? : string;
}
export interface EOBListResponseModelInterface {
   EOBList: EOBRecord[];
}
export interface CustomDateRangeMetaInterface {
    startDate?: string;
    endDate?: string;
}

export interface EOBRecord extends MyBlueGeneralAPIRequestModelInterface {
   
    result: number;
    errormessage: string;
    displaymessage: string;
    ServicingPlanCode: string;
    nascoSubscriberNumber: string;
    controlPlanCode: string;
    claimID: string;
    providerName: string;
    eobStatementDate: string;
    serviceStartDate:string;
    serviceEndDate:string;
}

export interface EOBDocumentReqParams extends MyBlueGeneralAPIRequestModelInterface {
   
    eobClaimId : number;
    nascoSubscriberNumber : number;
    serviceDate : string;
}


