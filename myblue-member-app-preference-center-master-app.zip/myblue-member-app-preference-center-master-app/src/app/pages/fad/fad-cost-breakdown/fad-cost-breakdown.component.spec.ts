import { DatePipe, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ModalController, PopoverController } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '../../../shared/services/alert.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { DependantsService } from '../../../shared/services/dependant.service';
import { GlobalService } from '../../../shared/services/global.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { FadCostBreakdownComponent } from './fad-cost-breakdown.component';
import { FadCostBreakdownService } from './fad-cost-breakdown.service';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AppState } from '../../../store/state/app.state';
import { StorageServiceModule } from 'angular-webstorage-service';
import { IonicStorageModule } from '@ionic/storage';

describe('FadCostBreakdownComponent', () => {
  let component: FadCostBreakdownComponent;
  let fixture: ComponentFixture<FadCostBreakdownComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NgxsSelectSnapshotModule.forRoot(),
        NgxsModule.forRoot([AppState]),
        StorageServiceModule,
        IonicStorageModule.forRoot()
      ],
      providers: [
        FadCostBreakdownService,
        BcbsmaHttpService,
        ConstantsService,
        GlobalService,
        AlertService,
        DependantsService,
        TitleCasePipe,
        DatePipe,
        FadSearchResultsService,
        FadBreadCrumbsService,
        FadFacilityProfileService,
        FadLandingPageService,
        FadDoctorProfileService,
        FadService,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      declarations: [FadCostBreakdownComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadCostBreakdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
