import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClaimsService } from './claims.service';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatSidenavModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatListModule,
  MatRadioModule,
  MatNativeDateModule,
  MatButtonModule
} from '@angular/material';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { DatePipe } from '@angular/common';
import { OrderModule } from 'ngx-order-pipe';
import { FilterPipe } from 'ngx-filter-pipe';
import { TitleCasePipe } from '@angular/common';
import { ClaimsPage } from './claims/claims.page';
import { ClaimDetailsPage } from './claim-details/claim-details.page';
import { ClaimStatusDetailsPage } from './claim-status-details/claim-status-details.page';
import { ClaimsAppRouter } from './claims.routing';
import { FilterClaimsComponent } from './claims/filter-claims/filter-claims.component';
import { IonicModule } from "@ionic/angular";

@NgModule({
  declarations: [ClaimsPage, ClaimDetailsPage, ClaimStatusDetailsPage, FilterClaimsComponent],
  imports: [
    CommonModule,
    ClaimsAppRouter,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MatExpansionModule,
    FilterPipeModule,
    OrderModule,
    IonicModule
  ],
  providers: [ClaimsService, DatePipe, FilterPipe, TitleCasePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [FilterClaimsComponent]
})
export class ClaimsAppModule {}
