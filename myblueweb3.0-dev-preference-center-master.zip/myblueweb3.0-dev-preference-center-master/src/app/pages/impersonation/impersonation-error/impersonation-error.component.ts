import { Component, Input, OnInit } from '@angular/core';
import { ImpersonationComponent } from '../impersonation.component';

@Component({
  selector: 'app-impersonation-error',
  templateUrl: './impersonation-error.component.html',
  // template:' {{ message }}',
  styleUrls: ['./impersonation-error.component.scss']
})
export class ImpersonationErrorComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
