import {
    AwardDetailInterface, DisclaimersInterface,
    FadAdditionalInformationInterface, FadAmenitiesInterface,
    FadAnswerListInterface,
    FadAwardsInterface,
    FadCostBenefitsInterface,
    FadFacilityCostInterface,
    FadFacilityProfileRequestModelInterface,
    FadFacilityResponseModelInterface,
    FadGeolocationDetailInterface,
    FadIdentifiersInterface,
    FadQualityListInterface,
    FadQuestionAnswerListInterface,
    FadRatingsListInterface,
    FadReviewsListInterface,
    FadTiersInterface,
    LocationListInterface
} from './interfaces/fad-facility-profile-details.interface';

export class FadFacilityProfileRequestModel implements FadFacilityProfileRequestModelInterface {
    geoLocation: string;
    locationId: number;
    facilityId: number;
    networkId: number;
    useridin: string;
    procedureId: string;
    radius: number;

    getGeoLocation(): string {
        return this.geoLocation;
    }
    setGeoLocation(geoLocation: string): FadFacilityProfileRequestModelInterface {
        this.geoLocation = geoLocation;
        return this;
    }

    getLocationId(): number {
        return this.locationId;
    }

    setLocationId(locationId: number): FadFacilityProfileRequestModelInterface {
        this.locationId = locationId;
        return this;
    }

    getfacilityId(): number {
        return this.facilityId;
    }
    setfacilityId(facilityId: number): FadFacilityProfileRequestModelInterface {
        this.facilityId = facilityId;
        return this;
    }

    getNetworkId(): number {
        return this.networkId;
    }
    setNetworkId(networkId: number): FadFacilityProfileRequestModelInterface {
        this.networkId = networkId;
        return this;
    }

    getProcedureId(): string {
        return this.procedureId;
    }
    setProcedureId(procedureId: string): FadFacilityProfileRequestModelInterface {
        this.procedureId = procedureId;
        return this;
    }

    getRadius(): number {
        return this.radius;
    }
    setRadius(radius: number): FadFacilityProfileRequestModelInterface {
        this.radius = radius;
        return this;
    }

}

export class FadFacilityResponseModel implements FadFacilityResponseModelInterface {
    result: number;
    errormessage: string;
    displaymessage: string;
    facilityName: string;
    disclaimers: DisclaimersModel[];
    location: LocationListModel[];
    matchedLocation: LocationListModel;
    onRecordDiclaimers?: DisclaimersModel;
}
export class LocationListModel implements LocationListInterface {
    specialty: string;
    facilityId: number;
    address: string;
    phone: number;
    geoLocation: FadGeolocationDetailModel[];
    amenities: FadAmenitiesModel[];
    awards: FadAwardsInterface[];
    costBenefit: FadCostBenefitsModel;
    facilityCost: FadFacilityCostModel;
    additionalInformation: FadAdditionalInformationModel[];
    identifiers: FadIdentifiersModel[];
    ratings: FadRatingsListModel[];
    quality: FadQualityListModel[];
    reviews: FadReviewsListInterface;
    tiers: FadTiersModel;
    locationId: number;
}

export class DisclaimersModel implements DisclaimersInterface {
    text: string;
    category: string;
    priority: 0;
    id?: number;
}

export class FadGeolocationDetailModel implements FadGeolocationDetailInterface {
    latitude: number;
    longitude: number;
}

export class FadAdditionalInformationModel implements FadAdditionalInformationInterface {
    typeCode: string;
    value: string;
}

export class FadQualityListModel implements FadQualityListInterface {
    name: string;
    score: number;
}

export class FadAmenitiesModel implements FadAmenitiesInterface {
    type: string;
}

export class FadIdentifiersModel implements FadIdentifiersInterface {
    typeCode: string;
    value: string;
}

export class FadAwardsModel implements FadAwardsInterface {
    name: string;
    awardDetails: FadAwardDetailModel[];
    typeCode: string;
}

export class FadFacilityCostModel implements FadFacilityCostInterface {
    copay: number;
    coinsuranceAmount: number;
    deductibleAmount: number;
    employerCost: number;
    procedureCost: number;
    memberCost: number;
    individualDeductibleLimit: number;
    individualDeductibleAccumulated: number;
    overallDeductibleLimit: number;
    overallDeductibleAccumulated: number;
    individualOutofPocketLimit: number;
    individualOutofPocketAccumulated: number;
    familyOutofPocketLimit: number;
    familyOutofPocketAccumulated: number;
}

export class FadCostBenefitsModel implements FadCostBenefitsInterface {
    individualDeductibleLimit: number;
    individualDeductibleAccumulated: number;
    overallDeductibleLimit: number;
    overallDeductibleAccumulated: number;
    individualOutofPocketLimit: number;
    individualOutofPocketAccumulated: number;
    familyOutofPocketLimit: number;
    familyOutofPocketAccumulated: number;
    copay: number;
    coinsuranceAmount: number;
    deductibleAmount: number;
    employerCost: number;
    procedureCost: number;
    memberCost: number;
}
export class FadAwardDetailModel implements AwardDetailInterface {
    name: string;
    url: string;
}


export class FadRatingsListModel implements FadRatingsListInterface {
    overallRating: number;
    percentRecommended: number;
    totalRatings: number;
}

export class FadReviewsList implements FadReviewsListInterface {
    name: string;
    questionAnswer: FadQuestionAnswerListModel[];
}

export class FadQuestionAnswerListModel implements FadQuestionAnswerListInterface {
    question: string;
    answers: FadAnswerListModel[];
}

export class FadAnswerListModel implements FadAnswerListInterface {
    answer: string;
    answerPercent: string;
}

export class FadTiersModel implements FadTiersInterface {
    description: string;
}
