import { GeneralErrorInterface } from '../../../../shared/models/interfaces/generic-app-models.interface';

export interface GetSearchByProviderRequestModelInterface {
    geoLocation: string;
    limit: number;
    page: number;
    networkId: number;
    searchParameter: number;
    useridin: string;

    getGeoLocation(): string;
    setGeoLocation(geoLocation: string): GetSearchByProviderRequestModelInterface;

    getLimit(): number;
    setLimit(limit: number): GetSearchByProviderRequestModelInterface;

    getPage(): number;
    setPage(page: number): GetSearchByProviderRequestModelInterface;

    getNetworkId(): number;
    setNetworkId(networkId: number): GetSearchByProviderRequestModelInterface;

    getSearchParameter(): number;
    setSearchParameter(searchParameter: number): GetSearchByProviderRequestModelInterface;
}

export interface GetSearchByProviderResponseModelInterface extends GeneralErrorInterface {
    searchParameter: string;
    professionalsCount: number;
    facilitiesCount: number;
    searchSpecialtyCount: number;
    searchProcedureCount: number;

    professionals: GSBPRProfessionalEntityInterface[];
    facilities: GSBPRFacilityEntityInterface[];
    searchSpecialties: GSBPRSearchSpecialtiesEntityInterface[];
    searchProcedures: GSBPRSearchProceduresEntityInterface[];
}

export interface GSBPRProfessionalEntityInterface {
    locationId: number;
    id: number;
    name: string;
    specialty: string;
}


// tslint:disable-next-line:no-empty-interface
export interface GSBPRFacilityEntityInterface extends GSBPRProfessionalEntityInterface {

}

export interface GSBPRSearchSpecialtiesEntityInterface {
    id: string;
    name: string;
    resourceTypeCode: string;
    isProcedure: boolean;
    procedureDescription: string;
}

export interface GSBPRSearchProceduresEntityInterface {
    id: number;
    name: string;
    resourceTypeCode: string;
    isProcedure: boolean;
    procedureDescription: string;
}
