import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';

@Injectable()
export class CommunicationPreferenceService {
  private preferenceDataChange = new BehaviorSubject<any>(null);
  public preferenceDataChange$ = this.preferenceDataChange;

  constructor() {}

  setDataChange() {
    this.preferenceDataChange.next(new Date().toString());
  }
}
