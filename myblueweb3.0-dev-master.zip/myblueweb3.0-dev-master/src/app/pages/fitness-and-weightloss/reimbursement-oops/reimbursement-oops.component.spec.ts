import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReimbursementOopsComponent } from './reimbursement-oops.component';

describe('ReimbursementOopsComponent', () => {
  let component: ReimbursementOopsComponent;
  let fixture: ComponentFixture<ReimbursementOopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReimbursementOopsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReimbursementOopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
