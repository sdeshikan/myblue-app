import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';

@Injectable()
export class FadReviewService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  constructor(private http: HttpClient) {}

  getReviewQuestions() {
    const request = {
      useridin: this.useridin
    };
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }
    return this.http.post<any>(FAD_CONSTANTS.urls.fadGetReviewQuestons, request);
  }
  postReviewSubmitQuestions(questionsrequestobject) {
    const request = {
      useridin: this.useridin
    };
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }
    request['reviewQuestions'] = questionsrequestobject;
    request['reviewIdentifier'] = sessionStorage.getItem('reviewIdentifier');

    return this.http.post<any>(FAD_CONSTANTS.urls.fadpostSubmitQuestions, request);
  }
}
