import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatePipe, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ModalController } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsModule } from '@ngxs/store';
import { StorageServiceModule } from 'angular-webstorage-service';
import { NgxMaskModule } from 'ngx-mask';
import { CamelCasePipe } from '../../pipes/camelcase/camel-case.pipe';
import { CasingForFilterPipe } from '../../pipes/casingForFilter/casing-for-filter.pipe';
import { ClaimIdPipe } from '../../pipes/claim-id/claim-id.pipe';
import { FeatureToggleService } from '../../services/feature.service';
import { FooterService } from '../../shared/layouts/footer/footer.service';
import { HeaderService } from '../../shared/layouts/header/header.service';
import { AlertService } from '../../shared/services/alert.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { GlobalService } from '../../shared/services/global.service';
import { HomeService } from '../../shared/services/home.service';
import { AppState } from '../../store/state/app.state';
import { MyMedicationDetailsService } from '../my-medication/my-medication-details/my-medication-details.service';
import { SsoService } from '../sso/sso.service';
import { HomePageComponent } from './home-page.component';
import { DeductibleService } from '../../services/deductible.service';

describe('HomePage', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);

  const mockService = jasmine.createSpyObj('FeatureToggleService', ['isFeatureEnabled']);

  mockService.isFeatureEnabled.and.returnValue(true);

  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NgxMaskModule.forRoot(),
        IonicStorageModule.forRoot(),
        StorageServiceModule,
        NgxsSelectSnapshotModule.forRoot(),
        NgxsModule.forRoot([AppState]),
        NgxMaskModule.forRoot()
      ],
      declarations: [HomePageComponent, CamelCasePipe, ClaimIdPipe, CasingForFilterPipe],
      providers: [
        {
          provide: FeatureToggleService,
          useValue: mockService
        },
        ConstantsService,
        GlobalService,
        DependantsService,
        AlertService,
        TitleCasePipe,
        DatePipe,
        HomeService,
        DeductibleService,
        MyMedicationDetailsService,
        InAppBrowser,
        SsoService,
        HeaderService,
        FooterService,
        AndroidPermissions,
        AppRate,
        AppVersion,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
