import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';

import { HomePageComponent } from './home-page.component';
import { FirstTimePage } from './first-time.page/first-time.page.component';
import { SharedModule } from '../../shared/shared.module';
import { HomepageResolver } from './../../shared/routeresolvers/homepage-resolver';
import { LandingGuard } from '../landing/landing.guard';
import { HomeGuard } from './home.guard';

import { HomeService } from '../../shared/services/home.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { PharmacyLinksService } from '../../shared/services/mypharmacy/pharmacylinks.service';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent,
    canActivate: [HomeGuard],
    resolve: {
      home: HomepageResolver
    },
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'first-time',
    component: FirstTimePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IonicStorageModule.forRoot(),
    SharedModule,
    MatDialogModule,
    MatIconModule,
    RouterModule.forChild(routes)
  ],

  providers: [
    HomeGuard,
    HomeService,
    InAppBrowser,
    AppRate,
    PharmacyLinksService
  ],
  declarations: [
    HomePageComponent,
    FirstTimePage,
  ]
})
export class HomePageModule {}
