import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';

@Injectable()
export class FadFacilityProfileService {
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  public facilityProfile: any;
  constructor(private http: HttpClient) {}

  getFadGetprofessionalprofileDetails(request: FadFacilityProfileRequestModelInterface): Observable<FadFacilityResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }
    return this.http.post<FadFacilityResponseModelInterface>(FAD_CONSTANTS.urls.facilityProfile, request);
  }
}
