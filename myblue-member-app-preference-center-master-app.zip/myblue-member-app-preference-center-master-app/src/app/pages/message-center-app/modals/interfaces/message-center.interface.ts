import { NoDocumentsFoundComponentModel } from '../message-center.modal';
import { MessageDetailsSearchResponseModelInterface } from './message-center-search.interface';

export interface CommonDocumentEntityInterface {
  messageId: string;
  messageUpdatedDateTime: string;
  dateStamp?: string;
  rowNum?: number;
  ShortText: string;
  LongText: string;
  hideEntityFromDisplay?: boolean;
}

export interface MessageCenterNoDocsFoundPageModelInterface {
  title: string;
  noDocsMessage: string;
  containerInfo: string;
}

export interface NoDocumentsFoundComponentModelInterface {
  mode: string;
  title: string;
  searchCriteria: MessageDetailsSearchResponseModelInterface;
}

export interface NoDocumentsFoundComponentConsumer {
  noDocsFound: NoDocumentsFoundComponentModelInterface;
}

export interface NoSearchResultsFoundComponentConsumer {
  noSearchResultsFound: NoDocumentsFoundComponentModelInterface;
  isNoSearchResults: boolean;
}
