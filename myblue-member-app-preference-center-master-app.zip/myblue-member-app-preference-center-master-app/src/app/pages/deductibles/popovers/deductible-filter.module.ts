import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { DeductibleFilterPopover } from './deductible-filter.popover';

@NgModule({
  imports: [CommonModule, FormsModule, IonicModule],
  declarations: [DeductibleFilterPopover]
})
export class DeductibleFilterModule {}
