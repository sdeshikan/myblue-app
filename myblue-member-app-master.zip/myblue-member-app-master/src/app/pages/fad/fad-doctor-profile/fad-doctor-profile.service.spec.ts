import { TestBed, inject } from '@angular/core/testing';

import { FadDoctorProfileService } from './fad-doctor-profile.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';

describe('FadDoctorProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [FadDoctorProfileService, AuthHttp, AuthService, ConstantsService]
    });
  });

  it('should be created', inject([FadDoctorProfileService], (service: FadDoctorProfileService) => {
    expect(service).toBeTruthy();
  }));
});
