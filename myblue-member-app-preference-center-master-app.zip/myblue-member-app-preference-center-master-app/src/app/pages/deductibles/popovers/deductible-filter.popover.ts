import { Component, OnInit } from '@angular/core';
import { NavParams, PopoverController } from '@ionic/angular';
import { MemberDeductibleModel } from '../models/member-deductible.model';
import { Store } from '@ngxs/store';
import { GetIndividualDeductibles, SetFamilyDeductibles } from '../../../store/actions/deductible.actions';

@Component({
  selector: 'app-deductible-filter-popover',
  templateUrl: './deductible-filter.popover.html'
})
export class DeductibleFilterPopover implements OnInit {
  members: MemberDeductibleModel[];
  selectedFilter: string;
  toggleMembers = true;
  useridin: string;

  constructor(private params: NavParams, private store: Store, private popoverController: PopoverController) {}

  ngOnInit() {
    this.members = this.params.data.members;
    this.useridin = this.params.data.useridin;
    this.selectedFilter = this.params.data.current;
  }

  onTypeChange() {
    this.toggleMembers = !this.toggleMembers;
  }

  applyFilter() {
    if (this.selectedFilter !== 'family') {
      this.store.dispatch(new GetIndividualDeductibles(this.selectedFilter));
      this.selectedFilter = this.params.data.current;
    } else {
      this.store.dispatch(new SetFamilyDeductibles());
    }

    this.popoverController.dismiss();
  }
}
