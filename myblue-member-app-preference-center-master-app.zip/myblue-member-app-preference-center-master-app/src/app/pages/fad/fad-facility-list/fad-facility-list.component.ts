import {
  ApplicationRef,
  ChangeDetectorRef,
  Component,
  ComponentFactoryResolver,
  ElementRef,
  EventEmitter,
  HostListener,
  Injector,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';

import { FadFacilityCardComponentInputModel } from '../modals/fad-profile-card.modal';
import { FadFacilityListComponentOutputModel, FadSearchListComponentOutputModel } from '../modals/fad-search-list.modal';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import {
  FadFacilityListComponentInputModelInterface,
  FadFacilityListComponentOutputModelInterface,
  FadSearchListComponentOutputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import { FadZipCodeSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { FadFacilityCardConsumer, FadNoSearchResultsPageConsumer } from '../modals/interfaces/fad.interface';
import { FadFacilityListService } from './fad-facility-list.service';

import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityCardComponentOutputModelInterface } from '../modals/interfaces/fad-profile-card.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

import { Router } from '@angular/router';
import { FadFacilityCompareService } from '../fad-facility-compare/fad-facility-compare.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import { FadFacilityInterface, GetSearchByFacilityResponseModelInterface } from '../modals/interfaces/getSearchByFacility-models.interface';

@Component({
  selector: 'app-fad-facility-list',
  templateUrl: './fad-facility-list.component.html',
  styleUrls: ['./fad-facility-list.component.scss']
})
export class FadFacilityListComponent implements OnInit, OnChanges, FadNoSearchResultsPageConsumer, FadFacilityCardConsumer {
  @Output() componentOutput: EventEmitter<FadFacilityListComponentOutputModelInterface> = new EventEmitter<
    FadFacilityListComponentOutputModel
  >();

  @Output() clearFilter: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<FadSearchListComponentOutputModel>();

  @Input() componentInput: FadFacilityListComponentInputModelInterface;

  @ViewChild('profileCardList') profileCardList: ElementRef;

  public isDisplayBanner = false;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public searchResponse: GetSearchByFacilityResponseModelInterface;
  public facilityList: FadFacilityInterface[] = null;
  public selectedProfessionals: FadFacilityInterface[] = [];
  private cachedAllZipCodeInfo: FadZipCodeSearchResponseModelInterface;

  public list: number[] = [];
  private maxSelectionAllowed = 5;
  isFilterChanged: boolean;

  constructor(
    private router: Router,
    private fadSearchListService: FadFacilityListService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private resolver: ComponentFactoryResolver,
    private injector: Injector,
    private appRef: ApplicationRef,
    private fadSearchResultsService: FadSearchResultsService,
    private landingPageService: FadLandingPageService,
    public fadFacilityCompareService: FadFacilityCompareService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.facility;
  }

  // Show banner section on window scroll to clear and delete message listing
  @HostListener('window:scroll', ['$event'])
  showBannerOnWindowScroll($event) {
    const fadSearchListPos = this.el.nativeElement.offsetTop;
    const windowScrollPos = window.pageYOffset;
    this.isDisplayBanner = windowScrollPos > fadSearchListPos;
  }

  ngOnInit() {
    try {
      this.cachedAllZipCodeInfo = this.landingPageService.vitalsZipCodeInfo;
    } catch (exception) {}
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      this.componentInput = changes.componentInput.currentValue;
      this.isFilterChanged = this.fadSearchResultsService.filterChanged;
      if (this.componentInput) {
        this.searchResponse = this.componentInput.facilityResults;
        if (this.searchResponse) {
          if (this.fadSearchListService.isFilterChangedFlag === true) {
            this.fadSearchListService.isFilterChangedFlag = false;
            this.clearProfileSelections();
          }
          if (this.fadFacilityCompareService.getSearchResult() == null) {
            this.clearProfileSelections();
          }

          this.facilityList = this.searchResponse.facilities;
          const disableFurtherSelection = this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed;
          this.facilityList = this.facilityList.map(item => ({
            ...item,
            isDisabled: item.isChecked ? false : disableFurtherSelection
          }));
          this.isNoSearchResults = false;
        } else {
          this.isNoSearchResults = true;
        }
        this.cdRef.detectChanges();
      }
    } catch (exception) {}
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(facility: FadFacilityInterface): FadFacilityCardComponentInputModel {
    return new FadFacilityCardComponentInputModel(facility);
  }

  public onSearchListComponentInteraction(event) {
    console.log(event);
    this.clearFilter.emit(event);
  }

  public onProfileCardComponentInteraction(facilityCardCompOutput: FadFacilityCardComponentOutputModelInterface) {
    const index = this.facilityList.findIndex(item => item.facilityId === facilityCardCompOutput.facility.facilityId);
    const selectedItem = this.facilityList[index];
    selectedItem.isChecked = facilityCardCompOutput.isSelected;
    this.selectedProfessionals = this.facilityList.filter(item => item.isChecked);
    const fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection = this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed;
    this.facilityList = this.facilityList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });
    this.fadFacilityCompareService.setSearchResult(this.selectedProfessionals);
    this.componentOutput.emit({ fadSeachListComponentOutput, index, isChecked: facilityCardCompOutput.isSelected });
  }

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList !== undefined) {
      const checkBoxList: NodeListOf<Element> = this.profileCardList.nativeElement.querySelectorAll('[type="checkbox"]');
      Array.from(checkBoxList).forEach(checkBox => {
        const chkBox = checkBox as HTMLInputElement;
        chkBox.removeAttribute('checked');
        chkBox.checked = false;
      });
    }
  }
}
