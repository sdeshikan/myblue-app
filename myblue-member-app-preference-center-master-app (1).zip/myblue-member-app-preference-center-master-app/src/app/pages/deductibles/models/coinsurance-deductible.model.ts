export interface CoinsuranceDeductibleModel {
  networkIndicatorForCoinsurance: string;
  coinsuranceMax: number;
  coinsuranceContributed: number;
  coinsuranceRemainingMeet: string;
  coinsuraneexclusionExcep: string;
  coinsuranceLimitationContent: string;
}
