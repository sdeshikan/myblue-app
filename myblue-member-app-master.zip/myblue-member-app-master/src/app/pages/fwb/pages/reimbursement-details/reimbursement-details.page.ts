import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { STATES_LIST } from '../../../my-profile-app/communication-preference/communication-preference.constant';
import { Actions, ofActionSuccessful, Select, Store } from '@ngxs/store';
import { FitnessSelectors } from '../../../../store/selectors/fitness.selectors';
import { Observable, of, Subject } from 'rxjs';
import { ReimbursementModel } from '../../models/reimbursement-model';
import { BenefitModel } from '../../models/benefit-model';
import { ActionSheetController, IonContent, ModalController, NavController, Platform, PopoverController } from '@ionic/angular';
import { InfoModalComponent } from '../../../../modals/info-modal/info-modal.component';
import { InfoPopoverComponent } from '../../../../popovers/info-popover/info-popover.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {
  ClearImages,
  DeleteImage,
  HideProgressModal,
  ShowProgressModal,
  SubmitReimbursementForm,
  UploadReimbursementReceipt
} from '../../../../store/actions/fitness.actions';
import { GlobalUtils } from '../../../../utils/global.utils';
import { MemberModel } from '../../models/member-model';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { AuthService } from '../../../../shared/services/auth.service';
import { ProgressModalComponent } from '../../../../modals/progress-modal/progress-modal.component';
import { takeUntil } from 'rxjs/operators';
import { amountWithinRange } from '../../../../utils/fitness.utils';
import { PhotoModel } from '../../models/photo.model';

@Component({
  selector: 'app-reimbursement-details',
  templateUrl: './reimbursement-details.page.html',
  styleUrls: ['./reimbursement-details.page.scss']
})
export class ReimbursementDetailsPage implements OnInit, OnDestroy {
  @ViewChild(IonContent) content: IonContent;

  @Select(FitnessSelectors.getSelectedReimbursement) selectedReimbursement$: Observable<ReimbursementModel>;
  @Select(FitnessSelectors.getSelectedBenefit) selectedBenefit$: Observable<BenefitModel>;
  @Select(FitnessSelectors.getMaskedEmail) maskedSubscriberEmail$: Observable<string>;
  @Select(FitnessSelectors.isSubscriber) isSubscriber$: Observable<boolean>;
  @Select(FitnessSelectors.getMaskedMemberEmail) memberEmail$: Observable<string>;
  @Select(FitnessSelectors.getPhotos) photos$: Observable<PhotoModel[]>;
  @Select(FitnessSelectors.getMembers) members$: Observable<MemberModel[]>;
  @Select(FitnessSelectors.disablePhotoSubmit) disablePhotoSubmit$: Observable<boolean>;

  unsubscribe$ = new Subject<void>();

  stateList = STATES_LIST;
  showAddEmail = false;
  isCordova = false;
  reimbursementForm: FormGroup;
  options: CameraOptions;
  progressModal: HTMLIonModalElement;
  isMedicare = false;

  membersAlertOptions: any = {
    header: 'Select a Member',
    translucent: true
  };

  stateAlertOptions: any = {
    header: 'Select your state',
    translucent: true
  };

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private modalController: ModalController,
    private popoverController: PopoverController,
    private actionSheetCtrl: ActionSheetController,
    private platform: Platform,
    private navCtrl: NavController,
    private camera: Camera,
    private authService: AuthService,
    private action$: Actions
  ) {
    this.isCordova = this.platform.is('cordova');
    if (this.authService.authToken) {
      this.isMedicare = this.authService.authToken.userType.toLowerCase() === 'medicare';
    }

    this.options = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };

    this.reimbursementForm = this.fb.group({
      category: new FormControl(null),
      state: new FormControl('MA', { validators: Validators.required }),
      unitAmount: new FormControl(''),
      annualFeeAmount: new FormControl(''),
      totalAmount: new FormControl('', { validators: [Validators.required, amountWithinRange()] }),
      programName: new FormControl('', { validators: [Validators.required] }),
      address: new FormControl('', Validators.required),
      zipcode: new FormControl('', [Validators.required, Validators.minLength(5)]),
      phone: new FormControl('', { validators: [Validators.required, Validators.minLength(14)] }),
      subscriberAlternateEmail: new FormControl(''),
      additionalEmail: new FormControl('', { validators: [Validators.pattern('[A-Za-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{1,4}\\S$')] }),
      acceptedAgreement: new FormControl(false)
    });
  }

  ngOnInit(): void {
    this.action$.pipe(ofActionSuccessful(ShowProgressModal), takeUntil(this.unsubscribe$)).subscribe(() => {
      this.presentProgressModal();
    });

    this.action$.pipe(ofActionSuccessful(HideProgressModal), takeUntil(this.unsubscribe$)).subscribe(() => {
      this.dismissProgressModal();
    });
  }

  ionViewDidEnter() {
    this.content.scrollToTop(500);
    this.store.dispatch(new ClearImages());
    this.setMember();
    this.setState();
    this.setEmail();
    this.setEHBcontrols();
  }

  ionViewDidLeave() {
    this.reimbursementForm.reset();
  }

  setEHBcontrols() {
    const selectedReimbursement = this.store.selectSnapshot(FitnessSelectors.getSelectedReimbursement);
    if (selectedReimbursement && selectedReimbursement.isEHB) {
      if (selectedReimbursement.collateralName === 'Fitness') {
        this.reimbursementForm.setControl('category', new FormControl('', { validators: Validators.required }));
      } else {
        this.reimbursementForm.removeControl('category');
      }

      this.reimbursementForm.setControl('unitAmount', new FormControl('', { validators: [Validators.required, amountWithinRange()] }));
      this.reimbursementForm.setControl('annualFeeAmount', new FormControl('', { validators: amountWithinRange() }));
    } else {
      this.reimbursementForm.removeControl('category');
      this.reimbursementForm.removeControl('unitAmount');
      this.reimbursementForm.removeControl('annualFeeAmount');
    }
  }

  setMember(): void {
    const subscriberModel = this.store.selectSnapshot(FitnessSelectors.getSubscriberName);

    if (subscriberModel) {
      const members = this.store.selectSnapshot(FitnessSelectors.getMembers);

      let memberFormControl: FormControl;

      if (members.length > 1) {
        memberFormControl = new FormControl(subscriberModel, { validators: Validators.required, updateOn: 'blur' });
      } else {
        memberFormControl = new FormControl(subscriberModel, { validators: Validators.required });
      }

      this.reimbursementForm.addControl('member', memberFormControl);
      this.reimbursementForm.controls.member.setValue(subscriberModel);
    }
  }

  setState() {
    this.reimbursementForm.controls['state'].setValue('MA');
  }

  setEmail() {
    const maskedSubscriberEmail = this.store.selectSnapshot(FitnessSelectors.getMaskedEmail);

    if (maskedSubscriberEmail === '' || maskedSubscriberEmail == null) {
      const emailFormControl = new FormControl('', {
        validators: [Validators.required, Validators.pattern('[A-Za-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{1,4}\\S$')]
      });
      this.reimbursementForm.setControl('subscriberAlternateEmail', emailFormControl);
    }
  }

  async presentModal(header: string) {
    const modal = await this.modalController.create({
      component: InfoModalComponent,
      cssClass: 'info-modal',
      componentProps: { header: header }
    });
    return await modal.present();
  }

  async presentActionSheet() {
    const actionSheetOptions = {
      header: 'Upload a photo',
      buttons: [
        {
          text: 'Camera',
          icon: 'camera',
          handler: () => {
            this.options.sourceType = this.camera.PictureSourceType.CAMERA;
            this.getPicture();
          }
        },
        {
          text: 'Library',
          icon: 'images',
          handler: () => {
            this.options.sourceType = this.camera.PictureSourceType.PHOTOLIBRARY;
            this.getPicture();
          }
        },
        {
          text: 'Cancel',
          icon: 'close',
          role: 'cancel',
          handler: () => {}
        }
      ]
    };

    const actionSheet = await this.actionSheetCtrl.create(actionSheetOptions);
    await actionSheet.present();
  }

  async presentProgressModal() {
    this.progressModal = await this.modalController.create({
      component: ProgressModalComponent,
      cssClass: 'progress-modal'
    });
    await this.progressModal.present();
  }

  async dismissProgressModal() {
    (await this.progressModal)
      ? this.progressModal
          .dismiss()
          .then(() => {
            this.progressModal = null;
          })
          .catch(e => console.log(e))
      : of(null);
  }

  async helpPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: InfoPopoverComponent,
      event: ev,
      mode: 'md',
      showBackdrop: false,
      componentProps: { popupText: this.store.selectSnapshot(FitnessSelectors.getHelpText) }
    });
    return await popover.present();
  }

  toggleEmail() {
    this.showAddEmail = !this.showAddEmail;
  }

  deleteImage(index) {
    this.store.dispatch(new DeleteImage(index));
  }

  getPicture() {
    this.camera.getPicture(this.options).then(imageData => {
      const base64Image = 'data:image/jpeg;base64,' + imageData;
      const base64Length = base64Image.length - (base64Image.indexOf(',') + 1);
      const padding = base64Image.charAt(base64Image.length - 2) === '=' ? 2 : base64Image.charAt(base64Image.length - 1) === '=' ? 1 : 0;
      const fileSize = base64Length * 0.75 - padding;
      console.log('File size ' + fileSize);

      let size = '0';
      if (fileSize < 1000) {
        size = fileSize + ' B';
      } else if (fileSize >= 1000 && fileSize < 1000000) {
        size = Math.round(fileSize / 1000) + ' KB';
      } else if (fileSize >= 1000000) {
        size = Math.round(fileSize / 1000000) + ' MB';
      }
      const blob = GlobalUtils.base64toBlob(imageData, 'image/jpeg');
      this.store.dispatch(new UploadReimbursementReceipt(base64Image, blob, size, fileSize));
    });
  }

  removeWhiteSpace(value) {
    this.reimbursementForm.controls[value].setValue(this.reimbursementForm.controls[value].value.trim());
  }

  importFile(event) {
    if (event.target.files.length === 0) {
      return;
    }
    const file: File = event.target.files[0];
    const reader: FileReader = new FileReader();

    reader.onloadend = () => {
      const photoString = reader.result.toString();
      const base64Length = photoString.length - (photoString.indexOf(',') + 1);
      const padding = photoString.charAt(photoString.length - 2) === '=' ? 2 : photoString.charAt(photoString.length - 1) === '=' ? 1 : 0;
      const fileSize = base64Length * 0.75 - padding;
      console.log('File size ' + fileSize);

      let size = '0';
      if (fileSize < 1000) {
        size = fileSize + ' B';
      } else if (fileSize >= 1000 && fileSize < 1000000) {
        size = Math.round(fileSize / 1000) + ' KB';
      } else if (fileSize >= 1000000) {
        size = Math.round(fileSize / 1000000) + ' MB';
      }

      const blob = GlobalUtils.base64toBlob(photoString.replace(/^data:image\/[a-z]+;base64,/, ''), 'image/jpeg');
      this.store.dispatch(new UploadReimbursementReceipt(reader.result.toString(), blob, size, fileSize));
    };

    reader.readAsDataURL(file);
  }

  clearEmail() {
    this.reimbursementForm.controls.additionalEmail.setValue('');
  }

  cancel() {
    this.navCtrl.navigateBack('/tabs/fitness-and-weightloss');
  }

  submit() {
    this.store.dispatch(new SubmitReimbursementForm(this.reimbursementForm.value));
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
