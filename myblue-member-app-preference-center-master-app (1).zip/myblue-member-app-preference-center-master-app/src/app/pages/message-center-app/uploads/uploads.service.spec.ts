import { inject, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { UploadsService } from './uploads.service';

describe('UploadsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UploadsService, BcbsmaHttpService]
    });
  });

  it('should be created', inject([UploadsService], (service: UploadsService) => {
    expect(service).toBeTruthy();
  }));
});
