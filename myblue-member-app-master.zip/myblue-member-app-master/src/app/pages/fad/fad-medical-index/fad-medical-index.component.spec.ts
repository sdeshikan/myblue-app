import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadMedicalIndexComponent } from './fad-medical-index.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FadMedicalIndexService } from './fad-medical-index.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import { AlertService } from '../../../shared/services/alert.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';

describe('FadMedicalIndexComponent', () => {
  let component: FadMedicalIndexComponent;
  let fixture: ComponentFixture<FadMedicalIndexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadMedicalIndexComponent],
      providers: [
        FadMedicalIndexService,
        BcbsmaHttpService,
        AuthHttp,
        AuthService,
        ConstantsService,
        FadLandingPageService,
        FadSearchResultsService,
        FadService,
        AlertService,
        FadBreadCrumbsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadMedicalIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
