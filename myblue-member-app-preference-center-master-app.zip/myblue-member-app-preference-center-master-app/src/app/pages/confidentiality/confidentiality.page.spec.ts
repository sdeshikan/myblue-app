import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../shared/services/constants.service';
import { HomeService } from '../../shared/services/home.service';
import { ConfidentialityPage } from './confidentiality.page';

describe('ConfidentialityPage', () => {
  let component: ConfidentialityPage;
  let fixture: ComponentFixture<ConfidentialityPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgxsModule.forRoot([]), HttpClientTestingModule],
      providers: [HomeService,ConstantsService],
      declarations: [ConfidentialityPage],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfidentialityPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
