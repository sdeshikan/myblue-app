import { environment } from '../../../environments/environment';
import { TitleCasePipe } from '@angular/common';

export class HomePageInfoModel {
  memFistName: string;
  memMidInit: string;
  memLastName: string;
  hasDependents: string;
  userState: string;
  userType: string;
  memMedexFlag: string;
  memMedicareFlag: string;
  hasHEQ: string;
  hasALG: string;
  hasSS: string;
  cerner: Cerner;
  hasBQi: string;
  hasBlueGreen: string;
  myclaims: MyClaims;
  unreadMessageCount: string;
  mydoctors: MyDoctors;
  mymedications: MyMedications;
  isAllowedChangePCP: string;
  isRequiredPCP: string;
  hasPCP: string;

  constructor(private titleCase: TitleCasePipe) {}

  get fullName() {
    return `${this.memFistName} ${this.memLastName}`;
  }

  fullMemInfo(sectionType: string) {
    let memName = '';
    if (sectionType === 'claims') {
      if (this.myclaims && this.myclaims.clmMidInit) {
        memName =
          this.titleCase.transform(this.myclaims.clmFrstName) +
          ' ' +
          this.titleCase.transform(this.myclaims.clmMidInit) +
          ' ' +
          this.titleCase.transform(this.myclaims.clmLastName) +
          ' (' +
          this.titleCase.transform(this.myclaims.clmrelationship) +
          ')';
      } else {
        memName =
          this.titleCase.transform(this.myclaims.clmFrstName) +
          ' ' +
          this.titleCase.transform(this.myclaims.clmLastName) +
          ' (' +
          this.titleCase.transform(this.myclaims.clmrelationship) +
          ')';
      }
    } else if (sectionType === 'medications') {
      if (this.mymedications && this.mymedications.rxMidInit) {
        memName =
          this.titleCase.transform(this.mymedications.rxFrstName) +
          ' ' +
          this.titleCase.transform(this.mymedications.rxMidInit) +
          ' ' +
          this.titleCase.transform(this.mymedications.rxLastName) +
          ' (' +
          this.titleCase.transform(this.mymedications.rxrelationship) +
          ')';
      } else {
        memName =
          this.titleCase.transform(this.mymedications.rxFrstName) +
          ' ' +
          this.titleCase.transform(this.mymedications.rxLastName) +
          ' (' +
          this.titleCase.transform(this.mymedications.rxrelationship) +
          ')';
      }
    }
    return memName;
  }

  deserialize(obj) {
    this.hasALG = obj.hasALG;
    this.hasDependents = obj.hasDependents;
    this.hasHEQ = obj.hasHEQ;
    this.hasSS = obj.hasSS;
    this.memFistName = obj.memFistName;
    this.memLastName = obj.memLastName;
    this.memMedexFlag = obj.memMedexFlag;
    this.memMedicareFlag = obj.memMedicareFlag;
    this.memMidInit = obj.memMidInit;
    this.unreadMessageCount = obj.unreadMessageCount;
    this.userState = obj.userState;
    this.userType = obj.userType;
    this.cerner = obj.cerner;
    this.myclaims = obj.myclaims;
    this.mydoctors = obj.mydoctors;
    this.mymedications = obj.mymedications;
    this.hasBQi = obj.hasBQi;
    this.hasBlueGreen = obj.hasBlueGreen;
    this.isAllowedChangePCP = obj.isAllowedChangePCP;
    this.isRequiredPCP = obj.isRequiredPCP;
    this.hasPCP = obj.hasPCP;
    return this;
  }
}

export interface Cerner {
  hasCerner: string;
  hasCernerEE: string;
  hasCernerMedicare: string;
}

export interface MyClaims {
  clmFrstName: string;
  clmMidInit: string;
  clmLastName: string;
  clmrelationship: string;
  clmICN: string;
  clmDOS: string;
  clmLastDOS: string;
  clmPrvName: string;
  clmCoveredAmt: string;
  clmYouOweAmt: string;
  clmPaymtStatus: string;
  clmStatus: string;
}

export interface MyDoctors {
  visitFrstName: string;
  visitMidInit: string;
  visitLastName: string;
  visitPrvNum: string;
  visitSvcDate: string;
  visitLastSvcDate: string;
  visitPrvName: string;
  visitSpec: string;
  visitPhone: string;
  visitDependentId: string;
}

export interface MyMedications {
  rxFrstName: string;
  rxMidInit: string;
  rxLastName: string;
  rxrelationship: string;
  rxDrugName: string;
  rxStrength: string;
  rxPrescPhone: string;
  rxDispPrvNum: string;
  rxDispPrvName: string;
  rxCoPay: string;
  rxLastFillDate: string;
  rxNDCCode: string;
  rxIncurredDate: string;
  rxDependentId: number;
}

export class ArticleModel {
  Icon: string;
  Index: number;
  Title: string;
  Body: string;
  Description: string;
  RegularImages: string;
  MobileImages: string;
  ArticleText: string;
  ArticleUrl: string;

  constructor(number) {
    this.Index = number;
  }

  deserialize(jsonObj, sanitizer?) {
    this.Title = jsonObj.Title;
    this.ArticleText = jsonObj.ArticleText;
    this.RegularImages = environment.drupalTestUrl + jsonObj.RegularImages;
    this.ArticleUrl = jsonObj.APPArticleUrl;
    return this;
  }
}
