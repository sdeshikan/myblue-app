import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService, ConstantsService } from '../../../shared/shared.module';
import { MessageCenterConstants } from '../constants/messageCenter.constants';
import {
  GetPlansBenefitsListPlanItemInterface,
  GetPlansBenefitsListResponseModelInterface
} from '../modals/interfaces/get-plans-benefits-list-models.interface';
import { EocPolicyInterface, GetBenefitCoverageResponseModelInterface } from '../modals/interfaces/getBenefitCoverage-models.interface';
import { NoDocumentsFoundComponentModel } from '../modals/message-center.modal';
import { DocumentsService } from './documents.service';

import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AuthToken } from '../../../models/auth-token.model';
import { PostLoginModel } from '../../../models/post-login.model';
import { FeatureToggleService } from '../../../services/feature.service';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { HomePageAppInfoModel } from '../../home/home.model';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getPreferences) preferences: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: AuthToken;

  public memberInfo: HomePageAppInfoModel;
  public planBenefitsList: GetPlansBenefitsListResponseModelInterface = null;
  public benefitCoverageDocs: GetBenefitCoverageResponseModelInterface = null;
  public policiesInBenefitCoverage: EocPolicyInterface = null;
  public hasContents: boolean;
  private clearAlertOnDestroy = true;
  title = 'Explanation of Benefits';
  showPreference = false;
  isTaxFormsEnabled = false;

  public noDocumentsFound: NoDocumentsFoundComponentModel = new NoDocumentsFoundComponentModel();
  public selectedPlan: GetPlansBenefitsListPlanItemInterface;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public documentsService: DocumentsService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private profileService: ProfileService,
    private featureToggleService: FeatureToggleService
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
    this.noDocumentsFound.mode = MessageCenterConstants.flags.documentsMode;
    
    const hasAltAdd = this.postLoginInfo && this.postLoginInfo.repPayeeFalg.toLowerCase() === 'false'
    const isMedicare = this.authToken.userType && this.authToken.userType.toLowerCase() === 'medicare'
    this.showPreference = !hasAltAdd ? false : (isMedicare ? false : true)
    this.isTaxFormsEnabled = this.featureToggleService.isFeatureEnabled('tax-forms');
  }

  ngOnInit() {
    try {
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewDocuments);
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_ViewDocuments_PlanDetailsLists);
      this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_PlanDetailsLists_BenefitLists);

      const oMemberData = this.route.snapshot.data.memberData;
      console.log(oMemberData);
      if (oMemberData) {
        if (Object.keys(oMemberData).length && 'ROWSET' in oMemberData && 'ROW' in oMemberData.ROWSET) {
          this.memberInfo = oMemberData.ROWSET.ROW;
        }
      }
      const t = this.authToken;
      if (t) {
        const authToken = this.authToken;
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false') {
          this.title = 'Summary of Health Plan Payments';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'true' &&
          authToken.planTypes['dental'] === 'false'
        ) {
          this.title = 'Explanation of Benefits';
        }
        if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true') {
          this.title = 'Explanation of Your Dental Benefits';
        }
        if (
          (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
          authToken.planTypes['medical'] === 'false' &&
          authToken.planTypes['dental'] === 'true'
        ) {
          this.title = 'Explanation of Your Dental Benefits';
        }
      }

      // console.log('router', this.router.url.split('/')[this.router.url.split('/').length - 1]);

      this.policiesInBenefitCoverage = this.route.snapshot.data.policiesInBenefitCoverage;
      this.planBenefitsList = this.route.snapshot.data.planDocuments;
      this.benefitCoverageDocs = this.route.snapshot.data.benefitCoverageDocs;

      if (this.planBenefitsList && this.planBenefitsList.result && this.planBenefitsList.result < 0) {
        this.alertService.setAlert(this.planBenefitsList.displaymessage, ' ', AlertType.Failure);
      } else {
        if (this.documentsService.getSelectedPlan()) {
          this.selectedPlan = this.documentsService.getSelectedPlan();
        }
      }
    } catch (exception) {
      console.error(exception, null, 2);
    }
  }

  ionViewWillEnter() {
    // this.profileService.setPreferencePromo(this.preferences);
    //Show paperless promo
    if(this.showPreference){
      this.profileService.swapPromo(this.useridin);
    } 
  }

  taxForm() {
    if (this.isTaxFormsEnabled) {
      this.router.navigate(['/tabs/tax-forms']);
    }
  }

  ngOnDestroy(): void {
    this.planBenefitsList = null;
    this.benefitCoverageDocs = null;
    if (this.clearAlertOnDestroy) {
      this.alertService.clearError();
    }
  }

  public goBack(): void {
    this.location.back();
  }

  planDetailsList() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments_PlanDetailsLists);
    this.router.navigate(['/tabs/myInbox/documents/planDocuments']);
  }

  openBenefitCoverageDocsList(plan: GetPlansBenefitsListPlanItemInterface) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_PlanDetailsLists_BenefitLists);
    this.documentsService.setSelectedPlan(plan);
    this.router.navigate(['/tabs/myInbox/documents/planDocuments/benefitCoverageList']);
  }

  openOverAllPlanInformation(): void {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_BenefitLists_OverallPlanLists);
    this.router.navigate(['/tabs/myInbox/documents/document-overall-view']);
  }

  openBenefitCoverage(policy: EocPolicyInterface) {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_BenefitLists_DocumentsLists);
    this.documentsService.setSelectedPolicy(policy);
    this.router.navigate(['/tabs/myInbox/documents/documents-list-view']);
  }

  eobListing() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_MyInbox_ViewDocuments_EobLists);
    this.router.navigate(['/tabs/myInbox/documents/eob']);
  }
}
