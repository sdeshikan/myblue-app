import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {BcbsmaHttpService} from '../../../shared/services/bcbsma-http.service';
import {GetSearchByProfessionalResponseModelInterface} from '../modals/interfaces/getSearchByProfessional-models.interface';
// import { HttpHeaders, HttpParams } from '@angular/common/http';
// import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import {FadConstants} from '../constants/fad.constants';
import {AuthService} from '../../../shared/shared.module';
import {AuthHttp} from '../../../shared/services/authHttp.service';

// import { FadVitalsProfessionalsSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';

@Injectable()
export class FadProfessionalCompareService {

  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public searchData;
  public compareString: string = '';

  constructor(private bcbsmaHttpService: BcbsmaHttpService, private authHttp: AuthHttp,
              private authService: AuthService
  ) {
  }

  

  setSearchResult(searchResults) {
    
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem('compareDoctor', compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem('doctorCostInfo', JSON.stringify(costInfo));
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('doctorCostInfo');
    if (costInfo) {
      const costInfoJson = JSON.parse(costInfo);
      return costInfoJson;
    }
    return null;
  }


}
