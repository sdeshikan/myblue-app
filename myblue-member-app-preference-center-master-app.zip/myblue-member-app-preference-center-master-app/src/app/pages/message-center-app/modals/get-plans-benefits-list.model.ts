import { MyBlueGeneralAPIRequestModel } from '../../../shared/models/generic-app.model';
import { GetPlansBenefitsListRequestModelInterface } from './interfaces/get-plans-benefits-list-models.interface';

export class GetPlansBenefitsListRequestModel extends MyBlueGeneralAPIRequestModel implements GetPlansBenefitsListRequestModelInterface {
  effectiveDate: string;

  setUseridin(useridin: string): GetPlansBenefitsListRequestModel {
    super.setUseridin(useridin);
    return this;
  }

  setEffectiveDate(effectiveDate: string): GetPlansBenefitsListRequestModel {
    this.effectiveDate = effectiveDate;
    return this;
  }
}
