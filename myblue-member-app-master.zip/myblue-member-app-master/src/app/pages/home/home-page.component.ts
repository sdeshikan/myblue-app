import { Component, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MenuController, Platform, IonContent, NavController } from '@ionic/angular';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AuthService } from '../../shared/services/auth.service';
import { GlobalService } from '../../shared/services/global.service';

import { ConstantsService } from '../../shared/services/constants.service';
import { AlertService } from '../../shared/services/alert.service';

import { LineChartOptionsInterface } from '../../shared/components/line-chart/line-chart.interface';
import { Finanical } from '../../shared/models/finanical.model';

import { AuthHttp } from '../../shared/services/authHttp.service';
import { MyDedCoService } from '../myded-co-app/myded-co.service';
import { HomePageAppInfoModel } from './home.model';
import { Observable, Subscription } from 'rxjs';
import { map, filter } from 'rxjs/operators';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { MyMedicationDetailsService } from '../my-medication/my-medication-details/my-medication-details.service';
import { RxDetailsRequestModelInterface } from '../my-medication/models/interfaces/rx-details-model.interface';
import { RxDetailsRequestModel } from '../my-medication/models/rx-details.model';

import { Storage } from '@ionic/storage';
import { SwrveService, SwrveEventNames } from '../../shared/services/swrve.service';
import { IabService } from '../../shared/services/iab/iab.service';
import { SsoService } from '../sso/sso.service';
import { environment } from './../../../environments/environment';
import { HeaderService } from '../../shared/layouts/header/header.service';
import { FooterService } from '../../shared/layouts/footer/footer.service';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { PharmacyLinksService } from '../../shared/services/mypharmacy/pharmacylinks.service';
import { DeductiblesAccumsInterface } from '../myded-co-app/models/interfaces/myded-co-info-model.interface';
import { HomeService } from '../../shared/services/home.service';
import { AccumChartType } from '../myded-co-app/models/types/myded-co.types';
import { FeatureToggleService } from '../../services/feature.service';
import { AlertType } from '../../shared/alerts/alertType.model';

declare let $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit, OnDestroy {
  constructor(
    private router: Router,
    private authService: AuthService,
    private globalService: GlobalService,
    public homeService: HomeService,
    private constantsService: ConstantsService,
    private alertService: AlertService,
    private http: AuthHttp,
    private myDedCoService: MyDedCoService,
    private datePipe: DatePipe,
    private myMedicationDetailsService: MyMedicationDetailsService,
    private titleCase: TitleCasePipe,
    private r: ActivatedRoute,
    private menu: MenuController,
    private storage: Storage,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    private headerService: HeaderService,
    private platform: Platform,
    private footerService: FooterService,
    private androidpermissions: AndroidPermissions,
    private pharmacyLinkService: PharmacyLinksService,
    private appRate: AppRate,
    private appVersion: AppVersion,
    private featureToggleService: FeatureToggleService,
    private navCtrl: NavController
  ) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.routeSubscription = this.router.events.pipe(filter(event => event && event instanceof NavigationEnd)).subscribe((event: any) => {
      if (event instanceof NavigationEnd && (event.url === '/tabs/home' || event.url === '/tabs') && !this.isFirstTime) {
        this.ionViewWillEnter();
      }
    });

    this.isFitnessEnabled = featureToggleService.isFeatureEnabled('fitness-benefits');
    // this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeAnonymous, '');
  }
  @ViewChild(IonContent) content: IonContent;
  isFitnessEnabled = false;
  isRegisteredUser: boolean;
  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  ismobile = false;
  mobileViewPort = 992;
  articles = [];
  carouselItemDetails: [] = [];
  memberFirstName: string;
  showDedcoSpinner = false;
  showDrupal = false;
  showDoctorDrupal = false;
  showMedicationDrupal = false;
  showClaimsDrupal = false;
  dedCoInfo: DeductiblesAccumsInterface = null;
  deductibleChartDetails: LineChartOptionsInterface[];
  financialChartCounter = 0;
  financialChartDetails: Finanical[] = [];
  isDisplayFinanceLoader: boolean;
  showNurseLine = false;
  hasBlueGreen = false;
  ahealthyme = false;
  hasFamily: boolean;
  dedCoName: string;
  title = 'Explanation of Benefits';
  memberInfo: HomePageAppInfoModel;
  isFinancialView = false;
  doctorData: any;
  medicationData: any;
  ClaimsData: any;
  isdependant = false;
  ismedicaremember = false;
  isSmartShopperUser = false;
  bannerImage: any = '';
  hasBqi = false;
  routeSubscription: Subscription;
  resolverSubscription: Subscription;
  isFirstTime = true;
  authFitness = this.swrveEventNames.AppClick_HomeAuthenticated_Fitness;
  unAuthFitness = this.swrveEventNames.AppClick_HomeAnonymous_Fitness;
  authAHealthyMe = this.swrveEventNames.AppClick_HomeAuthenticated_AHealthyMe;
  unAuthAHealthyMe = this.swrveEventNames.AppClick_HomeAnonymous_AHealthyMe;

  urlConfig = {
    mymedications: '/my-medications',
    medicationdetails: '/my-medications/medicationdetails',
    myclaims: '/myClaims',
    claimdetails: '/myClaims/claimdetails',
    mycards: '../mycards',
    myplans: '../myplans',
    myaccount: '../myaccount',
    messagecenter: '../message-center/messages',
    documents: '../myeobs',
    uploads: '../message-center/uploads',
    deductibles: '/mydedco-app',
    maintenance: '../pages/maintenance',
    mydoctors: '/my-doctor',
    doctordetails: '/my-doctor',
    myInbox: '../message-center-app',
    myprofile: '../myprofile',
    addpcp: '../my-doctor/add-pcp',
    updatepcp: '../my-doctor/update-pcp-homepage',
    requestwrittenestimate: '/request-estimate',
    myfinancial: '/my-financial',
    myPharmacy: '/myPharmacy'
  };

  homepageApiResponse: Observable<any>;
  homeNavigationApiResponse: any;
  homeHeroBannerResponse: Observable<any>;
  homeDiscountsResponse: Observable<any>;
  featureUrl = this.constantsService.featureUrl;
  anonymousFeedback = this.constantsService.anonymousFeedback;
  blue365Url = this.constantsService.blue365Url;
  footerGlobalLinks: any;
  drupalUrl = environment.drupalTestUrl;
  pharmacyLinks: PharmacyLinkType[];

  scrollToTop() {
    this.content.scrollToTop(400);
  }

  ionViewDidEnter() {
    this.scrollToTop();
  }

  @HostListener('window:resize', ['$event'])
  onresize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  toggleMenu() {
    this.menu.toggle();
  }

  ngOnInit() {
    this.homeService.getCarouselItemDetails().subscribe(response => {
      this.carouselItemDetails = this.transformCarouselResponse(response);
    });

    // Home Page -- Promo Block Code
    this.homeService.loadArticle(1);
    this.homeService.loadArticle(2);
    this.homeService.loadArticle(3);

    this.homeService.getHomePageApiResponse().subscribe(response => {
      this.homepageApiResponse = this.transformPageApiResonse(Array.isArray(response) ? response[0] : response);
    });
    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        sessionStorage.setItem('find_a_doctor_link', this.homeNavigationApiResponse.APPTextUrl3 || '');
        sessionStorage.setItem('call_nurse_link_link', this.homeNavigationApiResponse.APPTextUrl2 || '');
      }
    });
    this.homeService.getHomeHeroBannerResponse().subscribe(response => {
      this.homeHeroBannerResponse = Array.isArray(response) ? response[0] : response;
    });
    this.homeService.getHomeDiscountsResponse().subscribe(response => {
      this.homeDiscountsResponse = Array.isArray(response) ? response[0] : response;
    });

    this.alertService.clearError();
    this.clearSessionItems();
    this.getFooter();

    this.accessFineLocation();
  }

  async accessFineLocation() {
    const hasRequestedPermission = await this.storage.get('hasRequestedPermisson');
    if (!hasRequestedPermission) {
      this.storage.set('hasRequestedPermisson', true);
      if (this.platform.is('android')) {
        const hasPermission = await this.androidpermissions.checkPermission(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION);
        if (!hasPermission) {
          this.androidpermissions.requestPermissions(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION).then(() => {});
        }
      }
    }
  }

  getFooter() {
    if (!this.homeService.globalFooterData) {
      this.footerService
        .getGlobalFooter()
        .pipe(
          filter((response: any) => response && response.length),
          map(response => response[0])
        )
        .subscribe(data => {
          this.footerGlobalLinks = data;
          this.homeService.globalFooterData = data;
        });
    } else {
      this.footerGlobalLinks = this.homeService.globalFooterData;
    }
  }

  transformPageApiResonse(response: any) {
    return {
      ...response,
      MobileHeroBanner: this.constantsService.drupalTestUrl + response.MobileHeroBanner
    };
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  ionViewWillEnter() {
    this.isFirstTime = false;
    const scopeName = this.authService.getScopeName();
    this.isRegisteredUser = scopeName.includes('REGISTERED');
    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    this.alertService.clearError();
    if (scopeName === 'AUTHENTICATED-NOT-VERIFIED') {
      this.memberFirstName =
        this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
      if (this.isRegisteredUser) {
        // this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeRegistered, '');
      }
      // this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeAnonymous, '');
    } else if (scopeName === 'AUTHENTICATED-AND-VERIFIED') {
      this.memberFirstName =
        this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
      // this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_HomeAuthenticated, '');
    } else {
      //Show the alert for RV and RNV users
      this.alertService.setAlert(this.constantsService.registerNewMembers,"Welcome New Members!",AlertType.Warning,"component","registeredhomepage");
      this.memberFirstName = '';
    }
    const t = sessionStorage.getItem('authToken');
    if (t && t !== 'undefined' && JSON.parse(t)) {
      const authToken = JSON.parse(t);
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true') {
        this.title = 'Explanation of Your Dental Benefits';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
    }
    if (this.isAuthenticatedUser) {
      this.resolverSubscription = this.r.data.subscribe(data => {
        if (data.home && data.home.ROWSET && !Array.isArray(data.home.ROWSET.ROW) && typeof data.home.ROWSET.ROW === 'object') {
          this.memberInfo = new HomePageAppInfoModel(this.titleCase).deserialize(data.home.ROWSET && data.home.ROWSET.ROW);

          // Smart Shopper Deferred to 3.1
          // this.isSmartShopperUser = this.memberInfo.hasSS === 'true' ? true : false;
          const postLoginInfo = this.globalService.getPostLoginSessionObject();
          this.isSmartShopperUser = postLoginInfo ? this.checkSmartShopperUser(JSON.parse(postLoginInfo)) : false;

          this.showNurseLine =
            this.memberInfo.cerner &&
            this.memberInfo.cerner.hasCerner !== 'true' &&
            this.memberInfo.cerner.hasCernerEE !== 'true' &&
            this.memberInfo.cerner.hasCernerMedicare !== 'true' &&
            this.memberInfo.hasBlueGreen !== 'true' &&
            this.memberInfo.hasBQi !== 'true';
          this.hasBqi = this.memberInfo.hasBQi === 'true';
          this.hasBlueGreen = this.memberInfo.hasBlueGreen === 'true';

          this.ahealthyme =
            this.memberInfo.cerner &&
            (this.memberInfo.cerner.hasCerner === 'true' ||
              this.memberInfo.cerner.hasCernerEE === 'true' ||
              this.memberInfo.cerner.hasCernerMedicare === 'true');

          this.globalService.landingPageMemberInfoApp = this.memberInfo;
          this.authService.storeUserState(this.memberInfo.userState);

          if (this.memberInfo.myclaims && this.memberInfo.myclaims.clmICN) {
            sessionStorage.setItem('claimId', this.memberInfo.myclaims.clmICN);
          }
        } else if (data.home && data.home.result < 0) {
        }

        /* -- Don't Make changes Here -- */
        if (data && data.home) {
          this.showUserBanner();
          this.getFinancialData();
          this.showUserDataBlocks();
        }
      });
      if (this.authService.authToken && this.authService.authToken.unreadMsgCount && !this.headerService.unReadMsgCount) {
        this.headerService.unReadMsgCount = this.authService.authToken.unreadMsgCount.toString();
      }
      this.http.asycnPostLogin().then(response => {
        if (response && response.error !== true) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
        }
      });
      const postLoginInfo = sessionStorage.getItem('postLoginInfo');
      const postLoginJSON = JSON.parse(postLoginInfo);
      if (postLoginJSON.pharmacyLinks && postLoginJSON.pharmacyLinks.length > 0) {
        this.pharmacyLinks = this.pharmacyLinkService.getPharmacyLinks();
      }
    }
  }

  showUserBanner(): void {
    try {
      if (
        this.authService.authToken &&
        (this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex')
      ) {
        this.bannerImage = 'Hero_Image_Medicare';
        this.ismedicaremember = true;
      } else if (
        this.memberInfo &&
        this.memberInfo.hasDependents.toString() === 'false' &&
        (this.authService.authToken.userType.toLowerCase() !== 'medicare' || this.authService.authToken.userType.toLowerCase() !== 'medex')
      ) {
        this.bannerImage = 'Hero_Image_No_Dependents';
        this.isdependant = true;
      } else {
        this.bannerImage = 'Hero_Image_Default';
      }
    } catch (exception) {}
  }

  goToProfile() {
    this.router.navigateByUrl('myprofile');
  }
  goToLogin() {
    this.router.navigateByUrl('login-app');
  }
  goToRegistration() {
    this.router.navigateByUrl('register');
  }

  openInAppBrowser(url) {
    this.iabService.create(url);
  }

  openInAppBrowserSso(url: string, ssoLink: string, unAuthSwrveEvent: string, authSwrveEvent: string) {
    if (url.endsWith('fad')) {
      if (this.isSmartShopperUser) {
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['tabs/fad']);
      }
      return;
    }
    if (this.isAuthenticatedUser) {
      this.sendSwrveEventsForIABClicks(authSwrveEvent);
      this.ssoService.openSSO(ssoLink);
    } else {
      this.sendSwrveEventsForIABClicks(unAuthSwrveEvent);
      this.iabService.create(url);
    }
  }

  sendSwrveEventsForIABClicks(desctiption: string) {
    if (desctiption) {
      switch (desctiption) {
        case 'Find_a_doctor':
          if (this.isAuthenticatedUser) {
            this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAuthenticated_FindaDoctor);
          } else if (this.isRegisteredUser) {
            this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeRegistered_FindaDoctor);
          } else if (this.isAnonymousUser) {
            this.swrveService.sendAppMessage(this.swrveEventNames.AppClick_HomeAnonymous_FindaDoctor);
          }
          break;
      }
    }
  }

  authRestartScreen() {
    this.globalService
      .redirectionRoute()
      .then(response => {
        console.log(response);
      })
      .catch(route => {
        this.router.navigate([route]);
      });
  }

  transformCarouselResponse(response: any): [] {
    if (response && response.length) {
      return response.map(item => {
        const carouselItem = new Image() as any;
        carouselItem.src = this.constantsService.drupalTestUrl + item.RegularImages;
        carouselItem.mobilesrc = this.constantsService.drupalTestUrl + item.MobileImages;
        // item.isVideo ? '/assets/images/promo/bluebikes-myblue-promo-1002x435.png' : item.VIdeoUrl;
        carouselItem.text = item.ArticleText;
        carouselItem.isVideo = item.VideoUrl.length;
        carouselItem.VIdeoUrl = item.VideoUrl;
        carouselItem.urlLink = item.ArticleUrl;
        carouselItem.Title = item.Title;
        carouselItem.Body = item.Body;
        return carouselItem;
      });
    }
    return [];
  }

  getFinancialData() {
    if (this.hasFinancialsData()) {
      this.isFinancialView = true;
      this.isDisplayFinanceLoader = true;
      this.showDedcoSpinner = true;
      this.homeService.getFinanceBalancChartData().subscribe(
        response => {
          if (response && response.length) {
            // this.isFinancialView = true;
            this.financialChartDetails = response;
            console.log(this.financialChartDetails, 'financial data length');
          } else {
            // this.isFinancialView = true;
            this.financialChartDetails = [];
          }

          this.isDisplayFinanceLoader = false;
          if (this.financialChartDetails.length === 0) {
            this.deductibleChartDetails = [];
            this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
          } else {
            this.deductibleChartDetails = [];
            this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
          }
        },
        () => {
          this.isDisplayFinanceLoader = false;
        }
      );
    } else {
      this.deductibleChartDetails = [];
      this.financialChartDetails = [];
      this.getDeductiblesAndCoinsuranceInfo(this.financialChartDetails);
    }
  }

  getDeductiblesAndCoinsuranceInfo(financialChartDetails) {
    this.showDedcoSpinner = true;
    this.myDedCoService.getDeductiblesAndCoinsuranceInfo().subscribe(response => {
      this.showDedcoSpinner = false;
      if (response && response.accums && response.accums[0]) {
        this.dedCoInfo = response.accums[0];

        if (response.hasFamily === 'True') {
          this.hasFamily = true;
        } else {
          this.hasFamily = false;
          response.members.map(member => {
            this.dedCoName = member.name;
          });
        }
        this.deductibleChartDetails = this.getLineChartData(response.accums[0], financialChartDetails);
      }
    });
  }
  getLineChartOptionsList(serviceLineOptionsList, chartType: AccumChartType, lineChartOptions): LineChartOptionsInterface[] {
    if (serviceLineOptionsList && serviceLineOptionsList.length > 0) {
      for (const option of serviceLineOptionsList) {
        lineChartOptions.push(this.homeService.getLineChartOptions(option, chartType));
      }
    }
    return lineChartOptions;
  }

  getLineChartData(accum, financialChartDetails): LineChartOptionsInterface[] {
    let dedCoResponse = [];
    // if (accum.result === 0) {
    let lineChartOptions = [];
    lineChartOptions = this.getLineChartOptionsList(accum.coinsurance, AccumChartType.Coinsurance, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.overallDeductables, AccumChartType.overallDeductables, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.outOfPocket, AccumChartType.outOfPocket, lineChartOptions);
    lineChartOptions = this.getLineChartOptionsList(accum.overallBenefit, AccumChartType.overallBenefit, lineChartOptions);

    if (
      (financialChartDetails.length > 0 && lineChartOptions) ||
      (financialChartDetails.length === 0 && lineChartOptions && this.hasFinancialsData())
    ) {
      dedCoResponse = [lineChartOptions[0]];
    } else if (financialChartDetails.length === 0 && lineChartOptions) {
      dedCoResponse = lineChartOptions.length === 1 ? [lineChartOptions[0]] : lineChartOptions.slice(0, 2);
    }
    // }
    return dedCoResponse;
    // return financialChartDetails.length === 1 ? [...lineChartOptions[0]] : lineChartOptions;
  }

  hasFinancialsData(): boolean {
    const hasALG = this.memberInfo.hasALG.toString().toLowerCase();
    const hasHEQ = this.memberInfo.hasHEQ.toString().toLowerCase();
    const result = this.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    sessionStorage.setItem('hasALG', hasALG);
    sessionStorage.setItem('hasHEQ', hasHEQ);
    this.isFinancialView = result;
    return result;
  }
  showUserDataBlocks(): void {
    if (
      this.memberInfo &&
      this.memberInfo.mydoctors &&
      !this.memberInfo.mydoctors.visitPrvName &&
      this.memberInfo.mymedications &&
      !this.memberInfo.mymedications.rxDrugName &&
      this.memberInfo.myclaims &&
      !this.memberInfo.myclaims.clmICN
    ) {
      this.showDrupal = false;
      this.showMedicationDrupal = false;
      this.showDoctorDrupal = false;
      this.showClaimsDrupal = false;
    } else if (
      this.memberInfo &&
      ((this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) ||
        (this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) ||
        (this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN))
    ) {
      if (this.memberInfo && this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) {
        this.showDoctorDrupal = true;
        this.getDrupalContent(this.constantsService.drupalDoctorsUrl).subscribe(response => {
          this.doctorData = response[0];
        });
      }

      if (this.memberInfo && this.memberInfo.mymedications && !this.memberInfo.mymedications.rxDrugName) {
        this.showMedicationDrupal = true;
        this.getDrupalContent(this.constantsService.drupalMedicationsUrl).subscribe(response => {
          this.medicationData = response[0];
        });
      }
      if (this.memberInfo && this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN) {
        this.showClaimsDrupal = true;
        this.getDrupalContent(this.constantsService.drupalClaimsUrl).subscribe(response => {
          this.ClaimsData = response[0];
        });
      }
    } else {
      this.showDrupal = false;
    }
  }

  navigate(id, routeParams?) {
    const url = this.urlConfig[id];

    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });
      }
    } else {
      return;
    }
  }

  incrementFinancialDetailsCounter() {
    if (this.financialChartCounter !== this.financialChartDetails.length - 1) {
      this.financialChartCounter =
        this.financialChartCounter === this.financialChartDetails.length - 1 ? 0 : this.financialChartCounter + 1;
      $('.finanicals-details .financial-carousel').carousel('next');
    }
  }

  decrementFinancialDetailsCounter() {
    if (this.financialChartCounter > 0) {
      this.financialChartCounter =
        this.financialChartCounter === 0 ? this.financialChartDetails.length - 1 : this.financialChartCounter - 1;
      $('.finanicals-details .financial-carousel').carousel('prev');
    }
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }

  openUrlinNewWindow(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }
  openFadSSO() {
    window.open('/fad', '_blank');
  }

  openOtherPartySite() {
    $('#openOtherPartySite').modal('open');
  }

  getDrupalContent(url): Observable<any> {
    return this.http.get(url).pipe(
      map(response => {
        return this.transformCarouselResponse(response);
      })
    );
  }

  showMedicationDetails() {
    const medicationDetailReq: RxDetailsRequestModelInterface = new RxDetailsRequestModel();
    medicationDetailReq.useridin = this.authService.useridin;
    medicationDetailReq.rxIncurredDate = this.globalService.getUTCDate(this.memberInfo.mymedications.rxIncurredDate);
    medicationDetailReq.ndcCd = this.memberInfo.mymedications.rxNDCCode; // ndcCd;
    if (this.memberInfo && this.memberInfo.mymedications && this.memberInfo.mymedications.rxDependentId) {
      medicationDetailReq.dependentId = this.memberInfo.mymedications.rxDependentId;
    }
    this.myMedicationDetailsService.setMyMedicationDetailsRequest(medicationDetailReq);
    this.router.navigate(['../my-medications/medicationdetails']);
  }
  medicationDetailHeader() {
    if (this.memberInfo && this.memberInfo.mymedications && this.memberInfo.mymedications.rxDependentId) {
      this.showMedicationDetails();
    } else {
      this.router.navigate(['register/register-detail']);
    }
  }

  stopEventPropagation(event) {
    event.stopPropagation();
  }

  showDoctorDetails() {
    sessionStorage.setItem('providerName', this.memberInfo.mydoctors.visitPrvName);
    sessionStorage.setItem('providerNumber', this.memberInfo.mydoctors.visitPrvNum);
    if (this.memberInfo && this.memberInfo.mydoctors && this.memberInfo.mydoctors.visitDependentId) {
      sessionStorage.setItem('docDependentId', this.memberInfo.mydoctors.visitDependentId);
    }
    this.router.navigate([`/my-doctor/details`]);
  }

  handleMyFinancialClick() {
    if (this.isRegisteredUser) {
      this.authRestartScreen();
    } 
    // else if (this.isFinancialView && this.financialChartDetails.length) {
    //   this.navigateToAlegeus();
    // }
  }

  navigateToAlegeus(lineChart : Finanical): void {
    if (lineChart.isALGAccount) {
      this.ssoService.openSSO('alg');
    } else {
      this.ssoService.openSSO('heq');
    }
    // const hasALG = this.memberInfo && this.memberInfo.hasALG.toString().toLowerCase();
    // const hasHEQ = this.memberInfo && this.memberInfo.hasHEQ.toString().toLowerCase();

    // if (hasALG === 'true') {
    //   this.ssoService.openSSO('alg');
    // } else if (hasHEQ === 'true') {
    //   this.ssoService.openSSO('heq');
    // }
  }

  openAhealthyme() {
    if (this.memberInfo.cerner.hasCernerMedicare === 'true') {
      window.open(this.constantsService.CernerMedicareUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCernerEE === 'true') {
      window.open(this.constantsService.cernerEEUrl, '_blank');
    } else if (this.memberInfo.cerner.hasCerner === 'true') {
      window.open('/sso/cerner', '_blank');
    }
  }

  openBqi() {
    window.open('sso/connecture', '_blank');
  }

  isHsaAccount(accountType) {
    return accountType === 'ABH' || accountType === 'HSA' || accountType === 'AB2';
  }
  ngOnDestroy(): void {
    this.routeSubscription.unsubscribe();
    this.pharmacyLinks = null;
  }
  ionViewDidLeave() {
    if (this.resolverSubscription) {
      this.resolverSubscription.unsubscribe();
      this.pharmacyLinks = null;
    }
  }
  rateTheAppClick() {
    this.appRate.preferences.storeAppURL = {
      ios: '937789998',
      android: `market://details?id=${this.appVersion.getPackageName() || 'com.bcbsma.myblueredesign'}&hl=en_US`
    };

    this.appRate.promptForRating(true);
  }

  openSmartShopper() {
    const userId = this.authService.useridin;
    if (userId && userId !== 'undefined' && userId !== 'null') {
      this.http.postlogin().subscribe(response => {
        if (response && response.error !== true) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
        }
        if (response && response.error) {
          this.http.showServiceErrorModalPopup('globalError');
        } else if (response.hasSS || response.hasCI) {
          this.ssoService.openSSO('fad');
        }
        //         else{
        // this.router.navigate(['/fad']);
        // }
      });
    } else {
      this.http.postlogin().subscribe(response => {
        if (response && response.error !== true) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
        }
        if (response && response.error) {
          this.http.showServiceErrorModalPopup('globalError');
        } else if (response.hasSS || response.hasCI) {
          this.ssoService.openSSO('fad');
        }
        //         else{
        // this.router.navigate(['/fad']);
        // }
      });
    }
  }

  navigatePharmacyLink(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  openFitnessURL() {
    if (this.isFitnessEnabled) {
      this.navCtrl.navigateForward('/tabs/fitness-and-weightloss');
    } else {
      window.open('https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss', '_blank');
    }
  }
}
interface PharmacyLinkType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
  isExternal: boolean;
}
