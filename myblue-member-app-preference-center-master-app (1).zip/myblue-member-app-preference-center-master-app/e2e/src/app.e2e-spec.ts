import { AppPage } from './app.po';

describe('bcbsma App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('MyBlue: A personalized way to access your health care info, claims, and more.');
  });
});
