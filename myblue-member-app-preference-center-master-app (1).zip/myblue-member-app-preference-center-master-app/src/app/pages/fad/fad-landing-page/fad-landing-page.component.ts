import { Location } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import {
  FadAutoCompleteComplexOption,
  FadAutoCompleteOptionForSearchText,
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  FadMembersInfoModel,
  LandingPageResponseCacheModel
} from '../modals/fad-landing-page.modal';
import {
  FadAutoCompleteComplexOptionInterface,
  FadAutoCompleteOptionForSearchTextInterface,
  FadLandingPageCompInputInterface,
  FadLandingPageCompOutputInterface,
  FadLandingPageSearchControlValuesInterface,
  FadLinkOptionInterface
} from '../modals/interfaces/fad-landing-page.interface';

import {
  AuthRequestType,
  FadLandingPageComponentMode,
  FadLandingPageFocusTracker,
  FadResouceTypeCodeConfig,
  FadResourceTypeCode
} from '../modals/types/fad.types';

import { FormBuilder } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Platform } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import * as cloneDeep from 'lodash/cloneDeep';
import { of } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { delay } from 'rxjs/operators/delay';
import { startWith } from 'rxjs/operators/startWith';
import { AuthToken } from '../../../models/auth-token.model';
import { SwrveEventNames, SwrveService } from '../../../services/swrve.service';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { MatchTextHighlightPipe } from '../../../shared/pipes/match-text-highlight/match-text-highlight.pipe';
import { FadResolverService } from '../../../shared/routeresolvers/fad-resolver.service';
import { GlobalService } from '../../../shared/services/global.service';
import { SetHCCSFlag, SetMLEEligibility, SetMLEIndicator } from '../../../store/actions/app.actions';
import { AppSelectors } from '../../../store/selectors/app-selectors';
import { DependentsModelInterface } from '../../my-claims/models/interfaces/dependants-model.interface';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadPastSearchQueryListService } from '../fad-past-search-query-list/fad-past-search-query-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import {
  DoctorProfileSearchRequestModel,
  FadVitalsNetwork,
  FadVitalsZipCodeSearchRequestModel,
  FPSRPlan,
  FZCSRCity
} from '../modals/fad-vitals-collection.model';
import { GetSearchByProviderRequestModel } from '../modals/getSearchByProvider.models';
import {
  DoctorProfileSearchRequestModelInterface,
  FadVitalsNetworkInterface,
  FadVitalsZipCodeSearchRequestModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { FadPlanSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { GetSearchByProviderRequestModelInterface } from '../modals/interfaces/getSearchByProvider-models.interface';
import { ConstantsService } from './../../../shared/services/constants.service';
import { FadLandingPageService } from './fad-landing-page.service';

/* tslint:disable */
@Component({
  selector: 'app-fad-landing-page',
  templateUrl: './fad-landing-page.component.html',
  styleUrls: ['./fad-landing-page.component.scss']
})
export class FadLandingPageComponent implements OnInit, OnDestroy, OnChanges, AfterViewInit {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserState) currentUserState: any;
  @SelectSnapshot(AppSelectors.getMLEIndicator) mleIndicator: string;
  @SelectSnapshot(AppSelectors.getDependentsList) dependentsList: DependentsModelInterface;
  @SelectSnapshot(AppSelectors.getMLEEligibility) mleEligibility: string;

  @Input() componentInput: FadLandingPageCompInputInterface;
  @Output() componentOutput = new EventEmitter<FadLandingPageCompOutputInterface>();
  @Output() onSearchFocus = new EventEmitter<boolean>();
  @ViewChild('searchTextTypeAhead') searchTextTypeAheadTrigger;
  @ViewChild('zipCodeTypeAhead') zipCodeTypeAheadTrigger;
  @ViewChild('planTypeAhead') planTypeAheadTrigger;
  @ViewChild('dependantListTypeAhead', { read: MatAutocompleteTrigger }) dependantListTypeAheadTrigger;
  @ViewChild('searchBar') searchBar: ElementRef;

  public fadConstants = FAD_CONSTANTS;
  public zipClearIcon = 'hidden';
  public planClearIcon = 'hidden';
  public dependantClearIcon = 'hidden';
  public searchTextPlaceHolder = '';
  public networkPlaceHolder = '';
  public isMedicareUser = false;
  public isRVRNVUser = false;
  public componentMode: FadLandingPageComponentMode = FAD_CONSTANTS.flags.fadLandingPageComponentMode_Normal;
  public displayDependentsOptionFlag = false;
  public searchControls: FadLandingPageSearchControlsModel;
  public zipCodeOptions: FZCSRCity[] = [];
  public filteredZipCodeOptions: Observable<FZCSRCity[]>;
  public dependantsList: FadMembersInfoModel[] = [];
  public selectedMember: FadMembersInfoModel;
  public defaultPlanOptions: FadAutoCompleteOptionForSearchText[] = [];
  public planOptions: FadAutoCompleteOptionForSearchText[] = [];
  public filteredPlanOptions: Observable<FadAutoCompleteOptionForSearchText[]>;
  public autoCompleteOptionsForSearchText: FadAutoCompleteOptionForSearchText[] = [];
  public filteredAutoCompleteSearchOptions: Observable<FadAutoCompleteOptionForSearchText[]>;
  public viewPortWidth: number = null;
  public emboseSearchTextField = false;
  public emboseZipCodeField = false;
  public embosePlanField = false;
  public emboseDependantsField = false;
  public focusedTarget: string;
  public userCurrentPlan: FPSRPlan = new FPSRPlan();
  public getLocalStorageZipCodeOption: FZCSRCity;
  public fadInfo: any;
  public showTextField = false;

  private preventSearchTextAutoCompleteDropdown = false;
  private textToHighlightInPlanOption: string;
  private textToHighlightInSearchTextOption: string;
  private isLogin = false;
  private defaultAutoCompleteSearchOption: FadAutoCompleteOptionForSearchTextInterface[] = [];
  private searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
  private searchTextMaterialAutoCompleteBugWorkAroundTimerFlag = 0;
  private debounceTime = 400;
  private isPageReload = false;
  private bypassPlanFieldFocusLogic = false;
  private userState: string;

  public zipCodeValidationErrors = {
    invalidZipCode: {
      exists: false,
      errorMsg: 'Please enter Zip Code or City, State.',
      display: false
    },
    noMatchFound: {
      exists: false,
      errorMsg: 'Please check that you have entered the correct Zip Code or City.',
      display: false
    }
  };

  public planValidationErrors = {
    invalidPlan: {
      errorMsg: 'Please enter a valid network name.',
      display: false
    },
    noMatchFound: {
      errorMsg: 'Please check that you have entered a correct plan name.',
      display: false
    }
  };
  private isChangedUserFlag: boolean;
  public iszipcodechangeFlag = false;
  private currentPlanNetwork: any;
  private autoCompleteWarningFlag: any;
  public lat: string;
  public lng: string;

  hasSearchFocus = false;
  hasZipFocus = false;
  hasNetworkFocus = false;
  currentSelectedPlan = '';
  isOnitCalled = false;
  isIos = false;
  isDependentsFetched = false;
  isEditingForm = false;

  constructor(
    public fb: FormBuilder,
    public landingPageService: FadLandingPageService,
    public fadResolverService: FadResolverService,
    private store: Store,
    private router: Router,
    private fadSearchResultsService: FadSearchResultsService,
    private fadPastSearchQueryListService: FadPastSearchQueryListService,
    private doctorProfileService: FadDoctorProfileService,
    private facilityProfileService: FadFacilityProfileService,
    private fadService: FadService,
    private activatedRoute: ActivatedRoute,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private globalService: GlobalService,
    private constantsService: ConstantsService,
    private androidPermissions: AndroidPermissions,
    private geolocation: Geolocation,
    private platform: Platform,
    private cdRef: ChangeDetectorRef,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private loadingController: LoadingController,
    private location: Location
  ) {
    if (this.platform.is('ios')) {
      this.isIos = true;
    }

    this.landingPageService.planNetworkData = JSON.parse(sessionStorage.getItem('fadInfo')) as FadPlanSearchResponseModelInterface;
    this.activatedRoute.snapshot.data = { ...this.activatedRoute.snapshot.data, ...{ fadInfo: this.landingPageService.planNetworkData } };

    this.isChangedUserFlag = false;
    this.fadInfo = this.landingPageService.planNetworkData;
    const planOption = new FadAutoCompleteOptionForSearchText();
    if (!this.fadInfo) {
      this.fadResolverService.getVitalsPlanInfo().subscribe(data => {
        this.landingPageService.planNetworkData = data;
        this.fadInfo = data;
        this.fadInfo.networks.map(n => {
          const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), n);
          const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
          planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
          if (plan.getPlanIndicator()) {
            this.userCurrentPlan = plan;
          }
        });
      });
    }

    this.autoCompleteWarningFlag = false;

    // Reset Plan option when user login
    if (sessionStorage.getItem('userLoginFlag') !== 'true') {
      this.fadInfo = this.activatedRoute.snapshot.data.fadInfo;
      if (this.fadInfo) {
        this.userCurrentPlan = this.getDefaultPlan();

        this.store.dispatch(new SetMLEEligibility(this.fadInfo.mleEligibility));
        if (this.userCurrentPlan.getName() && this.userCurrentPlan.getId()) {
          const cachedPlans = new FadAutoCompleteComplexOption()
            .setSimpleText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId());

          this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlans);
          sessionStorage.setItem('userLoginFlag', 'true');
        }
      }
    }

    // setting modal popup for mleindicator for null & N scenarios
    const mleIndicator = this.fadInfo && this.fadInfo.mleEligibility;
    const hccsFlag = this.fadInfo && this.fadInfo.hccsFlag;

    if (hccsFlag) {
      this.store.dispatch(new SetHCCSFlag(hccsFlag));
    }

    this.store.dispatch(new SetMLEIndicator(mleIndicator));
    this.viewPortWidth = window.innerWidth;

    if (!sessionStorage.getItem('selMemIdx')) {
      sessionStorage.setItem('selMemIdx', '0');
    }

    this.geolocation
      .getCurrentPosition()
      .then(position => {
        this.zipCodeValidationErrors.noMatchFound.display = false;
        this.zipCodeValidationErrors.invalidZipCode.display = false;

        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          this.filteredZipCodeOptions = of([]);
          this.filteredZipCodeOptions = of(vitalsZipCodeResponse.cities);
          this.filteredZipCodeOptions.subscribe(response => {
            const defaultCityZip: FZCSRCity = new FZCSRCity();
            defaultCityZip
              .setZip(response[0].zip)
              .setCity(response[0].city)
              .setState_code(response[0].state_code)
              .setGeo(response[0].geo) // '42.242921,-71.009972');
              .setCounty(response[0].county)
              .setGeo(response[0].geo)
              .setLat(response[0].lat)
              .setLng(response[0].lng)
              .setName(response[0].name)
              .setPlace_id(response[0].place_id)
              .setScore(response[0].score)
              .setState(response[0].state)
              .setState_code(response[0].state_code)
              .setZip(response[0].zip);

            const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
            if (lastSelectedZipCodeOption.city === '') {
              this.fadSearchResultsService.setLastSelectedZipCodeOption(defaultCityZip);
              const zipCodeText = defaultCityZip.getDisplayValue();
              this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
              this.zipCodeTypeAheadTrigger.el.value = zipCodeText;
              this.zipCodeOptions.push(defaultCityZip);
              localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(defaultCityZip));
            }
          });
        });
        this.getLocalStorageZipCodeOption = null;
      })
      .catch(err => {
        const zipCodeLastSearchedWith: FZCSRCity = JSON.parse(localStorage.getItem('FadLandingPageSearchCriteria_zipCode')) as FZCSRCity;

        if (zipCodeLastSearchedWith) {
          this.getLocalStorageZipCodeOption = Object.assign(new FZCSRCity(), cloneDeep(zipCodeLastSearchedWith));
        }
        this.updateZipCodeFieldFromApplicationStorage();
      });

    this.platform.backButton.subscribeWithPriority(100, () => {
      this.handleBackButton();
    });
  }

  handleBackButton() {
    if (this.hasSearchFocus) {
      this.cancelSearchTextAutoCompleteDropDown();
      this.searchTextTypeAheadTrigger.el.blur();
    } else if (this.hasZipFocus) {
      this.hideZipCodeDropDown();
      this.zipCodeTypeAheadTrigger.el.blur();
    } else if (this.hasNetworkFocus) {
      this.hiddenPlanDropDown();
      this.planTypeAheadTrigger.el.blur();
    } else if (this.isEditingForm) {
      this.location.back();
    } else {
      this.router.navigate(['tabs/home']);
    }
  }

  emitSearchFocus() {
    this.onSearchFocus.emit(this.hasSearchFocus);
  }

  get pageTitle() {
    if (this.hasSearchFocus || this.isEditingForm) {
      return 'Search';
    } else if (this.hasNetworkFocus) {
      return 'Network';
    } else {
      return 'Find a Doctor & Estimate Costs';
    }
  }

  setPlanNameText(text: string): void {
    if (this.planTypeAheadTrigger && this.planTypeAheadTrigger.el) {
      this.planTypeAheadTrigger.el.value = text;
    }
  }

  displayZipCodeFn(location: any): string {
    return location ? `${location.zip} - ${location.city} , ${location.state_code}` : '';
  }

  ionViewDidLeave() {
    // Remove the focus and retain the initial state on navigation
    this.searchControls.searchTypeAheadControl.setValue('');
    this.hasSearchFocus = this.hasZipFocus = this.hasNetworkFocus = false;
    this.emitSearchFocus();
  }

  compareById(o1, o2) {
    return o1 && o2 ? (o1.fadVendorMemberNumber || o1) === (o2.fadVendorMemberNumber || o2) : o1 === o2;
  }

  ionViewWillEnter() {
    this.isEditingForm = sessionStorage.getItem('IsEditingSearch') === 'true';
    sessionStorage.removeItem('IsEditingSearch');
    if (!this.isOnitCalled) {
      this.isOnitCalled = true;
    } else {
      if (!sessionStorage.getItem('selMemIdx')) {
        this.geolocation
          .getCurrentPosition()
          .then(position => {
            this.zipCodeValidationErrors.noMatchFound.display = false;
            this.zipCodeValidationErrors.invalidZipCode.display = false;

            this.lat = position.coords.latitude.toString();
            this.lng = position.coords.longitude.toString();
            const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
            vitalsZipCodeSearchRequest.lat = this.lat;
            vitalsZipCodeSearchRequest.lng = this.lng;
            vitalsZipCodeSearchRequest.limit = 1;
            vitalsZipCodeSearchRequest.sort = 'distance';
            this.filteredZipCodeOptions = of([]);
            this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
              this.filteredZipCodeOptions = of([]);
              this.filteredZipCodeOptions = of(vitalsZipCodeResponse.cities);
              this.filteredZipCodeOptions.subscribe(response => {
                console.log(response[0]);
                const defaultCityZip: FZCSRCity = new FZCSRCity();
                defaultCityZip
                  .setZip(response[0].zip)
                  .setCity(response[0].city)
                  .setState_code(response[0].state_code)
                  .setGeo(response[0].geo) // '42.242921,-71.009972');
                  .setCounty(response[0].county)
                  .setGeo(response[0].geo)
                  .setLat(response[0].lat)
                  .setLng(response[0].lng)
                  .setName(response[0].name)
                  .setPlace_id(response[0].place_id)
                  .setScore(response[0].score)
                  .setState(response[0].state)
                  .setState_code(response[0].state_code)
                  .setZip(response[0].zip);

                this.fadSearchResultsService.setLastSelectedZipCodeOption(defaultCityZip);
                const zipCodeText = defaultCityZip.getDisplayValue();
                this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
                this.zipCodeTypeAheadTrigger.el.value = zipCodeText;
                this.zipCodeOptions.push(defaultCityZip);

                localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(defaultCityZip));
              });
            });
            this.getLocalStorageZipCodeOption = null;
          })
          .catch(err => {
            const zipCodeLastSearchedWith: FZCSRCity = JSON.parse(
              localStorage.getItem('FadLandingPageSearchCriteria_zipCode')
            ) as FZCSRCity;

            if (zipCodeLastSearchedWith) {
              this.getLocalStorageZipCodeOption = Object.assign(new FZCSRCity(), cloneDeep(zipCodeLastSearchedWith));
            }
            this.updateZipCodeFieldFromApplicationStorage();
          });

        //
        this.ngOnInit();
        this.ngAfterViewInit();
      } else {
        const zipCodeLastSearchedWith: FZCSRCity = JSON.parse(localStorage.getItem('FadLandingPageSearchCriteria_zipCode')) as FZCSRCity;

        if (zipCodeLastSearchedWith) {
          this.getLocalStorageZipCodeOption = Object.assign(new FZCSRCity(), cloneDeep(zipCodeLastSearchedWith));
        }
        this.updateZipCodeFieldFromApplicationStorage();

        this.ngOnInit();
        this.ngAfterViewInit();
      }
    }

    if (sessionStorage.getItem('optionsFlagSelection')) {
      const tempvar = sessionStorage.getItem('optionsFlagSelection');
      this.searchControls.searchTypeAheadControl.setValue(tempvar);
      sessionStorage.removeItem('optionsFlagSelection');
    }
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_FAD_Landing_Screen);

    const tracking = JSON.parse(sessionStorage.getItem('path')) ? JSON.parse(sessionStorage.getItem('path')) : [];
    if (tracking[tracking.length - 1] !== 'search-results') {
      tracking.push('fad');
    }
    sessionStorage.setItem('path', JSON.stringify(tracking));
    this.networkPlaceHolder = this.fadConstants.text.landingPage_selectPlan_placeHolder_anonymous;

    if (this.isAnonymousUser() || this.scopeName === 'REGISTERED-NOT-VERIFIED' || this.scopeName === 'REGISTERED-AND-VERIFIED') {
      this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
    } else if (this.userType && (this.userType.toLowerCase() === 'medicare' || this.userType.toLowerCase() === 'medex')) {
      this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
    } else {
      this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_user;
    }
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        if (!event.url.includes('/fad')) {
          sessionStorage.removeItem('selMemIdx');
        }
      }
    });

    // DO NOT CHANGE CODE ORDER - STEP 1
    // step 1 - If the component is being opened in abstract mode, the set values persisted from the
    // main screen on to the search fields in the current age
    if (this.componentInput && this.componentInput.componentMode === FAD_CONSTANTS.flags.fadLandingPageComponentMode_Abstract) {
      this.searchControls = new FadLandingPageSearchControlsModel();
      const controlValues = this.fadSearchResultsService.getSearchCriteria() as FadLandingPageSearchControlValues;
      this.searchControls.setValues(controlValues);
      this.setPlanNameText(controlValues.getPlanName().getSimpleText());
      this.landingPageService.setCachedSearchControlState(this.fadSearchResultsService.getSearchCriteria());
    }

    // DO NOTE CHANGE CODE ORDER - STEP 2
    // step 2 - use existing search control references if any
    if (this.landingPageService.getCachedSearchControlState()) {
      this.searchControls = this.landingPageService.getCachedSearchControlState() as FadLandingPageSearchControlsModel;
      this.fadInfo = this.landingPageService.planNetworkData;
      if (
        this.searchControls.planControl.value === '' ||
        this.searchControls.planControl.value == null ||
        this.searchControls.planControl.value.simpleText === ''
      ) {
        this.currentPlanNetwork = new FadAutoCompleteComplexOption()
          .setSimpleText(this.getDefaultPlanOption().getName())
          .setNetworkId(this.getDefaultPlanOption().getId());
        this.fadSearchResultsService.setLastSelectedPlanOption(this.currentPlanNetwork);
        this.searchControls.planControl.setValue(this.currentPlanNetwork);
        this.setPlanNameText(this.currentPlanNetwork.getSimpleText());
      }
    } else {
      this.searchControls = new FadLandingPageSearchControlsModel();
      this.fadInfo = this.landingPageService.planNetworkData;
    }

    // DO NOT CHANGE CODE ORDER - STEP 3
    // step 3 - service call initiations. This is sequential and hence the code order must not change
    if (
      // tslint:disable-next-line:no-magic-numbers
      this.viewPortWidth > 992 ||
      // tslint:disable-next-line:no-magic-numbers
      (this.componentMode === FAD_CONSTANTS.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
    ) {
      this.initData();
    } else if (
      this.landingPageService.getCachedSearchControlState() &&
      this.searchControls.dependantNameControl.value &&
      this.dependentsList &&
      this.dependentsList.dependents.length > 0
    ) {
      this.displayDependentsOptionFlag = true;
    } else if (this.landingPageService.getCachedSearchControlState() && this.searchControls.dependantNameControl.value) {
      this.fetchDependentList();
    }

    // DO NOTE CHANGE CODE ORDER - STEP 4
    // step 4 - page needs to be updated with cached values if any, only after the defaults are loaded into memory
    if (this.fadPastSearchQueryListService.searchControlValues) {
      const controlValues = this.fadPastSearchQueryListService.searchControlValues as FadLandingPageSearchControlValues;
      this.searchControls.setValues(controlValues);
      this.setPlanNameText(controlValues.getPlanName().getSimpleText());
      this.fadPastSearchQueryListService.searchControlValues = null;
    }

    // step 4 - help to enhanced the search functionlity in the typehead component which are loaded into memory with data
    if (
      // tslint:disable-next-line:no-magic-numbers
      this.viewPortWidth > 992 ||
      // tslint:disable-next-line:no-magic-numbers
      (this.componentMode === FAD_CONSTANTS.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
    ) {
      this.enhancedSearchAfterInitData();
    }

    const searchText: string = this.searchControls.searchTypeAheadControl.value;
    if (!searchText) {
      this.isPageReload = true;
    }

    if (searchText && searchText.trim) {
      this.isPageReload = false;
      this.stripAllDoctorFacilityTextAndUpdateUI(searchText);
    } else {
      this.searchControls.searchTypeAheadControl.setValue(searchText);
    }

    this.landingPageService.getToolTipInfo().subscribe((data: any) => {
      if (data && data.toolTipInfo && data.toolTipInfo.tiersLabel) {
        data.toolTipInfo.tiersLabel.map(tierLabels => {
          switch (tierLabels.toolTip.code) {
            case 'TEBT':
              tierLabels.toolTip.code = 'Enhanced Benefits Tier';
              break;
            case 'TBBT':
              tierLabels.toolTip.code = 'Basic Benefits Tier';
              break;
            case 'TSBT':
              tierLabels.toolTip.code = 'Standard Benefits Tier';
              break;
            case 'THCS':
              tierLabels.toolTip.code = 'Higher Cost Share';
              break;
            case 'TLCS':
              tierLabels.toolTip.code = 'Lower Cost Share';
              break;
            default:
              tierLabels.toolTip.code = 'Higher Cost Share';
              break;
          }
        });
        sessionStorage.setItem('tiersLabel', JSON.stringify(data.toolTipInfo.tiersLabel));
        sessionStorage.setItem('profileLabel', JSON.stringify(data.toolTipInfo.profile));
      }
    });
    this.currentSelectedPlan = sessionStorage.getItem('currentSelectedPlan');

    if (this.platform.is('cordova')) {
      this.locationPermission();
    }

    this.cdRef.detectChanges();
  }

  getLocation() {
    this.geolocation.getCurrentPosition().then(
      response => {
        const lat = response.coords.latitude.toString();
        const lng = response.coords.longitude.toString();

        const zipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        zipCodeSearchRequest.lat = lat;
        zipCodeSearchRequest.lng = lng;
        zipCodeSearchRequest.limit = 1;
        zipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = of([]);
        this.landingPageService.getVitalsZipCodeInfo(zipCodeSearchRequest).subscribe(zipcodeResponse => {
          this.filteredZipCodeOptions = of([]);
          this.filteredZipCodeOptions = of(zipcodeResponse.cities);
          console.log(zipcodeResponse.cities);
        });
      },
      error => console.log(error)
    );
  }

  async locationPermission() {
    const hasPermission = await this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION);
    if (!hasPermission) {
      const result = await this.androidPermissions.requestPermissions(this.androidPermissions.PERMISSION.ACCESS_FINE_LOCATION);
      if (result.hasPermission) {
        this.getLocation();
      }
    } else {
      this.getLocation();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    this.componentInput = changes.componentInput.currentValue;
    if (this.componentInput) {
      this.showTextField = true;
    }
  }

  ngAfterViewInit() {
    try {
      if (this.landingPageService.getCachedSearchControlState()) {
        this.landingPageService.clearCachedSearchControlState();
      }

      if (
        this.landingPageService.getCachedSearchControlState() &&
        this.landingPageService.cachedResponse.planOptions &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger.el.value = this.searchControls.planControl.value.getSimpleText();
      } else if (
        this.isLogin &&
        (!this.landingPageService.cachedResponse || !this.landingPageService.cachedResponse.planOptions) &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger.el.value = this.userCurrentPlan.getName();
      }

      if (this.componentMode === FAD_CONSTANTS.flags.fadLandingPageComponentMode_Normal) {
        if (!this.zipCodeTypeAheadTrigger.el.value) {
          this.updateZipCodeFieldFromApplicationStorage();
        }
        let cachedPlan: FadAutoCompleteComplexOption = this.fadSearchResultsService.getLastSelectedPlanOption();

        if (!cachedPlan) {
          const searchCriteria = Object.assign(new FadLandingPageSearchControlValues(), this.fadSearchResultsService.getSearchCriteria());
          cachedPlan = searchCriteria && searchCriteria.getPlanName ? searchCriteria.getPlanName() : null;
          if (!cachedPlan || !cachedPlan.getSimpleText || cachedPlan.getSimpleText() === '') {
            cachedPlan = new FadAutoCompleteComplexOption()
              .setSimpleText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId());
          }
        }
        this.searchControls.planControl.setValue(cachedPlan);
        this.setPlanNameText(cachedPlan.getSimpleText());
        this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlan);

        if (this.planOptions.length === 0) {
          const planOption = new FadAutoCompleteOptionForSearchText();
          planOption.addOption(
            new FadAutoCompleteComplexOption().setSimpleText(this.userCurrentPlan.getName()).setNetworkId(this.userCurrentPlan.getId())
          );
          this.planOptions.push(planOption);
        }
      } else {
        this.updateZipCodeFieldFromApplicationStorage();
      }
    } catch (exception) {}
    const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
    const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;

    this.autoCompleteWarningFlag = zipCode && !plan;

    const memIdx = sessionStorage.getItem('selMemIdx');
    //TODO: use ngxs store value here.
    this.dependantsList = JSON.parse(sessionStorage.getItem('dependantsList')) as FadMembersInfoModel[];
    if (this.dependantsList) {
      if (memIdx && memIdx !== '-1') {
        this.selectedMember = this.dependantsList[memIdx];
        sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
      } else {
        this.selectedMember = this.dependantsList[0];
        sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
      }
    }

    this.cdRef.detectChanges();
  }

  private addOnClickToAutoCompleteSpinner() {
    const autoCompleteSpinnerList: HTMLElement[] = Array.from(
      document.getElementsByClassName('mat-auto-complete-spinner')
    ) as HTMLElement[];
    autoCompleteSpinnerList.map(spinner => {
      const _spinner = spinner as HTMLDivElement;
      spinner['removeAllListeners'] ? spinner['removeAllListeners']() : this.noop();
      _spinner.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
      });
    });
  }

  getDefaultPlan(): FPSRPlan {
    let resultValue: FPSRPlan = new FPSRPlan();
    if (this.fadInfo && this.fadInfo && this.fadInfo.networks) {
      this.fadInfo.networks.some(res => {
        if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
          resultValue = Object.assign(new FPSRPlan(), res.network);
          return true;
        }
      });
    }
    return resultValue;
  }

  getDefaultPlanOption(): FPSRPlan {
    let resultValue: FPSRPlan = new FPSRPlan();

    if (this.fadInfo && this.fadInfo.networks) {
      this.fadInfo.networks.some(res => {
        if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
          resultValue = Object.assign(new FPSRPlan(), res.network);
          return true;
        }
      });
    }

    return resultValue;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this.fadService.resetServiceError();
  }

  // will help determine the window width of the screen at all times
  // helps make RWD specific code as necessary
  // viewPortWidth for desktop is >= 993, for mobile and tablet is <=992
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.viewPortWidth = window.innerWidth;
  }

  public redirectRequestPlanDropDown(event, target?: AuthRequestType) {
    try {
      if (target === AuthRequestType.authenticate) {
        this.globalService
          .redirectionRoute()
          .then(response => {})
          .catch(route => {
            this.router.navigate([route]);
          });
      } else if (target === AuthRequestType.login) {
        this.router.navigateByUrl('/login');
      } else if (target === AuthRequestType.register) {
        this.router.navigateByUrl('/register');
      }
      event.stopPropagation();
      // throw new Error('Yet to code >>> target is ' + target);
    } catch (exception) {}
  }

  public getMatchHighlightedTextInPlanOption(optionText: string): string {
    return optionText ? new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInPlanOption) : '';
  }

  public getTotalMatchHiglithedPlanOption(): boolean {
    return this.textToHighlightInPlanOption && this.textToHighlightInPlanOption !== '';
  }

  public getMatchHighlightedTextInSearchTextOption(optionText: string): string {
    return optionText ? new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInSearchTextOption) : '';
  }

  public removeIconFocusTracker(target: string, event?) {
    this.focusedTarget = target;
    if (this.viewPortWidth < 993) {
      switch (target) {
        // when remove icon inside the search doctor field is clicked
        case FadLandingPageFocusTracker.searchText:
          break;
        // when remove icon inside the search zipcode field is clicked
        case FadLandingPageFocusTracker.zipCode:
          this.landingPageService.cachedResponse.zipCodeOptions = [];
          this.filteredZipCodeOptions = of([]);
          this.displayZipCodeDropDown(event);
          break;
        // when remove icon inside the search plan field is clicked
        case FadLandingPageFocusTracker.plan:
          this.displayPlanDropDown(event);
          break;
        // when remove icon inside the search dependant field is clicked
        case FadLandingPageFocusTracker.dependant:
          break;
        // otherwise do nothing
        default:
          break;
      }
    }
  }

  public emboseSearchTextFieldOnScreen(flag: boolean, cancelButtonClicked?: boolean): boolean {
    try {
      this.emboseSearchTextField = flag;
      if (!flag && !cancelButtonClicked) {
        this.triggerSearchOnEnterKey();
      }
    } catch (exception) {}
    return flag;
  }

  public triggerSearchOnSearchLensIcon(flag: boolean): boolean {
    try {
      this.emboseSearchTextFieldOnScreen(flag);
    } catch (exception) {}
    return flag;
  }

  public emboseZipCodeFieldOnScreen(flag: boolean, location?: FZCSRCity): boolean {
    if (location) {
      const selectedZipCodeOption: FZCSRCity = new FZCSRCity();
      selectedZipCodeOption
        .setCity(location.city)
        .setCounty(location.county)
        .setGeo(location.geo)
        .setLat(location.lat)
        .setLng(location.lng)
        .setName(location.name)
        .setPlace_id(location.place_id)
        .setScore(location.score)
        .setState(location.state)
        .setState_code(location.state_code)
        .setZip(location.zip);

      this.fadSearchResultsService.setLastSelectedZipCodeOption(selectedZipCodeOption);

      setTimeout(() => {
        this.emboseZipCodeField = false;
        this.hasZipFocus = false;
      }, 100);
    } else {
      this.emboseZipCodeField = flag;
      this.hasZipFocus = flag;
    }

    this.zipClearIcon = flag ? 'visible' : 'hidden';

    return flag;
  }

  public embosePlanFieldOnScreen(flag: boolean, planOption?: FadAutoCompleteComplexOption): boolean {
    try {
      if (planOption) {
        const selectedPlanOption: FadAutoCompleteComplexOption = Object.assign(new FadAutoCompleteComplexOption(), planOption);

        this.planValidator(selectedPlanOption.getSimpleText() || selectedPlanOption.getContextText());

        this.fadSearchResultsService.setLastSelectedPlanOption(selectedPlanOption);
        this.searchControls.planControl.setValue(selectedPlanOption);
        this.setPlanNameText(selectedPlanOption.getSimpleText());
        console.log(this.searchControls);
        setTimeout(() => {
          try {
            this.planTypeAheadTrigger._onChange(selectedPlanOption.getSimpleText());
            this.planTypeAheadTrigger.closePanel();
            this.embosePlanField = false;
          } finally {
            // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
          }
        }, 100);
      } else {
        this.embosePlanField = flag;
      }

      this.planClearIcon = flag ? 'visible' : 'hidden';
    } catch (exception) {}

    return flag;
  }

  public planAutoCompleteListDesktopViewSelectionChange(option: FadAutoCompleteComplexOption): void {
    this.bypassPlanFieldFocusLogic = true;
    if (this.userCurrentPlan.getId() == option.getNetworkId()) {
      sessionStorage.setItem('networkChange', 'false');
    } else if (this.useridin && this.userType) {
      sessionStorage.setItem('networkChange', 'true');
    }

    if (option.getInfoText() === 'my-current-plan-option') {
      option.setSimpleText(option.getContextText());
      option.setInfoText('');
      option.setContextText('');
    }

    this.planTypeAheadTrigger.el.value = option.getSimpleText();
    this.hasNetworkFocus = false;
    if (option.getInfoText() !== FAD_CONSTANTS.plans.dontKnowPlanOption) {
      this.fadSearchResultsService.setLastSelectedPlanOption(option);
      this.planValidator(option.getSimpleText() || option.getContextText());

      this.doSearch();
    }
  }

  public emboseDependantsFieldOnScreen(flag: boolean): boolean {
    try {
      this.emboseDependantsField = flag;
      this.dependantClearIcon = flag ? 'visible' : 'hidden';
    } catch (exception) {}
    return flag;
  }

  public openSelectionList(event, link: FadLinkOptionInterface): boolean {
    try {
      this.router.navigate([link.href]);
      event.stopPropagation();
    } catch (exception) {}
    return false;
  }

  public checkAndDisplayZipCodeDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayZipCodeDropDown(event);
        return false;
      }
    } catch (exception) {}
    return true;
  }

  public checkAndDisplayPlanDropDown(event) {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPlanDropDown(event);
        return false;
      }
    } catch (exception) {}
  }

  public checkAndDisplayDependentListDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayDependentListDropDown(event);
        return false;
      }
    } catch (exception) {}
    return true;
  }

  public checkAndDisplayPastSearchHistory(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPastSearchHistory();
        return false;
      }
    } catch (exception) {}
    return true;
  }

  public onSearchTextOptionSelected(option: FadAutoCompleteComplexOption, isSpecialityOption: boolean): void {
    try {
      this.hasSearchFocus = false;
      this.emitSearchFocus();
      this.isPageReload = false;
      this.fadSearchResultsService.setLastSelectedSearchTextOption(option);
      this.preventSearchTextAutoCompleteDropdown = true;
      const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
      this.autoCompleteWarningFlag = zipCode && !plan;

      if (isSpecialityOption) {
        if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
          // if a speciality option is clicked in the autocomplete dropdown, trigger the search for the same
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
          searchControlValues.setSearchText(option);
          this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
          this.fadSearchResultsService.setSearchCriteria(searchControlValues);

          if (!this.isSearchButtonDisabled()) {
            this.doSearch();
          }
        }
      } else {
        this.searchControls.searchTypeAheadControl.setValue(option.getSimpleText() || option.getContextText());
      }
    } catch (exception) {}
  }

  onZipCodeTypeaheadOptionSelectionChange(location: FZCSRCity) {
    this.zipCodeTypeAheadTrigger.el.value = this.displayZipCodeFn(location);
    this.hasZipFocus = false;
    try {
      this.fadSearchResultsService.setLastSelectedZipCodeOption(location);
      this.iszipcodechangeFlag = true;
      sessionStorage.setItem('zipcodechangeflag', 'true');
      this.doSearch();
    } catch (exception) {}
  }

  private triggerSearchOnEnterKey(desktopSearchButtonClick?: boolean, enterKeyPressed?: boolean) {
    const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
    const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
    const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
    const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
      `${userProvidedSearchText}~${geoKey}`
    );

    if (cachedLookupOptions && cachedLookupOptions.length) {
      let cachedLookupOption = this.getCachedLookupOption(cachedLookupOptions, enterKeyPressed);
      cachedLookupOption = cachedLookupOption == null ? cachedLookupOptions[0] : cachedLookupOption;
      if (cachedLookupOption && cachedLookupOption.category === FAD_CONSTANTS.text.areYouLookingFor) {
        const firstSpecialityOption: FadAutoCompleteComplexOption = cachedLookupOptions[0].options[0] as FadAutoCompleteComplexOption;
        this.fadSearchResultsService.setLastSelectedSearchTextOption(firstSpecialityOption);
        if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
          this.emboseSearchTextField = false;
          this.searchControls.searchTypeAheadControl.setValue(cachedLookupOption.options[0].getSimpleText());
          if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.doSearch();
          }
        }
      } else if (
        cachedLookupOption &&
        cachedLookupOption.category &&
        cachedLookupOption.category.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) === 0
      ) {
        const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
        const searchTextOption = new FadAutoCompleteComplexOption();
        searchTextOption.setSimpleText(cachedLookupOption.category);
        searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);
        searchControlValues.setSearchText(searchTextOption);

        this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
        if (!this.isSearchButtonDisabled()) {
          this.searchControls.setValues(searchControlValues);
          this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
          if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.doSearch();
          }
        }
      } else if (
        cachedLookupOption &&
        cachedLookupOption.category &&
        cachedLookupOption.category.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0
      ) {
        const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

        const searchTextOption = new FadAutoCompleteComplexOption();
        searchTextOption.setSimpleText(cachedLookupOption.category);
        searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);

        searchControlValues.setSearchText(searchTextOption);

        this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
        if (!this.isSearchButtonDisabled()) {
          this.searchControls.setValues(searchControlValues);
          this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
          if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.doSearch();
          }
        }
      }
    } else if (desktopSearchButtonClick) {
      this.doSearch();
    }
  }

  private getCachedLookupOption(lookupOptions, enterKeyPressed: boolean) {
    let lookupOption = null;
    this.hasSearchFocus = false;
    this.emitSearchFocus();
    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    const searchText = searchCriteria ? searchCriteria.getSearchText() : null;
    const specialtyId = searchText ? searchText.getSpecialityId() : '';
    const procedureId = searchText ? searchText.getProcedureId() : '';
    const resourceTypeCode = searchText ? searchText.getResourceTypeCode() : '';
    // if specialty/procedure or Enter button is clicked
    if ((specialtyId || procedureId || !resourceTypeCode || enterKeyPressed) && lookupOptions[0]) {
      lookupOption = lookupOptions[0];
      // if 'All doctors'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'P') {
      this.hasSearchFocus = false;
      if (
        lookupOptions[0] &&
        lookupOptions[0].category &&
        lookupOptions[0].category.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) === 0
      ) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) === 0
      ) {
        lookupOption = lookupOptions[1];
      }
      // if 'All facilities'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'F') {
      this.hasSearchFocus = false;
      if (
        lookupOptions[0] &&
        lookupOptions[0].category &&
        lookupOptions[0].category.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[1];
      } else if (
        lookupOptions[2] &&
        lookupOptions[2].category &&
        lookupOptions[2].category.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[2];
      }
    }
    this.emitSearchFocus();
    return lookupOption;
  }

  public displaySearchTextAutoCompleteDropDown(event?: KeyboardEvent): void {
    this.removeIconFocusTracker(FadLandingPageFocusTracker.searchText);
    this.clearServiceAlert(FAD_CONSTANTS.flags.mobileView);

    if (this.preventSearchTextAutoCompleteDropdown) {
      this.preventSearchTextAutoCompleteDropdown = false;
      return;
    }

    setTimeout(() => {
      if (!!this.searchControls.searchTypeAheadControl.value && !!this.searchControls.searchTypeAheadControl.value.trim) {
        setTimeout(() => {
          this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
          this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag = window.setInterval(() => {
            this.searchTextMaterialAutoCompleteBugWorkAroundFlag++;

            const autoCompletePanes: HTMLCollection = document.getElementsByClassName('cdk-overlay-pane');
            let activeAutoCompletePane: HTMLElement = null;
            for (let acpItr = 0; acpItr < autoCompletePanes.length; acpItr++) {
              const autoCompPane: HTMLElement = autoCompletePanes[acpItr] as HTMLElement;
              if (autoCompPane.innerHTML !== '') {
                activeAutoCompletePane = autoCompPane;
                break;
              }
            }

            if (activeAutoCompletePane) {
              const optionGroups: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByClassName(
                'mat-optgroup-label'
              ) as HTMLCollectionOf<HTMLElement>;

              if (optionGroups && optionGroups.length && activeAutoCompletePane) {
                const firstOptGroupLabel: HTMLElement = optionGroups[0];

                if (
                  firstOptGroupLabel &&
                  firstOptGroupLabel.innerHTML &&
                  (firstOptGroupLabel.innerHTML.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) === 0 ||
                    firstOptGroupLabel.innerHTML.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0)
                ) {
                  if (firstOptGroupLabel.className.indexOf('mat-active') !== -1) {
                    this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                    window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
                    return;
                  }
                  firstOptGroupLabel.className += ' mat-active';

                  const matOptions: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByTagName(
                    'mat-option'
                  ) as HTMLCollectionOf<HTMLElement>;
                  const firstMatOption: HTMLElement = matOptions[0];
                  if (firstMatOption) {
                    firstMatOption.className = firstMatOption.className ? firstMatOption.className.replace('mat-active', '').trim() : '';
                  }
                } else if (
                  firstOptGroupLabel &&
                  firstOptGroupLabel.innerHTML &&
                  firstOptGroupLabel.innerHTML.indexOf(FAD_CONSTANTS.text.notSureWhatToSearch) === 0
                ) {
                  return;
                } else if (firstOptGroupLabel && firstOptGroupLabel.innerHTML === '') {
                  const matOptions: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByTagName(
                    'mat-option'
                  ) as HTMLCollectionOf<HTMLElement>;
                  const firstMatOption: HTMLElement = matOptions[0];
                  this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;

                  if (firstMatOption && firstMatOption.className.indexOf('mat-active') === -1) {
                    firstMatOption.className += ' mat-active';

                    return;
                  }
                }
              }
            }
            if (this.searchTextMaterialAutoCompleteBugWorkAroundFlag > 25) {
              this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
              window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
            }

            this.addOnClickToAutoCompleteSpinner();
          }, 200);
        }, 100);
      }
    }, 500);
  }

  public cancelSearchTextAutoCompleteDropDown(): void {
    this.hasSearchFocus = false;
    this.emitSearchFocus();

    if (this.viewPortWidth < 993) {
      const cancelFlag = true;
      this.emboseSearchTextFieldOnScreen(false, cancelFlag);
      // if pageloads to clear session storage to avoid last value fetching in autocomplete
      if (this.isPageReload) {
        const option: FadAutoCompleteComplexOption = new FadAutoCompleteComplexOption();
        option.setSimpleText('');
        const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
        searchControlValues.setSearchText(option);
        this.searchControls.setValues(searchControlValues);
        this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
      }
    }

    setTimeout(() => {
      if (this.searchControls.searchTypeAheadControl.value) {
        const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

        if (!searchCriteria) {
          this.searchControls.searchTypeAheadControl.setValue('');
        } else {
          const simpleText = searchCriteria.getSearchText().getSimpleText();
          this.searchControls.searchTypeAheadControl.setValue(simpleText);
        }
      }
    }, 100);
  }

  public fillLocation() {
    this.zipCodeValidationErrors.noMatchFound.display = false;
    this.zipCodeValidationErrors.invalidZipCode.display = false;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          this.filteredZipCodeOptions = of([]);
          this.filteredZipCodeOptions = of(vitalsZipCodeResponse.cities);
        });
      });
    }
  }

  public displayZipCodeDropDown(event, flag = false): void {
    if (flag) {
      this.filteredZipCodeOptions = of([]);
      this.fillLocation();
    }
    if (this.viewPortWidth < 993) {
      this.clearServiceAlert(FAD_CONSTANTS.flags.mobileView);
      this.emboseZipCodeFieldOnScreen(true);
    }
    document.getElementsByTagName('body')[0].click();
  }

  public hideZipCodeDropDown(): void {
    this.hasZipFocus = false;

    if (this.viewPortWidth < 993) {
      this.emboseZipCodeFieldOnScreen(false);
    }

    setTimeout(() => {
      const lastSelectedZipCodeOption: FZCSRCity = Object.assign(
        Object.create(new FZCSRCity()),
        this.fadSearchResultsService.getLastSelectedZipCodeOption()
      );

      this.searchControls.zipCodeTypeAheadControl.setValue(lastSelectedZipCodeOption.getDisplayValue());
    }, 100);
  }

  public displayPlanDropDown(event): void {
    this.hasNetworkFocus = true;

    if (this.bypassPlanFieldFocusLogic) {
      this.bypassPlanFieldFocusLogic = false;
      return;
    }

    if (event.keyCode && (event.keyCode === 38 || event.keyCode === 40)) {
      return;
    }

    if (this.viewPortWidth < 993) {
      this.clearServiceAlert(FAD_CONSTANTS.flags.mobileView);
      this.embosePlanFieldOnScreen(true);
    }
    document.getElementsByTagName('body')[0].click();

    event.stopPropagation();
    setTimeout(() => {
      this.filterAutoCompletePlanOptions(this.searchControls.planControl.value);

      if (this.viewPortWidth > 992) {
        setTimeout(() => {
          const planDropDownList: HTMLCollectionOf<Element> = document.getElementsByClassName('mat-autocomplete-panel planOption');
          const planDropDown: HTMLElement = planDropDownList ? (planDropDownList[0] as HTMLElement) : null;

          const planDropDownContainer: HTMLElement = planDropDown ? planDropDown.parentElement : null;
          if (planDropDownContainer) {
            let pddcClass = planDropDown.getAttribute('class');
            pddcClass = pddcClass && pddcClass.trim ? pddcClass.trim() : '';

            if (!!this.planValidationErrors.invalidPlan.display) {
              pddcClass = pddcClass.replace(' planValidationErrorExist-42', '').replace('planValidationErrorExist-42', '');
              if (pddcClass.indexOf('planValidationErrorExist-42') < 0) {
                pddcClass += ' planValidationErrorExist-42';
              }
            } else if (!!this.planValidationErrors.noMatchFound.display) {
              pddcClass = pddcClass.replace(' planValidationErrorExist-55', '').replace('planValidationErrorExist-55', '');
              if (pddcClass.indexOf('planValidationErrorExist-55') < 0) {
                pddcClass += ' planValidationErrorExist-55';
              }
            } else {
              pddcClass = pddcClass
                .replace(' planValidationErrorExist-42', '')
                .replace('planValidationErrorExist-42', '')
                .replace(' planValidationErrorExist-55', '')
                .replace('planValidationErrorExist-55', '');
            }
            planDropDown.setAttribute('class', pddcClass);
          }
        });
      }
    });
  }

  public hiddenPlanDropDown(): void {
    this.hasNetworkFocus = false;

    if (this.viewPortWidth < 993) {
      this.embosePlanFieldOnScreen(false);
    }

    setTimeout(() => {
      const lastSelectedPlanOption = this.fadSearchResultsService.getLastSelectedPlanOption();
      if (lastSelectedPlanOption) {
        this.searchControls.planControl.setValue(lastSelectedPlanOption);
        this.setPlanNameText(lastSelectedPlanOption.getSimpleText());
        if (lastSelectedPlanOption && lastSelectedPlanOption.getSimpleText) {
          this.planValidator(lastSelectedPlanOption.getSimpleText());
        }
      }
    }, 100);
  }

  public displayDependentListDropDown(event): void {
    if (this.viewPortWidth < 993) {
      this.emboseDependantsFieldOnScreen(true);
    }
    document.getElementsByTagName('body')[0].click();
    const dependantField = this.dependantListTypeAheadTrigger.nativeElement;
    dependantField.focus();
    this.dependantClearIcon = dependantField.value && dependantField.value.length > 0 ? 'visible' : 'hidden';
    event.stopPropagation();
    this.dependantListTypeAheadTrigger._onChange();
    this.dependantListTypeAheadTrigger.openPanel();
  }

  public hiddenDependantDropDown(): void {
    if (this.viewPortWidth < 993) {
      this.emboseDependantsFieldOnScreen(false);
    }

    this.dependantListTypeAheadTrigger._onChange(this.searchControls.dependantNameControl.value);
    this.dependantListTypeAheadTrigger.closePanel();
  }

  public showDoctorList(): void {
    this.router.navigate([FAD_CONSTANTS.urls.fadSearchResultsPage]);
  }

  public displayPastSearchHistory() {
    this.router.navigate([FAD_CONSTANTS.urls.fadPastSearchQueries]);
  }

  public openMedicalIndex(url: string) {
    this.landingPageService.setCachedSearchControlState(this.searchControls);
    this.router.navigate([url]);
  }

  public clearTargetValue(target?: string): void {
    target = target || this.focusedTarget;

    switch (target) {
      // when remove icon inside the search doctor field is clicked
      case FadLandingPageFocusTracker.searchText:
        this.searchControls.searchTypeAheadControl.setValue('');

        this.searchTextTypeAheadTrigger.el.value = '';
        this.searchTextTypeAheadTrigger.el.focus();
        break;
      // when remove icon inside the search zipcode field is clicked
      case FadLandingPageFocusTracker.zipCode:
        this.searchControls.zipCodeTypeAheadControl.setValue('');

        if (this.searchControls.zipCodeTypeAheadControl.value === '') {
          this.zipCodeValidationErrors.noMatchFound.display = false;
          this.zipCodeValidationErrors.invalidZipCode.display = true;
          this.landingPageService.cachedResponse.zipCodeOptions = [];
          this.filteredZipCodeOptions = of([]);
          this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
          this.landingPageService.cachedResponse.setZipCodeOptions([]);
        }

        break;
      // when remove icon inside the search plan field is clicked
      case FadLandingPageFocusTracker.plan:
        this.searchControls.planControl.setValue('');
        if (this.searchControls.planControl.value === '') {
          this.planValidationErrors.noMatchFound.display = false;
          this.fadSearchResultsService.setLastSelectedPlanOption(null);
          this.planValidationErrors.invalidPlan.display = true;
        }

        break;
      // when remove icon inside the search dependant field is clicked
      case FadLandingPageFocusTracker.dependant:
        this.searchControls.dependantNameControl.setValue('');
        break;
      // otherwise do nothing
      default:
        break;
    }
    this.focusedTarget = '';
  }

  public doSearch(flag = false): void {
    try {
      if (this.userCurrentPlan.getId() == this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()) {
        sessionStorage.setItem('networkChange', 'false');
      } else if (this.useridin && this.userType) {
        sessionStorage.setItem('networkChange', 'true');
      }
      if (this.isSearchButtonDisabled() && !flag) {
        return;
      }
      const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);
      // setting the plan name in session storage for results page
      sessionStorage.setItem('currentSelectedPlan', searchCriteria.getPlanName().getSimpleText());
      if (this.viewPortWidth <= 992 && this.showTextField && flag) {
        this.landingPageService.setCachedSearchControlState(this.searchControls);
        this.router.navigate([FAD_CONSTANTS.urls.fadLandingPage]);
        sessionStorage.setItem('IsEditingSearch', 'true');
        return;
      }
      this.router.navigate([FAD_CONSTANTS.urls.fadSearchResultsPage]).finally(() => (this.isEditingForm = false));
      if (this.showTextField) {
        this.fadService.searchDataSource.next(Math.random());
      }
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
    } catch (exception) {}
  }

  showAllProdecuresOptionInSearchDropdown(useridin) {
    return (
      useridin !== '' &&
      useridin !== undefined &&
      this.userState !== this.constantsService['Inactive'] &&
      //Replaced sessionStorage.getItem('mleEligibility') with this.mleEligibility
      this.mleEligibility &&
      this.mleEligibility !== 'N'
    );
  }

  private initData() {
    this.userCurrentPlan = this.getDefaultPlanOption();

    this.isLogin = this.authToken != null;
    const useridin = this.useridin;
    this.defaultAutoCompleteSearchOption = [];
    if (this.isLogin) {
      this.defaultAutoCompleteSearchOption.push(
        new FadAutoCompleteOptionForSearchText()
          .setCategory(FAD_CONSTANTS.text.notSureWhatToSearch)
          .addOption(new FadAutoCompleteComplexOption().setLink(FAD_CONSTANTS.text.allSpecialities, '/fad/medical-index/specialities'))
      );

      this.userState = this.currentUserState;
      const planOption = new FadAutoCompleteOptionForSearchText();

      if (!this.fadInfo) {
        this.fadResolverService.getVitalsPlanInfo().subscribe(data => {
          this.fadInfo = data;
          this.fadInfo.networks.map(_network => {
            const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
            const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
            planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
            if (plan.getPlanIndicator()) {
              this.userCurrentPlan = plan;
            }
          });
        });
      }
      if (
        this.userType != null &&
        (this.userType.toLowerCase() === 'medicare' || this.userType.toLowerCase() === 'medex') &&
        this.mleIndicator !== 'N' &&
        this.getDefaultPlan()
      ) {
        this.isMedicareUser = true;
      }
      if (this.userType == null && this.scopeName !== 'REGISTERED-NOT-VERIFIED') {
        this.isRVRNVUser = true;
      }

      if (this.showAllProdecuresOptionInSearchDropdown(useridin) && !this.isMedicareUser && !this.isRVRNVUser) {
        this.defaultAutoCompleteSearchOption.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption().setLink(FAD_CONSTANTS.text.allProcedures, '/fad/medical-index/procedures')
          )
        );
      }
      if (!this.landingPageService.getCachedSearchControlState()) {
        const defaultObj = new FadAutoCompleteComplexOption()
          .setSimpleText(this.userCurrentPlan.getName())
          .setNetworkId(this.userCurrentPlan.getId());
        this.searchControls.planControl.setValue(defaultObj);
      }
    } else {
      this.defaultAutoCompleteSearchOption.push(
        new FadAutoCompleteOptionForSearchText()
          .setCategory(FAD_CONSTANTS.text.notSureWhatToSearch)
          .addOption(new FadAutoCompleteComplexOption().setLink(FAD_CONSTANTS.text.allSpecialities, '/fad/medical-index/specialities'))
      );
    }

    if (!this.landingPageService.cachedResponse) {
      this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();
      this.landingPageService.cachedResponse.userId = this.useridin;
    } else if (this.isUserIdChanged()) {
      this.isChangedUserFlag = true;
      this.clearCacheResponseOnUserIdChange();
    }
    this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;

    this.fetchDependentList();
  }

  public fetchProcedureSummary() {
    this.landingPageService.getProcedureSummary().subscribe();
  }

  public fetchDependentList() {
    if (this.isDependentsFetched) {
      return;
    }
    this.isDependentsFetched = true;
    const useridin = this.useridin;
    const currScope = this.scopeName ? this.scopeName : '';
    const memIdx = sessionStorage.getItem('selMemIdx');
    if (
      useridin !== '' &&
      useridin !== undefined &&
      this.landingPageService.cachedResponse &&
      !this.landingPageService.cachedResponse.dependantsList &&
      (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'AUTHENTICATED-NOT-VERIFIED')
    ) {
      //TODO: use ngxs store value here.
      this.dependantsList = JSON.parse(sessionStorage.getItem('dependantsList')) as FadMembersInfoModel[];
      if (this.dependantsList) {
        if (memIdx && memIdx !== '-1') {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      }
      if (sessionStorage.getItem('memberdisplayerrormessage')) {
        this.setServiceAlert(sessionStorage.getItem('memberdisplayerrormessage'), AlertType.Failure);
      } else if (this.dependantsList.length > 0) {
        this.displayDependentsOptionFlag = true;

        this.landingPageService.cachedResponse.dependantsList = this.dependantsList;
        if (memIdx && memIdx !== '-1') {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      }
    } else if (useridin !== '' && useridin !== undefined && useridin !== 'undefined' && useridin !== 'null') {
      this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
      this.displayDependentsOptionFlag = true;
      if (this.dependantsList) {
        if (memIdx && memIdx !== '-1') {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      }
    } else if (this.landingPageService.cachedResponse && this.landingPageService.cachedResponse.dependantsList) {
      this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
      this.displayDependentsOptionFlag = true;
      if (memIdx && memIdx !== '-1') {
        this.selectedMember = this.landingPageService.cachedResponse.dependantsList[memIdx];
        sessionStorage.setItem(
          'fadVendorMemberNumber',
          this.landingPageService.cachedResponse.dependantsList[memIdx].fadVendorMemberNumber
        );
      } else {
        this.selectedMember = this.landingPageService.cachedResponse.dependantsList[0];
        sessionStorage.setItem('fadVendorMemberNumber', this.landingPageService.cachedResponse.dependantsList[0].fadVendorMemberNumber);
      }
    }
    this.cdRef.detectChanges();
  }

  private clearCacheResponseOnUserIdChange() {
    this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();
    this.landingPageService.cachedResponse.userId = this.useridin;
    this.landingPageService.cachedResponse.planOptions = null;
    this.landingPageService.cachedResponse.zipCodeOptions = [];
    this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
    this.landingPageService.cachedResponse.setZipCodeOptions([]);
  }

  private isUserIdChanged(): boolean {
    return (
      this.landingPageService.cachedResponse &&
      this.landingPageService.cachedResponse.userId &&
      this.landingPageService.cachedResponse.userId !== this.useridin
    );
  }

  private enhancedSearchAfterInitData() {
    this.searchControls.zipCodeTypeAheadControl.valueChanges.subscribe(
      searchText => {
        if (searchText && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
          this.removeZipCodeError();
        }

        if (!searchText || (searchText && searchText.length < 3)) {
          return;
        }

        const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(searchText.trim());
        if (cachedZipCodeLookupOptions) {
          this.zipCodeOptions = cachedZipCodeLookupOptions;
          this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);
          // TODO: NEED TO UNSUBSCRIBE
          this.searchControls.zipCodeTypeAheadControl.valueChanges
            .pipe(
              startWith(''),
              delay(0),
              map(val => {
                const currentSelectedValue = val;
                this.filteredZipCodeOptions = of(
                  this.zipCodeOptions.filter(
                    option =>
                      option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                      option.zip.indexOf(currentSelectedValue) !== -1
                  )
                );
              })
            )
            .subscribe();

          return;
        }

        const zip_inSearchText = searchText ? searchText.split('-')[0].trim() : '';
        const regex = new RegExp(/(\d{5}) - (\w{1,}), (\w{2})/);
        const wholezipcode = searchText.match(regex);
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.place = wholezipcode ? '' : zip_inSearchText;
        vitalsZipCodeSearchRequest.page = 1;
        vitalsZipCodeSearchRequest.limit = this.viewPortWidth > 992 ? 10 : 6;
        if (wholezipcode && wholezipcode.length) {
          vitalsZipCodeSearchRequest.zip = wholezipcode[1] || '';
          vitalsZipCodeSearchRequest.city = wholezipcode[2] || '';
          vitalsZipCodeSearchRequest.state = wholezipcode[3] || '';
        }

        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(
          vitalsZipCodeResponse => {
            this.landingPageService.vitalsZipCodeInfo = vitalsZipCodeResponse;
            this.zipcodeResponseValidator();
            this.clearServiceAlert();

            if (vitalsZipCodeResponse.cities) {
              // remove zipcode error message if match found with response
              if (
                searchText &&
                searchText.length >= 3 &&
                vitalsZipCodeResponse.cities.length === 0 &&
                this.zipCodeValidationErrors.noMatchFound.exists === false
              ) {
                this.zipCodeValidationErrors.noMatchFound.display = false;
                this.zipCodeValidationErrors.invalidZipCode.display = false;
              }

              // display zipcode error message if no match found with response
              if (
                searchText &&
                searchText.length >= 3 &&
                this.zipCodeValidationErrors.invalidZipCode.exists === false &&
                vitalsZipCodeResponse.cities.length === 0 &&
                this.zipCodeValidationErrors.noMatchFound.exists === true
              ) {
                this.zipCodeValidationErrors.noMatchFound.display = true;
                this.zipCodeValidationErrors.invalidZipCode.display = false;
              }
            }
            // display error message if invalid zipcode exists like alphanumberic
            if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
              this.zipCodeValidationErrors.noMatchFound.display = false;
              this.zipCodeValidationErrors.invalidZipCode.display = true;
            }

            this.zipCodeOptions =
              vitalsZipCodeResponse && vitalsZipCodeResponse.cities ? (vitalsZipCodeResponse.cities as FZCSRCity[]) : ([] as FZCSRCity[]);

            this.fadSearchResultsService.setLastSelectedZipCodeOption(this.zipCodeOptions[0]);
            this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);
            const zipFrag = searchText ? searchText.trim().split(' - ') : '';
            if (zipFrag[0] && Number(zipFrag[0].trim())) {
              this.landingPageService.setCachedZipCodeLookupOptions(zipFrag[0].trim(), Object.assign([], this.zipCodeOptions));
            }

            this.searchControls.zipCodeTypeAheadControl.valueChanges
              .pipe(
                startWith(''),
                delay(0),
                map(val => {
                  const currentSelectedValue = val;

                  this.filteredZipCodeOptions = of(
                    this.zipCodeOptions.filter(
                      option =>
                        option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                        option.zip.indexOf(currentSelectedValue) !== -1
                    )
                  );
                })
              )
              .subscribe();
          },
          error => {}
        );
      },
      error => {}
    );

    // Start Handle Plan Option list data //
    if (!this.landingPageService.cachedResponse.planOptions) {
      const planOption = new FadAutoCompleteOptionForSearchText();
      if (this.fadInfo && this.fadInfo.result && this.fadInfo.result < 0) {
        this.setServiceAlert(this.fadInfo['displaymessage'], AlertType.Failure);

        return;
      } else if (this.fadInfo && this.fadInfo.networks) {
        this.clearServiceAlert();

        this.fadInfo.networks.map(_network => {
          const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
          const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
          planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
          if (plan.getPlanIndicator()) {
            this.userCurrentPlan = plan;
          }
        });
      } else {
        return;
      }

      this.planOptions.push(planOption);
      this.defaultPlanOptions = this.planOptions;
      this.landingPageService.cachedResponse.planOptions = this.planOptions;
    } else {
      this.planOptions = this.landingPageService.cachedResponse.planOptions;
      this.defaultPlanOptions = this.planOptions;
    }

    this.filteredPlanOptions = this.searchControls.planControl.valueChanges.pipe(
      startWith(''),
      delay(0),
      map(val => {
        try {
          if (this.planTypeAheadTrigger) {
            const currentSelectedValue = val ? val : this.planTypeAheadTrigger.el.value;

            let searchPlanText = '';

            if (typeof currentSelectedValue === 'object') {
              searchPlanText = currentSelectedValue.getSimpleText(); // || currentSelectedValue.getSimpleText();
            }
            return this.filterAutoCompletePlanOptions(searchPlanText);
          } else {
            return this.filterAutoCompletePlanOptions('');
          }
        } catch (exception) {}
      })
    );
    // End Handle Plan Option list data

    this.searchControls.planControl.valueChanges.pipe(debounceTime(this.debounceTime), distinctUntilChanged()).subscribe(searchText => {
      if (searchText && typeof searchText === 'object') {
        searchText = searchText.getSimpleText();
      }

      this.planOptions = this.defaultPlanOptions;

      this.filteredPlanOptions = this.searchControls.planControl.valueChanges.pipe(
        startWith(''),
        delay(0),
        map(val => {
          const searchPlanText = searchText !== '' ? searchText : this.planTypeAheadTrigger.el.value;
          return this.filterAutoCompletePlanOptions(searchPlanText);
        })
      );
    });

    // Karthik uncomment this for single search wait time strategy //
    this.searchControls.searchTypeAheadControl.valueChanges.pipe(debounceTime(this.debounceTime), distinctUntilChanged()).subscribe(
      searchText => {
        searchText = searchText && searchText.trim ? searchText.trim() : '';
        if (searchText && searchText.length > 2) {
          const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
          const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
          const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
            `${searchText}~${geoKey}`
          );
          if (cachedLookupOptions) {
            this.autoCompleteOptionsForSearchText = cachedLookupOptions;
            this.filteredAutoCompleteSearchOptions = of(this.filterAutoCompleteSearchOptions(searchText));
            return;
          }
          const vitalsAutoCompleteSearchRequest: GetSearchByProviderRequestModelInterface = new GetSearchByProviderRequestModel();

          let searchName = searchText;
          if (searchName && searchName.trim && searchName.trim().indexOf(FAD_CONSTANTS.text.allDoctorOptionText) >= 0) {
            searchName = searchName.replace(FAD_CONSTANTS.text.allDoctorOptionText, '').replace(/["']/g, '');
          } else if (searchName && searchName.trim && searchName.trim().indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) >= 0) {
            searchName = searchName.replace(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
          }

          const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();
          vitalsAutoCompleteSearchRequest
            .setSearchParameter(searchName)
            .setGeoLocation(selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '')
            .setNetworkId(
              this.fadSearchResultsService.getLastSelectedPlanOption()
                ? this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()
                : FAD_CONSTANTS.defaults.networkId
            )
            .setLimit(FAD_CONSTANTS.defaults.autoCompleteSearchRequest_limit);

          const authUserId = this.useridin;
          if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
            vitalsAutoCompleteSearchRequest.useridin = this.useridin;

            this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
            this.displayDependentsOptionFlag = true;
            vitalsAutoCompleteSearchRequest['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
          }

          this.landingPageService.getVitalsAutoCompleteSearchResponse(vitalsAutoCompleteSearchRequest).subscribe(
            response => {
              if (response.result && response.result < 0) {
                this.setServiceAlert(response['displaymessage'], AlertType.Failure);

                return;
              } else {
                this.clearServiceAlert();
              }

              this.autoCompleteOptionsForSearchText = [];
              const conditionList = new FadAutoCompleteOptionForSearchText().setCategory('');
              const doctorsList = new FadAutoCompleteOptionForSearchText().setCategory(
                `${FAD_CONSTANTS.text.allDoctorOptionText}"${searchText}"`
              );
              const facilityList = new FadAutoCompleteOptionForSearchText().setCategory(
                `${FAD_CONSTANTS.text.allHospitalsOrFacilitiesText}"${searchText}"`
              );

              if (response.searchSpecialties) {
                response.searchSpecialties.map(speciality => {
                  const conditionOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                  conditionOption
                    .setSimpleText(speciality.name)
                    .setProcedure(speciality.isProcedure)
                    .setDescriptionText(speciality.procedureDescription)
                    .setInfoText(FAD_CONSTANTS.text.speciality)
                    .setResourceTypeCode(speciality.resourceTypeCode as FadResourceTypeCode);

                  if (speciality.isProcedure === true) {
                    conditionOption.setProcedureId(speciality.id);
                  } else {
                    conditionOption.setSpecialityId(speciality.id);
                  }
                  conditionList.options.push(conditionOption);
                });
              }

              if (response.professionals) {
                response.professionals.map(professional => {
                  const doctorNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                  doctorNameOption
                    .setContextText(professional.name)
                    .setInfoText(professional.specialty)
                    .setNetworkId(professional.id)
                    .setLocationId(professional.locationId)
                    .setResourceTypeCode(FadResouceTypeCodeConfig.professional);
                  doctorsList.options.push(doctorNameOption);
                });
              }

              if (response.facilities) {
                response.facilities.map(facility => {
                  const facilityNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                  facilityNameOption
                    .setContextText(facility.name)
                    .setInfoText(facility.specialty)
                    .setNetworkId(facility.id)
                    .setLocationId(facility.locationId)
                    .setResourceTypeCode(FadResouceTypeCodeConfig.facility);
                  facilityList.options.push(facilityNameOption);
                });
              }

              if (conditionList.options.length) {
                this.autoCompleteOptionsForSearchText.push(conditionList);
              }

              if (doctorsList.options.length) {
                this.autoCompleteOptionsForSearchText.push(doctorsList);
              }

              if (facilityList.options.length) {
                this.autoCompleteOptionsForSearchText.push(facilityList);
              }
              if (this.autoCompleteOptionsForSearchText && this.autoCompleteOptionsForSearchText.length > 0) {
                this.landingPageService.setCachedSearchTextLookupOptions(
                  `${searchText}~${selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : ''}`,
                  Object.assign([], this.autoCompleteOptionsForSearchText)
                );
              }

              this.filteredAutoCompleteSearchOptions = of(this.filterAutoCompleteSearchOptions(searchText));
            },
            error => {},
            () => {
              this.landingPageService.showAutoCompleteDropDownSpinner = false;
            }
          );
        } else {
          this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;
          this.filteredAutoCompleteSearchOptions = of(this.filterAutoCompleteSearchOptions(searchText));
        }
      },
      error => {}
    );
  }

  private updateZipCodeFieldFromApplicationStorage() {
    if (this.zipCodeTypeAheadTrigger) {
      let cachedCityZip: FZCSRCity = new FZCSRCity();

      if (this.getLocalStorageZipCodeOption) {
        const zipCodeOptionInLocalStorage = Object.assign(Object.create(new FZCSRCity()), this.getLocalStorageZipCodeOption);
        let zipInLS = false;
        let cityInLS = false;
        let stateCodeInLS = false;
        if (zipCodeOptionInLocalStorage.zip && zipCodeOptionInLocalStorage.getZip()) {
          if (zipCodeOptionInLocalStorage.getZip().trim) {
            zipInLS = !!zipCodeOptionInLocalStorage.getZip().trim();
          }
        }

        if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
          if (zipCodeOptionInLocalStorage.getCity().trim) {
            cityInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
          }
        }

        if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
          if (zipCodeOptionInLocalStorage.getCity().trim) {
            stateCodeInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
          }
        }

        if (zipInLS && cityInLS && stateCodeInLS) {
          cachedCityZip = new FZCSRCity();
          cachedCityZip
            .setZip(this.getLocalStorageZipCodeOption.zip)
            .setCity(this.getLocalStorageZipCodeOption.city)
            .setState_code(this.getLocalStorageZipCodeOption.state_code)
            .setGeo(this.getLocalStorageZipCodeOption.geo); // '42.242921,-71.009972');
        }
      }

      if (cachedCityZip) {
        this.fadSearchResultsService.setLastSelectedZipCodeOption(cachedCityZip);
        const zipCodeText = cachedCityZip.getDisplayValue();
        this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
        this.zipCodeTypeAheadTrigger.el.value = zipCodeText;
        this.zipCodeOptions.push(cachedCityZip);
      }
    }
  }

  private filterAutoCompletePlanOptions(searchText: string): FadAutoCompleteOptionForSearchText[] {
    this.textToHighlightInPlanOption = searchText;

    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    if (searchText && searchText.trim && searchText.trim().length && searchText.trim().length > 0) {
      this.planOptions.map(autoCompleteOption => {
        const matchingOptionTexts = autoCompleteOption.options.filter(option => {
          return (
            option.getSimpleText &&
            option.getSimpleText() &&
            option
              .getSimpleText()
              .toLowerCase()
              .indexOf(searchText.toLowerCase()) !== -1
          );
        });

        const matchingOption: FadAutoCompleteOptionForSearchText = new FadAutoCompleteOptionForSearchText();
        matchingOption.category = autoCompleteOption.category;
        matchingOption.options = matchingOptionTexts.length ? matchingOptionTexts : autoCompleteOption.options;
        filteredOptions.push(matchingOption);
      });

      if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FAD_CONSTANTS.plans.myCurrentPlanOption)
              .setContextText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId())
          )
        );
      } else if (this.isAuthenticationRequired()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FAD_CONSTANTS.plans.dontKnowPlanOption)
              .setNetworkId(FAD_CONSTANTS.plans.dontKnowPlanOptionId)
          )
        );
      } else if (this.isAnonymousUser()) {
        filteredOptions.unshift(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption().setInfoText(FAD_CONSTANTS.plans.defaultOption)
          )
        );
      }
    } else {
      filteredOptions = this.pushDefaultAutoCompletePlanOption();
    }

    if (filteredOptions.length && filteredOptions[0].options.length) {
      const firstOption: FadAutoCompleteComplexOptionInterface = filteredOptions[0].options[0];
      if (!firstOption.getContextText() && !firstOption.getInfoText() && !firstOption.getSimpleText()) {
        filteredOptions.splice(0, 1);
      }
    }

    return filteredOptions;
  }

  public pushDefaultAutoCompletePlanOption(): FadAutoCompleteOptionForSearchTextInterface[] {
    const filteredOptions: FadAutoCompleteOptionForSearchText[] = [];

    const defaultPlanArrary = [
      FAD_CONSTANTS.plans.myCurrentPlanOption,
      FAD_CONSTANTS.plans.dontKnowPlanOption,
      FAD_CONSTANTS.plans.defaultOption
    ];

    if (
      this.landingPageService.getCachedSearchControlState() &&
      this.searchControls.planControl.value &&
      this.searchControls.planControl.value.profileId &&
      !defaultPlanArrary.includes(this.searchControls.planControl.value.infoText)
    ) {
      filteredOptions.push(new FadAutoCompleteOptionForSearchText().addOption(this.searchControls.planControl.value));
    }

    if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
      filteredOptions.push(
        new FadAutoCompleteOptionForSearchText().addOption(
          new FadAutoCompleteComplexOption()
            .setInfoText(FAD_CONSTANTS.plans.myCurrentPlanOption)
            .setContextText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId())
        )
      );
    } else if (this.isAuthenticationRequired()) {
      filteredOptions.push(
        new FadAutoCompleteOptionForSearchText().addOption(
          new FadAutoCompleteComplexOption()
            .setInfoText(FAD_CONSTANTS.plans.dontKnowPlanOption)
            .setNetworkId(FAD_CONSTANTS.plans.dontKnowPlanOptionId)
        )
      );
    }

    return filteredOptions;
  }

  private stripExtraAllText(category: string) {
    if (!category) {
      return category;
    }
    const allHospitalsOrFacilitiesRegex = new RegExp('"' + FAD_CONSTANTS.text.allHospitalsOrFacilitiesText + '(.+)"');
    const allDoctorsRegex = new RegExp('"' + FAD_CONSTANTS.text.allDoctorOptionText + '(.+)"');
    if (category.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText, 1) > 0) {
      return category.replace(allHospitalsOrFacilitiesRegex, '$1');
    } else if (category.indexOf(FAD_CONSTANTS.text.allDoctorOptionText, 1) >= 0) {
      return category.replace(allDoctorsRegex, '$1');
    } else {
      return category;
    }
  }

  private filterAutoCompleteSearchOptions(searchText: string): FadAutoCompleteOptionForSearchText[] {
    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];

    if (searchText && searchText.length > 2) {
      this.textToHighlightInSearchTextOption = searchText;
      this.autoCompleteOptionsForSearchText.map(autoCompleteOption => {
        if (
          autoCompleteOption.category ||
          (autoCompleteOption.category === '' && autoCompleteOption.options && autoCompleteOption.options.length > 0)
        ) {
          autoCompleteOption.category = this.stripExtraAllText(autoCompleteOption.category);
          filteredOptions.push(autoCompleteOption);
        } else {
          const matchingOptionTexts = autoCompleteOption.options.filter(option => {
            return (
              option
                .getSimpleText()
                .toLowerCase()
                .indexOf(searchText.toLowerCase()) !== -1
            );
          });

          if (matchingOptionTexts.length) {
            const matchingOption: FadAutoCompleteOptionForSearchText = new FadAutoCompleteOptionForSearchText();
            matchingOption.category = autoCompleteOption.category;
            matchingOption.options = matchingOptionTexts;

            filteredOptions.push(matchingOption);
          }
        }
      });
    }

    if (!filteredOptions.length) {
      filteredOptions = this.defaultAutoCompleteSearchOption;
    }

    return filteredOptions;
  }

  public displaySelectedPlanOptionName(state) {
    if (state) {
      return state.contextText || state.simpleText;
    }
  }

  public async selectAutoCompleteSearchTextOption(optionObj: FadAutoCompleteComplexOption) {
    let plannetworkFlag;
    const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
    const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;

    this.autoCompleteWarningFlag = zipCode && !plan;

    if (this.searchControls.planControl.value === 'undefined' || this.searchControls.planControl.value === undefined) {
      plannetworkFlag = false;
      this.planValidationErrors.invalidPlan.display = true;
    } else {
      plannetworkFlag = true;
    }
    const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);

    searchCriteria.setSearchText(optionObj);
    this.fadSearchResultsService.setLastSelectedSearchTextOption(optionObj);
    this.fadSearchResultsService.setSearchCriteria(searchCriteria);

    if (
      this.searchControls.zipCodeTypeAheadControl.value &&
      this.searchControls.zipCodeTypeAheadControl.value.trim() &&
      this.searchControls.planControl.value &&
      plannetworkFlag
    ) {
      if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.professional) {
        const getDoctorProfileRequest: DoctorProfileSearchRequestModelInterface = new DoctorProfileSearchRequestModel();
        const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();

        getDoctorProfileRequest.professionalid = optionObj.getNetworkId().toString();
        getDoctorProfileRequest.geo_location = selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '';
        getDoctorProfileRequest.network_id = this.fadSearchResultsService.getLastSelectedPlanOption()
          ? this.fadSearchResultsService
              .getLastSelectedPlanOption()
              .getNetworkId()
              .toString()
          : '';
        getDoctorProfileRequest.locationId = optionObj.getLocationId().toString();

        this.doctorProfileService.doctorProfile = optionObj.getNetworkId();
        sessionStorage.setItem('professionalId', optionObj.getNetworkId().toString());
        sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
        this.router.navigate([FAD_CONSTANTS.urls.fadDoctorProfilePage]);
      } else if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.facility) {
        this.facilityProfileService.facilityProfile = optionObj.getNetworkId();
        sessionStorage.setItem('facilityProfileId', optionObj.getNetworkId().toString());

        sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
        this.router.navigate([FAD_CONSTANTS.urls.fadFacilityProfilePage]);
      }
    }
  }

  public searchTypeOptLableClickHandler(e) {
    const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
    const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;
    this.autoCompleteWarningFlag = zipCode && !plan;

    const optGroupParentElement: boolean = e.target.parentElement.classList.contains('clickable-label');
    this.isPageReload = false;
    if (optGroupParentElement) {
      if (this.viewPortWidth < 993) {
        this.emboseSearchTextFieldOnScreen(false);
      }

      if (e.target && e.target.innerText && e.target.innerText.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) === 0) {
        const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
        const searchTextOption = new FadAutoCompleteComplexOption();

        searchTextOption.setSimpleText(e.target.innerText.trim());
        searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);
        searchControlValues.setSearchText(searchTextOption);

        this.searchControls.setValues(searchControlValues);
        this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
        this.fadSearchResultsService.setSearchCriteria(searchControlValues);

        this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
        if (!this.isSearchButtonDisabled()) {
          this.searchControls.setValues(searchControlValues);
          this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
          this.doSearch();
        } else {
          this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
        }
      } else if (e.target && e.target.innerText && e.target.innerText.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) === 0) {
        const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

        const searchTextOption = new FadAutoCompleteComplexOption();
        searchTextOption.setSimpleText(e.target.innerText.trim());
        searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);
        searchControlValues.setSearchText(searchTextOption);
        this.fadSearchResultsService.setSearchCriteria(searchControlValues);
        this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
        if (!this.isSearchButtonDisabled()) {
          this.searchControls.setValues(searchControlValues);
          this.setPlanNameText(searchControlValues.getPlanName().getSimpleText());
          if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.doSearch();
          }
        } else {
          this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
        }
      } else {
        setTimeout(() => {
          if (!this.isSearchButtonDisabled()) {
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          }
        }, 100);
      }
    }
  }

  zipcodeValidator(zipText) {
    setTimeout(() => {
      this.zipcodeResponseValidator();
    }, 1000);
    const validZipCodeRegxp = /^(?:[\d\s-]+|[a-zA-Z\s-]+)$/; // alphanumeric validator
    this.zipCodeValidationErrors.invalidZipCode.exists =
      !zipText || (zipText && (zipText.trim() === '' || !validZipCodeRegxp.test(zipText)));
    if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
      this.zipCodeValidationErrors.invalidZipCode.display = true;
      this.zipCodeValidationErrors.noMatchFound.display = false;
    }
  }

  planValidator(planName) {
    // clean up
    this.planValidationErrors.noMatchFound.display = false;
    this.planValidationErrors.invalidPlan.display = false;

    if (!planName || !planName.trim || planName.trim().length === 0) {
      this.fadSearchResultsService.setLastSelectedPlanOption(null);
      this.planValidationErrors.invalidPlan.display = true;
    } else if (planName.trim().length > 0) {
      this.planValidationErrors.noMatchFound.display =
        this.planOptions.length === 0 ||
        !this.planOptions[0] ||
        !this.planOptions[0].options ||
        this.planOptions[0].options.length === 0 ||
        !this.planOptions[0].options.some(
          planOption =>
            planOption && planName && planOption.getSimpleText && planOption.getSimpleText().toUpperCase() === planName.toUpperCase().trim()
        );
    }
  }

  removeZipCodeError() {
    this.zipCodeValidationErrors.invalidZipCode.display = false;
    this.zipCodeValidationErrors.noMatchFound.display = false;
  }

  removePlanError() {
    this.planValidationErrors.invalidPlan.display = false;
    this.planValidationErrors.noMatchFound.display = false;
  }

  private zipcodeResponseValidator() {
    let searchText = this.searchControls.zipCodeTypeAheadControl.value;

    searchText = searchText && searchText.trim();
    if (searchText && searchText.length < 3) {
      return;
    }
    const zipFrag = searchText ? searchText.trim().split('-') : '';
    const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(
      zipFrag[0] ? zipFrag[0].trim() : ''
    );
    const alphaNumericRegex: RegExp = new RegExp(/^[a-z0-9]+$/i); // alpha numeric
    this.zipCodeValidationErrors.noMatchFound.exists = !!(
      searchText &&
      alphaNumericRegex.test(searchText) &&
      searchText.trim() !== '' &&
      (!cachedZipCodeLookupOptions || (cachedZipCodeLookupOptions && cachedZipCodeLookupOptions.length === 0))
    );

    if (
      alphaNumericRegex.test(searchText) &&
      cachedZipCodeLookupOptions === undefined &&
      this.zipCodeValidationErrors.noMatchFound.exists === undefined
    ) {
      this.zipCodeValidationErrors.noMatchFound.exists = true;
    }

    const cityFrag = zipFrag[1] ? zipFrag[1].trim().split(',') : '';
    if (cityFrag) {
      // it will compare each user input text with response to remove the error message
      const zipCodeOptionsIndex = this.zipCodeOptions.findIndex(
        x => x.zip === zipFrag[0].trim() && cityFrag[0] && cityFrag[1] && x.city === cityFrag[0] && x.state_code === cityFrag[1].trim()
      );
      if (zipCodeOptionsIndex !== -1) {
        this.zipCodeValidationErrors.invalidZipCode.exists = false;
        this.zipCodeValidationErrors.noMatchFound.exists = false;
        this.zipCodeValidationErrors.invalidZipCode.display = false;
        this.zipCodeValidationErrors.noMatchFound.display = false;
      }
    }

    // if user input is not present in cached lookup zipcode options then it will display no match found error message
    if (
      searchText &&
      searchText.length >= 3 &&
      cachedZipCodeLookupOptions &&
      cachedZipCodeLookupOptions.length === 0 &&
      this.zipCodeValidationErrors.invalidZipCode.exists === false &&
      this.zipCodeValidationErrors.noMatchFound.exists === true
    ) {
      this.zipCodeValidationErrors.noMatchFound.display = true;
      this.zipCodeValidationErrors.invalidZipCode.display = false;
    }
  }

  private hiddenSearchTypeAheadDropDown(): void {
    if (this.viewPortWidth < 993) {
      this.emboseSearchTextFieldOnScreen(false);
    }
  }

  private setServiceAlert(title, type = AlertType.Failure): void {
    this.fadService.setServiceAlert(title, type, FAD_CONSTANTS.components.fadLandingPageComponent);
    this.hiddenSearchTypeAheadDropDown();
  }

  private clearServiceAlert(view = FAD_CONSTANTS.flags.allView): void {
    switch (view) {
      case FAD_CONSTANTS.flags.allView:
        this.fadService.clearServiceAlert(FAD_CONSTANTS.components.fadLandingPageComponent);
        break;
      case FAD_CONSTANTS.flags.mobileView:
        if (this.viewPortWidth < 993) {
          this.fadService.clearServiceAlert(FAD_CONSTANTS.components.fadLandingPageComponent);
        }
        break;
      default:
        break;
    }
  }

  public isAuthenticationRequired() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.scopeName;
      returnValue = scopeName !== 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {}
    return returnValue;
  }

  public isAnonymousUser() {
    let returnValue = false;
    try {
      const userid = this.useridin;
      returnValue = !(userid && userid !== 'undefined' && userid !== 'null');
    } catch (exception) {}
    return returnValue;
  }

  public isAuthenticatedUser() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.scopeName;
      returnValue = scopeName === 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {}
    return returnValue;
  }

  public noop(event?) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    return false;
  }

  public updateLastSelectedPlanOption() {
    if (this.planOptions && this.planOptions[0] && this.planOptions[0].options && this.planOptions[0].options.length > 0) {
      this.planOptions[0].options.some(planOption => {
        if (
          planOption &&
          planOption.getSimpleText &&
          this.searchControls.planControl.value &&
          this.searchControls.planControl.value.toUpperCase &&
          planOption.getSimpleText().toUpperCase() === this.searchControls.planControl.value.toUpperCase().trim()
        ) {
          this.fadSearchResultsService.setLastSelectedPlanOption(planOption as FadAutoCompleteComplexOption);
          return true;
        }
      });
    }
  }

  public isSearchButtonDisabled() {
    const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
    const userProvidedZipCode = this.searchControls.zipCodeTypeAheadControl.value;
    const userProvidedPlanControl = this.searchControls.planControl.value;

    const effectiveSearchText = userProvidedSearchText && userProvidedSearchText.trim ? userProvidedSearchText.trim() : null;
    const effectiveZipCode = userProvidedZipCode && userProvidedZipCode.trim ? userProvidedZipCode.trim() : null;
    let effectivePlanControl = null;
    if (userProvidedPlanControl) {
      if (userProvidedPlanControl.simpleText || userProvidedPlanControl.contextText) {
        effectivePlanControl = userProvidedPlanControl.simpleText.trim ? userProvidedPlanControl.simpleText.trim() : '';
        if (effectivePlanControl === '' && userProvidedPlanControl.contextText && userProvidedPlanControl.contextText.trim) {
          effectivePlanControl = userProvidedPlanControl.contextText.trim();
        }
      } else if (userProvidedPlanControl.trim) {
        effectivePlanControl = userProvidedPlanControl.trim();
      }
    }

    let validSearchText = effectiveSearchText && effectiveSearchText.length > 2;
    const zipCodeValue = this.searchControls.zipCodeTypeAheadControl.value;
    const zipCodeValueNotValid = !zipCodeValue || !zipCodeValue.trim || zipCodeValue.trim().length < 3;

    const errors: boolean =
      !!this.zipCodeValidationErrors.noMatchFound.display ||
      !!this.zipCodeValidationErrors.invalidZipCode.display ||
      !!this.planValidationErrors.noMatchFound.display ||
      !!this.planValidationErrors.invalidPlan.display ||
      zipCodeValueNotValid;

    return errors || !(validSearchText && !!effectiveZipCode && !!effectivePlanControl);
  }

  private stripAllDoctorFacilityTextAndUpdateUI(searchText: string): string {
    if (searchText && searchText.trim) {
      this.isPageReload = false;
      searchText = searchText.trim();
      if (searchText.indexOf(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText) >= 0) {
        searchText = searchText.replace(FAD_CONSTANTS.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');

        this.searchControls.searchTypeAheadControl.setValue(searchText);
        this.searchTextTypeAheadTrigger.el.value = searchText;
      } else if (searchText.indexOf(FAD_CONSTANTS.text.allDoctorOptionText) >= 0) {
        searchText = searchText.replace(FAD_CONSTANTS.text.allDoctorOptionText, '').replace(/["']/g, '');

        this.searchControls.searchTypeAheadControl.setValue(searchText);
        this.searchTextTypeAheadTrigger.el.value = searchText;
      }
    }
    return searchText;
  }

  public changeSelectedMember(event) {
    let chMemberId;
    chMemberId = event.target.value.fadVendorMemberNumber ? event.target.value.fadVendorMemberNumber : event.target.value;

    if (chMemberId) {
      const memberIndex = this.dependantsList
        .map(mem => {
          return mem.fadVendorMemberNumber;
        })
        .indexOf(chMemberId);
      this.selectedMember = this.dependantsList[memberIndex];
      sessionStorage.setItem('selMemIdx', memberIndex.toString());
      this.searchControls.dependantNameControl.setValue(chMemberId);
      if (this.showTextField) {
        this.fetchProcedureSummary();
        this.doSearch();
      }
    } else if (sessionStorage.getItem('selMemIdx')) {
      const memberIndex = sessionStorage.getItem('selMemIdx');
      this.selectedMember = this.dependantsList[memberIndex];

      if (this.showTextField) {
        this.fetchProcedureSummary();
        this.doSearch();
      }
    } else {
      chMemberId = this.dependantsList[0].fadVendorMemberNumber;

      const memberIndex = this.dependantsList
        .map(mem => {
          return mem.fadVendorMemberNumber;
        })
        .indexOf(chMemberId);
      this.selectedMember = this.dependantsList[memberIndex];
      sessionStorage.setItem('selMemIdx', memberIndex.toString());
      this.searchControls.dependantNameControl.setValue(chMemberId);
      if (this.showTextField) {
        this.fetchProcedureSummary();
        this.doSearch();
      }
    }
  }

  getSelectedUserName(memberId: any = ''): string {
    const selectedUser =
      this.dependantsList &&
      this.dependantsList.filter(res => {
        return res.fadVendorMemberNumber === (memberId.fadVendorMemberNumber || memberId);
      });

    return selectedUser && selectedUser.length === 1
      ? `${selectedUser[0].subscriberFirstName} ${selectedUser[0].subscriberLastName} (${selectedUser[0].relation})`
      : '';
  }
}
