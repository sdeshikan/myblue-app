import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FadFacilityCompareResolver implements Resolve<Observable<any[]>> {
  resolve() {
    return null;
  }
}
