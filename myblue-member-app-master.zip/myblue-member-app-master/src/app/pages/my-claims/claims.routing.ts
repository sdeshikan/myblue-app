import { Routes, RouterModule } from '@angular/router';
import { ClaimsPage } from './claims/claims.page';
import { ClaimDetailsPage } from './claim-details/claim-details.page';
import { ClaimStatusDetailsPage } from './claim-status-details/claim-status-details.page';

import { MyclaimsResolverService } from '../../shared/routeresolvers/myclaims-resolver.service';

const CLAIMS_APP_ROUTER: Routes = [
  {
    path: '',
    component: ClaimsPage,
    data: {
      pageTitle: 'My Claims'
    }
  },
  {
    // path: 'claimDetails/:id/:recordKey',
    path: 'claimdetails',
    component: ClaimDetailsPage,
    data: {
      pageTitle: 'Claim Detail',
      breadcrumb: 'Claim Details'
    }
  },
  {
    // path: 'claimStatusDetails/:id/:recordKey',
    path: ':detail/:claimstatusdetails',
    component: ClaimStatusDetailsPage,
    data: {
      pageTitle: 'Claim Status Detail',
      breadcrumb: 'Claim Status Detail'
    }
  }
];

export const ClaimsAppRouter = RouterModule.forChild(CLAIMS_APP_ROUTER);
