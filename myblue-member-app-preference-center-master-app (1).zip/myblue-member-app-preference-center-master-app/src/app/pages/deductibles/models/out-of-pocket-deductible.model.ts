export interface OutOfPocketDeductibleModel {
  networkIndicatorForOutOfPocketMax: string;
  outOfPocketMax: number;
  oopMaxContributed: number;
  oopMaxRemainingToMeet: string;
  oopMaxLimitationContent: string;
  oopMaxExclusionExcep: string;
}
