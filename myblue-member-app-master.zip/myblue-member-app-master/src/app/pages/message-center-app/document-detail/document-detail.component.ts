import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { GetBenefitTextResponseModelInterface } from '../modals/interfaces/getBenefitText-models.interface';
import { MessageCenter_BenefitTextType } from '../modals/types/message-center.types';
import { DocumentDetailService } from './document-detail.service';
import { DocumentsService } from '../documents/documents.service';
import { SwrveService, SwrveEventNames } from './../../../shared/services/swrve.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-document-detail',
  templateUrl: './document-detail.component.html',
  styleUrls: ['./document-detail.component.scss']
})
export class DocumentDetailComponent implements OnInit {
  public benefitText: GetBenefitTextResponseModelInterface;
  public benefitTextType: MessageCenter_BenefitTextType;
  public benefitTypeText: string;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private documentDetailService: DocumentDetailService,
    private documentsService: DocumentsService,
    private location: Location,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames
  ) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.onBackPressed();
    });
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.AppScreen_MyInbox_BenefitLists_DocumentsDetails);
    this.benefitText = this.route.snapshot.data.benefitText;
    this.benefitTextType = this.documentDetailService.getBenefitTextType();
    if (this.benefitTextType === 0) {
      this.benefitTypeText = 'Eligibility Provisions';
    } else if (this.benefitTextType === 1) {
      this.benefitTypeText = 'Claims Filling Limit';
    } else if (this.benefitTextType === 2) {
      this.benefitTypeText = 'Coordination of Benefits';
    } else if (this.benefitTextType === 3) {
      this.benefitTypeText = 'Overall Plan Limitations & Exclusions';
    }
    // sessionStorage.getItem('MsgCenter_Doc_BenefitType') ? sessionStorage.getItem('MsgCenter_Doc_BenefitType')
    // sessionStorage.setItem('MsgCenter_Doc_BenefitType', this.benefitTypeText);
    this.benefitTypeText = this.benefitTypeText;
  }

  public onBackPressed(): void {
    this.location.back();
    // this.router.navigate(['../tabs/myInbox/documents/document-overall-view'], {replaceUrl: true});
  }
}
