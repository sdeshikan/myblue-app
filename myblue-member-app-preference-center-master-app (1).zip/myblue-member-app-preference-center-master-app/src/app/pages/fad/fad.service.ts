import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AlertService } from '../../shared/shared.module';
import { FAD_CONSTANTS } from './constants/fad.constants';

@Injectable()
export class FadService {
  public fadConstants = FAD_CONSTANTS;
  public searchDataSource = new BehaviorSubject<any>('');

  constructor(private alertService: AlertService, private router: Router) {}

  public setServiceAlert(title, type = AlertType.Failure, scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (JSON.stringify(errorList) === '{}' || errorList['component'] === '') {
      this.alertService.setAlert(title, '', type, scope);
    }
  }

  public clearServiceAlert(scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (errorList && errorList.hasOwnProperty(scope)) {
      this.resetServiceError();
    }
  }

  public resetServiceError(): void {
    this.alertService.resetErrorObject();
  }
  public reviewMyBenfits() {
    this.router.navigate([this.fadConstants.urls.reviewmybenfits]);
  }

  public requestWrittenEstimate() {
    this.router.navigate([this.fadConstants.urls.requestEstimateUrl]);
  }
}
