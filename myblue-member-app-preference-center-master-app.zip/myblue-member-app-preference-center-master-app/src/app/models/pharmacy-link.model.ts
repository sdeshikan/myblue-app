export class PharmacyLink {
  text: string;
  url: string;
}
