import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '../../../shared/services/alert.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadFacilityCompareComponent } from './fad-facility-compare.component';
import { FadFacilityCompareService } from './fad-facility-compare.service';
import { NgxMaskModule } from 'ngx-mask';

describe('FadFacilityCompareComponent', () => {
  let component: FadFacilityCompareComponent;
  let fixture: ComponentFixture<FadFacilityCompareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgxMaskModule.forRoot(), HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadFacilityCompareComponent],
      providers: [
        FadFacilityCompareService,
        BcbsmaHttpService,
        ConstantsService,
        FadSearchListService,
        FadBreadCrumbsService,
        AlertService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCompareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
