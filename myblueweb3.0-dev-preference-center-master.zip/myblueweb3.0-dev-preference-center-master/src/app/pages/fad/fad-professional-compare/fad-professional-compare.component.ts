import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadDoctorProfileRequestModel } from '../modals/fad-doctor-profile-details.model';
import { FadFacilityProfileRequestModel, FadFacilityResponseModel } from '../modals/fad-facility-profile-details.model';
import { FadDoctorProfileRequestModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { BreadCrumb } from '../utils/fad.utils';
import { FadProfessionalCompareService } from './fad-professional-compare.service';

declare let $: any;
@Component({
  selector: 'app-fad-professional-compare',
  templateUrl: './fad-professional-compare.component.html',
  styleUrls: ['./fad-professional-compare.component.scss']
})
export class FadProfessionalCompareComponent implements OnInit, OnDestroy {
  public fadConstants = FadConstants;
  public selectedFacilityID;
  public results;
  public selectedFacilityDetail = null;
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public costInfo;
  public awards;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public professionalCompareService: FadProfessionalCompareService,
    private fadSearchListService: FadSearchListService,
    private fadBreadCrumbService: FadBreadCrumbsService,
    private alertService: AlertService,
    private fadSearchResultsService: FadSearchResultsService,
    public authService: AuthService,
    private fadDoctorProfileService: FadDoctorProfileService,
    private authHttp: AuthHttp
  ) {}

  ngOnInit() {
    this.fadBreadCrumbService
      .addBreadCrumb(new BreadCrumb().setLabel('Search').setUrl('/fad/search-results'))
      .addBreadCrumb(new BreadCrumb().setLabel('Compare').setUrl('/fad/professional-compare'));
    try {
      // this.selectedFacilityID = this.fadSearchListService.getSelectedId();

      this.costInfo = this.professionalCompareService.getCostInfo();
      // this.facilityCompareService.getCompareTableDetail()
      //   .subscribe(response => {
      //     const resp = response;
      //     this.selectedFacilityDetail = resp.OutBodyFacility;

      //   });
      // if (this.route.snapshot.data.facilityCompareData && this.route.snapshot.data.facilityCompareData.result
      //   && this.route.snapshot.data.facilityCompareData.result < 0) {
      //   this.alertService.setAlert(this.route.snapshot.data.facilityCompareData.displaymessage, '', AlertType.Failure);
      // } else {
      //   this.selectedFacilityDetail = this.route.snapshot.data.facilityCompareData &&
      //     this.route.snapshot.data.facilityCompareData.OutBodyFacility;
      // }
      const original = this.professionalCompareService.getSearchResult();

      const result = [];

      Object.keys(original).map(function(key) {
        const firstLocation = original[key].locations[0];

        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });

          original[key].blueAwards = blueAwards;
          // if(blueAwards.length){
          // this.awards=[{"name":"Blue Distinctions","awardDetails":[]}];
          // blueAwards.forEach(award=>{
          // if(award.awardDetails.length){
          // award.awardDetails.forEach(awardDetail => {
          // this.awards[0].awardDetails.push(awardDetail);
          // original[key].blueAwards = this.awards;
          // });
          // }
          // });
          //}
        }

        result.push(original[key]);
        return result;
      });

      this.selectedFacilityDetail = original;
      setTimeout(() => {
        for (let i = 0; i < this.selectedFacilityDetail.length; i++) {
          this.getFacilityData(this.selectedFacilityDetail[i]);
          if (i == this.selectedFacilityDetail.length - 1) {
            $('ng4-loading-spinner .spinner').removeClass('visible');
          }
        }
      }, 500);

      //this.selectedFacilityDetail = this.facilityCompareService.getSearchResult();

      this.doctorStarRating = new StarRatingComponentInputModel();
      this.doctorStarRating.ratingInPercentage = 80;
      this.doctorStarRating.numberOfStars = 5;

      // this.doctorStarRating.ratingInPercentage = this.selectedFacilityDetail.professional.reviews.overall_rating;
      // this.doctorStarRating.numberOfStars = this.selectedFacilityDetail.professional.reviews.total_ratings;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.financialModule,
        FadConstants.components.fadFacilityCompareComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }

  getFacilityData(facilityoutput) {
    try {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const facilityProfileId = parseInt(facilityoutput.providerId.toString());
      // this.fadFacilityProfileService.facilityProfile;
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = facilityoutput.locations[0].id;
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadDoctorProfileRequestModelInterface = new FadDoctorProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setProfessional(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));

      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FadConstants.defaults.radius);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      this.fadDoctorProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {
        for (let i = 0; i < this.selectedFacilityDetail.length; i++) {
          if (this.selectedFacilityDetail[i].providerId == facilityoutput.providerId) {
            this.selectedFacilityDetail[i].acceptingNewPatients = data.locations[0].acceptingNewPatients;
          }
        }
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.onSearchListComponentInteraction
      );
    }
  }

  getDataOnSuccess(data) {
    this.results = data;
    this.selectedFacilityDetail = this.results.professionals.filter(professional => {
      return this.selectedFacilityID.indexOf(professional.id) !== -1;
    });
  }

  getCost(professionalId) {
    if (this.costInfo && this.costInfo[professionalId]) {
      return this.costInfo[professionalId];
    }
    return null;
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  // Remove from the compare table
  // In case only last one remains redirect to search results
  public removeFacility(idx: number) {
    if (this.selectedFacilityDetail.length == 1) {
      this.router.navigate([`/fad/search-results`]);
    }
    this.selectedFacilityDetail.splice(idx, 1);
  }

  // Move to Doctor's Profile Page
  public goToFacilityProfilePage(professional) {
    sessionStorage.setItem('locationId', professional.locations[0].id);
    sessionStorage.setItem('professionalId', professional.providerId);
    this.router.navigate(['/fad/doctor-profile']);
  }

  public goBackToSearchListPage() {
    this.router.navigate([`/fad/search-results`]);
  }

  getRating(ratings, totalReviews) {
    this.doctorStarRating = new StarRatingComponentInputModel();

    this.doctorStarRating.totalRatings = parseFloat(!totalReviews ? 0 : totalReviews);
    this.doctorStarRating.overAllRating = parseFloat(!ratings ? 0 : ratings);
    return this.doctorStarRating;
  }

  ngOnDestroy(): void {
    this.alertService.clearError();
  }
}
