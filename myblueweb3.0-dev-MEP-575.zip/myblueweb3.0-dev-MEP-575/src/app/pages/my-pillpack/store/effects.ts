import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { MyPillpackService } from '../../../shared/services/mypillpack/my-pillpack.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { DependentRecentRxRequestModel } from '../../medications/models/dependant-recent-rx.model';
import { DependentRecentRxRequestModelInterface } from '../../medications/models/interfaces/dependant-recent-rx-model.interface';
import { UpdateMedications } from './actions';
import * as ActionTypes from './actionTypes';
import { State } from './reducer';

@Injectable()
export class PillpackEffects {
  getMemberInfo(medications) {
    return {
      firstName: this.authService.authToken.firstName,
      lastName: '',
      medications
    };
  }

  @Effect()
  loadMedications$ = this.actions$.pipe(
    ofType(ActionTypes.LOAD_MEDICATIONS),
    // switchMap(() => this._myPillpackService.getDependents()),
    mergeMap(() =>
      this._myPillpackService.getMedicationsForSelf().pipe(
        map(medications => {
          return new UpdateMedications(medications);
        }),
        catchError(() => Observable.of(new UpdateMedications([])))
      )
    )
  );

  constructor(
    private actions$: Actions,
    private _myPillpackService: MyPillpackService,
    private http: AuthHttp,
    private constants: ConstantsService,
    private authService: AuthService,
    private store: Store<State>
  ) {}
}
