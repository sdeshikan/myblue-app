import {
  ApplicationRef,
  ChangeDetectorRef,
  Component,
  ComponentFactoryResolver,
  ElementRef,
  EventEmitter,
  HostListener,
  Injector,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { FadProfileCardComponentInputModel } from '../modals/fad-profile-card.modal';
import { FadSearchListComponentOutputModel } from '../modals/fad-search-list.modal';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import {
  FadSearchListComponentInputModelInterface,
  FadSearchListComponentOutputModelInterface
} from '../modals/interfaces/fad-search-list.interface';
import { FadZipCodeSearchResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { FadNoSearchResultsPageConsumer, FadProfileCardConsumer } from '../modals/interfaces/fad.interface';
import { FadSearchListService } from './fad-search-list.service';

import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadProfileCardComponentOutputModelInterface } from '../modals/interfaces/fad-profile-card.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

import { Router } from '@angular/router';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import {
  FadProfessionalInterface,
  GetSearchByProfessionalResponseModelInterface
} from '../modals/interfaces/getSearchByProfessional-models.interface';

@Component({
  selector: 'app-fad-search-list',
  templateUrl: './fad-search-list.component.html',
  styleUrls: ['./fad-search-list.component.scss']
})
export class FadSearchListComponent implements OnInit, OnChanges, FadNoSearchResultsPageConsumer, FadProfileCardConsumer {
  @Output() componentOutput: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<
    FadSearchListComponentOutputModel
  >();

  @Output() clearFilter: EventEmitter<FadSearchListComponentOutputModelInterface> = new EventEmitter<FadSearchListComponentOutputModel>();

  @Input() componentInput: FadSearchListComponentInputModelInterface;

  @ViewChild('profileCardList') profileCardList: ElementRef;

  public isDisplayBanner = false;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public searchResponse: GetSearchByProfessionalResponseModelInterface;
  public professionalsList: FadProfessionalInterface[] = null;
  public selectedProfessionals: FadProfessionalInterface[] = [];
  private maxSelectionAllowed = 5;
  private cachedAllZipCodeInfo: FadZipCodeSearchResponseModelInterface;
  public list: number[] = [];
  isFilterChanged: boolean;

  constructor(
    private router: Router,
    private fadSearchListService: FadSearchListService,
    private resolver: ComponentFactoryResolver,
    private fadProfessionalCompareService: FadProfessionalCompareService,
    private injector: Injector,
    private appRef: ApplicationRef,
    private fadSearchResultsService: FadSearchResultsService,
    private landingPageService: FadLandingPageService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.professional;
  }

  // Show banner section on window scroll to clear and delete message listing
  @HostListener('window:scroll', ['$event'])
  showBannerOnWindowScroll($event) {
    const fadSearchListPos = this.el.nativeElement.offsetTop;
    const windowScrollPos = window.pageYOffset;
    this.isDisplayBanner = windowScrollPos > fadSearchListPos;
  }

  ngOnInit() {
    this.cachedAllZipCodeInfo = this.landingPageService.vitalsZipCodeInfo;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      this.componentInput = Object.assign({}, changes.componentInput.currentValue);
      this.isFilterChanged = this.fadSearchResultsService.filterChanged;
      if (this.componentInput) {
        this.searchResponse = this.componentInput.searchResults;
        if (this.searchResponse) {
          if (this.fadSearchListService.isFilterChangedFlag === true) {
            this.fadSearchListService.isFilterChangedFlag = false;

            this.clearProfileSelections();
          }
          if (this.fadProfessionalCompareService.getSearchResult() == null) {
            this.clearProfileSelections();
          }

          console.log(this.searchResponse.professionals);
          this.professionalsList = this.searchResponse.professionals;
          const disableFurtherSelection =
            this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed ? true : false;
          this.professionalsList = this.professionalsList.map(item => ({
            ...item,
            isDisabled: item.isChecked ? false : disableFurtherSelection
          }));
          this.isNoSearchResults = false;
        } else {
          this.isNoSearchResults = true;
        }
        this.cdRef.detectChanges();
      }
    }
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(professional: FadProfessionalInterface): FadProfileCardComponentInputModel {
    return new FadProfileCardComponentInputModel(professional);
  }

  public onSearchListComponentInteraction(event) {
    console.log(event);
    this.clearFilter.emit(event);
  }
  public onProfileCardComponentInteraction(profileCardCompOutput: FadProfileCardComponentOutputModelInterface) {
    const index = this.professionalsList.findIndex(item => item.providerId === profileCardCompOutput.professional.providerId);
    const selectedItem = this.professionalsList[index];
    selectedItem.isChecked = profileCardCompOutput.isSelected;
    this.selectedProfessionals = this.professionalsList.filter(item => item.isChecked);
    const fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection = this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed;
    this.professionalsList = this.professionalsList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });
    console.log(this.selectedProfessionals);
    this.fadProfessionalCompareService.setSearchResult(this.selectedProfessionals);
    console.log(fadSeachListComponentOutput);
    this.componentOutput.emit({ fadSeachListComponentOutput, index, isChecked: profileCardCompOutput.isSelected });
  }

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList !== undefined) {
      const checkBoxList: NodeListOf<Element> = this.profileCardList.nativeElement.querySelectorAll('[type="checkbox"]');
      Array.from(checkBoxList).forEach(checkBox => {
        const chkBox = checkBox as HTMLInputElement;
        chkBox.removeAttribute('checked');
        chkBox.checked = false;
      });
    }
  }
}
