import {} from 'jasmine';

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FadDoctorProfileComponent } from './fad-doctor-profile.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PhoneNumberPipe } from '../../../shared/pipes/phone/phoneNumber.pipe';
import { PhonePipe } from '../../../shared/pipes/phone/phone.pipe';
import { FadDoctorProfileService } from './fad-doctor-profile.service';
import { AuthHttp } from '../../../shared/services/authHttp.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '../../../shared/services/auth.service';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { AlertService } from '../../../shared/services/alert.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadService } from '../fad.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { PopoverController } from '@ionic/angular';

describe('FadDoctorProfileComponent', () => {
  let component: FadDoctorProfileComponent;
  let fixture: ComponentFixture<FadDoctorProfileComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([])],
      declarations: [FadDoctorProfileComponent, PhoneNumberPipe, PhonePipe],
      providers: [
        FadDoctorProfileService,
        AuthHttp,
        AuthService,
        ConstantsService,
        AlertService,
        FadSearchResultsService,
        FadBreadCrumbsService,
        FadService,
        FadCostBreakdownService,
        BcbsmaHttpService,
        FadFacilityProfileService,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadDoctorProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
