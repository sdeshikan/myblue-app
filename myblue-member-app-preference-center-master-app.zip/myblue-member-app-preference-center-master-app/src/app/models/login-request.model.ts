export interface LoginRequest {
  useridin: string;
  passwordin: string;
}
