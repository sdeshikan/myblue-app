import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../shared/services/constants.service';
import { FadFacilityCardComponent } from '../fad-facility-card/fad-facility-card.component';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { NgxMaskModule } from 'ngx-mask';

describe('FadProviderFacilityCardComponent', () => {
  let component: FadFacilityCardComponent;
  let fixture: ComponentFixture<FadFacilityCardComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxMaskModule.forRoot(), NgxsModule.forRoot([])],
      declarations: [FadFacilityCardComponent],
      providers: [
        FadSearchResultsService,
        ConstantsService,
        FadFacilityProfileService,
        CallNumber,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
